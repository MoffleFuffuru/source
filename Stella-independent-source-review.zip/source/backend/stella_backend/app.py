from __future__ import annotations

import hmac
import os
import threading
import time
from collections import defaultdict, deque
from pathlib import Path
from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

from .store import AccountStore
from .pricing import default_pricebook


class Credentials(BaseModel):
    email: str = Field(min_length=3, max_length=254)
    password: str = Field(min_length=12, max_length=1024)


class CreditAdjustment(BaseModel):
    account_id: str = Field(min_length=36, max_length=36)
    bucket: str = Field(pattern="^(trial|purchased|bonus|subscription)$")
    delta: int = Field(ne=0, ge=-1_000_000_000, le=1_000_000_000)
    reason: str = Field(min_length=1, max_length=500)
    request_id: str | None = Field(default=None, max_length=100)


class AccountDeactivation(BaseModel):
    account_id: str = Field(min_length=36, max_length=36)
    reason: str = Field(default="Permanently deactivated by administrator", max_length=500)


ADMIN_HTML = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Stella Admin</title><style>
:root{color-scheme:dark;--bg:#141418;--panel:#23262d;--line:#393d48;--text:#f4eff2;--muted:#a8a2ab;--rose:#d986a7;--teal:#56d6d4}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at 78% 0,#2aa8a622,transparent 35%),var(--bg);color:var(--text);font:15px "Segoe UI",sans-serif}
main{max-width:1120px;margin:32px auto;padding:0 22px}.brand{display:flex;align-items:center;gap:14px;margin-bottom:28px}.mark{width:19px;height:19px;transform:rotate(45deg);border:2px solid var(--teal);box-shadow:0 0 16px #56d6d455}.brand h1{font-size:20px;letter-spacing:.16em;margin:0}.brand small{display:block;color:var(--muted);font-size:10px;letter-spacing:.12em;margin-top:5px}
.panel{background:linear-gradient(145deg,#23262df2,#1b1d22f2);border:1px solid var(--line);border-radius:14px;padding:20px;margin:14px 0;box-shadow:0 18px 40px #0003}.row{display:flex;gap:10px;align-items:end;flex-wrap:wrap}label{display:grid;gap:6px;color:var(--muted);font-size:12px;flex:1;min-width:170px}input,select,button{font:inherit;color:var(--text);background:#141418;border:1px solid #424650;border-radius:8px;padding:10px}input:focus,select:focus{outline:1px solid var(--teal)}button{cursor:pointer;background:#633950;border-color:var(--rose);font-weight:600}button:hover{filter:brightness(1.13)}h2{font-size:15px;margin:0 0 16px}table{width:100%;border-collapse:collapse;margin-top:14px}th,td{text-align:left;padding:11px 8px;border-bottom:1px solid #343841}th{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.09em}td{font-size:13px}.mono{font:12px Consolas,monospace;overflow-wrap:anywhere}.status{color:var(--teal);min-height:20px;margin:8px 0}.muted{color:var(--muted)}.danger{color:#ff98a7}.tiny{font-size:11px}.top{display:flex;justify-content:space-between;align-items:center;gap:12px}.trial{color:var(--teal);font-weight:600}
</style></head><body><main><div class="brand"><span class="mark"></span><div><h1>STELLA</h1><small>ADMINISTRATION · LOCAL TEST SERVICE</small></div></div>
<section class="panel"><div class="top"><div><h2>Account directory</h2><div class="muted tiny">Search by Account ID or email. Credit adjustments are written to an immutable ledger and audit log.</div></div><label style="max-width:230px">Admin access key<input id="key" type="password" autocomplete="off" placeholder="From STELLA_ADMIN_TOKEN"></label></div>
<div class="row" style="margin-top:15px"><label>Search accounts<input id="search" placeholder="Account ID or email"></label><button id="searchBtn">Search</button><button id="reloadBtn" style="background:#22252c;border-color:#4b535e">Refresh</button></div><div id="status" class="status" role="status"></div><div style="overflow:auto"><table><thead><tr><th>Account</th><th>Email</th><th>Status</th><th>Created</th><th>Trial</th><th>Purchased</th><th>Bonus</th><th>Subscription</th><th>Total</th><th>Access</th></tr></thead><tbody id="accounts"></tbody></table></div></section>
<section class="panel"><h2>Grant or remove credits</h2><form id="adjust" class="row"><label>Account ID<input id="account" required minlength="36" maxlength="36"></label><label>Credit bucket<select id="bucket"><option value="trial">Trial</option><option value="purchased">Purchased</option><option value="bonus">Promotional bonus</option><option value="subscription">Subscription allowance</option></select></label><label>Change amount<input id="delta" type="number" required min="-1000000000" max="1000000000" placeholder="50 grant / -10 remove"></label><label>Reason<input id="reason" required maxlength="500" placeholder="Support adjustment reason"></label><button type="submit">Apply adjustment</button></form><p class="muted tiny">Negative changes are refused if they would make the selected bucket negative. Every change is attributed to the authenticated admin and is idempotent.</p></section>
<section class="panel"><h2>Recent admin audit</h2><div style="overflow:auto"><table><thead><tr><th>Time (UTC)</th><th>Actor</th><th>Action</th><th>Account</th><th>Details</th></tr></thead><tbody id="audit"></tbody></table></div></section>
<section class="panel"><h2>Recent provider usage</h2><div class="muted tiny">Provider cost and charged credits are recorded separately for margin analysis.</div><div style="overflow:auto"><table><thead><tr><th>Time</th><th>Account</th><th>Provider / model</th><th>Input / output</th><th>Voice chars</th><th>Provider cost</th><th>Credits</th><th>Latency</th><th>Status</th></tr></thead><tbody id="usage"></tbody></table></div></section>
</main><script>
const $=id=>document.getElementById(id), headers=()=>({'X-Stella-Admin-Key':$('key').value,'Content-Type':'application/json'});
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function api(path,options={}){const r=await fetch(path,{...options,headers:{...headers(),...(options.headers||{})}});const d=await r.json();if(!r.ok)throw Error(d.detail||d.error||`Request failed (${r.status})`);return d}
function msg(s,bad=false){$('status').textContent=s;$('status').className='status'+(bad?' danger':'')}
let adjustmentRequestId=crypto.randomUUID();
async function load(){try{const data=await api('/admin/api/accounts?q='+encodeURIComponent($('search').value));$('accounts').innerHTML=data.accounts.map(a=>`<tr data-id="${esc(a.account_id)}"><td class="mono">${esc(a.account_id)}</td><td>${esc(a.email)}</td><td>${esc(a.status)}</td><td>${esc(new Date(a.created_at).toLocaleString())}</td><td>${a.credits.trial}</td><td>${a.credits.purchased}</td><td>${a.credits.bonus}</td><td>${a.credits.subscription}</td><td class="trial">${a.credits.total}</td><td>${a.status==='active'?`<button class="danger" data-deactivate="${esc(a.account_id)}">Deactivate</button>`:'<span class="muted">Disabled</span>'}</td></tr>`).join('')||'<tr><td colspan="10" class="muted">No accounts found</td></tr>';for(const tr of $('accounts').querySelectorAll('tr[data-id]'))tr.onclick=()=>{$('account').value=tr.dataset.id};for(const button of $('accounts').querySelectorAll('[data-deactivate]'))button.onclick=async event=>{event.stopPropagation();const id=button.dataset.deactivate;if(!confirm('Permanently deactivate this account? All signed-in sessions will be revoked. This cannot be undone.'))return;try{await api('/admin/api/accounts/deactivate',{method:'POST',body:JSON.stringify({account_id:id})});msg('Account permanently deactivated; all sessions revoked.');await load()}catch(error){msg(error.message,true)}};const aud=await api('/admin/api/audit');$('audit').innerHTML=aud.events.map(e=>`<tr><td>${esc(new Date(e.created_at).toLocaleString())}</td><td>${esc(e.actor)}</td><td>${esc(e.action)}</td><td class="mono">${esc(e.account_id||'')}</td><td class="mono">${esc(JSON.stringify(e.details))}</td></tr>`).join('')||'<tr><td colspan="5" class="muted">No audited actions yet</td></tr>';const usage=await api('/admin/api/usage');$('usage').innerHTML=usage.events.map(e=>`<tr><td>${esc(new Date(e.created_at).toLocaleString())}</td><td class="mono">${esc(e.account_id)}</td><td>${esc(e.provider)} · ${esc(e.model)}</td><td>${e.input_tokens} / ${e.output_tokens}</td><td>${e.audio_characters}</td><td>$${Number(e.provider_cost_usd).toFixed(5)}</td><td>${e.credit_charge}</td><td>${e.latency_ms} ms</td><td>${esc(e.status)}</td></tr>`).join('')||'<tr><td colspan="9" class="muted">No provider usage recorded yet</td></tr>';msg(`${data.accounts.length} account(s) loaded.`)}catch(e){msg(e.message,true)}}
$('searchBtn').onclick=load;$('reloadBtn').onclick=load;$('search').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();load()}};
$('adjust').onsubmit=async e=>{e.preventDefault();try{const d=await api('/admin/api/credits/adjust',{method:'POST',body:JSON.stringify({account_id:$('account').value,bucket:$('bucket').value,delta:Number($('delta').value),reason:$('reason').value,request_id:adjustmentRequestId})});adjustmentRequestId=crypto.randomUUID();msg(`Adjustment recorded. New total: ${d.credits.total} credits.`);$('delta').value='';$('reason').value='';await load()}catch(err){msg(err.message,true)}};
</script></body></html>"""


def create_app(*, db_path: Path | None = None, trial_credits: int | None = None,
               admin_token: str | None = None) -> FastAPI:
    root = Path(__file__).resolve().parents[1]
    path = db_path or Path(os.environ.get("STELLA_BACKEND_DB", root / "data" / "accounts.sqlite3"))
    grant = trial_credits if trial_credits is not None else int(os.environ.get("STELLA_TRIAL_CREDITS", "50"))
    secret = admin_token if admin_token is not None else os.environ.get("STELLA_ADMIN_TOKEN", "")
    store = AccountStore(path, grant)
    app = FastAPI(title="Stella Account Service", version="0.1.0", docs_url=None, redoc_url=None)
    app.state.store = store
    app.state.admin_token = secret
    app.state.pricebook = default_pricebook()
    app.state.login_attempts = defaultdict(deque)
    app.state.login_lock = threading.Lock()

    def current_account(authorization: str | None = Header(default=None)) -> dict:
        scheme, _, token = (authorization or "").partition(" ")
        account = store.authenticate(token) if scheme.casefold() == "bearer" else None
        if account is None:
            raise HTTPException(401, "Sign in to continue")
        return account

    def require_admin(x_stella_admin_key: str | None = Header(default=None)) -> str:
        configured = app.state.admin_token
        if not configured:
            raise HTTPException(503, "Admin dashboard is disabled until STELLA_ADMIN_TOKEN is configured")
        if not x_stella_admin_key or not hmac.compare_digest(x_stella_admin_key, configured):
            raise HTTPException(401, "Admin authentication failed")
        return "admin"

    def limit_auth(request: Request) -> None:
        now = time.monotonic()
        ip = request.client.host if request.client else "unknown"
        with app.state.login_lock:
            events = app.state.login_attempts[ip]
            while events and now - events[0] > 60:
                events.popleft()
            if len(events) >= 12:
                raise HTTPException(429, "Too many sign-in attempts. Try again in a minute.")
            events.append(now)

    @app.get("/health")
    def health() -> dict:
        return {"ok": True, "service": "stella-account-service", "mode": os.environ.get("STELLA_ENV", "local-test")}

    @app.post("/api/v1/auth/register", status_code=201)
    def register(body: Credentials, request: Request) -> dict:
        limit_auth(request)
        try:
            account, token = store.register(body.email, body.password)
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc
        except Exception as exc:
            if "UNIQUE constraint failed" in str(exc):
                raise HTTPException(409, "An account with that email already exists") from exc
            raise
        return {"account": account, "access_token": token, "token_type": "bearer", "expires_in": 30 * 86400}

    @app.post("/api/v1/auth/login")
    def login(body: Credentials, request: Request) -> dict:
        limit_auth(request)
        result = store.login(body.email, body.password)
        if result is None:
            raise HTTPException(401, "Email or password is incorrect")
        account, token = result
        return {"account": account, "access_token": token, "token_type": "bearer", "expires_in": 30 * 86400}

    @app.post("/api/v1/auth/logout", status_code=204)
    def logout(account: dict = Depends(current_account),
               authorization: str | None = Header(default=None)) -> None:
        del account
        _, _, token = (authorization or "").partition(" ")
        store.logout(token)

    @app.get("/api/v1/account")
    def account(account: dict = Depends(current_account)) -> dict:
        return store.account(account["account_id"])

    @app.get("/api/v1/credits")
    def credits(account: dict = Depends(current_account)) -> dict:
        return store.account(account["account_id"])["credits"]

    @app.get("/api/v1/usage")
    def usage(account: dict = Depends(current_account), limit: int = 12) -> dict:
        return store.usage_summary(account["account_id"], limit)

    @app.get("/api/v1/usage/quote")
    def usage_quote(account: dict = Depends(current_account), input_tokens: int = 0,
                    output_tokens: int = 0, tts_characters: int = 0,
                    stt_seconds: float = 0, keyterms_enabled: bool = False) -> dict:
        del account
        values = (input_tokens, output_tokens, tts_characters)
        if any(value < 0 or value > 2_000_000 for value in values) or not 0 <= stt_seconds <= 86400:
            raise HTTPException(400, "Usage estimate is outside supported bounds")
        return app.state.pricebook.quote(input_tokens=input_tokens, output_tokens=output_tokens,
            tts_characters=tts_characters, stt_seconds=stt_seconds,
            keyterms_enabled=keyterms_enabled)

    @app.get("/admin", response_class=HTMLResponse)
    def admin_page() -> str:
        return ADMIN_HTML

    @app.get("/admin/api/accounts", dependencies=[Depends(require_admin)])
    def admin_accounts(q: str = "", limit: int = 100) -> dict:
        return {"accounts": store.list_accounts(q, limit)}

    @app.post("/admin/api/accounts/deactivate", dependencies=[Depends(require_admin)])
    def admin_deactivate(body: AccountDeactivation) -> dict:
        try:
            return store.permanently_deactivate(account_id=body.account_id,
                actor="dashboard-admin", reason=body.reason)
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc

    @app.post("/admin/api/credits/adjust", dependencies=[Depends(require_admin)])
    def admin_adjust(body: CreditAdjustment) -> dict:
        try:
            return store.adjust_credits(account_id=body.account_id, bucket=body.bucket,
                delta=body.delta, actor="dashboard-admin", reason=body.reason,
                request_id=body.request_id)
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc
        except Exception as exc:
            if "UNIQUE constraint failed" in str(exc):
                raise HTTPException(409, "This adjustment request was already applied") from exc
            raise

    @app.get("/admin/api/audit", dependencies=[Depends(require_admin)])
    def admin_audit(limit: int = 100) -> dict:
        return {"events": store.audit(limit)}

    @app.get("/admin/api/usage", dependencies=[Depends(require_admin)])
    def admin_usage(limit: int = 100) -> dict:
        with store.connect() as db:
            rows = db.execute("""SELECT event_id,account_id,request_id,provider,model,input_tokens,
                output_tokens,audio_characters,provider_cost_usd,credit_charge,latency_ms,status,created_at
                FROM usage_events ORDER BY created_at DESC LIMIT ?""", (min(500, max(1, limit)),)).fetchall()
        return {"events": [dict(row) for row in rows]}

    return app


