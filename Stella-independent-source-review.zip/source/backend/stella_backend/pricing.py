from __future__ import annotations

import math
import os
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class PriceBook:
    cerebras_input_usd_per_million: float = 0.99
    cerebras_output_usd_per_million: float = 1.49
    eleven_tts_usd_per_thousand_characters: float = 0.04
    eleven_stt_usd_per_hour: float = 0.39
    eleven_stt_keyterm_multiplier: float = 1.20
    credits_per_usd: int = 100
    target_revenue_cost_multiple: float = 7.0

    @classmethod
    def from_environment(cls) -> "PriceBook":
        return cls(
            cerebras_input_usd_per_million=float(os.environ.get("STELLA_CEREBRAS_INPUT_USD_PER_M", "0.99")),
            cerebras_output_usd_per_million=float(os.environ.get("STELLA_CEREBRAS_OUTPUT_USD_PER_M", "1.49")),
            eleven_tts_usd_per_thousand_characters=float(os.environ.get("STELLA_ELEVEN_TTS_USD_PER_1K", "0.04")),
            eleven_stt_usd_per_hour=float(os.environ.get("STELLA_ELEVEN_STT_USD_PER_HOUR", "0.39")),
            eleven_stt_keyterm_multiplier=float(os.environ.get("STELLA_ELEVEN_STT_KEYTERM_MULTIPLIER", "1.20")),
            credits_per_usd=int(os.environ.get("STELLA_CREDITS_PER_USD", "100")),
            target_revenue_cost_multiple=float(os.environ.get("STELLA_TARGET_COST_MULTIPLE", "7")),
        )

    def quote(self, *, input_tokens: int = 0, output_tokens: int = 0,
              tts_characters: int = 0, stt_seconds: float = 0,
              keyterms_enabled: bool = False) -> dict[str, float | int]:
        input_cost = max(0, input_tokens) * self.cerebras_input_usd_per_million / 1_000_000
        output_cost = max(0, output_tokens) * self.cerebras_output_usd_per_million / 1_000_000
        tts_cost = max(0, tts_characters) * self.eleven_tts_usd_per_thousand_characters / 1_000
        stt_multiplier = self.eleven_stt_keyterm_multiplier if keyterms_enabled else 1.0
        stt_cost = max(0.0, stt_seconds) * self.eleven_stt_usd_per_hour * stt_multiplier / 3600
        provider_cost = input_cost + output_cost + tts_cost + stt_cost
        credits = math.ceil(provider_cost * self.credits_per_usd * self.target_revenue_cost_multiple)
        return {
            "cerebras_input_cost_usd": input_cost,
            "cerebras_output_cost_usd": output_cost,
            "eleven_tts_cost_usd": tts_cost,
            "eleven_stt_cost_usd": stt_cost,
            "provider_cost_usd": provider_cost,
            "credit_charge": credits,
        }


def default_pricebook() -> PriceBook:
    return PriceBook.from_environment()

