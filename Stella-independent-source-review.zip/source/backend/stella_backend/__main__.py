from __future__ import annotations

import os

import uvicorn


if __name__ == "__main__":
    host = os.environ.get("STELLA_BACKEND_HOST", "127.0.0.1")
    port = int(os.environ.get("STELLA_BACKEND_PORT", "8767"))
    uvicorn.run("stella_backend.app:create_app", factory=True, host=host, port=port, reload=False)

