from __future__ import annotations

import json
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Iterator

from .security import hash_password, new_session_token, token_digest, verify_password


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


class AccountStore:
    """Transactional account, session, and append-only credit ledger store."""

    def __init__(self, path: Path, trial_credits: int = 50) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.trial_credits = max(0, int(trial_credits))
        self._initialize()

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        db = sqlite3.connect(self.path, timeout=15, isolation_level="IMMEDIATE")
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def _initialize(self) -> None:
        with self.connect() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript("""
                CREATE TABLE IF NOT EXISTS accounts (
                    account_id TEXT PRIMARY KEY,
                    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
                    password_hash TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'active',
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS schema_migrations (
                    version INTEGER PRIMARY KEY,
                    applied_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS sessions (
                    token_hash TEXT PRIMARY KEY,
                    account_id TEXT NOT NULL REFERENCES accounts(account_id),
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    revoked_at TEXT
                );
                CREATE TABLE IF NOT EXISTS credit_ledger (
                    entry_id TEXT PRIMARY KEY,
                    account_id TEXT NOT NULL REFERENCES accounts(account_id),
                    bucket TEXT NOT NULL CHECK(bucket IN ('trial','purchased','bonus','subscription')),
                    delta INTEGER NOT NULL CHECK(delta != 0),
                    event_type TEXT NOT NULL,
                    request_id TEXT,
                    actor TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    metadata_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL,
                    UNIQUE(account_id, request_id)
                );
                CREATE INDEX IF NOT EXISTS idx_credit_ledger_account
                    ON credit_ledger(account_id, created_at DESC);
                CREATE TABLE IF NOT EXISTS admin_audit (
                    audit_id TEXT PRIMARY KEY,
                    actor TEXT NOT NULL,
                    action TEXT NOT NULL,
                    account_id TEXT,
                    details_json TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS usage_events (
                    event_id TEXT PRIMARY KEY,
                    account_id TEXT NOT NULL REFERENCES accounts(account_id),
                    request_id TEXT NOT NULL,
                    provider TEXT NOT NULL,
                    model TEXT NOT NULL,
                    input_tokens INTEGER NOT NULL DEFAULT 0,
                    output_tokens INTEGER NOT NULL DEFAULT 0,
                    audio_characters INTEGER NOT NULL DEFAULT 0,
                    provider_cost_usd REAL NOT NULL DEFAULT 0,
                    credit_charge INTEGER NOT NULL DEFAULT 0,
                    latency_ms INTEGER NOT NULL DEFAULT 0,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    UNIQUE(account_id, request_id)
                );
                CREATE TRIGGER IF NOT EXISTS credit_ledger_no_update
                    BEFORE UPDATE ON credit_ledger BEGIN
                    SELECT RAISE(ABORT, 'credit ledger entries are immutable');
                END;
                CREATE TRIGGER IF NOT EXISTS credit_ledger_no_delete
                    BEFORE DELETE ON credit_ledger BEGIN
                    SELECT RAISE(ABORT, 'credit ledger entries are immutable');
                END;
            """)
            db.execute("INSERT OR IGNORE INTO schema_migrations(version,applied_at) VALUES(1,?)", (utc_now(),))

    def register(self, email: str, password: str) -> tuple[dict, str]:
        email = email.strip().casefold()
        if len(email) > 254 or "@" not in email or email.startswith("@") or email.endswith("@"):
            raise ValueError("Enter a valid email address")
        encoded = hash_password(password)
        account_id = str(uuid.uuid4())
        now = utc_now()
        token = new_session_token()
        with self.connect() as db:
            db.execute(
                "INSERT INTO accounts(account_id,email,password_hash,created_at) VALUES(?,?,?,?)",
                (account_id, email, encoded, now),
            )
            if self.trial_credits:
                db.execute("""INSERT INTO credit_ledger
                    (entry_id,account_id,bucket,delta,event_type,actor,reason,created_at)
                    VALUES(?,?,?,?,?,?,?,?)""",
                    (str(uuid.uuid4()), account_id, "trial", self.trial_credits,
                     "TRIAL_GRANT", "system", "New account trial allowance", now))
            db.execute("INSERT INTO sessions VALUES(?,?,?,?,NULL)",
                       (token_digest(token), account_id, now,
                        (datetime.now(UTC) + timedelta(days=30)).isoformat()))
        return self.account(account_id), token

    def login(self, email: str, password: str) -> tuple[dict, str] | None:
        with self.connect() as db:
            row = db.execute("SELECT * FROM accounts WHERE email=? COLLATE NOCASE", (email.strip(),)).fetchone()
            if row is None or row["status"] != "active" or not verify_password(password, row["password_hash"]):
                return None
            token = new_session_token()
            now = datetime.now(UTC)
            db.execute("INSERT INTO sessions VALUES(?,?,?,?,NULL)",
                       (token_digest(token), row["account_id"], now.isoformat(),
                        (now + timedelta(days=30)).isoformat()))
        return self.account(row["account_id"]), token

    def authenticate(self, token: str) -> dict | None:
        if not token:
            return None
        with self.connect() as db:
            row = db.execute("""SELECT a.account_id,a.email,a.status,a.created_at,s.expires_at
                FROM sessions s JOIN accounts a USING(account_id)
                WHERE s.token_hash=? AND s.revoked_at IS NULL""", (token_digest(token),)).fetchone()
        if row is None or row["status"] != "active" or row["expires_at"] <= utc_now():
            return None
        return dict(row)

    def logout(self, token: str) -> None:
        with self.connect() as db:
            db.execute("UPDATE sessions SET revoked_at=? WHERE token_hash=? AND revoked_at IS NULL",
                       (utc_now(), token_digest(token)))

    def account(self, account_id: str) -> dict:
        with self.connect() as db:
            row = db.execute("SELECT account_id,email,status,created_at FROM accounts WHERE account_id=?",
                             (account_id,)).fetchone()
            if row is None:
                raise KeyError("Account not found")
            return {**dict(row), "credits": self.balance(account_id, db=db)}

    @staticmethod
    def balance(account_id: str, *, db: sqlite3.Connection) -> dict[str, int]:
        rows = db.execute("SELECT bucket,SUM(delta) AS balance FROM credit_ledger WHERE account_id=? GROUP BY bucket",
                          (account_id,)).fetchall()
        result = {name: 0 for name in ("trial", "purchased", "bonus", "subscription")}
        result.update({row["bucket"]: max(0, int(row["balance"] or 0)) for row in rows})
        result["total"] = sum(result.values())
        return result

    def adjust_credits(self, *, account_id: str, bucket: str, delta: int,
                       actor: str, reason: str, request_id: str | None = None) -> dict:
        if bucket not in {"trial", "purchased", "bonus", "subscription"}:
            raise ValueError("Unsupported credit balance")
        if not delta or abs(delta) > 1_000_000_000:
            raise ValueError("Credit adjustment must be a non-zero bounded integer")
        if not reason.strip() or len(reason) > 500:
            raise ValueError("A short reason is required")
        request_id = request_id or str(uuid.uuid4())
        with self.connect() as db:
            if not db.execute("SELECT 1 FROM accounts WHERE account_id=?", (account_id,)).fetchone():
                raise KeyError("Account not found")
            current = int(db.execute("SELECT COALESCE(SUM(delta),0) FROM credit_ledger WHERE account_id=? AND bucket=?",
                                     (account_id, bucket)).fetchone()[0])
            if current + delta < 0:
                raise ValueError("Adjustment would make this credit balance negative")
            entry_id, now = str(uuid.uuid4()), utc_now()
            db.execute("""INSERT INTO credit_ledger
                (entry_id,account_id,bucket,delta,event_type,request_id,actor,reason,created_at)
                VALUES(?,?,?,?,?,?,?,?,?)""",
                (entry_id, account_id, bucket, delta, "ADMIN_GRANT" if delta > 0 else "ADMIN_REVOKE",
                 request_id, actor, reason.strip(), now))
            db.execute("INSERT INTO admin_audit VALUES(?,?,?,?,?,?)",
                       (str(uuid.uuid4()), actor, "credit_adjustment", account_id,
                        json.dumps({"bucket": bucket, "delta": delta, "reason": reason.strip(),
                                    "request_id": request_id}), now))
        return {"entry_id": entry_id, "request_id": request_id,
                "credits": self.account(account_id)["credits"]}

    def list_accounts(self, query: str = "", limit: int = 100) -> list[dict]:
        query = query.strip()[:200]
        limit = min(250, max(1, limit))
        with self.connect() as db:
            if query:
                rows = db.execute("""SELECT account_id,email,status,created_at FROM accounts
                    WHERE account_id LIKE ? OR email LIKE ? ORDER BY created_at DESC LIMIT ?""",
                    (f"%{query}%", f"%{query}%", limit)).fetchall()
            else:
                rows = db.execute("SELECT account_id,email,status,created_at FROM accounts ORDER BY created_at DESC LIMIT ?",
                                  (limit,)).fetchall()
            return [{**dict(row), "credits": self.balance(row["account_id"], db=db)} for row in rows]

    def permanently_deactivate(self, *, account_id: str, actor: str, reason: str) -> dict:
        reason = reason.strip() or "Permanently deactivated by administrator"
        now = utc_now()
        with self.connect() as db:
            row = db.execute("SELECT status FROM accounts WHERE account_id=?", (account_id,)).fetchone()
            if row is None:
                raise KeyError("Account not found")
            changed = row["status"] != "permanently_deactivated"
            if changed:
                db.execute("UPDATE accounts SET status='permanently_deactivated' WHERE account_id=?", (account_id,))
                db.execute("UPDATE sessions SET revoked_at=? WHERE account_id=? AND revoked_at IS NULL", (now, account_id))
                db.execute("INSERT INTO admin_audit VALUES(?,?,?,?,?,?)",
                    (str(uuid.uuid4()), actor, "account_permanently_deactivated", account_id,
                     json.dumps({"reason": reason, "sessions_revoked": True}), now))
        return {"account_id": account_id, "status": "permanently_deactivated", "changed": changed}

    def audit(self, limit: int = 100) -> list[dict]:
        with self.connect() as db:
            rows = db.execute("SELECT * FROM admin_audit ORDER BY created_at DESC LIMIT ?",
                              (min(500, max(1, limit)),)).fetchall()
        return [{**dict(row), "details": json.loads(row["details_json"])} for row in rows]

    def usage_summary(self, account_id: str, limit: int = 12) -> dict:
        since = (datetime.now(UTC) - timedelta(days=7)).isoformat()
        with self.connect() as db:
            credits = self.balance(account_id, db=db)
            totals = db.execute("""SELECT COALESCE(SUM(credit_charge),0) AS credits_used,
                    COALESCE(SUM(provider_cost_usd),0) AS provider_cost_usd,
                    COUNT(*) AS request_count
                FROM usage_events WHERE account_id=? AND created_at>=? AND status='success'""",
                (account_id, since)).fetchone()
            rows = db.execute("""SELECT provider,model,input_tokens,output_tokens,audio_characters,
                    provider_cost_usd,credit_charge,latency_ms,status,created_at
                FROM usage_events WHERE account_id=? ORDER BY created_at DESC LIMIT ?""",
                (account_id, min(50, max(1, limit)))).fetchall()
        return {
            "credits": credits,
            "last_7_days": {"credits_used": int(totals["credits_used"]),
                "provider_cost_usd": round(float(totals["provider_cost_usd"]), 6),
                "request_count": int(totals["request_count"])},
            "recent": [dict(row) for row in rows],
        }

