# Initial Trial-Credit Economics

This is a configurable test baseline, not a claim about future account-specific provider invoices. The server uses regular (non-promotional) ElevenLabs TTS pricing for safety. Values are server-side environment defaults and should move to the admin-managed price book before a paid release.

## Measured Stella workload

Aggregated from the local `data/groq_usage.sqlite3` counters and response-length columns only; no message text was read or exported. Across 2,244 successful `qwen-3.8-27b` generations, the mean was 2,146 input tokens and 59 output tokens; p90 was 3,906 input and 92 output tokens. The response ledger's voice-call replies averaged 44 characters. This is an initial local sample, not a universal future-user profile.

At the currently displayed Cerebras developer-tier rates for Qwen 3.8 27B ($0.99/M input, $1.49/M output), the average model generation is approximately $0.00221. A 44-character ElevenLabs TTS response at the regular $0.04/1K rate adds about $0.00176. ElevenLabs Scribe Realtime is priced by connected audio time; at $0.39/hour, a 10-second measured audio interval adds about $0.00108, or about $0.00130 when keyterm usage is 20% higher. The combined 10-second example is about $0.0053 provider cost before rounding.

Initial conversion: **100 credits = $1 retail value**, matching the requested $10 = 1,000-credit purchase baseline. Initial target: **7x retail revenue/provider-cost multiple**. The example turn is charged 4 credits after rounding upward. New users receive 50 trial credits. Actual chat/voice usage must be settled against server-observed provider metrics; estimates must never be treated as final bills where actual usage is available.

The trial grant is not an economics guarantee. Call duration, quiet connected STT time, retries, long prompts, long replies, and provider price changes can materially change unit cost. Admin must be able to edit the price book and plans remotely and see worst-case margin before enabling a paid plan. Cerebras labels its self-serve developer tier for development/evaluation/experimentation, not production; production entitlements and capacity must be validated before launch.

## Sources checked 2026-10-06

- [Cerebras Inference pricing](https://www.cerebras.ai/pricing) — current displayed Qwen 3.8 27B developer-tier input/output rates and tier limitations.
- [ElevenLabs API pricing](https://elevenlabs.io/pricing/api) — API product billing units and model prices. The local integration handoff records Eleven v4 Turbo at $0.011/1K promotional through 2026-10-12 and $0.04/1K regular; this baseline intentionally uses the regular rate.
- [ElevenLabs realtime STT API](https://elevenlabs.io/docs/api-reference/speech-to-text/v-1-speech-to-text-realtime) — Realtime Scribe usage and keyterm controls. The local integration handoff records the 20% keyterm premium; verify account billing before production.
