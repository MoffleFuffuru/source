from __future__ import annotations

import uuid
import unittest
from pathlib import Path

from fastapi.testclient import TestClient

from stella_backend.app import create_app
from stella_backend.store import AccountStore
from stella_backend.pricing import PriceBook


class AccountServiceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.db = Path(__file__).resolve().parents[1] / f"account-test-{uuid.uuid4().hex}.sqlite3"
        self.client = TestClient(create_app(db_path=self.db, trial_credits=50, admin_token="test-admin-token"))

    def tearDown(self) -> None:
        self.client.close()
        for suffix in ("", "-wal", "-shm"):
            path = Path(f"{self.db}{suffix}")
            if path.exists():
                path.unlink()

    def register(self, email: str = "person@example.com") -> tuple[dict, str]:
        response = self.client.post("/api/v1/auth/register", json={"email": email, "password": "correct horse battery"})
        self.assertEqual(response.status_code, 201, response.text)
        body = response.json()
        return body["account"], body["access_token"]

    def test_registration_grants_trial_and_returns_random_account_id(self) -> None:
        account, token = self.register()
        self.assertEqual(account["credits"]["trial"], 50)
        self.assertEqual(account["credits"]["total"], 50)
        self.assertNotEqual(account["account_id"], "1")
        response = self.client.get("/api/v1/account", headers={"Authorization": f"Bearer {token}"})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["account_id"], account["account_id"])

    def test_usage_summary_is_account_scoped_and_reports_trial_balance(self) -> None:
        account, token = self.register()
        response = self.client.get("/api/v1/usage", headers={"Authorization": f"Bearer {token}"})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["credits"]["total"], 50)
        self.assertEqual(response.json()["last_7_days"]["request_count"], 0)
        self.assertEqual(self.client.get("/api/v1/usage").status_code, 401)

    def test_password_is_not_stored_and_logout_revokes_session(self) -> None:
        _, token = self.register()
        with AccountStore(self.db).connect() as db:
            row = db.execute("SELECT password_hash FROM accounts").fetchone()
        self.assertNotIn("correct horse battery", row["password_hash"])
        headers = {"Authorization": f"Bearer {token}"}
        self.assertEqual(self.client.post("/api/v1/auth/logout", headers=headers).status_code, 204)
        self.assertEqual(self.client.get("/api/v1/account", headers=headers).status_code, 401)

    def test_admin_can_grant_and_remove_with_audit_and_balance_guards(self) -> None:
        account, _ = self.register()
        admin = {"X-Stella-Admin-Key": "test-admin-token"}
        granted = self.client.post("/admin/api/credits/adjust", headers=admin, json={
            "account_id": account["account_id"], "bucket": "purchased", "delta": 100, "reason": "Test purchase"
        })
        self.assertEqual(granted.status_code, 200, granted.text)
        self.assertEqual(granted.json()["credits"]["total"], 150)
        removed = self.client.post("/admin/api/credits/adjust", headers=admin, json={
            "account_id": account["account_id"], "bucket": "purchased", "delta": -20, "reason": "Refund"
        })
        self.assertEqual(removed.status_code, 200, removed.text)
        self.assertEqual(removed.json()["credits"]["purchased"], 80)
        denied = self.client.post("/admin/api/credits/adjust", headers=admin, json={
            "account_id": account["account_id"], "bucket": "purchased", "delta": -81, "reason": "Too much"
        })
        self.assertEqual(denied.status_code, 400)
        audit = self.client.get("/admin/api/audit", headers=admin).json()["events"]
        self.assertEqual(len(audit), 2)

    def test_admin_key_required_and_idempotency_prevents_double_adjustment(self) -> None:
        account, _ = self.register()
        payload = {"account_id": account["account_id"], "bucket": "bonus", "delta": 15,
                   "reason": "promo", "request_id": "promo-101"}
        self.assertEqual(self.client.post("/admin/api/credits/adjust", json=payload).status_code, 401)
        headers = {"X-Stella-Admin-Key": "test-admin-token"}
        self.assertEqual(self.client.post("/admin/api/credits/adjust", headers=headers, json=payload).status_code, 200)
        duplicate = self.client.post("/admin/api/credits/adjust", headers=headers, json=payload)
        self.assertEqual(duplicate.status_code, 409)
        self.assertEqual(self.client.get("/admin/api/accounts", headers=headers).json()["accounts"][0]["credits"]["bonus"], 15)

    def test_admin_permanently_deactivates_account_and_revokes_every_session(self) -> None:
        account, token = self.register("deactivate@example.com")
        headers = {"X-Stella-Admin-Key": "test-admin-token"}
        path = "/admin/api/accounts/deactivate"
        payload = {"account_id": account["account_id"], "reason": "User requested closure"}
        response = self.client.post(path, headers=headers, json=payload)
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["status"], "permanently_deactivated")
        self.assertEqual(self.client.get("/api/v1/account", headers={"Authorization": f"Bearer {token}"}).status_code, 401)
        self.assertEqual(self.client.post("/api/v1/auth/login", json={
            "email": "deactivate@example.com", "password": "correct horse battery"
        }).status_code, 401)
        account_row = self.client.get("/admin/api/accounts", headers=headers).json()["accounts"][0]
        self.assertEqual(account_row["status"], "permanently_deactivated")
        audit = self.client.get("/admin/api/audit", headers=headers).json()["events"]
        self.assertEqual(audit[0]["action"], "account_permanently_deactivated")

    def test_short_password_rejected(self) -> None:
        response = self.client.post("/api/v1/auth/register", json={"email": "short@example.com", "password": "short"})
        self.assertEqual(response.status_code, 422)

    def test_quote_counts_cerebras_and_eleven_usage_at_target_margin(self) -> None:
        quote = PriceBook().quote(input_tokens=2146, output_tokens=59,
            tts_characters=44, stt_seconds=10, keyterms_enabled=True)
        self.assertGreater(quote["provider_cost_usd"], quote["cerebras_input_cost_usd"])
        self.assertEqual(quote["credit_charge"], 4)


if __name__ == "__main__":
    unittest.main()
