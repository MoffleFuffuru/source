const { contextBridge, ipcRenderer } = require('electron');
const bridge = {
  model: choose => ipcRenderer.invoke('model', Boolean(choose)),
  modelLoaded: path => ipcRenderer.send('model-loaded', path),
  action: action => ipcRenderer.send('window-action', action),
  request: request => ipcRenderer.invoke('shell-request', request),
  account: request => ipcRenderer.invoke('account-request', request),
  onboardingState: () => ipcRenderer.invoke('onboarding-state'),
  onboardingComplete: () => ipcRenderer.invoke('onboarding-complete'),
  onBody: callback => ipcRenderer.on('body', (_event, data) => callback(data)),
  onAttention: callback => ipcRenderer.on('attention', (_event, data) => callback(data)),
  onLock: callback => ipcRenderer.on('lock', (_event, data) => callback(data)),
  onError: callback => ipcRenderer.on('bridge-error', (_event, data) => callback(data)),
};
contextBridge.exposeInMainWorld('stella', bridge);
// Retained solely for the VRM renderer while the visual shell uses Stella.
contextBridge.exposeInMainWorld('avatar', bridge);
