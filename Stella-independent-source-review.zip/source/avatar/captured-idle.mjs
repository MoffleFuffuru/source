import * as THREE from 'three';
import { createVRMAnimationClip } from '@pixiv/three-vrm-animation';

export function createCapturedIdlePlayback(vrm, animation) {
  const bones = new Set(Object.keys(vrm.humanoid.humanBones));
  const targets = new Set();
  for (const name of bones) {
    const node = vrm.humanoid.getNormalizedBoneNode(name);
    if (!node) continue;
    targets.add(`${node.name}.quaternion`);
    if (name === 'hips') targets.add(`${node.name}.position`);
  }
  const animations = Array.isArray(animation) ? animation : [animation];
  const clips = animations.map(source => {
  const clip = createVRMAnimationClip(source, vrm);
  clip.tracks = clip.tracks.filter(track => targets.has(track.name));
  for (const name of ['hips', 'leftUpperLeg', 'rightUpperLeg', 'leftLowerLeg', 'rightLowerLeg', 'leftFoot', 'rightFoot']) {
    const node = vrm.humanoid.getNormalizedBoneNode(name);
    if (!node || !clip.tracks.some(track => track.name === `${node.name}.quaternion`)) {
      throw new Error(`Original captured idle cannot drive ${name}`);
    }
  }
  return clip;
  });
  const mixer = new THREE.AnimationMixer(vrm.scene);
  const actions = clips.map(clip => mixer.clipAction(clip).setEffectiveTimeScale(1).setLoop(THREE.LoopRepeat, Infinity));
  let selected = 0;
  actions[0].setEffectiveWeight(1).play();
  return {
    bones, clip: clips[0], mixer, action: actions[0],
    select(index) {
      if (index < 0 || index >= actions.length || index === selected) return;
      actions[selected].fadeOut(.45);
      actions[index].reset().setEffectiveWeight(1).fadeIn(.45).play();
      selected = index;
    },
    update: dt => mixer.update(dt),
    dispose() { mixer.stopAllAction(); mixer.uncacheRoot(vrm.scene); },
  };
}
