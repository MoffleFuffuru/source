const EXPRESSIONS = new Set(['neutral','warm','amused','playful','smug','curious','confused','surprised','concerned','annoyed','embarrassed','sad','excited','focused']);
const GESTURES = new Set(['none','wave','small_head_tilt','head_turn','small_nod','small_shake','lean_in','lean_back','shrug','think','laugh','celebrate','stretch','explain','disappointed','annoyed','pout','curious','pleased','startle']);
function validatePacket(buffer) {
  if (buffer.length > 4096) return null;
  try {
    const p = JSON.parse(buffer.toString());
    if (p.version !== 1 || !Number.isSafeInteger(p.sequence) || !p.intent) return null;
    const audio = {};
    // Omit metadata for legacy senders. Never invent freshness from body ticks.
    if ('audio_sequence' in p || 'audio_age_ms' in p) {
      if (!Number.isSafeInteger(p.audio_sequence) || p.audio_sequence < 0 ||
          !Number.isFinite(p.audio_age_ms) || p.audio_age_ms < 0) return null;
      audio.audio_sequence = p.audio_sequence;
      audio.audio_age_ms = p.audio_age_ms;
    }
    for (const field of ['audio_stopped', 'interrupted', 'speech_finished']) {
      if (field in p) {
        if (typeof p[field] !== 'boolean') return null;
        audio[field] = p[field];
      }
    }
    const bounded = (x, fallback = 0) => Number.isFinite(x) ? Math.min(1, Math.max(0, x)) : fallback;
    return { version: 1, sequence: p.sequence, state: String(p.state).slice(0,24),
      speaking: p.speaking === true, speech_level: bounded(p.speech_level),
      ...audio,
      intent: { expression: EXPRESSIONS.has(p.intent.expression) ? p.intent.expression : 'neutral',
        gesture: GESTURES.has(p.intent.gesture) ? p.intent.gesture : 'none',
        intensity: bounded(p.intent.intensity, .25), energy: bounded(p.intent.energy,.35),
        gaze: ['speaker','camera','thinking_away','idle_random'].includes(p.intent.gaze) ? p.intent.gaze : 'camera' }
    };
  } catch { return null; }
}
module.exports = { validatePacket };
