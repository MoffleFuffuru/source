# Mako VRM Companion

Independent transparent Windows avatar, built with Electron, Three.js and
@pixiv/three-vrm. Supports VRM 0.x/1.0 through three-vrm. No cloud requests,
additional model calls, microphone capture, or conversation storage.

## Start

Double-click `Start Avatar.bat` for the avatar alone, or the parent folder's
`Start Mako with Avatar.bat` to launch both. Restart an already running Mako
once to load the new desktop body adapter.

Hover for controls. Drag the top bar to move. Scroll to zoom. Lock enables
click-through; **Ctrl+Alt+M** restores interaction. X closes only the avatar.
Load VRM selects a replacement model; the last successfully loaded model is
remembered. Smile, Wave and Pose let you test without spending model quota.

## Motion

30 fps, subtle layered breathing, irregular blinks, gaze/head adjustments,
restrained upper-body sway, and smooth bounded gestures. The Motion slider
adjusts idle movement. This is procedural prototype motion, not mocap-quality
animation. Speech mouth opening uses Mako's actual playback amplitude; it is
not phoneme-accurate lip sync. No audio is synthesized or played by this viewer.

Mako sends renderer-neutral state to loopback UDP 39540. Gesture sequence IDs
prevent repeating a motion on each telemetry frame. A timeout restores idle
and closes the mouth when Mako disconnects. Current per-turn acting directives
are used when present; otherwise Mako's existing expression mapping remains.
The viewer does not invent semantic gestures from keyword matching.

## Placeholder and licenses

Donut-Chan is a temporary avatar, NOT Mako's finished likeness. The locally
supplied model's author is Kana Fuyuko; its included `assets/Thank You.txt`
declares it public domain. Keep that attribution. Each imported avatar has its
own license. Dependency licenses remain in node_modules.

## Rollback

Close the viewer and change only `body.adapter` in the parent config.json back
to `debug`, then restart Mako. Nothing in model, memory, STT, TTS, or Discord
configuration was changed. The original body.py and config.json are saved as
`body.before-avatar.py` and `config.before-avatar.json`; avoid restoring the
whole configuration after unrelated future changes.
