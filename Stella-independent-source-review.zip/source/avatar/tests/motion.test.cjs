const test = require('node:test');
const assert = require('node:assert/strict');
test('pose cancellation eases out and converges without overshoot', async () => {
  const { smoothingAlpha } = await import('../motion.mjs');
  let tilt = .13;
  tilt *= 1 - smoothingAlpha(1/30, 4);
  assert.ok(tilt > .11 && tilt < .13);
  for (let i=0; i<30; i++) tilt *= 1 - smoothingAlpha(1/30, 4);
  assert.ok(tilt > 0 && tilt < .003);
});
test('mouth responds to soft playback, stays bounded, and closes in silence', async () => {
  const { mouthTarget } = await import('../motion.mjs');
  assert.equal(mouthTarget(0),0);
  assert.ok(mouthTarget(.04) > .25);
  assert.equal(mouthTarget(10),.85);
});
