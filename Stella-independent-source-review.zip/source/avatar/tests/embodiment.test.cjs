const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');

async function fixture() {
  const THREE = await import('three');
  const { VRMHumanoid } = await import('@pixiv/three-vrm');
  const { GLTFLoader } = await import('three/addons/loaders/GLTFLoader.js');
  const { VRMAnimationLoaderPlugin, createVRMAnimationClip } = await import('@pixiv/three-vrm-animation');
  const { MovementDirector, MotionClip } = await import('../embodiment.mjs');
  const bytes = await fs.readFile(path.join(__dirname,'../assets/Mako.vrm'));
  const json = JSON.parse(bytes.subarray(20,20+bytes.readUInt32LE(12)).toString());
  const nodes = json.nodes.map(n => {
    const bone = new THREE.Object3D(); bone.name = n.name || '';
    if (n.translation) bone.position.fromArray(n.translation);
    if (n.rotation) bone.quaternion.fromArray(n.rotation);
    if (n.scale) bone.scale.fromArray(n.scale);
    return bone;
  });
  json.nodes.forEach((n,i) => (n.children || []).forEach(j => nodes[i].add(nodes[j])));
  const scene = new THREE.Group(); nodes.filter(n => !n.parent).forEach(n => scene.add(n)); scene.updateMatrixWorld(true);
  const humanBones = Object.fromEntries(json.extensions.VRM.humanoid.humanBones.map(b => [b.bone,{node:nodes[b.node]}]));
  const humanoid = new VRMHumanoid(humanBones);
  const bones = Object.fromEntries(Object.keys(humanoid.humanBones).map(n => [n,humanoid.getNormalizedBoneNode(n)]));
  const vrm = {humanoid,meta:{metaVersion:'0'},scene};
  const director = new MovementDirector(vrm,bones,{random:()=>.3});
  const loader = new GLTFLoader(); loader.register(parser => new VRMAnimationLoaderPlugin(parser));
  const files = (await fs.readdir(path.join(__dirname,'../assets/movement'))).filter(n => n.endsWith('.vrma'));
  for (const file of files) {
    const data = await fs.readFile(path.join(__dirname,'../assets/movement',file));
    const gltf = await loader.parseAsync(data.buffer.slice(data.byteOffset,data.byteOffset+data.byteLength),'');
    director.clips.set(file.slice(0,-5),new MotionClip(createVRMAnimationClip(gltf.userData.vrmAnimations[0],vrm),bones));
  }
  const idleFiles = await fs.readdir(path.join(__dirname,'../../motion/idle'));
  for (const file of idleFiles.filter(n => n.endsWith('.vrma'))) {
    const data = await fs.readFile(path.join(__dirname,'../../motion/idle',file));
    const gltf = await loader.parseAsync(data.buffer.slice(data.byteOffset,data.byteOffset+data.byteLength),'');
    director.clips.set(file.slice(0,-5),new MotionClip(createVRMAnimationClip(gltf.userData.vrmAnimations[0],vrm),bones));
  }
  director.idleClip = director.clips.get('stella_idle_rest_a');
  director.idleClipId = 'stella_idle_rest_a';
  director.lastIdleClip = director.idleClipId;
  director.reference = director.idleClip.sample(0,director.rest).pose;
  director.base = 'captured_motion_idle';
  return {director,bones};
}

test('explicit quiet gestures start without entering speech', async () => {
  const {director} = await fixture();
  director.receive({state:'idle', sequence:1, speaking:false,
    intent:{gesture:'small_head_tilt', expression:'warm', energy:.4}});
  director.update(.016);
  assert.equal(director.phase, 'idle');
  assert.equal(director.action?.name, 'small_head_tilt');
});

test('real Mako rig: assets retain finger and leg articulation, and all samples are finite', async () => {
  const {director} = await fixture();
  assert.equal(director.clips.size,41);
  let fingerMotion = 0;
  for (const [id,clip] of director.clips) {
    const first = clip.sample(0,director.rest);
    assert.ok(clip.rotation.size >= (id.startsWith('stella_idle_rest_') ? 20 : 48),id);
    for (let t=0;t<clip.duration;t+=.13) {
      const sample = clip.sample(t,director.rest);
      for (const [name,q] of Object.entries(sample.pose)) {
        assert.ok(q.toArray().every(Number.isFinite),`${id}/${name}`);
        assert.ok(Math.abs(q.length()-1)<1e-5);
        if (/Index|Middle|Thumb/.test(name)) fingerMotion = Math.max(fingerMotion,q.angleTo(first.pose[name]));
      }
    }
  }
  assert.ok(fingerMotion>.1,`No significant authored finger motion: ${fingerMotion}`);
});

test('pout -> anticipation -> speech -> interruption has bounded head speed and full-body motion', async () => {
  const {director,bones} = await fixture();
  const packet = (state,sequence,level=0) => ({state,sequence,speaking:state==='speaking',speech_level:level,intent:{expression:'annoyed',gesture:'none',intensity:.6,energy:.5}});
  director.update(0); let previous=bones.head.quaternion.clone(); let highest=0; let legMotion=0;
  director.react('discord_off');
  for (let i=0;i<300;i++) {
    const state = i<30?'processing':i<170?'speaking':'listening';
    director.receive(packet(state,i<30?1:i<170?2:3,state==='speaking'?.06:0));
    if (i===100) director.play('wave',{force:true});
    if (i===180) director.react('discord_on');
    const result = director.update(1/60,{fresh:true,x:i%2?1:-1,y:0,speed:8});
    highest=Math.max(highest,previous.angleTo(bones.head.quaternion)*60); previous.copy(bones.head.quaternion);
    legMotion=Math.max(legMotion,director.rest.leftUpperLeg.angleTo(bones.leftUpperLeg.quaternion),director.rest.rightUpperLeg.angleTo(bones.rightUpperLeg.quaternion));
    if(i===60) { assert.equal(result.phase,'speaking'); assert.equal(result.reaction,'discord_off'); assert.ok(result.reactionWeight>.4); }
  }
  assert.ok(highest<=1.301,`head speed ${highest}`);
  assert.ok(legMotion>.01,`full-body speech/listening/gesture motion did not reach the legs: ${legMotion}`);
});

test('continuous idle animates posture, arms, and fingers without gestures; Discord toggle reactions trigger once', async () => {
  const {director,bones} = await fixture();
  const initial = Object.fromEntries(['chest','leftUpperArm','rightUpperArm','leftIndexProximal','rightMiddleProximal']
    .map(name => [name, bones[name].quaternion.clone()]));
  const changes = Object.fromEntries(Object.keys(initial).map(name => [name, 0]));
  for (let i=0;i<900;i++) {
    const result = director.update(1/60);
    for (const name of Object.keys(initial)) changes[name] = Math.max(changes[name], initial[name].angleTo(bones[name].quaternion));
  assert.equal(result.base, 'captured_motion_idle');
    assert.equal(result.gesture, 'none');
  }
  assert.ok(changes.chest > .015, `idle chest motion too subtle: ${changes.chest}`);
  assert.ok(changes.leftUpperArm > .015, `left arm remained statue-still: ${changes.leftUpperArm}`);
  assert.ok(changes.rightUpperArm > .015, `right arm remained statue-still: ${changes.rightUpperArm}`);
  assert.ok(changes.leftIndexProximal > .015, `left fingers remained rigid: ${changes.leftIndexProximal}`);
  assert.ok(changes.rightMiddleProximal > .015, `right fingers remained rigid: ${changes.rightMiddleProximal}`);

  assert.equal(director.react('discord_off'), true);
  director.update(1/60);
  assert.equal(director.reaction.name, 'discord_off');
  assert.equal(director.action.name, 'disappointed');
  const reactionStarted = director.reaction.started;
  const actionStarted = director.action.started;
  director.update(.2);
  director.react('discord_off');
  assert.equal(director.reaction.started, reactionStarted);
  assert.equal(director.action.started, actionStarted);
  director.react('discord_on');
  director.update(1/60);
  assert.equal(director.action.name, 'small_nod');
});

test('captured idle loops drive pelvis and legs directly, without procedural leg overlays', async () => {
  const {director,bones} = await fixture();
  const names = ['hips','leftUpperLeg','rightUpperLeg','leftLowerLeg','rightLowerLeg','leftFoot','rightFoot'];
  director.update(0);
  const initial = Object.fromEntries(names.map(name => [name, bones[name].quaternion.clone()]));
  const changes = Object.fromEntries(names.map(name => [name, 0]));
  let leftRightDifference = 0;
  for (let i=0;i<600;i++) {
    director.update(1/60);
    for (const name of names) changes[name] = Math.max(changes[name], initial[name].angleTo(bones[name].quaternion));
    leftRightDifference = Math.max(leftRightDifference,
      bones.leftUpperLeg.quaternion.angleTo(bones.rightUpperLeg.quaternion),
      bones.leftLowerLeg.quaternion.angleTo(bones.rightLowerLeg.quaternion));
  }
  assert.ok(changes.hips > .04, `captured pelvis rotation was lost: ${changes.hips}`);
  for (const name of ['leftUpperLeg','rightUpperLeg']) assert.ok(changes[name] > .05, `${name} authored idle motion was lost: ${changes[name]}`);
  for (const name of ['leftLowerLeg','rightLowerLeg']) assert.ok(changes[name] > .03, `${name} authored idle motion was lost: ${changes[name]}`);
  assert.ok(leftRightDifference > .008, `captured left/right leg variation was lost: ${leftRightDifference}`);
});

test('idle has final authority over hips and legs beneath every movement layer', async () => {
  const {director,bones} = await fixture();
  const lower = ['hips','leftUpperLeg','rightUpperLeg','leftLowerLeg','rightLowerLeg','leftFoot','rightFoot'];
  const scenarios = [
    () => director.receive({sequence:1,state:'speaking',speaking:true,speech_level:.05,intent:{gesture:'none',intensity:1}}),
    () => director.receive({sequence:2,state:'listening',speaking:false,speech_level:0,intent:{gesture:'none',intensity:1}}),
    () => { director.receive({sequence:3,state:'speaking',speaking:true,speech_level:.05,intent:{gesture:'none',intensity:1}}); director.play('wave',{force:true}); },
    () => { director.react('discord_off'); director.play('wave',{force:true}); },
  ];
  for (const activate of scenarios) {
    activate();
    for (let i=0;i<90;i++) {
      director.update(1/60);
      const expected = director.idleClip.sample(director.idleClipElapsed,director.rest,true);
      for (const name of lower) {
        assert.ok(bones[name].quaternion.angleTo(expected.pose[name]) < 1e-5, `${name} overridden during ${director.phase}`);
      }
      assert.ok(bones.hips.position.distanceTo(expected.hips) < 1e-5, `hips translation overridden during ${director.phase}`);
    }
  }
});

test('idle cycles through the dedicated neutral clips instead of holding a static bind pose', async () => {
  const {director} = await fixture();
  const first = director.idleClipId;
  for (let i=0;i<1200;i++) director.update(1/60);
  assert.notEqual(director.idleClipId, first, 'idle clip did not rotate after its interval');
  assert.ok(['stella_idle_rest_a','stella_idle_rest_b','stella_idle_rest_c'].includes(director.idleClipId));
});

test('missing audio waits in anticipation; duplicate packets never retrigger a one-shot', async () => {
  const {director} = await fixture();
  const packet = {state:'speaking',sequence:12,speaking:true,speech_level:0,intent:{gesture:'small_nod',intensity:.6}};
  for(let i=0;i<30;i++){ director.receive(packet); director.update(1/30); }
  assert.equal(director.phase,'anticipation'); assert.equal(director.action,null);
  packet.speech_level=.06;
  for(let i=0;i<240;i++){ director.receive(packet); director.update(1/30); }
  assert.equal(director.action,null);
  assert.ok(director.lastAction<2,'duplicate event restarted gesture');
});
