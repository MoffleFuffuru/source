const test = require('node:test');
const assert = require('node:assert/strict');
const { validatePacket } = require('../protocol.cjs');
const decode = extra => validatePacket(Buffer.from(JSON.stringify({version: 1, sequence: 3, intent: {}, ...extra})));
test('reject malformed, oversized, and unrelated packets', () => {
  for (const data of ['no', '{}', 'null', 'a'.repeat(4097)]) assert.equal(validatePacket(Buffer.from(data)), null);
});

test('preserve independent audio freshness and stop flags without inventing legacy fields', () => {
  const p = decode({audio_sequence: 71, audio_age_ms: 102.5, audio_stopped: false});
  assert.equal(p.audio_sequence, 71);
  assert.equal(p.audio_age_ms, 102.5);
  assert.equal(p.audio_stopped, false);
  const legacy = decode({speech_level: .2});
  for (const key of ['audio_sequence', 'audio_age_ms', 'audio_stopped']) assert.equal(key in legacy, false);
  for (const field of ['audio_stopped', 'interrupted', 'speech_finished']) {
    assert.equal(decode({[field]: true})[field], true);
    assert.equal(decode({[field]: 'true'}), null);
  }
});

test('reject partial, negative, fractional sequence and nonfinite audio metadata', () => {
  for (const extra of [
    {audio_sequence: 1}, {audio_age_ms: 0},
    {audio_sequence: -1, audio_age_ms: 0}, {audio_sequence: 1.5, audio_age_ms: 0},
    {audio_sequence: Number.MAX_SAFE_INTEGER + 1, audio_age_ms: 0},
    {audio_sequence: '1', audio_age_ms: 0},
    ...[-1, null, '0', Infinity, NaN].map(audio_age_ms => ({audio_sequence: 1, audio_age_ms})),
  ]) assert.equal(decode(extra), null);
  // JSON can contain a numeric exponent that overflows even without NaN syntax.
  assert.equal(validatePacket(Buffer.from('{"version":1,"sequence":1,"intent":{},"audio_sequence":1,"audio_age_ms":1e999}')), null);
});

test('validated heartbeat cannot keep audio mouth open, while new samples can', async () => {
  const {AudioMouth} = await import('../lip-sync.mjs');
  const mouth = new AudioMouth();
  const sample = {audio_sequence: 1, audio_age_ms: 0, audio_stopped: false, speech_level: .2, speaking: false};
  mouth.receive(decode(sample));
  assert.ok(mouth.update(.05) > .5);
  for (let i = 1; i <= 8; i++) {
    mouth.receive(decode({...sample, sequence: i, audio_age_ms: i * 50}));
    mouth.update(.05);
  }
  assert.equal(mouth.weight, 0);
  mouth.receive(decode({...sample, audio_sequence: 2}));
  assert.ok(mouth.update(.05) > .5);
  mouth.receive(decode({...sample, audio_sequence: 3, audio_stopped: true, speech_level: 0}));
  assert.equal(mouth.update(.001), 0);
});
test('bound untrusted values and allow only known motion names', () => {
  const p = validatePacket(Buffer.from(JSON.stringify({version:1,sequence:3,speaking:true,speech_level:100,intent:{expression:'warm',gesture:'execute',intensity:-2}})));
  assert.equal(p.speech_level,1); assert.equal(p.intent.intensity,0); assert.equal(p.intent.gesture,'none'); assert.equal(p.intent.expression,'warm');
});
