const test = require('node:test');
const assert = require('node:assert/strict');
const modulePromise = import('../lip-sync.mjs');
const packet = (seq, level, extra = {}) => ({audio_sequence: seq, audio_age_ms: 0, speech_level: level, speaking: false, ...extra});

test('playback before speaking, bounded attack, rapid syllable closure and reopening', async () => {
  const {AudioMouth} = await modulePromise;
  const mouth = new AudioMouth();
  mouth.receive(packet(1, 1));
  assert.ok(mouth.update(.05) > .5);
  assert.ok(mouth.weight <= .55);
  mouth.receive(packet(2, 0));
  assert.ok(mouth.update(.05) < .075);
  mouth.receive(packet(3, .2));
  assert.ok(mouth.update(.05) > .5);
});

test('heartbeat never refreshes stale audio; fresh equal amplitude does', async () => {
  const {AudioMouth} = await modulePromise;
  const mouth = new AudioMouth();
  mouth.receive(packet(1, .2));
  for (let i = 0; i < 10; i++) {
    mouth.receive(packet(1, .2));
    mouth.update(.05);
  }
  assert.equal(mouth.weight, 0);
  mouth.receive(packet(2, .2));
  assert.ok(mouth.update(.05) > .5);
});

test('source age, dropped packets and long frames all close the mouth', async () => {
  const {AudioMouth} = await modulePromise;
  const mouth = new AudioMouth();
  mouth.receive(packet(1, .2, {audio_age_ms: 200}));
  assert.equal(mouth.update(.05), 0);
  mouth.receive(packet(2, .2));
  mouth.update(.05);
  assert.equal(mouth.update(1), 0);
  mouth.receive(packet(1, .2));
  assert.equal(mouth.update(.05), 0);
});

test('finish and interruption close immediately and duplicate audio cannot resurrect them', async () => {
  const {AudioMouth} = await modulePromise;
  for (const flag of ['audio_stopped', 'interrupted', 'speech_finished']) {
    const mouth = new AudioMouth();
    mouth.receive(packet(1, .2));
    mouth.update(.05);
    mouth.receive(packet(2, 0, {[flag]: true}));
    assert.equal(mouth.update(.001), 0);
    mouth.receive(packet(2, .2));
    assert.equal(mouth.update(.05), 0);
    mouth.receive(packet(3, .2));
    assert.ok(mouth.update(.05) > .5);
  }
});

test('legacy RMS follows playback without speaking; repeated heartbeats expire', async () => {
  const {AudioMouth} = await modulePromise;
  const mouth = new AudioMouth();
  mouth.receive({speech_level: .2, speaking: false});
  assert.ok(mouth.update(.05) > .5);
  for (let i = 0; i < 10; i++) {
    mouth.receive({speech_level: .2, speaking: true});
    mouth.update(.05);
  }
  assert.equal(mouth.weight, 0);
  mouth.receive({speech_level: 0});
  mouth.receive({speech_level: .2});
  assert.ok(mouth.update(.05) > .5);
  mouth.receive({speech_level: 0});
  assert.equal(mouth.update(.2), 0);
});

test('nonfinite input and malformed metadata cannot poison or open the mouth', async () => {
  const {AudioMouth} = await modulePromise;
  const mouth = new AudioMouth();
  for (const level of [NaN, Infinity, -Infinity, undefined, '0.5', -1]) {
    mouth.receive({speech_level: level});
    assert.equal(mouth.update(.05), 0);
  }
  for (const age of [NaN, Infinity, -1, undefined]) {
    const m = new AudioMouth();
    m.receive(packet(1, 1, {audio_age_ms: age}));
    assert.equal(m.update(.05), 0);
  }
  mouth.receive(null);
  for (const dt of [NaN, Infinity, -1, undefined, 0]) assert.equal(mouth.update(dt), 0);
});

test('envelope and expiry are invariant under frame subdivision', async () => {
  const {AudioMouth} = await modulePromise;
  const a = new AudioMouth(), b = new AudioMouth();
  a.receive(packet(1, .2)); b.receive(packet(1, .2));
  a.update(.2);
  for (let i = 0; i < 20; i++) b.update(.01);
  assert.ok(Math.abs(a.weight - b.weight) < 1e-10);
});
