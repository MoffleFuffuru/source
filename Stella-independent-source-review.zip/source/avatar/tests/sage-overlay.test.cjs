const test = require('node:test');
const assert = require('node:assert/strict');

test('SAGE upper gesture and gaze leave captured hips, legs and spine unchanged', async () => {
  const THREE = await import('three');
  const { MovementDirector } = await import('../embodiment.mjs');
  const names = ['hips', 'spine', 'leftUpperLeg', 'rightUpperLeg', 'leftLowerLeg',
    'rightLowerLeg', 'leftFoot', 'rightFoot', 'head', 'neck', 'leftUpperArm', 'leftIndexProximal'];
  const bones = Object.fromEntries(names.map(name => [name, new THREE.Object3D()]));
  for (const bone of Object.values(bones)) {
    bone.quaternion.setFromEuler(new THREE.Euler(.12, -.24, .18));
    bone.position.set(.1, .2, .3);
  }
  const before = Object.fromEntries(names.map(name => [name, {
    q: bones[name].quaternion.clone(), p: bones[name].position.clone(),
  }]));
  const director = Object.create(MovementDirector.prototype);
  director.bones = bones;
  director.vrm = { meta: { metaVersion: '0' } };
  director.externalBones = new Set(names);
  director.externalOverlay = {
    pose: Object.fromEntries(names.map(name => [name, new THREE.Quaternion()])),
    offsets: { head: [.1, .2, 0], neck: [.03, .04, 0] },
    actionName: 'wave', actionWeight: .8,
  };
  director.applyCapturedUpperOverlay();
  for (const name of names) {
    assert.ok(bones[name].position.equals(before[name].p), `${name} position changed`);
    if (!['head', 'neck', 'leftUpperArm', 'leftIndexProximal'].includes(name)) {
      assert.ok(bones[name].quaternion.equals(before[name].q), `${name} rotation changed`);
    } else {
      assert.ok(bones[name].quaternion.angleTo(before[name].q) > .01, `${name} did not move`);
    }
  }
});
