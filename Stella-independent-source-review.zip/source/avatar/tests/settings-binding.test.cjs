const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

test('every settings panel is collapsible and keeps existing control IDs', () => {
  const source = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
  const rail = source.split('<aside class="control-rail">')[1].split('</aside>')[0];
  assert.equal((rail.match(/<details\b/g) || []).length, 7);
  assert.equal((rail.match(/<\/details>/g) || []).length, 7);
  assert.equal((rail.match(/<summary\b/g) || []).length, 7);
  assert.ok(!rail.includes('<section'));
  for (const id of ['call-toggle', 'call-model', 'stt', 'discord-enabled', 'sage-enabled', 'sage-review']) {
    assert.ok(rail.includes(`id="${id}"`), `${id} missing`);
  }
  const css = fs.readFileSync(path.join(__dirname, '..', 'style.css'), 'utf8');
  assert.ok(css.includes('.control-rail > .panel { flex:0 0 auto; }'));
});

test('missing optional settings do not abort call-control initialization', () => {
  const source = fs.readFileSync(path.join(__dirname, '..', 'viewer.js'), 'utf8');
  const start = source.indexOf('for (const [id, key] of Object.entries(configField))');
  const end = source.indexOf("$('endpoint').addEventListener", start);
  const bound = [];
  const context = {
    configField: { missing: 'memory.enabled', present: 'model.call_model' },
    $: id => id === 'missing' ? null : { addEventListener: name => bound.push(name) },
  };
  vm.runInNewContext(source.slice(start, end) + '\ncompleted = true;', context);
  assert.equal(context.completed, true);
  assert.deepEqual(bound, ['change']);
});
