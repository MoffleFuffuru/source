const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');

test('original native idle reaches skinned leg and finger bones through the complete VRM update', async () => {
  const THREE = await import('three');
  const { GLTFLoader } = await import('three/addons/loaders/GLTFLoader.js');
  const { VRMLoaderPlugin, VRMUtils } = await import('@pixiv/three-vrm');
  const { VRMAnimationLoaderPlugin, createVRMAnimationClip } = await import('@pixiv/three-vrm-animation');
  const { createCapturedIdlePlayback } = await import('../captured-idle.mjs');
  const { MovementDirector, MotionClip } = await import('../embodiment.mjs');
  const data = await fs.readFile(path.join(__dirname, '../assets/Mako.vrm'));
  const jsonLength = data.readUInt32LE(12);
  const json = JSON.parse(data.subarray(20, 20 + jsonLength).toString());
  // Texture decoding needs a browser; keep the real geometry, skin, humanoid,
  // and spring bones while using untextured materials for this Node check.
  json.materials = (json.materials || []).map(() => ({}));
  delete json.extensions.VRM.materialProperties;
  const jsonBytes = Buffer.from(JSON.stringify(json));
  const padded = Buffer.alloc(Math.ceil(jsonBytes.length / 4) * 4, 32);
  jsonBytes.copy(padded);
  const binaryChunk = data.subarray(20 + jsonLength);
  const header = Buffer.alloc(20);
  header.write('glTF'); header.writeUInt32LE(2, 4);
  header.writeUInt32LE(20 + padded.length + binaryChunk.length, 8);
  header.writeUInt32LE(padded.length, 12); header.write('JSON', 16);
  const model = Buffer.concat([header, padded, binaryChunk]);
  const loader = new GLTFLoader(); loader.register(parser => new VRMLoaderPlugin(parser));
  const load = async () => {
    const gltf = await loader.parseAsync(model.buffer.slice(model.byteOffset, model.byteOffset + model.byteLength), '');
    const vrm = gltf.userData.vrm;
    VRMUtils.rotateVRM0(vrm);
    VRMUtils.removeUnnecessaryVertices(vrm.scene);
    VRMUtils.combineSkeletons(vrm.scene);
    return vrm;
  };
  const actual = await load(); const reference = await load();
  const source = await fs.readFile(path.join(__dirname, '../../motion/idle/stella_idle_rest_a.vrma'));
  const animationLoader = new GLTFLoader();
  animationLoader.register(parser => new VRMAnimationLoaderPlugin(parser));
  const sourceGltf = await animationLoader.parseAsync(source.buffer.slice(source.byteOffset, source.byteOffset + source.byteLength), '');
  const animation = sourceGltf.userData.vrmAnimations[0];
  const playback = createCapturedIdlePlayback(actual, animation);
  const referenceMixer = new THREE.AnimationMixer(reference.scene);
  referenceMixer.clipAction(createVRMAnimationClip(animation, reference)).play();
  const bones = Object.fromEntries(Object.keys(actual.humanoid.humanBones)
    .map(name => [name, actual.humanoid.getNormalizedBoneNode(name)]));
  const director = new MovementDirector(actual, bones, { externalBones: playback.bones, random: () => 0 });
  director.reference = Object.fromEntries(Object.entries(director.rest).map(([name, q]) => [name, q.clone()]));
  director.base = 'test';
  const competing = new MotionClip(createVRMAnimationClip(animation, actual), bones);
  for (const id of ['rb-idle-talking', 'rb-listen', 'rb-wave']) director.clips.set(id, competing);
  const tracked = ['hips', 'leftUpperLeg', 'rightUpperLeg', 'leftLowerLeg', 'rightLowerLeg', 'leftFoot', 'rightFoot', 'leftIndexProximal', 'rightIndexProximal'];
  const first = {}; const motion = Object.fromEntries(tracked.map(name => [name, 0]));
  for (let frame = 0; frame < 600; frame++) {
    const state = frame < 200 ? 'idle' : frame < 400 ? 'speaking' : 'listening';
    director.receive({ sequence: Math.floor(frame / 200), state, speaking: state === 'speaking', speech_level: .05,
      intent: { gesture: 'none', intensity: 1 } });
    if (frame === 240) director.play('wave', { force: true });
    if (frame === 420) director.react('discord_off');
    director.update(1 / 60);
    playback.update(1 / 60);
    actual.update(1 / 60);
    referenceMixer.update(1 / 60);
    reference.update(1 / 60);
    actual.scene.updateMatrixWorld(true); reference.scene.updateMatrixWorld(true);
    for (const name of tracked) {
      const raw = actual.humanoid.getRawBoneNode(name);
      const expected = reference.humanoid.getRawBoneNode(name);
      assert.ok(raw.quaternion.clone().normalize().angleTo(expected.quaternion.clone().normalize()) < 1e-5, `${state} frame ${frame}: raw ${name} differs from native playback`);
      if (name === 'hips') assert.ok(raw.position.distanceTo(expected.position) < 1e-5, 'hips position differs');
      first[name] ??= raw.quaternion.clone();
      motion[name] = Math.max(motion[name], first[name].angleTo(raw.quaternion));
    }
  }
  for (const name of ['leftUpperLeg', 'rightUpperLeg', 'leftLowerLeg', 'rightLowerLeg', 'leftIndexProximal', 'rightIndexProximal']) {
    assert.ok(motion[name] > .01, `raw ${name} did not articulate: ${motion[name]}`);
  }
  playback.dispose(); referenceMixer.stopAllAction();
});
