# Overte face-to-face animations

This folder contains the 31 unprefixed face-to-face VRM animation clips from
[Hanami](https://github.com/Undi95/Hanami/tree/6787685c8d40e4e79bffbb0d389b478f32ef88d6/vrma),
pinned to commit `6787685c8d40e4e79bffbb0d389b478f32ef88d6`.
IDs are the filenames without `.vrma`. This is a separate Overte family;
no `rb-`, `world-`, or `extra/` animation is included.

`NOTICE.md` is the unmodified pinned upstream attribution and license notice.
Its Overte face-to-face table identifies the original FBX sources and segments.
`README.hanami.md` preserves the pinned upstream README, which describes the
broader upstream library as well as these clips. Retain the notice with redistribution.

`sources.json` records the source URL, revision, byte size, SHA-256, and Git blob
SHA-1 for every downloaded file. Each animation also has a `.vrma.source.json`
sidecar with the same provenance. The upstream NOTICE identifies this animation
family as derived from Overte under Apache-2.0.

From the project root, acquire or verify the pinned files using Node's built-in fetch:

```text
node avatar/tools/acquire-overte.mjs
```

The script requires exactly 31 matching animations, verifies upstream byte sizes
and Git blob hashes, validates glTF v2 magic, declared length, chunk boundaries,
and VRM animation content, then reads back all written files. It reuses identical
existing files and refuses to overwrite differing files. It does not modify the
movement catalog or other families.
