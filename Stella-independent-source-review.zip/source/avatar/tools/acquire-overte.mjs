import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const revision = '6787685c8d40e4e79bffbb0d389b478f32ef88d6';
const repository = 'https://github.com/Undi95/Hanami';
const base = `https://raw.githubusercontent.com/Undi95/Hanami/${revision}/vrma/`;
const destination = fileURLToPath(new URL('../assets/movement/overte/', import.meta.url));
const sha256 = data => createHash('sha256').update(data).digest('hex');

async function fetchBytes(url) {
  const response = await fetch(url, {signal: AbortSignal.timeout(60000)});
  if (!response.ok) throw new Error(`${response.status}: ${url}`);
  return Buffer.from(await response.arrayBuffer());
}

function verifyGlb(data, name) {
  if (data.length < 20 || data.toString('ascii', 0, 4) !== 'glTF' ||
      data.readUInt32LE(4) !== 2 || data.readUInt32LE(8) !== data.length) {
    throw new Error(`Invalid glTF v2 header/size: ${name}`);
  }
  let offset = 12;
  let document;
  while (offset < data.length) {
    if (offset + 8 > data.length) throw new Error(`Truncated chunk: ${name}`);
    const length = data.readUInt32LE(offset);
    const type = data.readUInt32LE(offset + 4);
    if (length % 4 || offset + 8 + length > data.length) throw new Error(`Invalid chunk size: ${name}`);
    if (offset === 12) {
      if (type !== 0x4e4f534a) throw new Error(`Missing JSON chunk: ${name}`);
      document = JSON.parse(data.toString('utf8', offset + 8, offset + 8 + length));
    }
    offset += 8 + length;
  }
  if (!document?.extensions?.VRMC_vrm_animation || !document.animations?.length) {
    throw new Error(`Missing VRM animation content: ${name}`);
  }
}

async function checkExisting(name, data) {
  try {
    const existing = await readFile(path.join(destination, name));
    if (!existing.equals(data)) throw new Error(`Refusing to overwrite differing file: ${name}`);
    return true;
  } catch (error) {
    if (error.code === 'ENOENT') return false;
    throw error;
  }
}

const listing = JSON.parse((await fetchBytes(
  `https://api.github.com/repos/Undi95/Hanami/contents/vrma?ref=${revision}`,
)).toString('utf8'));
const animations = listing.filter(entry => entry.type === 'file' &&
  /^[a-z0-9-]+\.vrma$/.test(entry.name) && !/^(rb-|world-)/.test(entry.name))
  .sort((a, b) => a.name.localeCompare(b.name, 'en'));
if (animations.length !== 31) throw new Error(`Expected 31 animations, found ${animations.length}`);
const docs = ['NOTICE.md', 'README.md'].map(name => {
  const entry = listing.find(item => item.type === 'file' && item.name === name);
  if (!entry) throw new Error(`Missing upstream ${name}`);
  return entry;
});
const entries = [...animations, ...docs];
const downloads = [];
for (let i = 0; i < entries.length; i += 4) {
  downloads.push(...await Promise.all(entries.slice(i, i + 4).map(async entry => {
    const source = base + entry.name;
    const data = await fetchBytes(source);
    if (data.length !== entry.size) throw new Error(`Source size mismatch: ${entry.name}`);
    const gitSha = createHash('sha1').update(`blob ${data.length}\0`).update(data).digest('hex');
    if (gitSha !== entry.sha) throw new Error(`Pinned Git blob mismatch: ${entry.name}`);
    const isAnimation = entry.name.endsWith('.vrma');
    if (isAnimation) verifyGlb(data, entry.name);
    const file = entry.name === 'README.md' ? 'README.hanami.md' : entry.name;
    const provenance = {file, ...(isAnimation ? {id: file.slice(0, -5), family: 'overte'} : {}),
      source, revision, sha256: sha256(data), bytes: data.length, git_blob_sha1: gitSha};
    return {file, data, provenance};
  })));
  console.log(`Verified ${downloads.length}/${entries.length} pinned files`);
}

const jsonBytes = value => Buffer.from(JSON.stringify(value, null, 2) + '\n');
const outputs = downloads.map(({file, data}) => ({file, data}));
for (const item of downloads.filter(item => item.file.endsWith('.vrma'))) {
  outputs.push({file: `${item.file}.source.json`, data: jsonBytes(item.provenance)});
}
outputs.push({file: 'sources.json', data: jsonBytes({repository, revision, family: 'overte',
  animation_count: 31, files: downloads.map(item => item.provenance)})});

// Check every destination before writing any file. Existing identical files are reused.
for (const item of outputs) item.exists = await checkExisting(item.file, item.data);
await mkdir(destination, {recursive: true});
for (const item of outputs) {
  if (!item.exists) await writeFile(path.join(destination, item.file), item.data, {flag: 'wx'});
  const saved = await readFile(path.join(destination, item.file));
  if (!saved.equals(item.data)) throw new Error(`Read-back mismatch: ${item.file}`);
}
console.log(JSON.stringify({count: animations.length, bytes: animations.reduce((sum, e) => sum + e.size, 0),
  ids: animations.map(entry => entry.name.slice(0, -5)), destination}, null, 2));
