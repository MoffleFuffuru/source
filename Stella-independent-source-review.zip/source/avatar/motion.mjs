export function smoothingAlpha(dt, speed = 5) {
  return 1 - Math.exp(-Math.max(0, dt) * speed);
}
export function mouthTarget(level, gain = 8) {
  return Math.min(.85, Math.max(0, level - .006) * gain);
}
