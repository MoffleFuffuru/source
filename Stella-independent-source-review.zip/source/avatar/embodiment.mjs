import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { VRMAnimationLoaderPlugin, createVRMAnimationClip } from '@pixiv/three-vrm-animation';
import { BASES, GESTURES, CUSTOM_POSES, INTERFACE_REACTIONS, ALL_CLIPS } from './movement-catalog.mjs';

const clamp = THREE.MathUtils.clamp;
const ease = x => { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); };
const alpha = (dt, rate) => 1 - Math.exp(-Math.max(0, dt) * rate);
const lowerBody = name => /^(hips|left(UpperLeg|LowerLeg|Foot|Toes)|right(UpperLeg|LowerLeg|Foot|Toes))$/.test(name);
const upper = name => !lowerBody(name);
const headOnly = name => /^(head|neck)$/.test(name);
const headGesture = name => ['small_nod', 'small_shake', 'small_head_tilt', 'head_turn'].includes(name);
const quaternion = (xyz, version) => new THREE.Quaternion().setFromEuler(new THREE.Euler(
  xyz[0] * (version === '0' ? -1 : 1), xyz[1], xyz[2] * (version === '0' ? -1 : 1), 'XYZ'));

export class MotionClip {
  constructor(clip, bones) {
    this.duration = clip.duration;
    this.rotation = new Map(); this.translation = new Map();
    for (const [name, bone] of Object.entries(bones)) {
      if (!bone) continue;
      for (const [property, map] of [['quaternion', this.rotation], ['position', this.translation]]) {
        const track = clip.tracks.find(t => t.name === `${bone.name}.${property}`);
        if (track) map.set(name, track.createInterpolant());
      }
    }
  }
  sample(time, rest, loop = false) {
    const t = loop ? ((time % this.duration) + this.duration) % this.duration : clamp(time, 0, this.duration);
    const pose = {};
    // Blend the end back to the actual first sample, retaining every finger key.
    const seam = loop ? ease((t - this.duration + .45) / .45) : 0;
    for (const [name, original] of Object.entries(rest)) {
      const interp = this.rotation.get(name);
      const q = interp ? new THREE.Quaternion().fromArray(interp.evaluate(t)) : original.clone();
      if (interp && seam) q.slerp(new THREE.Quaternion().fromArray(interp.evaluate(0)), seam);
      pose[name] = q.normalize();
    }
    let hips = null;
    const translation = this.translation.get('hips');
    if (translation) {
      hips = new THREE.Vector3().fromArray(translation.evaluate(t));
      if (seam) hips.lerp(new THREE.Vector3().fromArray(translation.evaluate(0)), seam);
    }
    return { pose, hips };
  }
}

function mix(a, b, weight, mask = () => true, includeHipsTranslation = true) {
  for (const name of Object.keys(a.pose)) if (mask(name) && b.pose[name]) a.pose[name].slerp(b.pose[name], weight);
  if (includeHipsTranslation && a.hips && b.hips && mask('hips')) a.hips.lerp(b.hips, weight);
  return a;
}

export class MovementDirector {
  constructor(vrm, bones, { random = Math.random, externalBones = new Set() } = {}) {
    this.vrm = vrm; this.bones = bones; this.random = random;
    this.externalBones = externalBones;
    this.rest = Object.fromEntries(Object.entries(bones).filter(([, b]) => b).map(([n,b]) => [n, b.quaternion.clone()]));
    this.restHips = bones.hips?.position.clone();
    this.clips = new Map(); this.time = 0; this.base = null;
    this.idleClip = null; this.idleClipId = ''; this.idleClipElapsed = 0;
    this.idleTime = 0; this.nextIdleChange = 18; this.lastIdleClip = '';
    this.action = null; this.lastAction = -10; this.lastClip = ''; this.sequence = null;
    this.phase = 'idle'; this.phaseAge = 0; this.speechTime = 0; this.speechStarted = false;
    this.packet = null; this.packetAt = -100; this.reaction = null; this.reactionWeight = 0;
    this.pendingReactionGesture = null;
    this.displayed = new Map(); this.displayedOffsets = {};
    this.gaze = new THREE.Vector2(); this.gazeTarget = new THREE.Vector2(); this.nextGaze = 0;
    this.audio = 0; this.previousAudio = 0; this.beat = 0; this.nextBeat = 0;
    this.disposed = false; this.errors = [];
    this.reference = {}; this.talk = null; this.talkWeight = 0; this.listen = null; this.listenWeight = 0;
  }
  async load() {
    const loader = new GLTFLoader();
    loader.register(parser => new VRMAnimationLoaderPlugin(parser));
    const load = async (id, source = `./assets/movement/${id}.vrma`) => {
      try {
        const gltf = await loader.loadAsync(source);
        if (this.disposed) return;
        const animation = gltf.userData.vrmAnimations?.[0];
        if (!animation) throw new Error('missing VRMA animation');
        const clip = new MotionClip(createVRMAnimationClip(animation, this.vrm), this.bones);
        this.clips.set(id, clip);
      } catch (error) { this.errors.push(`${id}: ${error.message}`); }
    };
    for (const id of BASES.idle) await load(id, `../motion/idle/${id}.vrma`);
    const firstIdle = BASES.idle.find(id => this.clips.has(id));
    if (!firstIdle) {
      await load('rb-idle');
      if (!this.clips.has('rb-idle')) throw new Error(this.errors.join('; '));
    }
    const idleBase = firstIdle || 'rb-idle';
    this.reference = this.clips.get(idleBase).sample(0, this.rest).pose;
    this.idleClip = this.clips.get(idleBase); this.idleClipId = idleBase;
    this.lastIdleClip = idleBase;
    this.base = firstIdle ? 'captured_motion_idle' : 'rocketbox_fallback';
    // Small bounded batches keep the first useful pose available immediately.
    this.loading = (async () => {
      const ids = ALL_CLIPS.filter(id => !BASES.idle.includes(id) && id !== 'rb-idle');
      for (let i = 0; i < ids.length && !this.disposed; i += 4) await Promise.all(ids.slice(i, i + 4).map(load));
    })();
    return this;
  }
  dispose() { this.disposed = true; this.clips.clear(); }
  choose(ids) {
    const candidates = ids.filter(id => this.clips.has(id) && id !== this.lastClip);
    return candidates[Math.floor(this.random() * candidates.length)] || ids.find(id => this.clips.has(id));
  }
  receive(packet) {
    this.packet = packet; this.packetAt = this.time;
    if (packet.sequence !== this.sequence) {
      this.sequence = packet.sequence;
      const name = packet.intent?.gesture || 'none';
      if (name !== 'none') this.pendingGesture = name;
      else this.pendingGesture = null;
      if (packet.state === 'idle' && this.action) this.action.cancelAt ??= this.time;
    }
  }
  react(name) {
    const definition = INTERFACE_REACTIONS[name];
    if (!definition) return false;
    // The UI reacts immediately; ignore the matching runtime echo.
    if (this.reaction?.name === name && this.time - this.reaction.started < 1.5) return true;
    this.reaction = { ...definition, name, started: this.time };
    if (name === 'discord_off') this.pendingReactionGesture = 'disappointed';
    else if (name === 'discord_on') this.pendingReactionGesture = 'small_nod';
    // No resetting of displayed bones or blend weights on a new event.
    return true;
  }
  play(name, { force = false } = {}) {
    if (!force && this.time - this.lastAction < 2.2) return false;
    const id = this.choose(GESTURES[name] || []);
    if (!id && !CUSTOM_POSES[name]) return false;
    this.lastAction = this.time; this.lastClip = id;
    this.action = { name, id, started: this.time, seconds: id ? this.clips.get(id).duration : 2.6 };
    return true;
  }
  preview(phase, expression = 'neutral') {
    this.receive({ sequence: (this.sequence || 0) + 1, state: phase, speaking: phase === 'speaking', speech_level: phase === 'speaking' ? .08 : 0,
      intent: { expression, intensity: .6, energy: .5, gesture: 'none', gaze: 'speaker' } });
  }
  update(dt, attention = {}) {
    dt = clamp(dt, 0, .1); this.time += dt;
    if (!this.base) return null;
    const fresh = this.time - this.packetAt < 2.2;
    const packet = fresh ? this.packet : null;
    const intent = packet?.intent || {};
    const level = packet?.speech_level || 0;
    if (!packet?.speaking) this.speechStarted = false;
    if (level > .008) this.speechStarted = true;
    const desiredPhase = packet?.speaking ? (this.speechStarted ? 'speaking' : 'anticipation')
      : packet?.state === 'listening' ? 'listening' : packet?.state === 'processing' ? 'anticipation' : 'idle';
    if (desiredPhase !== this.phase && !(this.phase === 'settle' && desiredPhase === 'idle')) {
      this.phase = desiredPhase === 'idle' && this.phase === 'speaking' ? 'settle' : desiredPhase;
      this.phaseAge = 0;
      if (this.phase === 'speaking') { this.speechTime = 0; this.talk = this.choose(BASES.speaking); }
      if (this.phase === 'listening') this.listen = this.choose(BASES.listening);
    }
    this.phaseAge += dt;
    if (this.phase === 'settle' && this.phaseAge > 1.1) this.phase = 'idle';
    if (this.phase === 'speaking') this.speechTime += dt;
    const isIdle = this.phase === 'idle' || this.phase === 'settle';
    if (isIdle) this.idleTime += dt;
    if (isIdle && this.idleTime >= this.nextIdleChange) {
      const candidates = BASES.idle.filter(id => this.clips.has(id) && id !== this.lastIdleClip);
      if (candidates.length) {
        this.idleClipId = candidates[Math.floor(this.random() * candidates.length)];
        this.lastIdleClip = this.idleClipId;
        this.idleClip = this.clips.get(this.idleClipId);
        this.idleClipElapsed = 0;
      }
      this.nextIdleChange = this.idleTime + 18 + this.random() * 14;
    }
    // Keep the captured idle advancing even while upper-body actions run. Its
    // hips and legs remain the authoritative lower-body motion in every phase.
    this.idleClipElapsed += dt;
    if (this.pendingReactionGesture) {
      const available = (GESTURES[this.pendingReactionGesture] || []).some(id => this.clips.has(id));
      if (available && this.play(this.pendingReactionGesture, { force: true })) this.pendingReactionGesture = null;
    }
    if (this.pendingGesture && ['speaking','listening','idle','settle'].includes(this.phase)) {
      if (this.play(this.pendingGesture)) this.pendingGesture = null;
    }
    const idle = this.phase === 'idle' || this.phase === 'settle';
    const current = {
      pose: Object.fromEntries(Object.entries(this.reference).map(([name, q]) => [name, q.clone()])),
      hips: this.restHips?.clone() || null,
    };
    const idleClipWeight = idle ? ease(this.idleClipElapsed / .9) : 0;
    if (idleClipWeight && this.idleClip) {
      // Idle contributes the complete hips/leg pose; this layer is reapplied
      // last below so speech, listening, and gestures cannot displace it.
      mix(current, this.idleClip.sample(this.idleClipElapsed, this.rest, true), idleClipWeight);
    }
    this.talkWeight = THREE.MathUtils.lerp(this.talkWeight, this.phase === 'speaking' ? .65 : 0, alpha(dt, 3));
    this.listenWeight = THREE.MathUtils.lerp(this.listenWeight, this.phase === 'listening' ? .55 : 0, alpha(dt, 3));
    if (this.talk && this.clips.has(this.talk)) mix(current, this.clips.get(this.talk).sample(this.speechTime, this.rest, true), this.talkWeight);
    if (this.listen && this.clips.has(this.listen)) mix(current, this.clips.get(this.listen).sample(this.phaseAge, this.rest, true), this.listenWeight);

    // Resting upper arms stay near the family's natural hanging pose. Keep
    // elbow, wrist and all thirty finger tracks intact. Explicit gestures below
    // may leave this resting envelope and return through the same blend path.
    for (const name of ['leftUpperArm','rightUpperArm']) {
      const q = current.pose[name], ref = this.reference[name];
      if (q && ref) {
        const angle = ref.angleTo(q), limit = .42;
        if (angle > limit) q.copy(ref.clone().slerp(q, limit / angle));
      }
    }
    let reaction = this.reaction;
    const reactionAge = reaction ? this.time - reaction.started : 100;
    if (reaction && reactionAge > reaction.seconds) { this.reaction = null; reaction = null; }
    const reactionTarget = reaction ? (this.phase === 'speaking' ? .6 : 1) : 0;
    this.reactionWeight = THREE.MathUtils.lerp(this.reactionWeight, reactionTarget, alpha(dt, 4));
    if (reaction) this.lastReaction = reaction;
    const offsets = {};
    const idleScale = idle ? 1 : .48;
    const breathe = Math.sin(this.time * 1.22) * .042 * idleScale;
    const sway = (Math.sin(this.time * .31) + .32 * Math.sin(this.time * .53 + 2)) * .052 * idleScale;
    // Slow weight shifts make the avatar visibly alive without inventing a gesture.
    const weightShift = idle ? Math.pow(Math.max(0, Math.sin(this.time * .115 + .8)), 5) : 0;
    offsets.spine = [breathe * .48, sway * .34, -sway * .32];
    offsets.chest = [breathe * .84, sway * .28, sway * .38];
    offsets.upperChest = [breathe * .24, 0, 0];
    offsets.neck = [Math.sin(this.time * .49) * .009 * idleScale, 0, 0];
    offsets.head = [0, 0, sway * .72];
    if (idle) {
      offsets.leftShoulder = [0, 0, .012 + breathe * .15];
      offsets.rightShoulder = [0, 0, -.012 - breathe * .15];
      offsets.leftUpperArm = [.018 + weightShift * .026, 0, .012 + sway * .12];
      offsets.rightUpperArm = [.018 - weightShift * .026, 0, -.012 - sway * .12];
      offsets.leftLowerArm = [-.014 - weightShift * .018, .008, .006];
      offsets.rightLowerArm = [-.014 + weightShift * .018, -.008, -.006];
      offsets.leftHand = [0, 0, .012 * Math.sin(this.time * .62)];
      offsets.rightHand = [0, 0, -.012 * Math.sin(this.time * .62 + .8)];
      // Subtle, asynchronous finger relaxation prevents rigid open-palm hands.
      const fingerRelax = .035 + .018 * Math.sin(this.time * .72);
      for (const side of ['left', 'right']) {
        for (const finger of ['Thumb', 'Index', 'Middle', 'Ring', 'Little']) {
          for (const joint of ['Proximal', 'Intermediate', 'Distal']) {
            const bone = `${side}${finger}${joint}`;
            if (current.pose[bone]) offsets[bone] = [fingerRelax * (finger === 'Thumb' ? .45 : 1), 0, 0];
          }
        }
      }
    }
    const addPose = (name, weight) => {
      for (const [bone, angles] of Object.entries(CUSTOM_POSES[name] || {})) {
        offsets[bone] ??= [0,0,0];
        angles.forEach((v,i) => { offsets[bone][i] += v * weight; });
      }
    };
    if (this.lastReaction) addPose(this.lastReaction.pose, this.reactionWeight);
    let actionName = 'none';
    let actionWeight = 0;
    if (this.action) {
      const a = this.action, age = this.time - a.started;
      let weight = ease(age / .55) * (1 - ease((age - a.seconds + .65) / .65));
      if (a.cancelAt != null) weight *= 1 - ease((this.time - a.cancelAt) / .6);
      if (age >= a.seconds || (a.cancelAt != null && this.time - a.cancelAt > .6)) this.action = null;
      else {
        actionName = a.name;
        actionWeight = weight;
        if (a.id) mix(current, this.clips.get(a.id).sample(age, this.rest), weight * clamp(intent.intensity ?? .7, .35, 1), headGesture(a.name) ? headOnly : undefined);
        else addPose(a.name, weight);
      }
    }
    if (this.time >= this.nextGaze) {
      this.gazeTarget.set((this.random() - .5) * .30, (this.random() - .5) * .10);
      this.nextGaze = this.time + 3 + this.random() * 5;
    }
    const gazeTarget = this.gazeTarget.clone();
    if (['listening','speaking'].includes(this.phase)) gazeTarget.multiplyScalar(.2);
    else if (this.phase === 'anticipation') gazeTarget.set(.14, -.03);
    else if (attention.fresh && attention.speed < .7) gazeTarget.lerp(new THREE.Vector2(clamp(attention.x || 0,-1,1) * .26, -clamp(attention.y || 0,-1,1) * .1), .7);
    if (reaction?.gaze) gazeTarget.lerp(new THREE.Vector2(...reaction.gaze), .45 * this.reactionWeight);
    const gazeDelta = gazeTarget.sub(this.gaze).multiplyScalar(alpha(dt, 2.8));
    gazeDelta.clampLength(0, .45 * dt); this.gaze.add(gazeDelta);
    this.audio = THREE.MathUtils.lerp(this.audio, level, alpha(dt, 8));
    if (this.phase === 'speaking' && level - this.previousAudio > .015 && this.time >= this.nextBeat) {
      this.beat = .018 * clamp(intent.energy ?? .4, .1, 1); this.nextBeat = this.time + .8;
    }
    this.previousAudio = level; this.beat *= Math.exp(-dt * 5);
    offsets.head ??= [0,0,0]; offsets.neck ??= [0,0,0]; offsets.chest ??= [0,0,0];
    offsets.head[0] += this.gaze.y * .65; offsets.head[1] += this.gaze.x * .65;
    offsets.neck[0] += this.gaze.y * .35; offsets.neck[1] += this.gaze.x * .35;
    offsets.chest[0] += this.beat;
    for (const [name, values] of Object.entries(offsets)) current.pose[name]?.multiply(quaternion(values, this.vrm.meta?.metaVersion));
    this.externalOverlay = { pose: current.pose, offsets, actionName, actionWeight };
    const idleAuthority = this.idleClip?.sample(this.idleClipElapsed, this.rest, true);
    if (idleAuthority) {
      for (const [name, q] of Object.entries(idleAuthority.pose)) {
        if (lowerBody(name) && current.pose[name]) current.pose[name].copy(q);
      }
      if (current.hips && idleAuthority.hips) current.hips.copy(idleAuthority.hips);
    }
    for (const [name, q] of Object.entries(current.pose)) {
      if (this.externalBones.has(name)) continue;
      const bone = this.bones[name]; if (!bone) continue;
      if (!upper(name)) { bone.quaternion.copy(q); continue; }
      let displayed = this.displayed.get(name);
      if (!displayed) { displayed = q.clone(); this.displayed.set(name, displayed); }
      else {
        const angle = displayed.angleTo(q), maxSpeed = headOnly(name) ? 1.3 : /Hand|Thumb|Index|Middle|Ring|Little/.test(name) ? 6 : 2.8;
        const weight = angle > 1e-6 ? Math.min(alpha(dt, headOnly(name) ? 7 : 12), maxSpeed * dt / angle) : 1;
        displayed.slerp(q, weight).normalize();
      }
      bone.quaternion.copy(displayed);
    }
    if (!this.externalBones.has('hips') && current.hips && this.bones.hips) this.bones.hips.position.copy(current.hips);
    return {
      phase: this.phase, gesture: actionName, gaze: [this.gaze.x, this.gaze.y],
      expression: this.phase === 'speaking' && intent.expression && intent.expression !== 'neutral' ? intent.expression : reaction && this.reactionWeight > .15 ? reaction.expression : intent.expression || 'neutral',
      intensity: this.phase === 'speaking' ? intent.intensity ?? .4 : reaction && this.reactionWeight > .15 ? reaction.intensity : intent.intensity ?? .3,
      reaction: reaction?.name || '', reactionWeight: this.reactionWeight,
      clips: this.clips.size, base: this.base, errors: this.errors,
    };
  }

  applyCapturedUpperOverlay() {
    const overlay = this.externalOverlay;
    if (!overlay) return;
    // Native captured motion retains absolute ownership of hips, spine and legs.
    // Gaze is additive; deliberate gestures may blend only shoulders/arms/hands.
    for (const name of ['head', 'neck']) {
      const bone = this.bones[name];
      if (bone && this.externalBones.has(name) && overlay.offsets[name]) {
        bone.quaternion.multiply(quaternion(overlay.offsets[name], this.vrm.meta?.metaVersion)).normalize();
      }
    }
    if (overlay.actionName === 'none') return;
    for (const [name, q] of Object.entries(overlay.pose)) {
      if (!/^(left|right)(Shoulder|UpperArm|LowerArm|Hand|Thumb|Index|Middle|Ring|Little)/.test(name)) continue;
      const bone = this.bones[name];
      if (bone && this.externalBones.has(name)) bone.quaternion.slerp(q, overlay.actionWeight).normalize();
    }
  }
}
