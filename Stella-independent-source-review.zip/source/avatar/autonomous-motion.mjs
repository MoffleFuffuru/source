import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { VRMAnimationLoaderPlugin, createVRMAnimationClip } from '@pixiv/three-vrm-animation';
import { MovementDirector, MotionClip } from './embodiment.mjs';
import { BASES, GESTURES, CUSTOM_POSES, INTERFACE_REACTIONS } from './movement-catalog.mjs';

const clamp = THREE.MathUtils.clamp;
const ease = x => { x = clamp(x, 0, 1); return x*x*x*(10+x*(-15+6*x)); };
const lower = n => /^(hips|(?:left|right)(?:UpperLeg|LowerLeg|Foot|Toes))$/.test(n);
const quick = n => /head|neck|Shoulder|Arm|Hand|Thumb|Index|Middle|Ring|Little/i.test(n);
const clone = p => ({pose: Object.fromEntries(Object.entries(p.pose).map(([n,q])=>[n,q.clone()])), hips:p.hips?.clone()});
const rotation = v => new THREE.Quaternion().setFromEuler(new THREE.Euler(...v));
const OVERTE = {
  idle:['idle','idle-2','idle-3','idle-4','idle-7'],
  speaking:['idle-talking','idle-talking-4','idle-talking-5','idle-talking-6','idle-talking-7'],
  gestures:{small_nod:['nod','nod-2','nod-3','nod-4','nod-5'], small_shake:['shake'],
    head_turn:['neutral'], small_head_tilt:['neutral'], celebrate:['happy','happy-2','happy-3','happy-6'],
    annoyed:['angry','angry-2'], disappointed:['sad'], think:['think','think-2'],
    stretch:['relaxed','relaxed-2','relaxed-3'], explain:['idle-talking-4','idle-talking-5','idle-talking-6','idle-talking-7']},
};
export const FAMILY_IDS = {
  stella: [...BASES.idle],
  rocketbox: [...new Set([...Object.values(GESTURES).flat(), ...BASES.listening, ...BASES.speaking,
    'rb-idle','rb-idle-2','rb-idle-3','rb-idle-4'])],
  overte: [...new Set([...OVERTE.idle,...OVERTE.speaking,...Object.values(OVERTE.gestures).flat(),'raise-hand','raise-hand-2'])],
};

// World-space two-segment geometry. Written for Stella's normalized VRM rig.
export class StandingContacts {
  constructor(bones) { this.bones=bones; this.anchors=new Map(); this.error=0; }
  reset() { this.anchors.clear(); }
  solve() {
    this.error=0;
    for (const side of ['left','right']) {
      const a=this.bones[side+'UpperLeg'], b=this.bones[side+'LowerLeg'], foot=this.bones[side+'Foot'];
      if (!a || !b || !foot) continue;
      a.updateWorldMatrix(true,true);
      let anchor=this.anchors.get(side);
      if (!anchor) {
        anchor={p:foot.getWorldPosition(new THREE.Vector3()),q:foot.getWorldQuaternion(new THREE.Quaternion())};
        this.anchors.set(side,anchor);
      }
      const h=a.getWorldPosition(new THREE.Vector3()), k=b.getWorldPosition(new THREE.Vector3()), f=foot.getWorldPosition(new THREE.Vector3());
      const l1=h.distanceTo(k), l2=k.distanceTo(f), dir=anchor.p.clone().sub(h), raw=dir.length();
      if (Math.min(l1,l2,raw)<1e-6) continue;
      dir.normalize();
      const dist=clamp(raw,Math.abs(l1-l2)+1e-5,l1+l2-1e-5);
      const pole=k.clone().sub(h).addScaledVector(dir,-k.clone().sub(h).dot(dir));
      if (pole.lengthSq()<1e-8) pole.set(0,0,1).addScaledVector(dir,-dir.z);
      pole.normalize();
      const along=(l1*l1-l2*l2+dist*dist)/(2*dist);
      const knee=h.clone().addScaledVector(dir,along).addScaledVector(pole,Math.sqrt(Math.max(0,l1*l1-along*along)));
      const turn=(bone,from,to) => {
        const delta=new THREE.Quaternion().setFromUnitVectors(from.normalize(),to.normalize());
        const world=bone.getWorldQuaternion(new THREE.Quaternion()).premultiply(delta);
        const parent=bone.parent?.getWorldQuaternion(new THREE.Quaternion()) || new THREE.Quaternion();
        bone.quaternion.copy(parent.invert().multiply(world)).normalize();
        bone.updateWorldMatrix(false,true);
      };
      turn(a,k.clone().sub(h),knee.clone().sub(h));
      const at=b.getWorldPosition(new THREE.Vector3());
      turn(b,foot.getWorldPosition(new THREE.Vector3()).sub(at),anchor.p.clone().sub(at));
      foot.quaternion.copy(foot.parent.getWorldQuaternion(new THREE.Quaternion()).invert().multiply(anchor.q));
      foot.updateWorldMatrix(false,true);
      this.error=Math.max(this.error,foot.getWorldPosition(new THREE.Vector3()).distanceTo(anchor.p));
    }
  }
}

export class AutonomousDirector extends MovementDirector {
  constructor(vrm,bones,options={}) {
    super(vrm,bones,options);
    this.family='stella'; this.contacts=new StandingContacts(bones);
    this.modeLayers=[]; this.actions=[]; this.history=[]; this.variantHistory=new Map();
    this.nextAmbient=8; this.nextModeChange=10; this.nextIdleChange=20;
    this.currentPose=null; this.poseTransition=null; this.transitionAge=0;
    this.idleFirst=null; this.restArms={}; this.motionScale=1;
    for (const side of ['left','right']) {
      const sign=Math.sign(bones[side+'LowerArm']?.position.x || (side==='left'?1:-1));
      for (const part of ['Shoulder','UpperArm','LowerArm','Hand']) {
        const n=side+part; if(!this.rest[n])continue;
        const angles=part==='UpperArm'?[0,0,-sign*1.34]:part==='LowerArm'?[0,-sign*.10,0]:[0,0,0];
        this.restArms[n]=this.rest[n].clone().multiply(rotation(angles));
      }
    }
    this.moodShoulders=[0,0];
  }
  async load() {
    await super.load();
    await this.loading;
    const loader=new GLTFLoader(); loader.register(p=>new VRMAnimationLoaderPlugin(p));
    this.extendedLoading=(async()=>{
      for(const family of ['rocketbox','overte']) {
        const ids=FAMILY_IDS[family].filter(id=>!this.clips.has(id));
        for(let i=0;i<ids.length&&!this.disposed;i+=4) await Promise.all(ids.slice(i,i+4).map(async id=>{
          try {
            const gltf=await loader.loadAsync(`./assets/movement/${family==='overte'?'overte/':''}${id}.vrma`);
            if(this.disposed)return;
            const source=gltf.userData.vrmAnimations?.[0]; if(!source)throw Error('missing animation');
            this.clips.set(id,new MotionClip(createVRMAnimationClip(source,this.vrm),this.bones));
          }catch(e){this.errors.push(`${id}: ${e.message}`);}
        }));
      }
    })();
    await this.extendedLoading;
    this.family='stella';
    this.selectFamilyBase();
    return this;
  }
  idleIds(family=this.family) {
    return family==='stella'?BASES.idle:family==='overte'?OVERTE.idle:['rb-idle','rb-idle-2','rb-idle-3','rb-idle-4'];
  }
  selectFamilyBase() {
    const ids=this.idleIds();
    const id=ids.find(candidate=>this.clips.has(candidate));
    if(!id) return false;
    this.idleClipId=id;this.idleClip=this.clips.get(id);this.idleClipElapsed=0;
    this.idleFirst=this.idleClip.sample(0,this.rest).pose;
    this.reference=this.idleFirst;this.lastIdleClip=id;
    this.base=this.family==='stella'?'stella_native_idle':this.family==='overte'?'overte_face_to_face':'rocketbox_face_to_face';
    return true;
  }
  choose(ids) {
    const valid=ids.filter(id=>this.clips.has(id));
    const candidates=valid.filter(id=>!this.history.slice(-3).includes(id));
    const pool=candidates.length?candidates:valid.filter(id=>id!==this.lastClip);
    const id=(pool.length?pool:valid)[Math.floor(this.random()*(pool.length||valid.length))];
    if(id){this.lastClip=id; this.history.push(id); if(this.history.length>12)this.history.shift();}
    return id;
  }
  setFamily(family) {
    if(!FAMILY_IDS[family] || !this.idleIds(family).some(id=>this.clips.has(id)))return false;
    if(this.family===family)return true;
    this.captureTransition(); this.family=family; this.actions=[]; this.modeLayers=[];
    this.contacts.reset();this.selectFamilyBase();
    this.nextModeChange=0; return true;
  }
  captureTransition() {
    this.poseTransition=this.currentPose?clone(this.currentPose):null;
    this.transitionAge=0;
  }
  receive(packet) {
    const previous=this.sequence;
    super.receive(packet);
    if(packet.sequence!==previous && ['listening','processing','idle'].includes(packet.state)) {
      for(const a of this.actions) a.cancelAt ??= this.time;
    }
  }
  play(name,{force=false}={}) {
    if(!force && this.time-this.lastAction<3)return false;
    const ids=this.family==='stella'?[]:this.family==='overte'?OVERTE.gestures[name]:GESTURES[name];
    const id=this.choose(name==='explain'&&this.family==='rocketbox'?BASES.speaking:(ids||[]));
    const procedural=['laugh','wave','shrug','curious','pout','pleased','startle','lean_in','lean_back','small_head_tilt','head_turn','small_nod','small_shake','explain'].includes(name);
    if(!id&&!CUSTOM_POSES[name]&&!procedural)return false;
    this.captureTransition();
    for(const a of this.actions)a.cancelAt ??= this.time;
    const variant=((this.variantHistory.get(name)??-1)+1+Math.floor(this.random()*2))%3;
    this.variantHistory.set(name,variant);
    const seconds=id?this.clips.get(id).duration:3.4+variant*.4;
    this.action={name,id,variant,started:this.time,seconds:Math.max(2,seconds)};
    this.actions.push(this.action); this.actions=this.actions.slice(-4);
    this.lastAction=this.time; this.nextAmbient=this.time+seconds+5+this.random()*7;
    return true;
  }
  sampleIdle(dt) {
    this.idleClipElapsed+=dt;
    if(this.time>=this.nextIdleChange) {
      const id=this.choose(this.idleIds());
      if(id&&id!==this.idleClipId){
        this.outgoingIdle={clip:this.idleClip,elapsed:this.idleClipElapsed,age:0,first:this.idleFirst};
        this.idleClipId=id; this.idleClip=this.clips.get(id); this.idleClipElapsed=0;
        this.idleFirst=this.idleClip.sample(0,this.rest).pose;
      }
      this.nextIdleChange=this.time+18+this.random()*16;
    }
    const relax=(sample,first)=>{
      for(const [n,q] of Object.entries(this.restArms)) {
        if(!sample.pose[n])continue;
        const delta=(first[n]||this.rest[n]).clone().invert().multiply(sample.pose[n]);
        sample.pose[n].copy(q).multiply(new THREE.Quaternion().slerp(delta,/Shoulder/.test(n)?.2:.10));
      }
      return sample;
    };
    const p=relax(this.idleClip.sample(this.idleClipElapsed,this.rest,true),this.idleFirst||this.reference);
    if(this.outgoingIdle) {
      const old=this.outgoingIdle; old.elapsed+=dt;old.age+=dt;
      const from=relax(old.clip.sample(old.elapsed,this.rest,true),old.first||this.reference);
      for(const [n,q] of Object.entries(p.pose))q.copy(from.pose[n]);
      const to=relax(this.idleClip.sample(this.idleClipElapsed,this.rest,true),this.idleFirst||this.reference);
      for(const [n,q] of Object.entries(p.pose))q.slerp(to.pose[n],ease(old.age/1.2));
      if(p.hips&&from.hips)p.hips.copy(from.hips).lerp(to.hips,ease(old.age/1.2));
      if(old.age>=1.2)this.outgoingIdle=null;
    }
    return p;
  }
  update(dt,attention={}) {
    dt=clamp(dt,0,.1);this.time+=dt;if(!this.idleClip)return null;
    const packet=this.time-this.packetAt<2.2?this.packet:null, intent=packet?.intent||{};
    const level=Number.isFinite(packet?.speech_level)?packet.speech_level:0;
    this.audio=level;
    if(!packet?.speaking)this.speechStarted=false;
    if(level>.008)this.speechStarted=true;
    const phase=packet?.speaking?(this.speechStarted?'speaking':'anticipation'):packet?.state==='listening'?'listening':packet?.state==='processing'?'anticipation':'idle';
    if(phase!==this.phase){this.captureTransition();this.phase=phase;this.phaseAge=0;this.nextModeChange=0;}
    this.phaseAge+=dt;
    if(this.nextModeChange<=this.time) {
      for(const l of this.modeLayers)l.exit ??=this.time;
      const ids=this.phase==='speaking'?(this.family==='overte'?OVERTE.speaking:this.family==='rocketbox'?BASES.speaking:[]):this.phase==='listening'&&this.family==='rocketbox'?BASES.listening:[];
      const id=this.choose(ids);
      if(id)this.modeLayers.push({id,start:this.time});
      this.modeLayers=this.modeLayers.slice(-4);
      this.nextModeChange=this.time+8+this.random()*7;
    }
    const p=this.sampleIdle(dt);
    for(const layer of this.modeLayers) {
      const sampled=this.clips.get(layer.id).sample(this.time-layer.start,this.rest,true);
      for(const [n,q] of Object.entries(p.pose)) {
        if(lower(n))continue;
        const fade=quick(n)?.5:1;
        const weight=ease((this.time-layer.start)/fade)*(layer.exit==null?1:1-ease((this.time-layer.exit)/fade));
        q.slerp(sampled.pose[n],weight);
      }
    }
    this.modeLayers=this.modeLayers.filter(l=>l.exit==null||this.time-l.exit<1);
    if(this.pendingReactionGesture){if(this.play(this.pendingReactionGesture,{force:true}))this.pendingReactionGesture=null;}
    if(this.pendingGesture&&this.phase!=='anticipation'){if(this.play(this.pendingGesture))this.pendingGesture=null;}
    const mood=intent.expression||'neutral';
    if(this.time>=this.nextAmbient&&!this.actions.length) {
      const options=this.phase==='speaking'?['explain','explain','head_turn']:this.phase==='anticipation'?['curious']:['curious','pleased','head_turn'];
      // Semantic laughs/agreements only come from acting directives.
      if(this.phase!=='listening'&&this.random()<.65)this.play(options[Math.floor(this.random()*options.length)]);
      this.nextAmbient=this.time+7+this.random()*9;
    }
    let actionName='none',actionWeight=0;
    const add=(name,xyz,w=1)=>p.pose[name]?.multiply(rotation(xyz.map(x=>x*w)));
    const energy=clamp(intent.energy??.35,0,1), motion=clamp(this.motionScale,0,2);
    const breath=Math.sin(this.time*(1.1+energy*.22))*.012*motion;
    add('chest',[breath,0,Math.sin(this.time*.27)*.008*motion]);
    const poses={annoyed:[-.025,0,.015],sad:[.035,0,0],concerned:[.025,0,0],excited:[-.018,0,0],embarrassed:[.025,.025,0]};
    const target=poses[mood]||[0,0,0];this.moodPose??=[0,0,0];
    this.moodPose=this.moodPose.map((x,i)=>THREE.MathUtils.damp(x,target[i],2,dt));add('chest',this.moodPose);
    const shoulderMood={sad:-.025,concerned:.018,annoyed:.025,excited:.018,embarrassed:.012,curious:.012};
    const shoulderTarget=shoulderMood[mood]||0;
    this.moodShoulders=this.moodShoulders.map(x=>THREE.MathUtils.damp(x,shoulderTarget,2,dt));
    add('leftShoulder',[0,0,this.moodShoulders[0]]);add('rightShoulder',[0,0,-this.moodShoulders[1]]);
    for(const a of this.actions) {
      const age=this.time-a.started;
      const clip=a.id?this.clips.get(a.id).sample(age,this.rest):null;
      for(const [n,q]of Object.entries(p.pose)) {
        if(lower(n))continue;
        if(['small_nod','small_shake','head_turn','small_head_tilt'].includes(a.name)&&!['head','neck'].includes(n))continue;
        const fade=quick(n)?.5:1;
        const w=ease(age/fade)*(1-ease((age-a.seconds+fade)/fade))*(a.cancelAt==null?1:1-ease((this.time-a.cancelAt)/fade));
        if(clip)q.slerp(clip.pose[n],w);
      }
      const w=ease(age/.5)*(1-ease((age-a.seconds+1)/1))*(a.cancelAt==null?1:1-ease((this.time-a.cancelAt)/.65));
      actionName=a.name;actionWeight=w;
      for(const [n,xyz]of Object.entries(CUSTOM_POSES[a.name]||{}))add(n,xyz,w);
      if(a.name==='laugh') {
        const pulse=Math.sin(age*(7+a.variant))*.012;
        add('chest',[pulse*(1+a.variant*.3),0,0],w);add('head',[-.018,0,(a.variant-1)*.035],w);
        if(a.variant===1)add('rightLowerArm',[0,.18,.06],w);
        if(a.variant===2)add('leftLowerArm',[0,-.22,-.06],w);
      }
      if(!a.id&&a.name==='wave'){
        add('rightUpperArm',[-.35,0,-.65],w);add('rightLowerArm',[0,0,-1.1],w);add('rightHand',[0,Math.sin(age*8)*.18,0],w);
      }
      if(!a.id&&a.name==='shrug')for(const side of ['left','right'])add(side+'Shoulder',[0,0,(side==='left'?1:-1)*.10],w);
      if(!a.id&&a.name==='explain') {
        const side=a.variant===1?'left':'right',sign=side==='left'?1:-1;
        add(side+'UpperArm',[-.10,0,sign*.24],w);
        add(side+'LowerArm',[0,sign*.08,sign*-.18],w);
        add(side+'Hand',[0,0,sign*-.08],w);
      }
      if(a.name==='head_turn')add('head',[0,(a.variant-1)*.1,.025],w);
      if(a.name==='small_head_tilt')add('head',[0,0,(a.variant===1?-1:1)*.07],w);
    }
    this.actions=this.actions.filter(a=>this.time-a.started<a.seconds&&(a.cancelAt==null||this.time-a.cancelAt<1));
    this.action=this.actions.at(-1)||null;
    if(this.reaction&&this.time-this.reaction.started>this.reaction.seconds)this.reaction=null;
    this.reactionWeight=THREE.MathUtils.damp(this.reactionWeight,this.reaction?1:0,3,dt);
    if(this.reaction)this.lastReaction=this.reaction;
    if(this.lastReaction)for(const[n,xyz]of Object.entries(CUSTOM_POSES[this.lastReaction.pose]||{}))add(n,xyz,this.reactionWeight);
    if(this.time>=this.nextGaze){this.gazeTarget.set((this.random()-.5)*.22,(this.random()-.5)*.07);this.nextGaze=this.time+3+this.random()*5;}
    const gaze=this.gazeTarget.clone();
    if(['speaking','listening'].includes(this.phase))gaze.multiplyScalar(.25);
    if(this.phase==='anticipation')gaze.set(.10,-.025);
    if(attention.fresh&&attention.speed<.7&&this.phase==='idle')gaze.lerp(new THREE.Vector2(clamp(attention.x||0,-1,1)*.18,-clamp(attention.y||0,-1,1)*.06),.4);
    this.gaze.lerp(gaze,1-Math.exp(-dt*2.5));add('head',[this.gaze.y,this.gaze.x,0]);
    if(this.poseTransition){
      this.transitionAge+=dt;
      for(const[n,q]of Object.entries(p.pose)) {
        const target=q.clone();
        q.copy(this.poseTransition.pose[n]).slerp(target,ease(this.transitionAge/(quick(n)?.5:1)));
      }
      if(p.hips&&this.poseTransition.hips)p.hips.copy(this.poseTransition.hips).lerp(p.hips,ease(this.transitionAge/1));
      if(this.transitionAge>=1)this.poseTransition=null;
    }
    // A single final pose owner. Rate limiting catches severe asset discontinuities;
    // normal source motion passes through without another low-pass filter.
    for(const[n,q]of Object.entries(p.pose)){
      const bone=this.bones[n];if(!bone)continue;
      const old=this.currentPose?.pose[n];
      if(old&&!lower(n)){
        const angle=old.angleTo(q), speed=/Hand|Thumb|Index|Middle|Ring|Little/.test(n)?5:quick(n)?2.2:1.4;
        if(angle>speed*dt&&dt>0)q.copy(old.clone().slerp(q,speed*dt/angle));
      }
      bone.quaternion.copy(q);
    }
    if(p.hips&&this.bones.hips)this.bones.hips.position.copy(p.hips);
    this.contacts.solve();
    this.currentPose=clone(p);
    const reaction=this.reaction&&this.reactionWeight>.15?this.reaction:null;
    return {phase:this.phase,gesture:actionName,variant:this.action?.variant??null,gaze:[this.gaze.x,this.gaze.y],
      expression:actionName==='laugh'?'amused':reaction?.expression||mood,intensity:reaction?.intensity??intent.intensity??.3,
      reaction:reaction?.name||'',reactionWeight:this.reactionWeight,clips:this.clips.size,base:this.base,family:this.family,
      errors:this.errors,footError:this.contacts.error,transitioning:this.poseTransition!=null||this.modeLayers.some(l=>this.time-l.start<1||l.exit!=null),
      relaxedArms:true};
  }
}
