const { app, BrowserWindow, ipcMain, dialog, globalShortcut, screen, safeStorage } = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const http = require('node:http');
const dgram = require('node:dgram');
const { spawn } = require('node:child_process');
const { validatePacket } = require('./protocol.cjs');

const runtimePath = path.join(process.env.LOCALAPPDATA || app.getPath('appData'), 'Stella');
fs.mkdirSync(runtimePath, { recursive: true });
app.setPath('userData', runtimePath);
app.setPath('sessionData', runtimePath);
app.setAppUserModelId('com.princemoffle.stella');
let win, cameraWin, socket, shellProcess, accountProcess, attentionTimer, locked = false, closingWindow = false;
let settings = {};
const settingsPath = () => path.join(app.getPath('userData'), 'stella-shell-settings.json');
const rootPath = path.resolve(__dirname, '..');
const profilePath = app.isPackaged ? runtimePath : rootPath;
const runtimeEnv = { ...process.env, STELLA_APP_ROOT: rootPath, STELLA_PROFILE_DIR: profilePath };
const pythonPath = path.join(rootPath, '.venv', 'Scripts', 'python.exe');
const accountTokenPath = path.join(profilePath, 'data', 'account-session.bin');
let accountToken = '';
function saveSettings() { try { fs.writeFileSync(settingsPath(), JSON.stringify(settings)); } catch (error) { console.error(error.message); } }
function shellRequest(route, method = 'GET', body) {
  return new Promise((resolve, reject) => {
    const payload = body ? Buffer.from(JSON.stringify(body)) : null;
    const request = http.request({ hostname: '127.0.0.1', port: 39541, path: route, method, timeout: 5000,
      headers: payload ? { 'Content-Type': 'application/json', 'Content-Length': payload.length } : {} }, response => {
        let raw = ''; response.setEncoding('utf8'); response.on('data', chunk => { raw += chunk; }); response.on('end', () => {
          let parsed; try { parsed = JSON.parse(raw || '{}'); } catch { parsed = { error: raw || 'Invalid response' }; }
          if (response.statusCode >= 400) reject(new Error(parsed.error || `Local service returned ${response.statusCode}`)); else resolve(parsed);
        });
      });
    request.on('timeout', () => request.destroy(new Error('Stella runtime is still starting.'))); request.on('error', reject);
    if (payload) request.write(payload); request.end();
  });
}
function accountRequest(route, method = 'GET', body) {
  return new Promise((resolve, reject) => {
    const payload = body ? Buffer.from(JSON.stringify(body)) : null;
    const headers = { ...(accountToken ? { Authorization: `Bearer ${accountToken}` } : {}) };
    if (payload) { headers['Content-Type'] = 'application/json'; headers['Content-Length'] = payload.length; }
    const request = http.request({ hostname: '127.0.0.1', port: 8767, path: route, method, timeout: 8000, headers }, response => {
      let raw = ''; response.setEncoding('utf8'); response.on('data', chunk => { raw += chunk; }); response.on('end', () => {
        let parsed = {}; try { parsed = raw ? JSON.parse(raw) : {}; } catch { parsed = { detail: raw || 'Invalid account-service response' }; }
        if (response.statusCode >= 400) reject(new Error(parsed.detail || parsed.error || `Account service returned ${response.statusCode}`)); else resolve(parsed);
      });
    });
    request.on('timeout', () => request.destroy(new Error('Account service is still starting.'))); request.on('error', reject);
    if (payload) request.write(payload); request.end();
  });
}
function saveAccountToken(token) {
  accountToken = token || '';
  try {
    fs.mkdirSync(path.dirname(accountTokenPath), { recursive: true });
    if (!accountToken) { if (fs.existsSync(accountTokenPath)) fs.unlinkSync(accountTokenPath); return; }
    if (!safeStorage.isEncryptionAvailable()) throw new Error('Windows secure storage is unavailable.');
    fs.writeFileSync(accountTokenPath, safeStorage.encryptString(accountToken));
  } catch (error) { accountToken = ''; throw error; }
}
function loadAccountToken() {
  try {
    if (safeStorage.isEncryptionAvailable() && fs.existsSync(accountTokenPath))
      accountToken = safeStorage.decryptString(fs.readFileSync(accountTokenPath));
  } catch { accountToken = ''; }
}
function startAccountService() {
  const serviceEnv = { ...runtimeEnv, PYTHONPATH: path.join(rootPath, 'backend'), STELLA_BACKEND_DB: path.join(profilePath, 'data', 'accounts.sqlite3') };
  try {
    accountProcess = spawn(fs.existsSync(pythonPath) ? pythonPath : 'python', ['-m', 'stella_backend'], {
      cwd: rootPath, env: serviceEnv, windowsHide: true, stdio: ['ignore', 'ignore', 'pipe'],
    });
    accountProcess.stderr.on('data', data => console.error(`Stella account service: ${data}`));
    accountProcess.on('exit', code => { if (win && !win.isDestroyed()) win.webContents.send('account-service-state', { online: false, detail: `Account service stopped (${code ?? 'unknown'}).` }); });
  } catch (error) { console.error(`Could not start Stella account service: ${error.message}`); }
}
function startRuntime() {
  const executable = fs.existsSync(pythonPath) ? pythonPath : 'python';
  try {
    shellProcess = spawn(executable, ['main.py', '--electron-shell'], { cwd: rootPath, windowsHide: true, stdio: ['ignore', 'ignore', 'pipe'] });
    shellProcess.stderr.on('data', data => console.error(`Stella runtime: ${data}`));
    shellProcess.on('exit', code => { if (win && !win.isDestroyed()) win.webContents.send('bridge-error', `Stella runtime stopped (${code ?? 'unknown'}).`); });
  } catch (error) {
    if (win && !win.isDestroyed()) win.webContents.send('bridge-error', `Could not start the Stella runtime: ${error.message}`);
  }
}
function toggleLock() { locked = !locked; win.setIgnoreMouseEvents(locked, { forward: true }); win.webContents.send('lock', locked); }
function toggleCameraOutput() {
  if (cameraWin && !cameraWin.isDestroyed()) {
    cameraWin.close();
    return;
  }
  cameraWin = new BrowserWindow({
    width: 960, height: 540, minWidth: 480, minHeight: 270,
    frame: false, backgroundColor: '#090d13', show: false, title: 'Stella Cam // Live Avatar',
    icon: path.join(__dirname, 'assets', 'stella_app_icon.ico'),
    // Discord captures this window while it is unfocused. Prevent Chromium
    // from pausing its requestAnimationFrame loop in that state.
    webPreferences: { preload: path.join(__dirname, 'preload.cjs'), contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false },
  });
  cameraWin.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  cameraWin.webContents.on('will-navigate', event => event.preventDefault());
  cameraWin.once('ready-to-show', () => cameraWin.show());
  cameraWin.on('closed', () => { cameraWin = undefined; });
  cameraWin.loadFile('index.html', { query: { camera: '1' } });
}
function startAttentionFeed() {
  let previous = null;
  attentionTimer = setInterval(() => {
    if (!win || win.isDestroyed()) return;
    const point = screen.getCursorScreenPoint();
    const display = screen.getDisplayNearestPoint(point);
    const area = display.workArea;
    const now = Date.now();
    const x = Math.max(-1, Math.min(1, ((point.x - area.x) / Math.max(1, area.width)) * 2 - 1));
    const y = Math.max(-1, Math.min(1, ((point.y - area.y) / Math.max(1, area.height)) * 2 - 1));
    const elapsed = previous ? Math.max(.016, (now - previous.at) / 1000) : 1;
    const speed = previous ? Math.min(4, Math.hypot(x - previous.x, y - previous.y) / elapsed) : 0;
    previous = { x, y, at: now };
    const attention = { x, y, speed, at: now };
    win.webContents.send('attention', attention);
    if (cameraWin && !cameraWin.isDestroyed()) cameraWin.webContents.send('attention', attention);
  }, 120);
}
if (!app.requestSingleInstanceLock()) app.quit(); else {
  app.whenReady().then(() => {
    try { settings = JSON.parse(fs.readFileSync(settingsPath(), 'utf8')); } catch {}
    const area = screen.getPrimaryDisplay().workArea;
    win = new BrowserWindow({
      width: settings.width || 1420, height: settings.height || 900,
      x: settings.x ?? Math.max(area.x + 20, area.x + Math.round((area.width - (settings.width || 1420)) / 2)),
      y: settings.y ?? Math.max(area.y + 20, area.y + Math.round((area.height - (settings.height || 900)) / 2)),
      minWidth: 1020, minHeight: 690, frame: false, backgroundColor: '#090d13', show: false, title: 'Stella // Companion',
      icon: path.join(__dirname, 'assets', 'stella_app_icon.ico'),
      webPreferences: { preload: path.join(__dirname, 'preload.cjs'), contextIsolation: true, nodeIntegration: false, sandbox: true },
    });
    win.webContents.setWindowOpenHandler(() => ({ action: 'deny' })); win.webContents.on('will-navigate', event => event.preventDefault());
    win.once('ready-to-show', () => win.show()); win.loadFile('index.html');
    win.on('resize', () => { const bounds = win.getBounds(); settings = { ...settings, ...bounds }; });
    win.on('move', () => { const { x, y } = win.getBounds(); settings = { ...settings, x, y }; });
    win.on('close', event => {
      saveSettings();
      if (closingWindow) return;
      // The runtime can outlive this window briefly on Windows. Explicitly
      // release an active call so a reopened Stella never inherits its mic.
      event.preventDefault();
      closingWindow = true;
      shellRequest('/api/call/end', 'POST').catch(() => {}).finally(() => win.close());
    });
    ipcMain.handle('model', async (_event, choose) => {
      let selected = settings.model || path.join(__dirname, 'assets', 'Mako.vrm');
      if (choose) { const result = await dialog.showOpenDialog(win, { filters: [{ name: 'VRM avatar', extensions: ['vrm'] }], properties: ['openFile'] }); if (result.canceled) return null; selected = result.filePaths[0]; }
      const bytes = await fs.promises.readFile(selected); if (bytes.length > 150 * 1024 * 1024) throw new Error('Avatar exceeds the 150 MB limit.');
      return { bytes, name: path.basename(selected), path: selected };
    });
    ipcMain.on('model-loaded', (_event, selected) => { if (typeof selected === 'string' && path.extname(selected).toLowerCase() === '.vrm') { settings.model = selected; saveSettings(); } });
    ipcMain.on('window-action', (_event, action) => { if (action === 'close') win.close(); if (action === 'minimize') win.minimize(); if (action === 'lock') toggleLock(); if (action === 'top') win.setAlwaysOnTop(!win.isAlwaysOnTop()); if (action === 'camera') toggleCameraOutput(); });
    ipcMain.handle('shell-request', (_event, request) => {
      const valid = new Set(['/api/state', '/api/events', '/api/devices', '/api/chat', '/api/call/toggle', '/api/call/end', '/api/config', '/api/onboarding/speak', '/api/onboarding/stop-speaking', '/api/sage', '/api/sage/control']);
      if (!request || !valid.has(request.route)) throw new Error('Unsupported local runtime request.'); return shellRequest(request.route + (request.query || ''), request.method || 'GET', request.body);
    });
    ipcMain.handle('account-request', async (_event, request) => {
      if (!request || typeof request.action !== 'string') throw new Error('Invalid account request.');
      if (request.action === 'register' || request.action === 'login') {
        const route = request.action === 'register' ? '/api/v1/auth/register' : '/api/v1/auth/login';
        const result = await accountRequest(route, 'POST', { email: request.email, password: request.password });
        saveAccountToken(result.access_token);
        return { account: result.account };
      }
      if (request.action === 'logout') {
        try { await accountRequest('/api/v1/auth/logout', 'POST'); } finally { saveAccountToken(''); }
        return { ok: true };
      }
      if (request.action === 'usage') {
        const data = await accountRequest('/api/v1/usage?limit=5');
        return data;
      }
      if (request.action === 'session') {
        const account = await accountRequest('/api/v1/account');
        const usage = await accountRequest('/api/v1/usage?limit=5');
        return { account, usage };
      }
      throw new Error('Unsupported account action.');
    });
    ipcMain.handle('onboarding-state', () => ({ complete: Boolean(settings.onboardingComplete) }));
    ipcMain.handle('onboarding-complete', () => { settings.onboardingComplete = true; saveSettings(); return { complete: true }; });
    globalShortcut.register('Control+Alt+L', toggleLock);
    socket = dgram.createSocket('udp4'); socket.on('message', buffer => { const packet = validatePacket(buffer); if (packet && win && !win.isDestroyed()) { win.webContents.send('body', packet); if (cameraWin && !cameraWin.isDestroyed()) cameraWin.webContents.send('body', packet); } });
    socket.on('error', error => { if (win && !win.isDestroyed()) win.webContents.send('bridge-error', error.message); }); socket.bind(39540, '127.0.0.1');
    loadAccountToken(); startAccountService(); startAttentionFeed(); startRuntime();
  });
}
app.on('window-all-closed', () => app.quit());
app.on('will-quit', () => { globalShortcut.unregisterAll(); clearInterval(attentionTimer); try { socket?.close(); } catch {} if (shellProcess && !shellProcess.killed) shellProcess.kill(); if (accountProcess && !accountProcess.killed) accountProcess.kill(); });
