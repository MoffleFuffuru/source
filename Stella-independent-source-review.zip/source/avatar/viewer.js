import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { VRMLoaderPlugin, VRMUtils } from '@pixiv/three-vrm';
import { VRMAnimationLoaderPlugin, createVRMAnimationClip } from '@pixiv/three-vrm-animation';
import { smoothingAlpha, mouthTarget } from './motion.mjs';
import { AutonomousDirector as MovementDirector } from './autonomous-motion.mjs';
import { AudioMouth } from './lip-sync.mjs';
import { GESTURES, CUSTOM_POSES, INTERFACE_REACTIONS } from './movement-catalog.mjs';

const $ = id => document.getElementById(id);
const isCameraOutput = document.documentElement.classList.contains('camera-output');
const stage = $('stage');
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(28, Math.max(1, stage.clientWidth) / Math.max(1, stage.clientHeight), .01, 50);
// The broadcast surface is deliberately opaque. Windows Graphics Capture is
// more reliable with an opaque composited frame than a transparent WebGL one.
let renderer;
try {
  renderer = new THREE.WebGLRenderer({ alpha: !isCameraOutput, antialias: true, powerPreference: isCameraOutput ? 'high-performance' : 'low-power' });
} catch (error) {
  // A GPU/WebGL failure must not prevent the independent chat and voice UI booting.
  console.error('Stella avatar renderer unavailable:', error);
  const canvas = document.createElement('canvas');
  stage.classList.add('renderer-unavailable');
  stage.dataset.rendererError = String(error?.message || error).slice(0, 180);
  $('status').textContent = '3D display unavailable';
  renderer = {
    domElement: canvas, outputColorSpace: null, toneMapping: null, toneMappingExposure: 1,
    setClearColor() {}, setPixelRatio() {}, setSize() {}, getClearAlpha: () => 0, render() {},
  };
}
renderer.setClearColor(0x090d13, isCameraOutput ? 1 : 0);
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
renderer.setSize(stage.clientWidth || innerWidth, stage.clientHeight || innerHeight, false);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = .82;
renderer.domElement.style.width = '100%';
renderer.domElement.style.height = '100%';
stage.appendChild(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xc9d9e9, 0x273247, .72));
const key = new THREE.DirectionalLight(0xffe6d2, .82);
key.position.set(-2, 3, 4); scene.add(key);
const rim = new THREE.DirectionalLight(0x91b8e8, .3);
rim.position.set(2, 2, -2); scene.add(rim);
const gazeObject = new THREE.Object3D();
scene.add(gazeObject);
let vrm, modelName = '', lastPacket = -Infinity, packet = null, sequence = null;
let idleAnimation = null, idleMixer = null;
let audioMouth = new AudioMouth();
let movement = null, motionState = null, previewUntil = 0, previewPhase = 'idle';
let pendingInterfaceReaction = null;
const legacyMovement = new URLSearchParams(location.search).get('movement') === 'legacy';
let gesture = 'none', gestureStart = -100, lastGesture = -100, manualUntil = 0;
let expression = 'neutral', strength = .35, pose = false, zoom = 1, panX = 0, panY = 0, modelHeight = 1.6, modelCenterX = 0, modelCenterZ = 0, modelBaseYaw = 0;
let blinkAt = 2 + Math.random() * 3, blinkStart = -100, gazeAt = 0;
let gazeX = 0, gazeY = 0, targetX = 0, targetY = 0;
let lastFrame = performance.now(), elapsed = 0, mouth = 0, loadSerial = 0, nextSpeechBeat = 0;
let faceEnergy = 0;
let desktopAttention = { x: 0, y: 0, speed: 4, at: -Infinity, weight: 0 };
let handRestAmount = 0, handRestUntil = 0, handRestNext = 0;
const faceChannels = { happy: 0, angry: 0, sad: 0, surprised: 0, relaxed: 0 };
const bones = {}, armSign = {};
const displayedRotations = new Map();
const blend = (a, b, dt, speed = 7) => THREE.MathUtils.lerp(a, b, 1 - Math.exp(-dt * speed));
const smooth = x => { x = THREE.MathUtils.clamp(x, 0, 1); return x * x * (3 - 2 * x); };
const positive = new Set(['warm','amused','playful','smug','embarrassed','excited']);
function expressionPreset(manager, ...candidates) {
  const map = manager?.expressionMap || {};
  return candidates.find(name => map[name]) || null;
}
function status() {
  const connected = performance.now() - lastPacket < 2200;
  $('status').textContent = `${modelName || 'VRM'} / ${connected ? 'live: ' + packet.state : 'standing idle'}`;
  $('model-name').textContent = `${modelName || 'VRM'} / ${connected ? 'LIVE BODY SIGNAL' : 'STANDING IDLE'}`;
}
function frameCamera() {
  const distance = modelHeight * 2.42 / zoom;
  const focusY = isCameraOutput ? modelHeight * .78 : modelHeight * .51;
  camera.position.set(modelCenterX + panX, focusY + panY, modelCenterZ + distance);
  camera.lookAt(modelCenterX + panX, focusY + panY, modelCenterZ);
}
function resizeAvatarViewport() {
  const width = stage.clientWidth;
  const height = stage.clientHeight;
  if (!width || !height) return;
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
  renderer.setSize(width, height, false);
  if (vrm) frameCamera();
}
function centerAvatar() {
  if (!vrm) return;
  vrm.scene.updateMatrixWorld(true);
  // Precise skinned bounds need current bone matrices even before first render.
  vrm.scene.traverse(object => { if (object.isSkinnedMesh) object.skeleton.update(); });
  const box = new THREE.Box3().setFromObject(vrm.scene, true);
  const center = box.getCenter(new THREE.Vector3());
  modelHeight = Math.max(.1, box.max.y - box.min.y);
  // Center the actual rendered body, not the file's authored root/pivot.
  vrm.scene.position.x -= center.x;
  vrm.scene.position.y -= box.min.y;
  vrm.scene.position.z -= center.z;
  modelCenterX = 0; modelCenterZ = 0;
  zoom = isCameraOutput ? 3.35 : 1; panX = 0; panY = 0;
  frameCamera();
}
new ResizeObserver(resizeAvatarViewport).observe(stage);
function rebaseUpperBody(animation) {
  const poses = {
    // Lowered, neutral upper-arm rests. The sign is deliberately forward so
    // hands do not settle behind the hips on this mirrored VRM rig.
    leftUpperArm: [.045, -.28, -1.39], rightUpperArm: [.045, .28, 1.39],
    leftLowerArm: [0, 0, .025], rightLowerArm: [0, 0, -.025],
  };
  for (const [name, track] of animation.humanoidTracks.rotation) {
    // Arm placement is corrected through the elbow. Wrist and fingertip
    // animation remains exactly as authored in the VRMA.
    if (!/^(left|right)(Shoulder|UpperArm|LowerArm)$/.test(name)) continue;
    const first = new THREE.Quaternion(...track.values.slice(0, 4));
    const inverse = first.clone().invert();
    const target = poses[name]
      ? new THREE.Quaternion().setFromEuler(new THREE.Euler(...poses[name], 'XYZ'))
      : new THREE.Quaternion();
    const gain = /UpperArm/.test(name) ? .35 : /LowerArm/.test(name) ? .32 : .38;
    for (let i = 0; i < track.values.length; i += 4) {
      const delta = inverse.clone().multiply(new THREE.Quaternion(...track.values.slice(i, i + 4)));
      track.values.set(target.clone().multiply(new THREE.Quaternion().slerp(delta, gain)).normalize().toArray(), i);
    }
  }
}
async function loadIdleAnimation(target) {
  if (!legacyMovement) {
    if (target !== vrm) return;
    const director = new MovementDirector(target, { ...bones });
    try {
      await director.load();
      if (target !== vrm) { director.dispose(); return; }
      movement?.dispose(); movement = director;
      if (pendingInterfaceReaction) {
        movement.react(pendingInterfaceReaction);
        pendingInterfaceReaction = null;
      }
      idleMixer?.stopAllAction(); idleMixer = null; idleAnimation = true;
      director.update(0); target.update(0);
      if (packet) director.receive(packet);
      return;
    } catch (error) {
      director.dispose();
      if (movement === director) movement = null;
      console.warn('Movement library unavailable; retaining original idle.', error);
    }
  }
  const loader = new GLTFLoader();
  loader.register(parser => new VRMAnimationLoaderPlugin(parser));
  const gltf = await loader.loadAsync('./assets/natural-standing-idle.vrma');
  const animation = gltf.userData.vrmAnimations?.[0];
  if (!animation) throw new Error('Natural standing idle contains no VRM animation.');
  rebaseUpperBody(animation);
  idleMixer?.stopAllAction();
  idleMixer = new THREE.AnimationMixer(target.scene);
  const clip = createVRMAnimationClip(animation, target);
  clip.tracks = clip.tracks.filter(track => !/expression|morphTargetInfluences/i.test(track.name));
  idleMixer.clipAction(clip)
    .setLoop(THREE.LoopRepeat, Infinity)
    .play();
  idleAnimation = animation;
}
async function loadModel(choose = false) {
  const serial = ++loadSerial;
  try {
    const file = await window.avatar.model(choose);
    if (!file) return;
    $('status').textContent = 'Loading ' + file.name + '...';
    const loader = new GLTFLoader();
    loader.register(parser => new VRMLoaderPlugin(parser));
    const bytes = new Uint8Array(file.bytes);
    const gltf = await loader.parseAsync(bytes.buffer, '');
    const next = gltf.userData.vrm;
    if (!next) throw new Error('This file does not contain a VRM humanoid.');
    if (serial !== loadSerial) { VRMUtils.deepDispose(next.scene); return; }
    VRMUtils.rotateVRM0(next);
    modelBaseYaw = next.scene.rotation.y;
    VRMUtils.removeUnnecessaryVertices(next.scene);
    VRMUtils.combineSkeletons(next.scene);
    movement?.dispose(); movement = null; idleMixer?.stopAllAction(); idleMixer = null; idleAnimation = null;
    if (vrm) { scene.remove(vrm.scene); VRMUtils.deepDispose(vrm.scene); }
    vrm = next; scene.add(vrm.scene); modelName = file.name;
    for (const name of Object.keys(bones)) delete bones[name];
    displayedRotations.clear();
    for (const name of [
      'hips','spine','chest','upperChest','neck','head',
      'leftShoulder','rightShoulder','leftUpperArm','rightUpperArm',
      'leftLowerArm','rightLowerArm','leftHand','rightHand',
      'leftUpperLeg','rightUpperLeg','leftLowerLeg','rightLowerLeg',
      'leftFoot','rightFoot','leftToes','rightToes',
      'leftThumbProximal','rightThumbProximal',
      'leftThumbMetacarpal','rightThumbMetacarpal',
      'leftThumbIntermediate','rightThumbIntermediate','leftThumbDistal','rightThumbDistal',
      'leftIndexProximal','rightIndexProximal',
      'leftIndexIntermediate','rightIndexIntermediate','leftIndexDistal','rightIndexDistal',
      'leftMiddleProximal','rightMiddleProximal',
      'leftMiddleIntermediate','rightMiddleIntermediate','leftMiddleDistal','rightMiddleDistal',
      'leftRingProximal','rightRingProximal',
      'leftRingIntermediate','rightRingIntermediate','leftRingDistal','rightRingDistal',
      'leftLittleProximal','rightLittleProximal',
      'leftLittleIntermediate','rightLittleIntermediate','leftLittleDistal','rightLittleDistal',
    ]) {
      bones[name] = vrm.humanoid.getNormalizedBoneNode(name);
    }
    for (const side of ['left','right']) armSign[side] = Math.sign(bones[side + 'LowerArm']?.position.x || (side === 'left' ? 1 : -1));
    vrm.scene.traverse(o => { o.frustumCulled = false; });
    // A model reload should never inherit authored root offsets, a prior drag,
    // or a window resize.
    centerAvatar();
    if (vrm.lookAt) vrm.lookAt.target = gazeObject;
    window.avatar.modelLoaded(file.path);
    document.body.classList.remove('error');
    window.avatarDiagnostics = { ready: true, model: modelName, vrmVersion: vrm.meta?.metaVersion, idleAnimation: Boolean(idleAnimation), transparent: renderer.getClearAlpha() === 0, frames: 0, bones: Object.keys(bones).filter(k => bones[k]), expressions: Object.keys(vrm.expressionManager?.expressionMap || {}) };
    status();
    // The model must never wait on optional animation parsing. Load the VRMA
    // after the first usable frame and retain procedural idle on any failure.
    setTimeout(() => {
      const target = vrm;
      Promise.race([
        loadIdleAnimation(target),
        new Promise((_, reject) => setTimeout(() => reject(new Error('VRMA load timed out')), 10000)),
      ]).then(() => {
        if (vrm === target && window.avatarDiagnostics) {
          window.avatarDiagnostics.idleAnimation = true;
          // Animation loading can change the active skeleton bounds; frame only
          // after that final state is present.
          requestAnimationFrame(() => { centerAvatar(); resizeAvatarViewport(); });
        }
      }).catch(animationError => {
        if (vrm === target) { idleAnimation = null; idleMixer = null; }
        console.warn('Natural standing idle unavailable; using procedural idle.', animationError);
      });
    }, 0);
  } catch (e) {
    document.body.classList.add('error');
    $('status').textContent = 'Model error: ' + e.message + ' (use Load VRM to recover)';
    console.error(e);
  }
}
function startGesture(name, manual = false) {
  if (movement) { movement.play(name, { force: manual }); return; }
  if (['wave'].includes(name)) name = 'none';
  if (!manual && elapsed - lastGesture < 2.8) return;
  gesture = name; gestureStart = elapsed; lastGesture = elapsed;
}
window.avatar.onBody(data => {
  const reconnect = performance.now() - lastPacket > 2200;
  if (reconnect) audioMouth = new AudioMouth();
  if (elapsed >= previewUntil) audioMouth.receive(data);
  lastPacket = performance.now(); packet = data;
  if (movement && elapsed >= previewUntil) movement.receive(data);
  if (movement) { status(); return; }
  if (sequence !== data.sequence || reconnect) {
    sequence = data.sequence;
    if (elapsed >= manualUntil) {
      // Listening/idle transitions cancel any stale response motion.
      if (['idle','degraded'].includes(data.state)) gesture = 'none';
      else startGesture(data.intent.gesture);
    }
  }
  status();
});
window.avatar.onAttention(data => {
  if (!Number.isFinite(data?.x) || !Number.isFinite(data?.y)) return;
  desktopAttention.x = THREE.MathUtils.clamp(data.x, -1, 1);
  desktopAttention.y = THREE.MathUtils.clamp(data.y, -1, 1);
  desktopAttention.speed = Math.max(0, Number(data.speed) || 0);
  desktopAttention.at = elapsed;
});
window.avatar.onLock(locked => document.body.classList.toggle('locked', locked));
addEventListener('resize', () => {
  resizeAvatarViewport();
});
window.avatar.onError(message => { document.body.classList.add('error'); $('status').textContent = message; if(message.includes('Ctrl+Alt+M')) $('lock').disabled = true; });
for (const id of ['close','lock','top','minimize','camera']) $(id).onclick = () => {
  movement?.react(id === 'top' ? 'pin' : id); window.avatar.action(id);
};
$('load').onclick = () => loadModel(true);
$('smile').onclick = () => { expression = 'warm'; strength = .7; manualUntil = elapsed + 4; };
$('wave').onclick = () => { expression = 'warm'; strength = .6; manualUntil = elapsed + 2; };
$('pose').onclick = () => { pose = false; };
$('reset').onclick = () => { pose = false; gesture = 'none'; expression = 'neutral'; manualUntil = 0; zoom = 1; panX = 0; panY = 0; frameCamera(); movement?.react('recenter'); };
$('orbit').addEventListener('change', () => movement?.react('orbit'));
let lastViewReaction = -10;
addEventListener('wheel', e => {
  if (!stage.contains(e.target)) return;
  if (e.target.matches('input, meter, button')) return;
  e.preventDefault();
  zoom = THREE.MathUtils.clamp(zoom - e.deltaY * .001, .55, 2.5);
  frameCamera();
  if (elapsed - lastViewReaction > 3) { movement?.react(e.deltaY < 0 ? 'zoom_in' : 'zoom_out'); lastViewReaction = elapsed; }
}, { passive: false });
let cameraDrag = null;
$('stage').addEventListener('pointerdown', e => {
  if (e.button !== 0) return;
  cameraDrag = { x: e.clientX, y: e.clientY, panX, panY };
  if (elapsed - lastViewReaction > 3) { movement?.react('drag'); lastViewReaction = elapsed; }
  $('stage').setPointerCapture(e.pointerId);
});
$('stage').addEventListener('pointermove', e => {
  if (!cameraDrag) return;
  const scale = modelHeight * 1.7 / Math.max(300, innerHeight) / zoom;
  panX = cameraDrag.panX - (e.clientX - cameraDrag.x) * scale;
  panY = cameraDrag.panY + (e.clientY - cameraDrag.y) * scale;
  frameCamera();
});
$('stage').addEventListener('pointerup', e => { cameraDrag = null; $('stage').releasePointerCapture(e.pointerId); });
$('stage').addEventListener('pointercancel', () => { cameraDrag = null; });
function rotate(name, x = 0, y = 0, z = 0) { bones[name]?.rotation.set(x, y, z, 'XYZ'); }
function offset(name, x = 0, y = 0, z = 0) {
  const bone = bones[name];
  if (!bone) return;
  bone.rotateX(x); bone.rotateY(y); bone.rotateZ(z);
}
let poseAmount = 0;
function draw(now) {
  requestAnimationFrame(draw);
  // Cap at 30 fps so the visual layer leaves GPU time for STT/TTS.
  if (now - lastFrame < 1000 / 30) return;
  const dt = Math.min((now - lastFrame) / 1000, .1); lastFrame = now; elapsed += dt;
  if (!vrm) { renderer.render(scene, camera); return; }
  const connected = performance.now() - lastPacket < 2200;
  // Preserve UniVRM's VRM0 front-facing correction, then add a small display
  // turn only when Auto Orbit is enabled.
  vrm.scene.rotation.y = modelBaseYaw + ($('orbit').checked ? Math.sin(elapsed * .125) * .32 : 0);
  frameCamera();
  if (movement) {
    if (elapsed < previewUntil) {
      const sample = { sequence: -1, state: previewPhase, speaking: previewPhase === 'speaking', speech_level: previewPhase === 'speaking' && elapsed % 1.7 < 1.25 ? .06 + .05 * Math.sin(elapsed * 16) : 0, intent: { expression: $('movement-mood')?.value || 'warm', intensity: .65, energy: .5, gesture: 'none', gaze: 'speaker' } };
      movement.receive(sample); audioMouth.receive(sample);
    }
    movement.motionScale = Number($('motion').value);
    motionState = movement.update(dt, { ...desktopAttention, fresh: elapsed - desktopAttention.at < .7 });
    if (motionState) {
      if (elapsed >= manualUntil) { expression = motionState.expression; strength = motionState.intensity; }
      gazeX = motionState.gaze[0]; gazeY = motionState.gaze[1]; gesture = motionState.gesture;
    }
  } else {
  idleMixer?.update(dt);
  if (elapsed >= manualUntil) {
    expression = connected ? packet.intent.expression : 'neutral';
    strength = connected ? packet.intent.intensity : .3;
  }
  if (!connected && gesture !== 'wave' && elapsed >= manualUntil) gesture = 'none';
  const liveSpeaking = connected && packet.speaking;
  if (liveSpeaking && elapsed >= nextSpeechBeat) {
    // The semantic intent may choose one restrained gesture. Do not invent
    // recurring nods/shakes from an expression: they read as visible tremors.
    startGesture(packet.intent.gesture || 'none');
    nextSpeechBeat = elapsed + 4.5 + Math.random() * 2.5;
  } else if (!liveSpeaking) nextSpeechBeat = elapsed + .35;
  const motion = Number($('motion').value);
  // Keep a low-amplitude procedural layer even when VRMA is present. Some
  // VRMA files only animate a subset of bones; without this layer the rest of
  // the body reads as frozen. These are neutral settling motions, never
  // semantic actions such as a wave or greeting.
  const idleScale = idleAnimation ? .5 : 1;
  const breathe = Math.sin(elapsed * 1.47) * .012 * motion * idleScale;
  const sway = (Math.sin(elapsed * .41) + .35 * Math.sin(elapsed * .73 + 2)) * .011 * motion * idleScale;
  poseAmount = blend(poseAmount, 0, dt, 2);
  if (!idleAnimation) {
    rotate('hips', 0, sway * .2, sway * .35);
    rotate('spine', breathe * .5, sway * .4, -sway * .3);
    rotate('chest', breathe, sway * .3, sway * .45);
    rotate('upperChest', breathe * .25, 0, 0);
    rotate('neck', Math.sin(elapsed * .61) * .009 * motion, 0, 0);
  }
  if (elapsed > gazeAt) {
    // Occasional attention shifts make idle feel observant, not restless.
    targetX = (Math.random() - .5) * .32 * motion;
    targetY = (Math.random() - .5) * .12 * motion;
    gazeAt = elapsed + 3.5 + Math.random() * 5.5;
  }
  const thinking = connected && packet.intent.gaze === 'thinking_away';
  const receptive = !connected || ['idle', 'listening'].includes(packet.state);
  // A close portrait can occasionally settle both hands on the console edge.
  // It is idle/listening-only, so spoken gestures always retain priority.
  const restEligible = idleAnimation && receptive && !liveSpeaking && zoom >= 2.15;
  if (!restEligible) {
    handRestUntil = 0;
    handRestNext = elapsed + 1.25;
  } else if (!handRestUntil && elapsed >= handRestNext) {
    handRestUntil = elapsed + 4 + Math.random() * 3;
  } else if (handRestUntil && elapsed >= handRestUntil) {
    handRestUntil = 0;
    handRestNext = elapsed + 8 + Math.random() * 10;
  }
  const handRestTarget = restEligible && handRestUntil > elapsed ? 1 : 0;
  handRestAmount = blend(handRestAmount, handRestTarget, dt, handRestTarget ? 1.15 : 3.2);
  document.querySelector('.avatar-panel').classList.toggle('hand-rest', handRestAmount > .03);
  const cursorFresh = elapsed - desktopAttention.at < .7;
  // Cursor motion only earns attention after it slows down. This makes a
  // dwell feel intentional while a fast screen crossing does not whip her neck.
  const requestedAttention = receptive && cursorFresh && desktopAttention.speed < .7 ? .52 : 0;
  desktopAttention.weight = blend(desktopAttention.weight, requestedAttention, dt, requestedAttention ? 1.5 : 3.6);
  const attentionX = desktopAttention.x * .24;
  const attentionY = -desktopAttention.y * .075;
  const desiredGazeX = thinking ? .16 : blend(targetX, attentionX, desktopAttention.weight);
  const desiredGazeY = thinking ? .035 : blend(targetY, attentionY, desktopAttention.weight);
  gazeX = blend(gazeX, desiredGazeX, dt, desktopAttention.weight ? 1.6 : 2);
  gazeY = blend(gazeY, desiredGazeY, dt, desktopAttention.weight ? 1.6 : 2);
  let headX = gazeY, headY = gazeX, headZ = sway * .7;
  const age = elapsed - gestureStart;
  const duration = gesture === 'wave' ? 3.4 : 2.4;
  const envelope = smooth(age / .5) * (1 - smooth((age - duration + .6) / .6));
  if (age > duration) gesture = 'none';
  if (gesture === 'small_nod') headX += Math.sin(age * 6) * .08 * envelope;
  if (gesture === 'small_shake') headY += Math.sin(age * 7) * .09 * envelope;
  if (gesture === 'small_head_tilt') headZ += .13 * envelope;
  if (gesture === 'head_turn') headY += .2 * envelope;
  if (idleAnimation) {
    offset('hips', 0, sway * .12, sway * .17);
    offset('spine', breathe * .42, sway * .25, -sway * .2);
    offset('chest', breathe * .72, sway * .2, sway * .3);
    offset('upperChest', breathe * .18, 0, 0);
    offset('neck', Math.sin(elapsed * .61) * .004 * motion, 0, 0);
    if (gesture === 'lean_in') offset('spine', .055 * envelope);
    if (gesture === 'lean_back') offset('spine', -.055 * envelope);
    offset('head', headX, headY, headZ);
    const conversationalLift = connected && packet.speaking ? .018 + .012 * Math.sin(elapsed * 1.8) : 0;
    offset('leftShoulder', 0, 0, conversationalLift);
    offset('rightShoulder', 0, 0, -conversationalLift);
    if (handRestAmount > .001) {
      // The source VRMA still owns wrists and fingers; only the arm chain lifts.
      offset('leftUpperArm', -.52 * handRestAmount, 0, .09 * handRestAmount);
      offset('rightUpperArm', -.52 * handRestAmount, 0, -.09 * handRestAmount);
      offset('leftLowerArm', -.34 * handRestAmount, .05 * handRestAmount, .06 * handRestAmount);
      offset('rightLowerArm', -.34 * handRestAmount, -.05 * handRestAmount, -.06 * handRestAmount);
    }
  } else {
    if (gesture === 'lean_in') bones.spine.rotation.x += .055 * envelope;
    if (gesture === 'lean_back') bones.spine.rotation.x -= .055 * envelope;
    rotate('head', headX, headY, headZ);
  }
  // Smooth the final pose, including cancellation and state changes. Never
  // interpolate intermediate targets or reset the displayed pose on a packet.
  if (!idleAnimation) {
    for (const [name, bone] of Object.entries(bones)) {
      if (!bone) continue;
      let displayed = displayedRotations.get(name);
      if (!displayed) { displayed = bone.quaternion.clone(); displayedRotations.set(name, displayed); }
      else displayed.slerp(bone.quaternion, smoothingAlpha(dt, name === 'head' ? 4 : 6));
      bone.quaternion.copy(displayed);
    }
  }
  }
  gazeObject.position.set(gazeX * 3, modelHeight * .9 - gazeY * 2, 4);
  if (elapsed >= blinkAt) { blinkStart = elapsed; blinkAt = elapsed + 2.8 + Math.random() * 4.5; }
  const blinkAge = elapsed - blinkStart;
  const blink = blinkAge < .18 ? Math.sin(blinkAge / .18 * Math.PI) : 0;
  // Let VRM animation/look-at update first. Live facial controls are applied
  // exactly once afterward so no subsystem can pulse or overwrite them.
  // Captured motion owns the stance; only gaze and upper-body gestures overlay it.
  vrm.update(dt);
  const em = vrm.expressionManager;
  if (em) {
    const level = movement ? movement.audio : connected ? packet.speech_level : 0;
    mouth = Math.min(.65, audioMouth.update(dt) * Number($('lips').value) / 8);
    $('audio').value = Math.min(1, level * 8);
    const speaking = movement ? motionState?.phase === 'speaking' || mouth > .025 : connected && (packet.speaking || mouth > .025);
    const listener = movement ? motionState?.phase === 'listening' : connected && packet.state === 'listening';
    // Slow variation is intentional: it gives a line small living changes
    // without making the face stutter alongside each audio frame.
    const facePulse = speaking ? .7 + .3 * Math.sin(elapsed * .72) : 1;
    faceEnergy = blend(faceEnergy, speaking ? .15 * facePulse : listener ? .07 : 0, dt, 3.5);
    const presets = {
      happy: expressionPreset(em, 'happy', 'joy', 'fun'),
      angry: expressionPreset(em, 'angry'),
      sad: expressionPreset(em, 'sad', 'sorrow'),
      surprised: expressionPreset(em, 'surprised'),
      relaxed: expressionPreset(em, 'relaxed'),
      blink: expressionPreset(em, 'blink'),
      mouth: expressionPreset(em, 'aa', 'a'),
    };
    const speakingBase = speaking ? .28 + .16 * facePulse : .7;
    const desired = {
      // These intentionally use different blends instead of turning every
      // positive delivery into the same held smile.
      happy: expression === 'warm' ? strength * speakingBase
        : ['amused', 'playful'].includes(expression) ? strength * (speakingBase + .13)
        : expression === 'smug' ? strength * (speakingBase + .05)
        : expression === 'excited' ? strength * (speakingBase + .19)
        : expression === 'embarrassed' ? strength * (speakingBase - .08)
        : speaking ? faceEnergy * .28 : 0,
      angry: expression === 'annoyed' ? strength * (speaking ? .5 + .12 * facePulse : .5) : 0,
      sad: ['sad','concerned'].includes(expression) ? strength * (speaking ? .48 + .12 * facePulse : .45) : 0,
      surprised: expression === 'excited' ? strength * (speaking ? .16 + .1 * facePulse : .1)
        : expression === 'surprised' ? strength * (speaking ? .7 : .65)
        : expression === 'confused' ? strength * (speaking ? .2 : listener ? .12 : 0) : 0,
      relaxed: expression === 'embarrassed' ? strength * (.2 + .16 * facePulse)
        : expression === 'smug' ? strength * .16
        : expression === 'warm' ? strength * .08
        : 0,
    };
    if (motionState?.reaction === 'discord_off' || motionState?.reaction === 'autonomy_off') {
      desired.sad += .16 * motionState.reactionWeight;
      desired.angry += .08 * motionState.reactionWeight;
    }
    for (const [kind, value] of Object.entries(desired)) {
      const name = presets[kind];
      faceChannels[kind] = blend(faceChannels[kind], THREE.MathUtils.clamp(value, 0, .85), dt, speaking ? 5 : 3.5);
      if (name) em.setValue(name, faceChannels[kind]);
    }
    if (presets.blink) em.setValue(presets.blink, blink);
    if (presets.mouth) em.setValue(presets.mouth, mouth);
    em.update();
  }
    renderer.render(scene, camera);
  if (window.avatarDiagnostics) Object.assign(window.avatarDiagnostics, { frames: window.avatarDiagnostics.frames + 1, connected, gesture, mouth, head: [gazeY,gazeX,0], movement: motionState, pose: poseAmount });
  if ($('movement-readout') && movement) $('movement-readout').textContent = `V5 / ${motionState?.base || movement.base} / ${motionState?.phase || 'loading'} / ${motionState?.reaction || motionState?.gesture || 'none'} / ${movement.clips.size} clips`;
}
setInterval(() => { if (vrm && !document.body.classList.contains('error')) status(); }, 1000);
loadModel(); requestAnimationFrame(draw);

const shell = window.stella;
let eventCursor = 0;
let settingsReady = false;
let devicesReady = false;
const configField = {
  'call-model': 'model.call_model', 'call-provider': 'model.call_provider', reasoning: 'model.call_reasoning_effort',
  'output-tokens': 'model.call_max_output_tokens', 'recent-turns': 'model.call_recent_turns',
  stt: 'voice.stt_backend', tts: 'voice.tts_backend', voice: 'voice.inworld_tts_voice', microphone: 'voice.input_device',
  'eleven-voice': 'voice.elevenlabs_tts_voice', 'eleven-keyterms': 'voice.elevenlabs_keyterms',
  'eleven-silence': 'voice.elevenlabs_vad_silence_seconds', 'vocal-context': 'voice.vocal_context_provider',
  'stt-fallback': 'voice.elevenlabs_stt_fallback', 'tts-fallback': 'voice.elevenlabs_tts_fallback',
  'discord-enabled': 'discord.enabled', 'discord-autonomy': 'discord.autonomy_enabled',
  'memory-enabled': 'memory.enabled', 'output-device': 'voice.output_device', 'output-volume': 'voice.output_volume',
};
function addMessage(speaker, text, metadata = {}) {
  const transcript = $('transcript');
  const responseId = metadata.response_id;
  if (speaker === 'stella' && responseId) {
    const existing = transcript.querySelector(`[data-response-id="${CSS.escape(responseId)}"] .bubble`);
    if (existing) { existing.textContent = text; transcript.scrollTop = transcript.scrollHeight; return; }
  }
  transcript.querySelector('.empty-state')?.remove();
  const item = document.createElement('article'); item.className = `message ${speaker === 'user' ? 'user' : speaker === 'viewer' ? 'viewer' : 'stella'}`;
  if (speaker === 'stella' && responseId) item.dataset.responseId = responseId;
  const who = document.createElement('span'); who.className = 'who';
  const label = speaker === 'user' ? 'YOU' : speaker === 'viewer' ? (metadata.display_name || 'VIEWER') : 'STELLA';
  const stamp = metadata.at ? new Date(metadata.at * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '';
  who.textContent = [label, metadata.simulated ? 'SIM' : '', stamp].filter(Boolean).join(' · ');
  const bubble = document.createElement('span'); bubble.className = 'bubble'; bubble.textContent = text;
  item.append(who, bubble); transcript.append(item); transcript.scrollTop = transcript.scrollHeight;
  if (metadata.generation_seconds) $('latency').textContent = `${metadata.generation_seconds.toFixed(2)} S GEN`;
}
function setStatus(value) {
  const normalized = String(value || 'ready'); const chip = $('system-state');
  chip.textContent = normalized.toUpperCase(); chip.classList.toggle('thinking', normalized.includes('thinking') || normalized.includes('processing'));
  $('call-toggle').classList.toggle('active', normalized.includes('call'));
}
function dispatchInterfaceReaction(name) {
  if (movement) movement.react(name);
  else pendingInterfaceReaction = name;
}
function selectValue(id, value) { const node = $(id); if (node && value !== undefined && [...node.options].some(option => option.value === String(value))) node.value = String(value); }
function hydrate(state) {
  const sage = state.sage || {};
  if ($('conversation-title')) $('conversation-title').textContent = sage.stream_active ? 'Stream Chat' : 'Conversation';
  if ($('conversation-mode')) $('conversation-mode').textContent = sage.simulation ? 'LOCAL REHEARSAL / SIMULATED VIEWERS' : sage.stream_active ? 'LIVE STREAM EXCHANGE' : 'LIVE EXCHANGE';
  if ($('sage-state')) $('sage-state').title = sage.last_outcome || '';
  if ($('sage-enabled')) $('sage-enabled').checked = Boolean(sage.enabled);
  if ($('sage-state')) $('sage-state').textContent = sage.quiet ? 'QUIET' : sage.busy ? 'WORKING' : sage.last_outcome?.includes('failed') ? 'ERROR' : sage.last_outcome === 'model chose silence' ? 'MODEL SILENT' : sage.stream_active ? 'STREAMING' : 'READY';
  if ($('sage-stream')) { $('sage-stream').textContent = sage.stream_active ? 'STOP STREAM' : 'START STREAM'; $('sage-stream').dataset.active = String(Boolean(sage.stream_active)); }
  if ($('sage-quiet')) { $('sage-quiet').textContent = sage.quiet ? 'RESUME' : 'QUIET'; $('sage-quiet').dataset.quiet = String(Boolean(sage.quiet)); }
  const config = state.config || {}; const model = config.model || {}; const voice = config.voice || {}; const discord = config.discord || {};
  selectValue('call-model', model.call_model); selectValue('call-provider', model.call_provider); selectValue('reasoning', model.call_reasoning_effort);
  $('output-tokens').value = model.call_max_output_tokens ?? 96; $('recent-turns').value = model.call_recent_turns ?? 7;
  selectValue('stt', voice.stt_backend); selectValue('tts', voice.tts_backend); selectValue('voice', voice.inworld_tts_voice); $('endpoint').value = voice.inworld_stt_min_eot_silence_ms ?? 220;
  $('eleven-voice').value = voice.elevenlabs_tts_voice || '';
  $('eleven-keyterms').value = (voice.elevenlabs_keyterms || []).join(', ');
  $('eleven-silence').value = voice.elevenlabs_vad_silence_seconds ?? .45;
  selectValue('vocal-context', voice.vocal_context_provider);
  selectValue('stt-fallback', voice.elevenlabs_stt_fallback);
  selectValue('tts-fallback', voice.elevenlabs_tts_fallback);
  $('endpoint-value').textContent = `${$('endpoint').value} ms`; $('discord-enabled').checked = Boolean(discord.enabled); $('discord-autonomy').checked = Boolean(discord.autonomy_enabled);
  $('discord-state').textContent = discord.connected ? 'ONLINE' : (discord.enabled ? 'STARTING' : 'PAUSED'); $('discord-state').classList.toggle('online', Boolean(discord.connected));
  const activeVoice = voice.tts_backend === 'elevenlabs_tts' ? (voice.elevenlabs_tts_voice === 'TaAj41g1TDT9zKVixsDm' ? 'Stella' : voice.elevenlabs_tts_voice) : voice.inworld_tts_voice;
  $('voice-readout').textContent = `${voice.stt_backend || 'STT'} / ${voice.tts_backend || 'TTS'} · ${activeVoice || 'VOICE'}`.toUpperCase();
  $('call-toggle').textContent = state.call_active ? 'END CALL  ◉' : 'START CALL  ◉'; $('call-toggle').classList.toggle('active', Boolean(state.call_active)); setStatus(state.status); settingsReady = true;
}
async function runtime(request) { return shell.request(request); }
async function sageControl(action) {
  try {
    await runtime({ route: '/api/sage/control', method: 'POST', body: { action, voice: Boolean($('sage-stream-voice')?.checked) } });
    hydrate(await runtime({ route: '/api/state' }));
  } catch (error) { addMessage('stella', `SAGE control failed: ${error.message}`); }
}
$('sage-enabled')?.addEventListener('change', event => sageControl(event.target.checked ? 'on' : 'off'));
$('sage-stream')?.addEventListener('click', event => sageControl(event.currentTarget.dataset.active === 'true' ? 'stream_stop' : 'stream_start'));
$('sage-quiet')?.addEventListener('click', event => sageControl(event.currentTarget.dataset.quiet === 'true' ? 'resume' : 'quiet'));
$('sage-review')?.addEventListener('click', () => sageControl('review'));
function setAccountMessage(text, error = false) {
  const node = $('account-message'); node.textContent = text; node.classList.toggle('error', error);
}
function showAccount(data) {
  $('account-signed-out').hidden = true; $('account-signed-in').hidden = false;
  $('account-identity-email').textContent = data.account.email;
  updateUsage(data.usage);
}
function updateUsage(data) {
  const credits = data.credits || {};
  $('credits-total').textContent = Number(credits.total || 0).toLocaleString();
  const trial = Math.max(0, Number(credits.trial || 0));
  $('credits-trial-label').textContent = `${trial.toLocaleString()} / 50`;
  $('credits-trial-bar').value = Math.min(50, trial);
  const week = data.last_7_days || {};
  $('usage-summary').textContent = `Last 7 days: ${Number(week.credits_used || 0).toLocaleString()} credits used · ${Number(week.request_count || 0).toLocaleString()} requests`;
}
async function refreshUsage() {
  try {
    const data = await shell.account({ action: 'session' }); showAccount(data);
    setAccountMessage('Balance synced just now.');
  } catch (error) {
    if (/sign in to continue/i.test(error.message)) {
      $('account-signed-in').hidden = true; $('account-signed-out').hidden = false;
      setAccountMessage('Sign in to view your live balance.');
    } else setAccountMessage(error.message, true);
  }
}
async function authenticateAccount(action) {
  const email = $('account-email').value.trim(); const password = $('account-password').value;
  if (!email || !password) { setAccountMessage('Enter your email and password first.', true); return; }
  $('account-login').disabled = $('account-register').disabled = true;
  setAccountMessage(action === 'register' ? 'Creating your account…' : 'Signing in…');
  try {
    const result = await shell.account({ action, email, password });
    $('account-password').value = ''; showAccount({ account: result.account, usage: { credits: result.account.credits } });
    setAccountMessage(action === 'register' ? 'Account created. Your 50 trial credits are ready.' : 'Signed in.');
    await refreshUsage();
  } catch (error) { setAccountMessage(error.message, true); }
  finally { $('account-login').disabled = $('account-register').disabled = false; }
}
$('account-login').addEventListener('click', () => authenticateAccount('login'));
$('account-register').addEventListener('click', () => authenticateAccount('register'));
$('account-password').addEventListener('keydown', event => { if (event.key === 'Enter') authenticateAccount('login'); });
$('usage-refresh').addEventListener('click', refreshUsage);
$('account-logout').addEventListener('click', async () => {
  try { await shell.account({ action: 'logout' }); $('account-signed-in').hidden = true; $('account-signed-out').hidden = false; setAccountMessage('Signed out.'); }
  catch (error) { setAccountMessage(error.message, true); }
});
refreshUsage(); setInterval(refreshUsage, 15000);
async function populateDevices(selected) {
  try {
    const { devices } = await runtime({ route: '/api/devices' }); const microphone = $('microphone'); microphone.replaceChildren();
    for (const device of devices) { const option = document.createElement('option'); option.value = device.id; option.textContent = `${device.id} · ${device.name}`; microphone.append(option); }
    selectValue('microphone', selected);
  } catch (error) { console.warn('Audio device list unavailable', error); }
}
async function initializeRuntime() {
  const state = await runtime({ route: '/api/state' });
  hydrate(state);
  if (!devicesReady) {
    devicesReady = true;
    await populateDevices(state.config?.voice?.input_device);
  }
}
async function updateSettings(changes) {
  for (const [key,value] of Object.entries(changes)) {
    const reaction = key === 'discord.enabled' ? (value ? 'discord_on' : 'discord_off')
      : key === 'discord.autonomy_enabled' ? (value ? 'autonomy_on' : 'autonomy_off')
      : key.startsWith('model.') ? 'model_change' : key === 'voice.input_device' ? 'microphone_change'
      : key.startsWith('voice.') ? 'voice_change' : 'settings_change';
    dispatchInterfaceReaction(reaction);
  }
  try { const state = await runtime({ route: '/api/config', method: 'POST', body: { changes } }); hydrate(state); }
  catch (error) { movement?.react('error'); addMessage('stella', `Control update failed: ${error.message}`); }
}
for (const [id, key] of Object.entries(configField)) {
  // Some settings exist only in onboarding, not the main console.
  const control = $(id);
  if (!control) continue;
  control.addEventListener('change', event => {
    if (!settingsReady) return;
    const value = id === 'eleven-keyterms' ? event.target.value.split(',').map(term => term.trim()).filter(Boolean)
      : event.target.type === 'checkbox' ? event.target.checked : (event.target.type === 'number' ? Number(event.target.value) : event.target.value);
    updateSettings({ [key]: value });
  });
}
$('endpoint').addEventListener('input', event => { $('endpoint-value').textContent = `${event.target.value} ms`; });
$('endpoint').addEventListener('change', event => updateSettings({ 'voice.inworld_stt_min_eot_silence_ms': Number(event.target.value) }));
$('chat-form').addEventListener('submit', async event => {
  event.preventDefault(); const input = $('chat-input'); const text = input.value.trim(); if (!text) return;
  input.value = ''; try { await runtime({ route: '/api/chat', method: 'POST', body: { text } }); } catch (error) { addMessage('stella', `Message failed: ${error.message}`); }
});
$('call-toggle').addEventListener('click', async () => {
  try { const result = await runtime({ route: '/api/call/toggle', method: 'POST' }); movement?.react(result.call_active ? 'call_start' : 'call_end'); $('call-toggle').textContent = result.call_active ? 'END CALL  ◉' : 'START CALL  ◉'; $('call-toggle').classList.toggle('active', result.call_active); }
  catch (error) { addMessage('stella', `Call control failed: ${error.message}`); }
});
async function pollRuntime() {
  try {
    // The runtime starts alongside Electron. If the first request wins that
    // race, keep retrying state hydration instead of polling events forever
    // with settingsReady permanently false.
    if (!settingsReady) await initializeRuntime();
    const packet = await runtime({ route: '/api/events', query: `?after=${eventCursor}` }); eventCursor = packet.last ?? eventCursor;
    for (const event of packet.events || []) {
      if (event.type === 'sage_stream_chat') addMessage('viewer', event.data.text, { display_name: event.data.name, at: event.data.at, simulated: event.data.simulated });
      if (event.type === 'sage_stream_reply') addMessage('stella', event.data.text, { response_id: event.data.event_id });
      if (event.type === 'sage_error') addMessage('stella', `SAGE notice: ${event.data.message}`);
    }
    for (const event of packet.events || []) { if (event.type === 'message') addMessage(event.data.speaker, event.data.text, event.data); else if (event.type === 'onboarding_speech_done') window.dispatchEvent(new CustomEvent('stella-onboarding-speech-done', { detail: event.data })); else if (event.type === 'interface_reaction') dispatchInterfaceReaction(event.data.name); else if (event.type === 'status' || event.type === 'call_state') setStatus(event.data.text || event.data.state); else if (event.type === 'error') { dispatchInterfaceReaction('error'); addMessage('stella', `Runtime note: ${event.data.message}`); } }
    if (settingsReady) { const state = await runtime({ route: '/api/state' }); hydrate(state); }
  } catch (error) { setStatus(settingsReady ? 'runtime reconnecting' : 'runtime starting'); }
  setTimeout(pollRuntime, 650);
}
(async () => {
  try { await initializeRuntime(); }
  catch (error) { setStatus('runtime starting'); }
  pollRuntime();
})();

const previewSelect = $('movement-choice');
window.addEventListener('stella-presenter', event => {
  const name = event.detail?.pose;
  if (INTERFACE_REACTIONS[name]) movement?.react(name);
  else if (GESTURES[name] || CUSTOM_POSES[name]) movement?.play(name, { force: true });
});
for (const name of [...Object.keys(GESTURES), ...Object.keys(CUSTOM_POSES), ...Object.keys(INTERFACE_REACTIONS).map(n => 'ui:' + n)]) {
  const option = document.createElement('option'); option.value = name; option.textContent = name.replaceAll('_', ' '); previewSelect?.append(option);
}
$('movement-play')?.addEventListener('click', () => {
  const name = previewSelect.value;
  if (name.startsWith('ui:')) movement?.react(name.slice(3)); else movement?.play(name, { force: true });
});
for (const phase of ['idle','listening','speaking']) $(`preview-${phase}`)?.addEventListener('click', () => {
  audioMouth = new AudioMouth();
  previewPhase = phase; previewUntil = elapsed + 12;
});
$('movement-family')?.addEventListener('change', event => {
  if (!movement?.setFamily(event.target.value)) {
    event.target.value = movement?.family || 'stella';
    $('movement-readout').textContent = 'Motion family is still loading. Try again shortly.';
  }
});
