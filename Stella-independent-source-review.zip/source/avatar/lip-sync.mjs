/** Playback RMS -> mouth weight. receive(packet); update(dtSeconds).
 * Forward audio_sequence, audio_age_ms and audio_stopped through the protocol.
 * Recreate on producer reconnect: sequence numbers are producer-local.
 * Legacy packets refresh only on RMS changes; heartbeats are not audio evidence.
 */
export class AudioMouth {
  constructor() {
    this.weight = 0;
    this.target = 0;
    this.age = Infinity;
    this.sequence = null;
    this.legacyLevel = null;
  }

  receive(packet) {
    if (!packet || typeof packet !== 'object') return;
    const sequenced = Number.isSafeInteger(packet.audio_sequence) && packet.audio_sequence >= 0;
    if (sequenced && this.sequence !== null && packet.audio_sequence < this.sequence) return;
    if (packet.audio_stopped === true || packet.interrupted === true || packet.speech_finished === true) {
      if (sequenced) this.sequence = packet.audio_sequence;
      this.target = this.weight = 0;
      this.age = Infinity;
      this.legacyLevel = null;
      return;
    }
    const level = Number.isFinite(packet.speech_level) ? Math.max(0, Math.min(1, packet.speech_level)) : 0;
    if (sequenced) {
      const age = Number.isFinite(packet.audio_age_ms) && packet.audio_age_ms >= 0
        ? packet.audio_age_ms / 1000 : Infinity;
      if (packet.audio_sequence === this.sequence) {
        // Body ticks cannot restart the audio expiry clock.
        this.age = Math.max(this.age, age);
        return;
      }
      this.sequence = packet.audio_sequence;
      this.age = age;
    } else {
      if (this.sequence !== null) return;
      if (level === this.legacyLevel) return;
      this.legacyLevel = level;
      this.age = 0;
    }
    // Streamed playback can precede the semantic speaking flag.
    this.target = Math.min(.55, Math.max(0, level - .012) * 4);
  }

  update(dt) {
    if (!Number.isFinite(dt) || dt <= 0) return this.weight;
    // Split at expiry so a long frame cannot prolong an open mouth.
    const live = Math.min(dt, Math.max(0, .150 - this.age));
    if (live > 0) this._advance(this.target, live);
    if (dt > live) this._advance(0, dt - live);
    this.age += dt;
    return this.weight;
  }

  _advance(target, dt) {
    const tau = target > this.weight ? .018 : .025;
    this.weight += (target - this.weight) * -Math.expm1(-dt / tau);
    if (target === 0 && this.weight < .001) this.weight = 0;
  }
}
