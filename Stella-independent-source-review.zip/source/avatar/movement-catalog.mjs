// Semantic choices never select arbitrary files. All clips share one source rig.
export const BASES = {
  idle: ['stella_idle_rest_a', 'stella_idle_rest_b', 'stella_idle_rest_c'],
  listening: ['rb-listen', 'rb-listen-2', 'rb-listen-3'],
  speaking: ['rb-idle-talking', 'rb-idle-talking-2', 'rb-idle-talking-3'],
};
export const GESTURES = {
  wave: ['rb-wave', 'rb-wave-2'],
  small_nod: ['rb-nod', 'rb-nod-2', 'rb-nod-3'],
  small_shake: ['rb-shake', 'rb-shake-2', 'rb-shake-3'],
  small_head_tilt: ['rb-neutral-3'],
  head_turn: ['rb-neutral', 'rb-neutral-2', 'rb-neutral-4', 'rb-neutral-5'],
  shrug: ['rb-shrug', 'rb-shrug-2'],
  think: ['rb-think', 'rb-think-2'],
  laugh: ['rb-laugh'],
  celebrate: ['rb-happy', 'rb-happy-2', 'rb-happy-3'],
  stretch: ['rb-relaxed', 'rb-relaxed-2', 'rb-relaxed-3', 'rb-relaxed-4'],
  explain: ['rb-idle-talking-2'],
  disappointed: ['rb-sad'],
  annoyed: ['rb-angry', 'rb-angry-2'],
};
export const CUSTOM_POSES = {
  pout: { head: [.16, -.13, -.075], chest: [.075, 0, 0], leftShoulder: [0, 0, .11], rightShoulder: [0, 0, -.11] },
  lean_in: { spine: [.07, 0, 0], chest: [.035, 0, 0], head: [-.07, 0, .015] },
  lean_back: { spine: [-.055, 0, 0], chest: [-.025, 0, 0], head: [.04, 0, 0] },
  curious: { head: [0, .055, .09], chest: [.025, 0, 0] },
  pleased: { chest: [-.025, 0, 0], head: [-.025, 0, -.035] },
  startle: { chest: [-.045, 0, 0], head: [-.025, 0, 0], leftShoulder: [0, 0, .08], rightShoulder: [0, 0, -.08] },
};
// Most controls get a glance or posture reaction. Only social connection changes
// request a spoken remark; moving sliders must never flood the conversation.
export const INTERFACE_REACTIONS = {
  discord_off: { pose: 'pout', expression: 'annoyed', intensity: .62, seconds: 9, gaze: [.18, .03] },
  discord_on: { pose: 'pleased', expression: 'warm', intensity: .58, seconds: 7, gaze: [.16, 0] },
  autonomy_off: { pose: 'pout', expression: 'annoyed', intensity: .3, seconds: 4 },
  autonomy_on: { pose: 'pleased', expression: 'playful', intensity: .45, seconds: 4 },
  call_start: { pose: 'lean_in', expression: 'warm', intensity: .4, seconds: 3 },
  call_end: { pose: 'pleased', expression: 'warm', intensity: .35, seconds: 4 },
  model_change: { pose: 'curious', expression: 'curious', intensity: .5, seconds: 4 },
  voice_change: { pose: 'curious', expression: 'curious', intensity: .42, seconds: 4 },
  microphone_change: { pose: 'lean_in', expression: 'focused', intensity: .3, seconds: 3 },
  settings_change: { pose: 'curious', expression: 'focused', intensity: .2, seconds: 2, gaze: [.15, .03] },
  camera: { pose: 'pleased', expression: 'playful', intensity: .4, seconds: 3 },
  pin: { pose: 'pleased', expression: 'warm', intensity: .25, seconds: 2 },
  recenter: { pose: 'pleased', expression: 'neutral', intensity: .2, seconds: 2, gaze: [0, 0] },
  zoom_in: { pose: 'curious', expression: 'curious', intensity: .35, seconds: 3 },
  zoom_out: { pose: 'pleased', expression: 'neutral', intensity: .2, seconds: 2 },
  drag: { pose: 'curious', expression: 'curious', intensity: .25, seconds: 2 },
  orbit: { pose: 'curious', expression: 'playful', intensity: .3, seconds: 3 },
  error: { pose: 'curious', expression: 'confused', intensity: .4, seconds: 3 },
  minimize: { pose: 'pleased', expression: 'relaxed', intensity: .2, seconds: 2 },
};
export const ALL_CLIPS = [...new Set([...Object.values(BASES).flat(), ...Object.values(GESTURES).flat()])];
