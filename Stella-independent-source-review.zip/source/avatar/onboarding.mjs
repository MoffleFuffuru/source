const $ = id => document.getElementById(id);
const app = window.stella;
const onboarding = $('onboarding');
const content = $('onboarding-content');
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
const prefersReducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
let step = 0, config = {}, devices = [], outputs = [], meterStream = null, meterContext = null, meterFrame = 0;
let speechId = 0, speechResolve = null, narrationSerial = 0, micReady = false, micGreetingShown = false, textOnly = false;
let account = null, pickedVoice = '', memoryEnabled = true, voiceLineTimer = null;

const panels = [
  { name: 'AUDIO OUTPUT', pose: 'curious' }, { name: 'MICROPHONE', pose: 'microphone_change' },
  { name: 'ACCOUNT', pose: 'pleased' }, { name: 'VOICE', pose: 'voice_change' },
  { name: 'MEMORY & PRIVACY', pose: 'think' }, { name: 'READY', pose: 'celebrate' },
];

function pose(name) { window.dispatchEvent(new CustomEvent('stella-presenter', { detail: { pose: name } })); }
function showCaption(text) { $('onboarding-caption').textContent = text || ''; }
function setContinue(enabled, label = 'CONTINUE') { const button = $('onboarding-continue'); button.disabled = !enabled; button.textContent = label; }
function cancelNarration() {
  narrationSerial++;
  if (speechResolve) { speechResolve(); speechResolve = null; }
  app.request({ route: '/api/onboarding/stop-speaking', method: 'POST' }).catch(() => {});
}
function sleep(ms, serial) { return new Promise(resolve => setTimeout(() => resolve(serial === narrationSerial), ms)); }
async function say(text, serial = narrationSerial) {
  if (serial !== narrationSerial) return false;
  const id = `onboard-${++speechId}`;
  showCaption(text);
  const finished = new Promise(resolve => {
    const timeout = setTimeout(() => { window.removeEventListener('stella-onboarding-speech-done', done); resolve(false); }, 45000);
    function done(event) {
      if (event.detail?.request_id !== id) return;
      clearTimeout(timeout); window.removeEventListener('stella-onboarding-speech-done', done); resolve(true);
    }
    window.addEventListener('stella-onboarding-speech-done', done);
    speechResolve = () => { clearTimeout(timeout); window.removeEventListener('stella-onboarding-speech-done', done); resolve(false); };
  });
  try { await app.request({ route: '/api/onboarding/speak', method: 'POST', body: { text, request_id: id } }); }
  catch (error) { showCaption(`Voice preview unavailable: ${error.message}`); speechResolve?.(); speechResolve = null; return false; }
  const result = await finished;
  if (speechResolve) speechResolve = null;
  return result && serial === narrationSerial;
}
async function script(lines, entryDelay = 500) {
  const serial = ++narrationSerial;
  if (!await sleep(entryDelay, serial)) return;
  for (const [text, pauseAfter = 0] of lines) {
    if (!await say(text, serial)) return false;
    if (pauseAfter && !await sleep(pauseAfter, serial)) return false;
  }
  return serial === narrationSerial;
}
async function updateConfig(changes) {
  try {
    const state = await app.request({ route: '/api/config', method: 'POST', body: { changes } });
    config = state.config || config;
    window.dispatchEvent(new CustomEvent('stella-onboarding-config', { detail: state }));
  } catch (error) { showCaption(`Couldn't save that setting: ${error.message}`); throw error; }
}
function selectedDevice(select) { return select.value === '' ? null : Number(select.value); }
function deviceOptions(list, selected, emptyText) {
  const none = `<option value="">${emptyText}</option>`;
  return none + list.map(device => `<option value="${device.id}" ${String(device.id) === String(selected) ? 'selected' : ''}>${String(device.name).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}</option>`).join('');
}
function render() {
  const panel = panels[step];
  $('onboarding-step-label').textContent = `STEP ${step + 1} OF ${panels.length} · ${panel.name}`;
  $('onboarding-progress').value = step + 1;
  $('onboarding-back').disabled = step === 0;
  $('onboarding-skip').hidden = ![1, 3, 4].includes(step);
  $('onboarding-skip').textContent = step === 1 ? 'USE TEXT ONLY' : 'SKIP';
  $('onboarding-continue').hidden = step === 0 || step === 2;
  setContinue(step !== 0 && step !== 2, step === 5 ? 'FINISH' : 'CONTINUE');
  pose(panel.pose);
  if (step === 0) renderOutput();
  if (step === 1) renderMicrophone();
  if (step === 2) renderAccount();
  if (step === 3) renderVoice();
  if (step === 4) renderMemory();
  if (step === 5) renderReady();
  requestAnimationFrame(() => document.querySelector('.onboarding-card')?.animate(
    [{ opacity: .7, transform: 'translateY(8px)' }, { opacity: 1, transform: 'none' }],
    { duration: prefersReducedMotion ? 1 : 360, easing: 'cubic-bezier(.2,.8,.2,1)' }
  ));
}
function renderOutput() {
  content.innerHTML = `<h1>Let's make sure you can hear me.</h1><p class="onboard-script">Choose where Stella should speak. The test starts only when you press the button.</p>
    <label>OUTPUT DEVICE<select id="setup-output"></select></label>
    <label>VOLUME <span id="setup-volume-value">${Math.round((config.voice?.output_volume ?? 1) * 100)}%</span><input id="setup-volume" type="range" min="0" max="1" step="0.01" value="${config.voice?.output_volume ?? 1}"></label>
    <div class="onboard-actions"><button class="primary" id="setup-test-output">PLAY STELLA</button><button id="setup-heard" disabled>YEP, I HEAR YOU</button><button id="setup-nope" disabled>NOPE</button></div>
    <p class="onboard-hint" id="setup-output-hint">Pick an output, then play the voice test.</p>`;
  const select = $('setup-output'); select.innerHTML = deviceOptions(outputs, config.voice?.output_device, 'System default');
  select.onchange = async () => { await updateConfig({ 'voice.output_device': selectedDevice(select) }); };
  $('setup-volume').oninput = event => {
    $('setup-volume-value').textContent = `${Math.round(Number(event.target.value) * 100)}%`;
    clearTimeout(voiceLineTimer); voiceLineTimer = setTimeout(() => updateConfig({ 'voice.output_volume': Number(event.target.value) }), 130);
  };
  $('setup-test-output').onclick = async () => {
    $('setup-heard').disabled = $('setup-nope').disabled = true;
    const lines = [['oh.', 400], ['hi.', 500], ["before we do anything else, let's make sure you can actually hear me."], ["if you can't hear this, we're going to have a pretty serious communication problem."]];
    await script(lines, 0);
    $('setup-heard').disabled = $('setup-nope').disabled = false;
    pose('pleased');
  };
  $('setup-heard').onclick = async () => { cancelNarration(); pose('pleased'); await script([['good.', 300], ["then i guess i exist now."]], 0); next(); };
  $('setup-nope').onclick = async () => { cancelNarration(); pose('confused'); await script([['okay. rude.', 300], ['try another output.']], 0); $('setup-output').focus(); };
}
function renderMicrophone() {
  stopMeter();
  content.innerHTML = `<h1>Now I need to hear you.</h1><p class="onboard-script">Pick your microphone and say something. The meter checks input locally.</p>
    <label>MICROPHONE<select id="setup-mic"></select></label><div class="onboard-meter"><i id="mic-level"></i></div>
    <div class="onboard-actions"><button class="primary" id="setup-test-mic">TEST MICROPHONE</button><button id="setup-text-only">NO MICROPHONE · USE TEXT ONLY</button></div>
    <p class="onboard-hint" id="setup-mic-hint">Your microphone audio is used for the level test and is not recorded by this meter.</p>`;
  const select = $('setup-mic'); select.innerHTML = deviceOptions(devices, config.voice?.input_device, 'Choose a microphone');
  select.onchange = async () => { await updateConfig({ 'voice.input_enabled': true, 'voice.input_device': selectedDevice(select) }); micReady = false; micGreetingShown = false; setContinue(false); };
  $('setup-test-mic').onclick = async () => {
    try {
      stopMeter();
      const chosen = select.value ? devices.find(d => String(d.id) === select.value) : null;
      const available = await navigator.mediaDevices.enumerateDevices();
      const matching = chosen && available.find(d => d.kind === 'audioinput' && d.label && d.label.toLowerCase().includes(chosen.name.toLowerCase().slice(0, 14)));
      meterStream = await navigator.mediaDevices.getUserMedia({ audio: matching ? { deviceId: { exact: matching.deviceId } } : true });
      meterContext = new AudioContext(); const analyser = meterContext.createAnalyser(); analyser.fftSize = 512;
      meterContext.createMediaStreamSource(meterStream).connect(analyser);
      const samples = new Uint8Array(analyser.fftSize); let peak = 0, spokeAt = 0, lowAttempts = 0;
      const draw = () => {
        analyser.getByteTimeDomainData(samples);
        let sum = 0; for (const value of samples) { const sample = (value - 128) / 128; sum += sample * sample; }
        const rms = Math.sqrt(sum / samples.length); $('mic-level').style.width = `${Math.min(100, rms * 360)}%`;
        if (rms > .012) { spokeAt ||= Date.now(); peak = Math.max(peak, rms); }
        if (Date.now() - spokeAt > 1100 && spokeAt) {
          spokeAt = 0;
          if (peak > .025) { micReady = true; setContinue(true); if (!micGreetingShown) { micGreetingShown = true; pose('pleased'); script([['oh.', 250], ['there you are.', 250], ['yep. i can hear you.']], 0); } }
          else lowAttempts++;
          peak = 0;
        }
        if (lowAttempts >= 3) { $('setup-mic-hint').textContent = 'Your microphone is very quiet. Try increasing its level or choosing another input.'; pose('curious'); lowAttempts = -100; }
        meterFrame = requestAnimationFrame(draw);
      };
      draw(); await updateConfig({ 'voice.input_enabled': true, 'voice.input_device': selectedDevice(select) });
      $('setup-mic-hint').textContent = 'Listening for your test phrase…';
    } catch (error) { $('setup-mic-hint').textContent = `Microphone unavailable: ${error.message}`; }
  };
  $('setup-text-only').onclick = async () => { textOnly = true; micReady = true; stopMeter(); await updateConfig({ 'voice.input_enabled': false, 'voice.input_device': null }); $('setup-mic-hint').textContent = "that's fine. text works. i'll survive without ears."; setContinue(true); pose('shrug'); script([["that's fine.", 250], ['text works.', 250], ["i'll survive without ears."]], 0); };
  setContinue(false);
}
function stopMeter() { if (meterFrame) cancelAnimationFrame(meterFrame); meterFrame = 0; if (meterStream) { for (const track of meterStream.getTracks()) track.stop(); meterStream = null; } if (meterContext) { meterContext.close().catch(() => {}); meterContext = null; } }
function renderAccount() {
  content.innerHTML = `<h1>Next, we need to figure out who you are.</h1><p class="onboard-script">Not philosophically. I'm not qualified for that.</p>
    <p>Your account connects your settings, credits, and memory choices. No API keys or developer setup.</p>
    <label>EMAIL<input id="setup-email" type="email" autocomplete="username" maxlength="254" placeholder="you@example.com"></label>
    <label>PASSWORD<input id="setup-password" type="password" autocomplete="current-password" minlength="12" maxlength="1024"></label>
    <div class="onboard-actions"><button class="primary" id="setup-signin">SIGN IN</button><button id="setup-register">CREATE ACCOUNT</button></div><p class="onboard-hint" id="setup-account-status">Sign in or create your account to continue.</p>`;
  if (account) $('setup-account-status').textContent = `Signed in · ${account.account_id.slice(0, 8)} · ${account.credits?.total ?? 0} credits`;
  const submit = async action => {
    const email = $('setup-email').value.trim(), password = $('setup-password').value;
    if (!email || !password) { $('setup-account-status').textContent = 'Enter your email and password first.'; return; }
    cancelNarration(); const waitSerial = narrationSerial; let waitLine = false;
    const timers = [1500, 2500, 5000].map((ms, index) => setTimeout(async () => {
      if (waitSerial !== narrationSerial || account) return;
      if (index === 0) { pose('think'); $('setup-account-status').textContent = 'Creating your account…'; }
      if (index === 1 && !waitLine) { waitLine = true; await say('...still thinking.', waitSerial); }
      if (index === 2) await say('apparently bureaucracy exists for robots too.', waitSerial);
    }, ms));
    try {
      const response = await app.account({ action, email, password }); account = response.account;
      timers.forEach(clearTimeout); cancelNarration(); $('setup-password').value = '';
      $('setup-account-status').textContent = `Signed in · ${account.account_id.slice(0, 8)} · ${account.credits?.total ?? 0} credits`;
      $('setup-signin').disabled = $('setup-register').disabled = true; setContinue(true); pose('celebrate');
      await script([['there you are.', 350], ['officially a person.', 250], ...(action === 'register' ? [['congratulations.']] : [])], 0);
    } catch (error) { timers.forEach(clearTimeout); $('setup-account-status').textContent = error.message; }
  };
  $('setup-signin').onclick = () => submit('login'); $('setup-register').onclick = () => submit('register');
  $('setup-signin').disabled = $('setup-register').disabled = Boolean(account);
  setContinue(Boolean(account));
}
function renderVoice() {
  const currentId = config.voice?.elevenlabs_tts_voice || '';
  pickedVoice = currentId;
  content.innerHTML = `<h1>You get to decide what I sound like.</h1><p class="onboard-script">No pressure. You can change it later, so don't have an existential crisis over it.</p>
    <div class="voice-choice"><span class="voice-orb">S</span><div><strong>${currentId ? 'Your configured Stella voice' : 'Current voice provider'}</strong><small>${currentId ? 'Selected voice is ready to preview' : 'A voice will be available when your account voice service is connected'}</small></div></div>
    <label>STELLA VOICE ID<input id="setup-voice-id" type="text" value="${currentId.replace(/[&<>"']/g, '')}" autocomplete="off" placeholder="Voice supplied by your Stella account"></label>
    <div class="onboard-actions"><button class="primary" id="setup-preview-voice" ${currentId ? '' : 'disabled'}>PREVIEW STELLA</button><span class="onboard-hint" id="setup-voice-status">Use the same short line to compare voice changes.</span></div>`;
  $('setup-voice-id').onchange = async event => {
    pickedVoice = event.target.value.trim(); await updateConfig({ 'voice.elevenlabs_tts_voice': pickedVoice });
    $('setup-preview-voice').disabled = !pickedVoice;
  };
  $('setup-preview-voice').onclick = async () => { await updateConfig({ 'voice.elevenlabs_tts_voice': $('setup-voice-id').value.trim() }); await script([["okay, i actually kinda like this one."]], 0); };
  setContinue(true);
}
function renderMemory() {
  memoryEnabled = config.memory?.enabled !== false;
  content.innerHTML = `<h1>Okay. This one's actually important.</h1><p>Memory lets Stella use continuity between conversations. Replies and voice are processed by external AI services; optional integrations stay off unless you enable them.</p>
    <p>Choose whether Stella can use saved memory. When off, replies use only temporary in-session dialogue context. Existing memory files are not deleted, but are not included in her replies.</p>
    <label class="memory-choice"><input type="radio" name="memory-mode" value="on" ${memoryEnabled ? 'checked' : ''}><span><strong>Memory enabled</strong><small>Use and retain saved continuity.</small></span></label>
    <label class="memory-choice"><input type="radio" name="memory-mode" value="off" ${!memoryEnabled ? 'checked' : ''}><span><strong>Memory disabled</strong><small>Keep dialogue context only for this session.</small></span></label>
    <details class="privacy-details"><summary>Privacy details</summary><p>Provider processing, account records, memory files, and retention are separate. Optional connections such as Discord remain disabled until explicitly enabled in Settings.</p></details>`;
  content.querySelectorAll('[name=memory-mode]').forEach(input => input.onchange = async () => {
    memoryEnabled = input.value === 'on'; await updateConfig({ 'memory.enabled': memoryEnabled }); pose(memoryEnabled ? 'pleased' : 'shrug');
  });
  content.querySelector('.privacy-details').addEventListener('toggle', event => { if (event.target.open) { pose('curious'); script([["oh. you're actually reading it.", 350], ['good.']], 0); } });
  setContinue(true);
}
async function renderReady() {
  const accountText = account ? `Account: ${account.email}` : 'Account: Not signed in';
  const voiceText = pickedVoice ? 'Voice: Selected' : 'Voice: Provider default';
  const micText = textOnly ? 'Microphone: Text only' : `Microphone: ${config.voice?.input_device == null ? 'System default' : 'Selected'}`;
  content.innerHTML = `<h1>Looks like everything survived.</h1><p>Quick check before I let you loose:</p><ul class="onboard-checks"><li data-check="audio">Audio output: ${outputs.find(d => String(d.id) === String(config.voice?.output_device))?.name || 'System default'}</li><li data-check="mic">${micText}</li><li data-check="account">${accountText}</li><li data-check="voice">${voiceText}</li><li data-check="memory">Memory: ${memoryEnabled ? 'On' : 'Off'}</li><li data-check="diagnostic">Stella: ...</li></ul><p id="diagnostic-label" class="onboard-hint">Checking one last thing…</p>`;
  setContinue(false, 'FINISH');
  for (const [index, item] of [...content.querySelectorAll('[data-check]')].entries()) {
    await wait(prefersReducedMotion ? 0 : 190); item.classList.add('ready');
    if (index < 5) await wait(prefersReducedMotion ? 0 : 130);
  }
  if (!prefersReducedMotion) await wait(1200);
  const diagnostic = content.querySelector('[data-check=diagnostic]');
  diagnostic.textContent = 'Stella: Probably fine ✓'; $('diagnostic-label').textContent = "don't worry about that one.";
  pose('small_head_tilt'); setContinue(true, 'FINISH');
  script([['alright.', 400], ['voice...', 220], ['microphone...', 220], ['account...', 220], ['memory...', 350], ['looks like everything survived.']], 0);
}
async function next() {
  cancelNarration(); stopMeter();
  if (step === 0) { step = 1; render(); script([['you can hear me.', 300], ['now i need to hear you.', 300], ['pick your microphone, then say something for me.']]); }
  else if (step === 1) { step = 2; render(); script([["next, we need to figure out who you are.", 350], ['not philosophically.', 250], ["i'm not qualified for that.", 350], ['your account keeps your settings, credits, and the things i am allowed to remember connected to you.', 250], ["you won't need any weird API keys or developer stuff."]]); }
  else if (step === 2) { step = 3; render(); script([["now, this part's important.", 250], ['you have to decide what i sound like.', 250], ['no pressure.', 300], ["you can change it later, so don't sit here having an existential crisis over it."]]); }
  else if (step === 3) { step = 4; render(); script([["okay. this one's actually important.", 250], ['memory is what lets me remember conversations instead of meeting you for the first time every time you open the app.', 300], ['if you want that, turn it on.', 250], ["if you don't, leave it off. i'm not going to sneak around behind the switch."]], 650); }
  else if (step === 4) { step = 5; render(); }
  else await finish();
}
async function back() {
  if (step === 0) return;
  cancelNarration(); stopMeter(); step--; render();
}
async function finish() {
  cancelNarration(); stopMeter(); await app.onboardingComplete();
  document.body.classList.remove('onboarding-active'); onboarding.hidden = true;
  showCaption('');
  await wait(800); pose('pleased'); await script([['well...', 600], ['hi.', 250], ["i'm Stella."]], 0);
}
function goForward() { if (step === 0) return; if (step === 1 && !micReady) return; if (step === 2 && !account) return; if (step === 3) {
    if (!prefersReducedMotion && !localStorage.getItem('stellaVoiceFakeContinue')) {
      localStorage.setItem('stellaVoiceFakeContinue', '1'); setContinue(false); pose('small_head_tilt'); script([["...you thought i'd let you leave that easily?", 700], ["i'm kidding. press it again."]], 700).then(() => setContinue(true)); return;
    }
  } next(); }
$('onboarding-back').onclick = back;
$('onboarding-continue').onclick = goForward;
$('onboarding-skip').onclick = async () => {
  if (step === 1) { textOnly = true; micReady = true; await updateConfig({ 'voice.input_enabled': false, 'voice.input_device': null }); }
  if (step === 3 || step === 4) return next();
  setContinue(true); await next();
};
window.addEventListener('stella-onboarding-speech-done', event => { if (event.detail?.request_id === 'onboarding-final') showCaption(''); });
window.addEventListener('stella-onboarding-config', event => { config = event.detail.config || config; });

async function start() {
  try {
    const forced = new URLSearchParams(location.search).has('onboarding');
    const state = await app.onboardingState(); if (state.complete && !forced) return;
    const runtime = await app.request({ route: '/api/state' }); config = runtime.config || {};
  memoryEnabled = config.memory?.enabled !== false;
    try { account = (await app.account({ action: 'session' })).account; } catch { account = null; }
    const listed = await app.request({ route: '/api/devices' }); devices = listed.devices || []; outputs = listed.output_devices || [];
    document.body.classList.add('onboarding-active'); onboarding.hidden = false; render();
    if (!config.voice?.elevenlabs_tts_voice) showCaption('Connect Stella’s voice service to hear the narrated onboarding. You can continue setup silently.');
    // Audio-device card intentionally waits for a direct click before playing speech.
  } catch (error) { console.warn('Stella onboarding could not start:', error); }
}
start();
