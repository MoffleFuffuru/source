// A local visual rehearsal with no microphone, Discord or model requests.
if (new URLSearchParams(location.search).has('movementLab') && !window.avatar) {
  const callbacks = {}; let sequence = 1, phase = 'idle', reactionToken = 0;
  const transitionTimers = [];
  const events = []; let last = 0;
  const state = {status:'movement lab (offline)', call_active:false, config:{model:{call_model:'qwen-3.8-27b',call_provider:'cerebras',call_reasoning_effort:'none',call_max_output_tokens:96,call_recent_turns:10}, voice:{stt_backend:'inworld_stt',tts_backend:'inworld_tts',inworld_tts_voice:'Piper',input_device:0,inworld_stt_min_eot_silence_ms:180},discord:{enabled:true,connected:false,autonomy_enabled:false}}};
  const bridge = {
    model: async () => ({ bytes: Array.from(new Uint8Array(await (await fetch('./assets/Mako.vrm')).arrayBuffer())), name:'Mako.vrm', path:'offline-lab' }),
    modelLoaded() {}, action() {},
    onBody: fn => { callbacks.body = fn; }, onAttention: fn => { callbacks.attention = fn; }, onLock() {}, onError() {},
    request: async ({ route, body }) => {
      if (route === '/api/state') return state;
      if (route === '/api/events') return { events:events.splice(0), last };
      if (route === '/api/devices') return {devices:[]};
      if (route === '/api/config') {
        for (const [key,value] of Object.entries(body.changes)) { const [group,field] = key.split('.'); state.config[group][field] = value; }
        if ('discord.enabled' in body.changes) {
          transitionTimers.splice(0).forEach(clearTimeout);
          const token = ++reactionToken;
          events.push({ id:++last, type:'interface_reaction', data:{name:body.changes['discord.enabled']?'discord_on':'discord_off',pose:body.changes['discord.enabled']?'pleased':'pout',expression:body.changes['discord.enabled']?'warm':'annoyed',intensity:.62,seconds:9,gaze:[.18,.03]} });
          phase = 'processing'; sequence++;
          transitionTimers.push(setTimeout(() => { if (token !== reactionToken) return; phase = 'speaking'; sequence++; events.push({ id:++last, type:'message', data:{speaker:'stella',text:'[Offline preview: simulated speaking transition, no model request.]'} }); }, 1000));
          transitionTimers.push(setTimeout(() => { if (token !== reactionToken) return; phase = 'idle'; sequence++; }, 6500));
        }
        return state;
      }
      if (route === '/api/call/toggle') { state.call_active = !state.call_active; phase = state.call_active ? 'listening' : 'idle'; sequence++; return state; }
      return {};
    },
  };
  window.avatar = bridge; window.stella = bridge;
  document.title = 'Stella Movement Lab (offline)';
  setInterval(() => callbacks.body?.({version:1,sequence,state:phase,speaking:phase==='speaking',speech_level:phase==='speaking' ? .045 + .04 * Math.sin(performance.now() * .012) : 0,intent:{expression:phase==='speaking'?'annoyed':'neutral',gesture:'none',intensity:.6,energy:.5,gaze:'speaker'}}), 50);
  addEventListener('pointermove', e => callbacks.attention?.({x:e.clientX/innerWidth*2-1,y:e.clientY/innerHeight*2-1,speed:.2}));
}
