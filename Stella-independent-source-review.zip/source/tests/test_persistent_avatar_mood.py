import unittest
from types import SimpleNamespace
from unittest.mock import Mock

from mako.core import MakoCore


class PersistentAvatarMoodTests(unittest.TestCase):
    def project(self, **traits):
        core = MakoCore.__new__(MakoCore)
        core.mood = SimpleNamespace(state=SimpleNamespace(
            warmth=traits.get("warmth", .28),
            playfulness=traits.get("playfulness", .36),
            curiosity=traits.get("curiosity", .55),
            irritation=traits.get("irritation", .06),
            energy=traits.get("energy", .48),
        ))
        core.body = SimpleNamespace(set_persistent_mood=Mock())
        core._sync_body_mood()
        return core.body.set_persistent_mood.call_args.args

    def test_persistent_traits_map_to_quiet_baseline(self):
        expression, intensity, energy = self.project(warmth=.8, energy=.6)
        self.assertEqual(expression, "warm")
        self.assertLessEqual(intensity, .30)
        self.assertEqual(energy, .6)

    def test_high_irritation_has_precedence_over_warmth(self):
        expression, intensity, _ = self.project(warmth=.9, irritation=.7)
        self.assertEqual(expression, "annoyed")
        self.assertLessEqual(intensity, .34)


if __name__ == "__main__":
    unittest.main()
