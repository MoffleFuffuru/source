from __future__ import annotations

import threading
import unittest
from collections import deque
from types import SimpleNamespace

from mako.body import ActingIntent
from mako.config import AppConfig
from mako.dialogue import DialogueManager
from mako.interface_events import interface_prompt, setting_reaction
from mako.models import ConversationEvent, EventSource, InteractionMode
from mako.shell_server import ShellRuntime


class _AlreadyRunning:
    def is_alive(self) -> bool:
        return True


class InterfaceMovementTests(unittest.TestCase):
    def test_discord_off_is_a_factual_non_user_event_with_a_pout(self) -> None:
        event = setting_reaction("discord.enabled", False)
        prompt = interface_prompt(event)

        self.assertEqual(event["name"], "discord_off")
        self.assertIn("disabled Discord integration", event["summary"])
        self.assertIn("Desktop conversation remains available", event["summary"])
        self.assertIn("not user speech", prompt)
        self.assertIn("pout", prompt)
        self.assertIn("Do not claim", prompt)

    def test_interface_events_coalesce_to_most_recent_state(self) -> None:
        runtime = ShellRuntime.__new__(ShellRuntime)
        runtime._lock = threading.Lock()
        runtime._events = deque()
        runtime._sequence = 0
        runtime._interface_pending = None
        runtime._interface_worker = _AlreadyRunning()

        runtime._react_to_setting("discord.enabled", False)
        runtime._react_to_setting("discord.enabled", True)

        self.assertEqual(runtime._interface_pending[1]["name"], "discord_on")
        reactions = [e["data"]["name"] for e in runtime._events if e["type"] == "interface_reaction"]
        self.assertEqual(reactions, ["discord_off", "discord_on"])

    def test_non_social_controls_do_not_queue_spoken_comments(self) -> None:
        runtime = ShellRuntime.__new__(ShellRuntime)
        runtime._lock = threading.Lock()
        runtime._events = deque()
        runtime._sequence = 0
        runtime._interface_pending = None
        runtime._interface_worker = None

        runtime._react_to_setting("voice.input_device", 2)

        self.assertIsNone(runtime._interface_pending)
        self.assertEqual(runtime._events[-1]["type"], "interface_reaction")
        self.assertEqual(runtime._events[-1]["data"]["name"], "microphone_change")

    def test_discord_event_dispatch_starts_before_slow_client_shutdown(self) -> None:
        order: list[str] = []
        config = AppConfig()
        config.discord.enabled = True
        runtime = ShellRuntime.__new__(ShellRuntime)
        runtime.core = SimpleNamespace(
            config=config,
            save_config=lambda: None,
        )
        runtime.discord = SimpleNamespace(
            _thread=None,
            stop=lambda: order.append("discord_stop"),
        )
        runtime.call = SimpleNamespace(active=False)
        runtime._lock = threading.Lock()
        runtime._events = deque()
        runtime._sequence = 0
        runtime._busy = False
        runtime._interface_pending = None
        runtime._interface_worker = _AlreadyRunning()
        runtime._react_to_setting = lambda key, value: order.append("qwen_event")

        runtime.update_config({"discord.enabled": False})

        self.assertEqual(order, ["qwen_event", "discord_stop"])

    def test_dialogue_gestures_are_recognized_by_the_body_controller(self) -> None:
        intent = ActingIntent.normalized(gesture="small_nod")
        self.assertEqual(intent.gesture, "small_nod")
        self.assertEqual(ActingIntent.normalized(gesture="pout").gesture, "pout")
        self.assertEqual(ActingIntent.normalized(gesture="invented").gesture, "none")

    def test_call_prompt_marks_the_control_event_as_interface_state(self) -> None:
        manager = SimpleNamespace(config=SimpleNamespace(model=SimpleNamespace(call_memory_limit=4)))
        event = ConversationEvent(
            content="The user just disabled Discord integration.",
            source=EventSource.SYSTEM,
            mode=InteractionMode.CALL,
            metadata={"interface_event": setting_reaction("discord.enabled", False)},
        )
        prompt = DialogueManager._generation_prompt(
            manager,
            event=event,
            history=[], memories=[], mood_summary="",
            semantic_guidance="", lessons=[], rejected=[], private_feedback="",
            exhausted_topics=set(), forbidden_topics=set(),
        )

        self.assertIn("Interface event, not user speech", prompt)
        self.assertIn("Current interface state:", prompt)
        self.assertNotIn("Current transcript:", prompt)


if __name__ == "__main__":
    unittest.main()
