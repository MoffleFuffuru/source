from __future__ import annotations

import threading
import unittest
from types import SimpleNamespace
from uuid import uuid4

from mako.call import CallCallbacks, CallSession, _tts_acting, is_call_invitation
from mako.models import Expression, OutboundCallPlan, ResponseResult


class FakeCore:
    def __init__(self) -> None:
        self.config = SimpleNamespace(
            proactive_calls=SimpleNamespace(ring_timeout_seconds=30.0)
        )
        self.recorded: list[tuple[object, str]] = []

    def record_call_reflex(
        self,
        event,
        response_text: str,
        *,
        expression: Expression = Expression.NEUTRAL,
    ) -> ResponseResult:
        self.recorded.append((event, response_text))
        return ResponseResult(
            turn_id=uuid4().hex,
            event_id=event.id,
            text=response_text,
            expression=expression,
            move="prepared outbound call turn",
            complexity=1,
            mood_delta={},
            relationship_delta={},
            score=1.0,
            repaired=False,
            attempts=0,
            model="test",
            generation_seconds=0.0,
        )


class FakeVoice:
    def __init__(self) -> None:
        self.spoken: list[str] = []
        self.started = False
        self.stream_callbacks = []
        self.config = SimpleNamespace(tts_backend="elevenlabs_tts")

    def start(self, _on_utterance, _on_status) -> None:
        self.started = True

    def prepare_speech(self) -> None:
        pass

    def speak(self, text: str, on_done=None) -> None:
        self.spoken.append(text)
        if on_done:
            on_done()

    def speak_stream(self, _chunks, on_done=None, on_started=None) -> None:
        self.stream_callbacks.append(on_started)
        if on_started:
            on_started()
        if on_done:
            on_done()

    def stop(self) -> None:
        self.started = False


class AppCallDispatchTests(unittest.TestCase):
    def test_call_stream_forwards_first_audio_callback(self):
        from mako.call import _CallSpeechStream

        voice = FakeVoice()
        started = []
        stream = _CallSpeechStream(voice, lambda: None, on_started=lambda: started.append(True))
        stream.on_token('{"expression":"neutral","text":"Hello there. Next sentence."}')

        self.assertEqual(len(voice.stream_callbacks), 1)
        self.assertEqual(started, [True])

    def test_tts_acting_uses_stellas_response_expression_not_user_mood(self):
        result = SimpleNamespace(
            expression=Expression.CONCERNED,
            acting={"vocal_cue": "sigh", "delivery": "soft"},
        )
        self.assertEqual(_tts_acting(result), ("sigh", "soft", "concerned"))

    def test_stable_scribe_partial_can_start_speculation(self) -> None:
        from unittest.mock import Mock

        session = object.__new__(CallSession)
        session._lock = threading.RLock()
        session._active = True
        session._connected = True
        session._partial_text = "Sorry, Stella."
        session._generation_thread = None
        session._speculative_timer = None
        session._on_semantic_eot = Mock()

        session._start_stable_partial_speculation("Sorry, Stella.")

        session._on_semantic_eot.assert_called_once_with("Sorry, Stella.")

    def test_revised_scribe_partial_cannot_start_stale_speculation(self) -> None:
        from unittest.mock import Mock

        session = object.__new__(CallSession)
        session._lock = threading.RLock()
        session._active = True
        session._connected = True
        session._partial_text = "Sorry, Stella, I"
        session._generation_thread = None
        session._speculative_timer = None
        session._on_semantic_eot = Mock()

        session._start_stable_partial_speculation("Sorry, Stella.")

        session._on_semantic_eot.assert_not_called()

    def test_speculative_reply_is_only_validated_for_matching_final_transcript(self) -> None:
        from unittest.mock import Mock
        from mako.call import _SpeculativeCall
        from mako.models import ConversationEvent

        session = object.__new__(CallSession)
        session._lock = threading.RLock()
        session.core = SimpleNamespace(
            config=SimpleNamespace(model=SimpleNamespace(call_streaming_tts=False)),
            discard_deferred_call_response=Mock(),
        )
        session._speculative = _SpeculativeCall(
            provisional="Sorry, Stella.",
            event=ConversationEvent(content="Sorry, Stella."),
            cancel=threading.Event(), tokens=[], started_at=0.0,
        )
        session._deliver_speculative_if_ready = Mock()

        self.assertTrue(session._validate_speculative("Sorry, Stella!", voice_profile="calm; low energy"))
        self.assertTrue(session._speculative.validated)
        self.assertEqual(
            session._speculative.event.metadata["voice_profile"],
            "calm; low energy",
        )
        session._deliver_speculative_if_ready.assert_called_once()

        stale = session._speculative
        session._speculative = stale
        self.assertFalse(session._validate_speculative("Sorry, Stella, wait."))
        self.assertTrue(stale.cancel.is_set())
        session.core.discard_deferred_call_response.assert_called_once_with(stale.event.id)

    def test_every_finalized_call_utterance_dispatches_without_a_name_gate(self) -> None:
        from mako.affect import AffectState

        session = object.__new__(CallSession)
        session.core = SimpleNamespace()
        session.voice = SimpleNamespace(affect_snapshot=lambda _speaker: AffectState())
        session.callbacks = CallCallbacks(
            on_state=lambda _state: None, on_response=lambda _result: None,
            on_error=lambda error: self.fail(error), on_offer=lambda _plan: None,
            on_transcript=self._transcripts.append,
        )
        session._lock = threading.RLock()
        session._active = True
        session._connected = True
        session._xai_voice = None
        session._partial_text = "sorry"
        session._journal = None
        session._voice_profile = ""
        session._generation_thread = None
        session._active_is_greeting = False
        session._active_text = ""
        session._active_text_only = False
        session._awaiting_replacement = False
        session._pending_inputs = []
        session._speculative_timer = None
        session._validate_speculative = lambda _text, **_kwargs: False
        session._start_generation = self._start_generation

        session._on_utterance("sorry")

        self.assertEqual(self._transcripts, ["sorry"])
        self._start_generation.assert_called_once()
        self.assertEqual(self._start_generation.call_args.args[0], "sorry")

    def setUp(self) -> None:
        from unittest.mock import Mock
        self._transcripts = []
        self._start_generation = Mock()

class OutboundCallTests(unittest.TestCase):
    def setUp(self) -> None:
        self.core = FakeCore()
        self.voice = FakeVoice()
        self.states: list[str] = []
        self.offers: list[OutboundCallPlan] = []
        self.responses: list[ResponseResult] = []
        self.finished = threading.Event()
        self.session = CallSession(
            self.core,
            self.voice,
            CallCallbacks(
                on_state=self.states.append,
                on_response=self._on_response,
                on_error=lambda error: self.fail(error),
                on_offer=self.offers.append,
            ),
        )
        self.plan = OutboundCallPlan(
            greeting="hey, you",
            opener="i kept thinking about that hardware joke from earlier.",
            reason="continue a shared joke",
            memory_basis="the user joked about Mako living in their hardware",
            expression=Expression.SMUG,
        )

    def tearDown(self) -> None:
        if self.session.active:
            self.session.hang_up()

    def _on_response(self, result: ResponseResult) -> None:
        self.responses.append(result)
        if len(self.responses) == 2:
            self.finished.set()

    def test_answer_speaks_greeting_then_prepared_opener(self) -> None:
        self.assertTrue(self.session.offer_outbound(self.plan))
        self.assertTrue(self.session.outbound_pending)
        self.assertEqual(self.offers, [self.plan])

        self.session.accept_outbound()
        self.assertTrue(self.finished.wait(2.0))

        self.assertEqual(self.voice.spoken, [self.plan.greeting, self.plan.opener])
        self.assertEqual([result.text for result in self.responses], self.voice.spoken)
        self.assertEqual(self.responses[0].expression, Expression.SMUG)
        self.assertFalse(self.session.outbound_pending)

    def test_decline_records_hidden_call_event_without_starting_voice(self) -> None:
        self.session.offer_outbound(self.plan)
        self.session.decline_outbound("declined")

        self.assertFalse(self.session.active)
        self.assertFalse(self.voice.started)
        self.assertEqual(len(self.core.recorded), 1)
        event, _ = self.core.recorded[0]
        self.assertEqual(event.metadata["call_event"], "outbound_declined")
        self.assertEqual(self.states[-1], "offline")

    def test_call_invitation_accepts_word_order_variations(self) -> None:
        self.assertTrue(is_call_invitation("wanna call?"))
        self.assertTrue(is_call_invitation("Mako, can we call"))
        self.assertTrue(is_call_invitation("call me when you're ready"))
        self.assertFalse(is_call_invitation("i called someone yesterday"))


if __name__ == "__main__":
    unittest.main()
