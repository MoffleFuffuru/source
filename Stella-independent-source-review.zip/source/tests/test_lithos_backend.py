import json
import unittest
from unittest.mock import MagicMock, patch
from mako.config import ModelConfig
from mako.model_backend import (
    Generation, GroqBackend, HybridCodexCallBackend, ModelError,
    ProviderFallbackBackend, create_backend,
)


class LithosBackendTests(unittest.TestCase):
    def test_lithos_failure_uses_cerebras_without_changing_prompt(self):
        primary = MagicMock()
        primary.active_model = 'deepseek-flash'
        primary.generate.side_effect = ModelError('LithosAI HTTP 429: model is at capacity')
        fallback = MagicMock(spec=GroqBackend)
        fallback.provider_name = 'Cerebras'
        fallback.generate.return_value = Generation('reply', 'qwen-3.8-27b', 0.2)
        backend = ProviderFallbackBackend(primary, fallback, model='qwen-3.8-27b')
        callback = MagicMock()
        result = backend.generate(
            messages=[{'role': 'user', 'content': 'Can you hear me?'}],
            json_schema={'type': 'object'}, on_token=callback,
        )
        self.assertEqual(result.model, 'qwen-3.8-27b')
        self.assertEqual(fallback.generate.call_args.kwargs['messages'], [
            {'role': 'user', 'content': 'Can you hear me?'}
        ])
        self.assertEqual(fallback.generate.call_args.kwargs['json_schema'], {'type': 'object'})
        self.assertEqual(fallback.generate.call_args.kwargs['model'], 'qwen-3.8-27b')

    def test_cooling_down_primary_routes_directly_to_fallback(self):
        primary = GroqBackend(ModelConfig(provider='lithos', primary='deepseek-flash'))
        fallback = MagicMock(spec=GroqBackend)
        fallback.provider_name = 'Cerebras'
        fallback.generate.return_value = Generation('reply', 'qwen-3.8-27b', 0.2)
        backend = ProviderFallbackBackend(primary, fallback, model='qwen-3.8-27b')

        with patch('mako.model_backend.provider_cooling_down', return_value=True), \
             patch.object(primary, 'generate') as primary_generate:
            result = backend.generate(messages=[{'role': 'user', 'content': 'Quick follow-up'}])

        self.assertEqual(result.model, 'qwen-3.8-27b')
        primary_generate.assert_not_called()
        fallback.generate.assert_called_once()

    def test_transport_timeout_opens_cooldown_for_following_turns(self):
        primary = GroqBackend(ModelConfig(
            provider='lithos', primary='deepseek-flash', api_key_environment_variable='TEST_LITHOS_KEY',
        ))
        fallback = MagicMock(spec=GroqBackend)
        fallback.provider_name = 'Cerebras'
        fallback.generate.return_value = Generation('reply', 'qwen-3.8-27b', 0.2)
        backend = ProviderFallbackBackend(primary, fallback, model='qwen-3.8-27b')

        with patch.dict('os.environ', {'TEST_LITHOS_KEY': 'test-only'}), \
             patch('mako.model_backend._provider_pause_until', {}, create=True) as pauses, \
             patch.object(primary, '_open_request', side_effect=TimeoutError('read timed out')) as open_request:
            first = backend.generate(messages=[{'role': 'user', 'content': 'first turn'}])
            self.assertEqual(first.model, 'qwen-3.8-27b')
            self.assertTrue(pauses.get('lithos', 0) > 0)

            second = backend.generate(messages=[{'role': 'user', 'content': 'follow-up'}])
            self.assertEqual(second.model, 'qwen-3.8-27b')

        self.assertEqual(open_request.call_count, 1)
        self.assertEqual(fallback.generate.call_count, 2)

    def test_no_fallback_after_streaming_or_for_nontransient_errors(self):
        for error, streamed in (
            (ModelError('LithosAI HTTP 401: unauthorized'), False),
            (ModelError('LithosAI HTTP 503: unavailable'), True),
        ):
            primary = MagicMock()
            primary.active_model = 'deepseek-flash'

            def fail(**kwargs):
                if streamed:
                    kwargs['on_token']('partial')
                raise error

            primary.generate.side_effect = fail
            fallback = MagicMock(spec=GroqBackend)
            fallback.provider_name = 'Cerebras'
            backend = ProviderFallbackBackend(primary, fallback, model='qwen-3.8-27b')
            with self.assertRaises(ModelError):
                backend.generate(on_token=MagicMock())
            fallback.generate.assert_not_called()

    def test_create_backend_wires_lithos_fallback(self):
        config = ModelConfig(
            provider='lithos', primary='deepseek-flash', call_fallback_provider='cerebras',
            call_fallback_model='qwen-3.8-27b',
        )
        backend = create_backend(config)
        self.assertIsInstance(backend, ProviderFallbackBackend)
        self.assertEqual(backend.fallback.config.endpoint, 'https://api.cerebras.ai/v1')
        self.assertEqual(backend.fallback.config.api_key_environment_variable, 'CEREBRAS_API_KEY')

    def test_stream_with_null_usage_details_and_reasoning(self):
        backend = GroqBackend(ModelConfig(provider='lithos', primary='deepseek-ai/DeepSeek-V4.1-Flash', fallback='', reasoning_effort='none'))
        packets = [
            {'choices':[{'delta':{'reasoning_content':'not spoken'}}]},
            {'choices':[{'delta':{'content':'Hello!'}}]},
            {'choices':[], 'usage':{'prompt_tokens':10,'completion_tokens':2,'prompt_tokens_details':None}},
        ]
        response = MagicMock()
        response.__enter__.return_value = response
        response.__iter__.return_value = iter([(f'data: {json.dumps(p)}\n').encode() for p in packets] + [b'data: [DONE]\n'])
        spoken=[]
        with patch.object(backend,'_require_api_key',return_value='test-only'), patch.object(backend,'_open_request',return_value=response) as opened:
            result=backend.generate(prompt='Hi',on_token=spoken.append)
        payload=json.loads(opened.call_args.args[0].data)
        self.assertEqual(payload['reasoning_effort'],'none')
        self.assertEqual(spoken,['Hello!'])
        self.assertEqual(result.cached_tokens,0)
        self.assertEqual(result.prompt_tokens,10)

    def test_scoped_memory_tool_call_is_run_and_returned_to_model(self):
        backend = GroqBackend(ModelConfig(
            provider='lithos', primary='deepseek-ai/DeepSeek-V4.1-Flash', fallback='',
        ))
        handler = MagicMock(side_effect=[
            'Established memory evidence: [memory:01234567]',
            'Source turn and surrounding context',
        ])
        backend.set_dynamic_tool_handler(handler)
        search_packet = {
            'choices': [{
                'delta': {'tool_calls': [{
                    'index': 0, 'id': 'call_search_1', 'type': 'function',
                    'function': {
                        'name': 'search_memory',
                        'arguments': '{"query":"where did I say it"}',
                    },
                }]},
                'finish_reason': 'tool_calls',
            }],
        }
        inspect_packet = {
            'choices': [{
                'delta': {'tool_calls': [{
                    'index': 0, 'id': 'call_inspect_2', 'type': 'function',
                    'function': {
                        'name': 'inspect_memory',
                        'arguments': '{"handle":"01234567","full_call":true,"call_offset":12,"page_size":12}',
                    },
                }]},
                'finish_reason': 'tool_calls',
            }],
        }
        final_packet = {'choices': [{'delta': {'content': '{"text":"Here is the surrounding context."}'}}]}

        def response_for(packet):
            response = MagicMock()
            response.__enter__.return_value = response
            response.__iter__.return_value = iter([
                (f'data: {json.dumps(packet)}\n').encode(), b'data: [DONE]\n',
            ])
            return response

        with patch.object(backend, '_require_api_key', return_value='test-only'), \
             patch.object(backend, '_open_request', side_effect=[
                 response_for(search_packet), response_for(inspect_packet), response_for(final_packet),
             ]) as opened:
            result = backend.generate(
                messages=[{'role': 'user', 'content': 'Where did that memory come from?'}],
                conversation_scope='desktop:owner',
                json_schema={'type': 'object'},
            )

        self.assertEqual(handler.call_args_list[0].args, ('search_memory', {'query': 'where did I say it'}))
        self.assertEqual(handler.call_args_list[1].args, ('inspect_memory', {
            'handle': '01234567', 'full_call': True, 'call_offset': 12, 'page_size': 12,
        }))
        first_payload = json.loads(opened.call_args_list[0].args[0].data)
        second_payload = json.loads(opened.call_args_list[1].args[0].data)
        third_payload = json.loads(opened.call_args_list[2].args[0].data)
        self.assertTrue(any(
            tool['function']['name'] == 'inspect_memory' for tool in first_payload['tools']
        ))
        inspect_schema = next(
            tool['function']['parameters'] for tool in first_payload['tools']
            if tool['function']['name'] == 'inspect_memory'
        )
        self.assertIn('full_call', inspect_schema['properties'])
        self.assertIn('call_offset', inspect_schema['properties'])
        self.assertNotIn('response_format', first_payload)
        self.assertEqual(second_payload['messages'][-1]['content'], 'Established memory evidence: [memory:01234567]')
        self.assertNotIn('response_format', second_payload)
        self.assertEqual(third_payload['messages'][-1]['role'], 'tool')
        self.assertEqual(third_payload['messages'][-1]['content'], 'Source turn and surrounding context')
        self.assertEqual(third_payload['response_format']['type'], 'json_schema')
        self.assertIn('surrounding context', result.text)

    def test_hybrid_defaults_and_call_effort(self):
        with patch('mako.model_backend.CodexAppServerBackend'):
            backend=HybridCodexCallBackend(ModelConfig(call_provider='lithos',call_model='deepseek-ai/DeepSeek-V4.1-Flash',call_reasoning_effort='none'))
        self.assertEqual(backend.call.config.endpoint,'https://api.lithosai.cloud/v1')
        self.assertEqual(backend.call.config.api_key_environment_variable,'LITHOSAI_API_KEY')
        self.assertEqual(backend.call.config.reasoning_effort,'none')

if __name__=='__main__':unittest.main()
