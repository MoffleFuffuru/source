import asyncio
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from datetime import datetime, UTC
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, AsyncMock, patch

from mako.config import DiscordConfig
from mako.discord_service import DiscordService
from mako.model_backend import ModelError
from mako.models import ConversationEvent


@asynccontextmanager
async def typing():
    yield


class DiscordTextTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.service = object.__new__(DiscordService)
        s = self.service
        s.config = DiscordConfig(direct_response_channel_ids=["2"], autonomy_enabled=True,
                                 post_read_delay_seconds=0)
        s._client = SimpleNamespace(user=SimpleNamespace(id=99))
        s._discord = SimpleNamespace(AllowedMentions=SimpleNamespace(none=lambda: None))
        s._handled_message_ids = deque(maxlen=512)
        s._handled_message_id_set = set()
        s._pending_observations = defaultdict(set)
        s._sage_text_channels = {}
        s._sage_busy_text = set()
        s._recent_channel_replies = defaultdict(lambda: deque(maxlen=8))
        s._is_permitted = Mock(return_value=True)
        s._handle_sage_command = AsyncMock(return_value=False)
        s._handle_owner_voice_command = AsyncMock(return_value=False)
        s._replies_to_mako = Mock(return_value=False)
        s._mako_user_id = Mock(return_value="discord:7")
        s._observe_message = Mock()
        s._recent_reply_context = Mock(return_value="")
        s._remember_channel_reply = Mock()
        s._speak_reply_in_voice = AsyncMock()
        result = SimpleNamespace(text="Hey, Jalty. What's up?", complexity=1, acting={}, turn_id="result1",
                                 mood_delta={"warmth": 0.12, "irritation": 0.0})
        s.core = SimpleNamespace(sage=None, memory=SimpleNamespace(record_public_observation=Mock()),
            clock=SimpleNamespace(reading_seconds=lambda _: 0,
                                  schedule=lambda **_: SimpleNamespace(delivery_at=0)),
            respond=Mock(return_value=result), commit_deferred_call_response=Mock(),
            discard_deferred_call_response=Mock())
        self.message = SimpleNamespace(id=123, content="Hello, Stella.", mentions=[], reference=None,
            created_at=datetime.now(UTC), guild=SimpleNamespace(id=1),
            channel=SimpleNamespace(id=2, typing=typing),
            author=SimpleNamespace(id=7, bot=False, name="Jalty", display_name="Jalty"), reply=AsyncMock())

    async def test_direct_response_channel_answers_without_mention(self):
        await self.service._handle_message(self.message)
        self.message.reply.assert_awaited_once()
        self.assertEqual(self.message.reply.call_args.args[0], "Hey, Jalty. What's up?")
        self.service._speak_reply_in_voice.assert_not_awaited()
        self.service.core.commit_deferred_call_response.assert_called_once()
        self.assertFalse(self.service._sage_busy_text)

    async def test_unaddressed_public_message_is_left_for_autonomy_review(self):
        self.message.channel.id = 3
        self.message.content = "That was a funny ending."

        await self.service._handle_message(self.message)

        self.service._observe_message.assert_called_once()
        self.service.core.respond.assert_not_called()
        self.message.reply.assert_not_awaited()

    async def test_explicit_mention_uses_one_direct_reply_not_autonomy(self):
        self.message.channel.id = 3
        self.message.mentions = [self.service._client.user]

        await self.service._handle_message(self.message)

        self.service.core.respond.assert_called_once()
        self.message.reply.assert_awaited_once()
        self.assertFalse(self.service._pending_observations["3"])

    async def test_delivered_reply_applies_model_mood_delta_to_addressee(self):
        sage = Mock(enabled=True)
        sage.user_mood.return_value = {"label": "neutral", "intensity": 0.0}
        sage.user_mood_prompt.return_value = ""
        self.service.core.sage = sage

        await self.service._handle_message(self.message)

        sage.apply_user_mood_delta.assert_called_once_with(
            "discord:text:1:2", "discord:7", {"warmth": 0.12, "irritation": 0.0}
        )

    async def test_capacity_failure_is_retried_once_and_reported(self):
        self.service.core.respond.side_effect = ModelError("LithosAI HTTP 429: provider_overloaded")
        with patch("mako.discord_service.sleep"):
            await self.service._handle_message(self.message)
        self.assertEqual(self.service.core.respond.call_count, 2)
        self.message.reply.assert_awaited_once()
        self.assertIn("AI service couldn't complete", self.message.reply.call_args.args[0])
        self.service.core.commit_deferred_call_response.assert_not_called()

    async def test_failed_delivery_is_not_committed_as_a_heard_reply(self):
        self.message.reply.side_effect = RuntimeError("network unavailable")
        sage = Mock(enabled=True)
        self.service.core.sage = sage
        with self.assertLogs("mako.discord_service", level="ERROR"):
            await self.service._handle_message(self.message)
        self.service.core.commit_deferred_call_response.assert_not_called()
        self.service.core.discard_deferred_call_response.assert_called_once()
        sage.apply_user_mood_delta.assert_not_called()

    async def test_duplicate_discord_event_does_not_send_twice(self):
        await self.service._handle_message(self.message)
        await self.service._handle_message(self.message)
        self.message.reply.assert_awaited_once()


class ReasoningRoutingTests(unittest.TestCase):
    def test_calls_none_and_text_low_reach_backend(self):
        from mako.config import AppConfig
        from mako.dialogue import DialogueManager
        from mako.models import InteractionMode, EventSource
        from tests.test_dialogue import FakeBackend, candidate
        cfg = AppConfig()
        cfg.model.reasoning_effort = "low"
        cfg.model.call_reasoning_effort = "none"
        cfg.model.critic_mode = "never"
        backend = FakeBackend([candidate("Morning. How did you sleep?"), candidate("Hey, you're through.")])
        ledger = Mock()
        ledger.lessons_for.return_value = []
        ledger.relevant_lessons.return_value = []
        ledger.recent_responses.return_value = []
        manager = DialogueManager(cfg, backend, ledger)
        manager.respond(ConversationEvent(content="Good morning.", source=EventSource.DISCORD),
                        history=[], memories=[], mood_summary="")
        manager.respond(ConversationEvent(content="Hello", mode=InteractionMode.CALL),
                        history=[], memories=[], mood_summary="")
        self.assertEqual(backend.calls[0]["reasoning_effort"], "low")
        self.assertEqual(backend.calls[1]["reasoning_effort"], "none")
