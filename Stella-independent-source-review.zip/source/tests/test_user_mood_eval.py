"""Synthetic phrase-level evaluation for per-person social mood cues."""
from __future__ import annotations

import unittest

from mako.sage.user_mood import advance_mood


CASES = [
    ("That damn update is awful.", "neutral"),
    ("This app is stupid.", "neutral"),
    ("I hate this bug.", "neutral"),
    ("The server is frustrating.", "neutral"),
    ("I am angry at the game.", "neutral"),
    ("You are not stupid.", "neutral"),
    ("The game is stupid.", "neutral"),
    ("This bug is frustrating.", "neutral"),
    ("Fuck this broken menu.", "neutral"),
    ("You never listen to what I asked.", "annoyed"),
    ("You keep ignoring me.", "annoyed"),
    ("You ignored me again.", "annoyed"),
    ("You're being useless.", "annoyed"),
    ("You're a fucking idiot.", "annoyed"),
    ("You are stupid.", "annoyed"),
    ("You are useless.", "annoyed"),
    ("Stella, shut up.", "annoyed"),
    ("You are an idiot.", "annoyed"),
    ("You suck.", "annoyed"),
    ("I hate you.", "annoyed"),
    ("Thanks for helping.", "happy"),
    ("Thank you so much.", "happy"),
    ("I appreciate you.", "happy"),
    ("Great job, Stella.", "happy"),
    ("I love you.", "happy"),
]


class UserMoodEvaluationTests(unittest.TestCase):
    def test_labeled_single_turn_social_tone_cues(self) -> None:
        correct = 0
        mismatches = []
        for text, expected in CASES:
            actual = advance_mood(None, text, 100.0)["label"]
            correct += actual == expected
            if actual != expected:
                mismatches.append(f"{text!r}: expected {expected}, got {actual}")
        self.assertGreaterEqual(correct / len(CASES), 0.90, "\n".join(mismatches))

    def test_repeated_direct_criticism_strengthens_but_external_frustration_does_not(self) -> None:
        state = None
        for index, text in enumerate(("You never listen.", "You keep ignoring me.", "You are useless.")):
            state = advance_mood(state, text, 100.0 + index)
        self.assertEqual(state["label"], "angry")
        external = advance_mood(None, "This game is infuriating.", 100.0)
        external = advance_mood(external, "That server is still terrible.", 101.0)
        self.assertEqual(external["label"], "neutral")


if __name__ == "__main__":
    unittest.main()
