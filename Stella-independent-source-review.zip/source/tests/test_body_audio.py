import json
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

from mako.body import BodyController, DesktopAvatarAdapter
from mako.models import Expression


class BodyAudioTests(unittest.TestCase):
    def setUp(self):
        self.clock = patch('mako.body.time.monotonic', return_value=10.0)
        self.now = self.clock.start()
        self.addCleanup(self.clock.stop)
        self.body = BodyController()
        self.addCleanup(self.body.close)

    def test_raw_playback_and_syllable_gap_before_speaking(self):
        self.body.set_speech_level(.2)
        first = self.body.snapshot()
        self.assertFalse(first.speaking)
        self.assertEqual(first.speech_level, .2)
        self.body.set_speech_level(0)
        self.assertEqual(self.body.snapshot().speech_level, 0)
        self.assertEqual(self.body.snapshot().audio_sequence, first.audio_sequence + 1)

    def test_heartbeat_does_not_refresh_audio(self):
        self.body.set_speech_level(.2)
        sequence = self.body.snapshot().audio_sequence
        self.now.return_value = 10.2
        self.body.tick()
        snapshot = self.body.snapshot()
        self.assertEqual(snapshot.audio_sequence, sequence)
        self.assertAlmostEqual(snapshot.audio_age_ms, 200)
        self.assertEqual(snapshot.speech_level, 0)
        self.body.set_speech_level(.2)
        self.assertEqual(self.body.snapshot().speech_level, .2)
        self.assertEqual(self.body.snapshot().audio_sequence, sequence + 1)

    def test_response_preserves_playing_audio_and_finish_preserves_mood(self):
        self.body.set_speech_level(.2)
        self.body.apply_response(SimpleNamespace(expression=Expression.HAPPY, acting={}))
        active = self.body.snapshot()
        self.assertEqual(active.speech_level, .2)
        self.body.speech_finished()
        finished = self.body.snapshot()
        self.assertEqual(finished.speech_level, 0)
        self.assertTrue(finished.audio_stopped)
        self.assertFalse(finished.speaking)
        self.assertGreater(finished.audio_sequence, active.audio_sequence)
        self.assertEqual(finished.intent.expression, active.intent.expression)
        self.assertEqual(finished.intent.intensity, active.intent.intensity)
        self.assertEqual(finished.intent.gesture, 'none')
        self.body.set_speech_level(.1)
        self.assertFalse(self.body.snapshot().audio_stopped)

    def test_invalid_and_out_of_range_levels(self):
        for level in [float('nan'), float('inf'), float('-inf'), None, 'bad', -1]:
            self.body.set_speech_level(level)
            self.assertEqual(self.body.snapshot().speech_level, 0)
        self.body.set_speech_level(2)
        self.assertEqual(self.body.snapshot().speech_level, 1)

    def test_transient_response_expression_expires_back_to_persistent_mood(self):
        self.body.set_persistent_mood("warm", .3, .4)
        self.body.apply_response(SimpleNamespace(expression=Expression.ANNOYED, acting={}))
        self.body.speech_finished()
        self.assertEqual(self.body.snapshot().intent.expression, "annoyed")
        self.now.return_value = 17.1
        self.body.tick()
        self.assertEqual(self.body.snapshot().intent.expression, "warm")
        self.assertEqual(self.body.snapshot().intent.intensity, .3)

    def test_new_response_restarts_transient_expression_timeout(self):
        self.body.apply_response(SimpleNamespace(expression=Expression.ANNOYED, acting={}))
        self.body.speech_finished()
        self.now.return_value = 16.0
        self.body.apply_response(SimpleNamespace(expression=Expression.EXCITED, acting={}))
        self.body.speech_finished()
        self.now.return_value = 17.1
        self.body.tick()
        self.assertEqual(self.body.snapshot().intent.expression, "excited")
        self.now.return_value = 23.1
        self.body.tick()
        self.assertEqual(self.body.snapshot().intent.expression, "neutral")

    def test_idle_animation_returns_to_persistent_mood(self):
        self.body.set_persistent_mood("warm", .3, .4)
        self.now.return_value = 16.0
        self.assertTrue(self.body.stream_idle())
        self.assertNotEqual(self.body.snapshot().intent.expression, "warm")
        self.now.return_value = 19.6
        self.body.tick()
        self.assertEqual(self.body.snapshot().intent.expression, "warm")
        self.assertEqual(self.body.snapshot().intent.intensity, .3)

    def test_adapter_serializes_independent_audio_metadata(self):
        with patch('mako.body.socket.socket', return_value=Mock()):
            adapter = DesktopAvatarAdapter()
        self.addCleanup(adapter.close)
        self.body.set_speech_level(.2)
        adapter.apply(self.body.snapshot())
        first = json.loads(adapter.socket.sendto.call_args.args[0])
        self.now.return_value = 10.1
        adapter.apply(self.body.snapshot())
        second = json.loads(adapter.socket.sendto.call_args.args[0])
        self.assertEqual(first['sequence'], second['sequence'])
        self.assertEqual(first['audio_sequence'], second['audio_sequence'])
        self.assertAlmostEqual(second['audio_age_ms'], 100)
        self.assertFalse(second['audio_stopped'])


if __name__ == '__main__':
    unittest.main()
