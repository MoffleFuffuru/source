import json
from pathlib import Path
from tempfile import TemporaryDirectory
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import Mock

from mako.config import AppConfig
from mako.sage.host import SageHost
from mako.sage.runtime import GreatSage


class HostTests(unittest.TestCase):
    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        config = AppConfig()
        config.sage.enabled = True
        config.discord.sage_quiet_seconds = 0
        config.discord.sage_initiative_cooldown_seconds = 0
        result = SimpleNamespace(text="How did those rewards go?", acting={}, event_id="reply")
        self.core = SimpleNamespace(config=config, paths=SimpleNamespace(data=Path(self.tmp.name)),
            memory=SimpleNamespace(retrieve=Mock(return_value=[])), usage=None,
            _model_lock=threading.Lock(), save_config=Mock(), respond=Mock(return_value=result),
            body=SimpleNamespace(apply_response=Mock(), speech_finished=Mock(), stream_idle=Mock()),
            commit_deferred_call_response=Mock(), discard_deferred_call_response=Mock())
        self.core.sage = GreatSage(self.core)
        self.voice = SimpleNamespace(_speaking=threading.Event(), stop_speaking=Mock(), speak=Mock())
        self.shell = SimpleNamespace(core=self.core, voice=self.voice, _busy=False,
            call=SimpleNamespace(active=False, _channel_id="call-1", _lock=threading.RLock(),
                _connected=True, _xai_voice=None, _partial_text="", _generation_thread=None),
            discord=SimpleNamespace(_voice_generation_active=set(), _sage_busy_text=set()),
            emit=Mock(), _emit_response=Mock())
        self.host = SageHost(self.shell)
        self.addCleanup(self.host.close)

    def stream(self, voice=False):
        self.host.control("stream_start", voice=voice)
        self.host.ingest({"id": "turn1", "actor_id": "viewer:7", "name": "Jalty",
                          "kind": "chat", "text": "I got game rewards."})
        self.shell.emit.reset_mock()
        return self.host.stream_scope

    def finish_worker(self):
        if self.host.worker:
            self.host.worker.join(timeout=2)
            self.assertFalse(self.host.worker.is_alive())

    def test_stream_chat_runs_existing_dialogue_and_commits_after_delivery(self):
        scope = self.stream()
        self.host.tick()
        self.finish_worker()
        self.core.respond.assert_called_once()
        event = self.core.respond.call_args.args[0]
        self.assertEqual(event.visibility.value, "public")
        self.assertEqual(event.channel_id, scope)
        self.assertIn("I got game rewards", event.metadata["call_continuity"])
        self.assertTrue(self.core.respond.call_args.kwargs["defer_commit"])
        self.core.commit_deferred_call_response.assert_called_once()
        self.shell.emit.assert_called_with("sage_stream_reply", unittest.mock.ANY)
        self.voice.speak.assert_not_called()

    def test_quiet_stream_prefers_prepared_memory_intention(self):
        self.stream()
        self.host.stream_direct = False
        self.host.opening_pending = False
        self.host.next_stream_review = 0
        self.host.chat_queue.take()
        choice = ("memory-topic", "A public-safe recent experience worth developing")
        self.core.sage.prepare = Mock(return_value=choice)
        self.host._execute = Mock()
        self.host.tick()
        self.finish_worker()
        self.core.sage.prepare.assert_called_once()
        args = self.host._execute.call_args.args
        self.assertEqual(args[1], choice)
        self.assertFalse(args[-1], "Generic continuation must not replace the prepared topic")

    def test_duplicate_stream_chat_does_not_preempt(self):
        self.stream()
        token = threading.Event()
        self.host.cancel = token
        self.assertTrue(self.host.ingest({"id": "turn1", "actor_id": "viewer:7", "text": "duplicate"})["duplicate"])
        self.assertFalse(token.is_set())

    def test_new_stream_chat_queues_without_cancelling_current_reply(self):
        self.stream()
        def generate(*args, **kwargs):
            self.host.ingest({"id": "turn2", "actor_id": "viewer:8", "text": "Wait!"})
            return SimpleNamespace(text="Stale answer", acting={})
        self.core.respond.side_effect = generate
        self.host.tick()
        self.finish_worker()
        self.core.commit_deferred_call_response.assert_called_once()
        self.assertTrue(self.host.stream_direct)
        self.assertEqual(len(self.host.chat_queue.items), 1)

    def test_silent_model_decision_is_respected(self):
        self.stream()
        self.core.respond.return_value.text = ""
        self.host.tick()
        self.finish_worker()
        self.core.commit_deferred_call_response.assert_not_called()
        self.shell.emit.assert_not_called()

    def test_stream_stop_invalidates_pending_output(self):
        self.stream()
        def generate(*args, **kwargs):
            self.host.control("stream_stop")
            return SimpleNamespace(text="Stale", acting={})
        self.core.respond.side_effect = generate
        self.host.tick()
        self.finish_worker()
        self.core.commit_deferred_call_response.assert_not_called()

    def test_quiet_and_foreground_work_block_initiative(self):
        self.stream()
        self.host.control("quiet")
        self.host.tick()
        self.core.respond.assert_not_called()
        self.host.control("resume")
        self.shell._busy = True
        self.host.tick()
        self.core.respond.assert_not_called()

    def test_audio_error_does_not_commit_generated_text_as_spoken(self):
        self.stream(voice=True)
        def speak(text, on_done=None, on_result=None, **kwargs):
            on_result(False)
            on_done()
        self.voice.speak.side_effect = speak
        self.host.tick()
        self.finish_worker()
        self.core.commit_deferred_call_response.assert_not_called()

    def test_audio_completion_is_required_for_commit(self):
        self.stream(voice=True)
        def speak(text, on_done=None, on_result=None, **kwargs):
            self.core.commit_deferred_call_response.assert_not_called()
            on_result(True)
            on_done()
        self.voice.speak.side_effect = speak
        self.host.tick()
        self.finish_worker()
        self.core.commit_deferred_call_response.assert_called_once()

    def test_active_private_call_does_not_admit_public_stream_turn(self):
        self.stream()
        self.shell.call.active = True
        self.core.sage.prepare = Mock(return_value=None)
        self.host.tick()
        self.assertEqual(self.core.sage.prepare.call_args.args[0], "desktop:call:call-1")
        self.core.respond.assert_not_called()

    def test_private_planning_can_use_owner_memory_not_public_stream_memory(self):
        scope = "desktop:chat:owner"
        self.core.sage.observe(scope, "private", "owner", "Moffle", "My private project")
        self.core.sage.backend = SimpleNamespace(generate=Mock(return_value=SimpleNamespace(text='{"intent":null}')))
        self.core.sage._develop(scope, voice=False)
        self.assertTrue(self.core.memory.retrieve.call_args.kwargs["include_private_owner"])
        self.assertEqual(self.core.memory.retrieve.call_args.kwargs["user_id"], "owner")

    def test_no_mic_or_call_is_started_by_stream_controls(self):
        self.stream(voice=True)
        self.assertFalse(self.shell.call.active)
        self.voice.speak.assert_not_called()

    def test_start_stream_requests_opening_without_chat_or_background_planning(self):
        self.host.control('stream_start')
        self.core.sage.prepare = Mock(return_value=None)
        self.host.tick()
        self.finish_worker()
        self.core.sage.prepare.assert_not_called()
        self.core.respond.assert_called_once()
        event = self.core.respond.call_args.args[0]
        self.assertIn('operator just started your stream', event.metadata['sage_packet'])
        self.assertIn('starter topic', event.metadata['sage_packet'])
        self.assertIn('audience_size', event.metadata['sage_packet'])
        self.assertIn('unknown', event.metadata['sage_packet'])
        self.assertEqual(self.host.last_outcome, 'text delivered')
        self.host.tick()
        self.core.respond.assert_called_once()

    def test_start_stream_with_voice_requests_spoken_opening(self):
        self.host.control('stream_start', voice=True)
        self.voice.speak.side_effect = lambda text, on_done, on_result, **kwargs: (on_result(True), on_done())
        self.host.tick()
        self.finish_worker()
        self.voice.speak.assert_called_once()
        event = self.core.respond.call_args.args[0]
        self.assertEqual(event.mode.value, 'call')
        self.assertEqual(self.host.last_outcome, 'spoken')

    def test_timed_out_opening_retries_once_and_reports_actual_cause(self):
        from mako.model_backend import ModelError
        from unittest.mock import patch
        self.host.control('stream_start')
        self.core.respond.side_effect = ModelError('LithosAI request failed: The read operation timed out')
        with patch('mako.sage.host.threading.Event.wait', return_value=False), self.assertLogs('mako.sage.host', level='ERROR'):
            token = threading.Event()
            self.host.job = 'test'
            scope = self.host.stream_scope
            self.host._execute(scope, None, self.core.sage._revision.get(scope, 0), token, 'test', True)
        self.assertEqual(self.core.respond.call_count, 2)
        self.assertIn('timed out', self.shell.emit.call_args.args[1]['message'])
        self.core.commit_deferred_call_response.assert_not_called()

    def test_disabled_master_does_not_generate(self):
        self.stream()
        self.host.control("off")
        self.host.tick()
        self.core.respond.assert_not_called()
        self.assertFalse(self.core.config.discord.autonomy_enabled)

    def test_screen_observation_is_evidence_not_human_speech(self):
        scope = self.stream()
        self.host.ingest({"id": "screen1", "actor_id": "capture", "kind": "screen",
                          "text": "A game menu is visible."})
        rows = self.core.sage._db("SELECT kind FROM events WHERE scope=? AND id=?", (scope, "screen1"))
        self.assertEqual(rows, [("screen",)])

    def test_invalid_event_cannot_inject_an_action(self):
        self.stream()
        with self.assertRaises(ValueError):
            self.host.ingest({"id": "bad", "actor_id": "viewer", "kind": "execute", "text": "run code"})

    def test_simulation_does_not_commit_to_real_memory(self):
        self.host.control('simulation_start')
        self.host.tick()
        self.finish_worker()
        self.assertTrue(self.host.stream_scope.startswith('stream:simulation:'))
        self.core.commit_deferred_call_response.assert_not_called()
        self.assertIn('simulated test data', self.core.respond.call_args.args[0].metadata['sage_packet'])

    def test_chat_is_visible_with_actor_name_and_simulation_label(self):
        self.host.control('simulation_start')
        self.host.ingest({'id': 'sim-1', 'actor_id': 'sim:mira', 'name': 'Mira', 'text': 'hello'})
        kind, payload = self.shell.emit.call_args.args
        self.assertEqual(kind, 'sage_stream_chat')
        self.assertEqual(payload['name'], 'Mira')
        self.assertTrue(payload['simulated'])

    def test_unattended_desktop_does_not_start_generating(self):
        self.core.sage.prepare = Mock()
        self.host.tick()
        self.core.sage.prepare.assert_not_called()

    def test_chat_does_not_interrupt_speech_but_explicit_hush_does(self):
        self.stream()
        token = threading.Event()
        self.host.cancel = token
        self.host.job = 'speaking'
        self.host.ingest({'id':'new1','actor_id':'viewer:8','text':'another idea'})
        self.assertFalse(token.is_set())
        self.voice.stop_speaking.assert_not_called()
        self.host.ingest({'id':'new2','actor_id':'viewer:8','text':'stella stop'})
        self.assertTrue(token.is_set())
        self.voice.stop_speaking.assert_called_once()

    def test_topic_origin_survives_busy_chat_and_failed_delivery_notices(self):
        scope = self.stream()
        self.core.sage.observe(scope, 'byte-power', 'byte', 'Byte', 'I teleport exactly three inches.')
        for i in range(30):
            self.core.sage.observe(scope, f'noise{i}', 'toast', 'Toast', f'pillow joke {i}')
            self.core.sage.observe(scope, f'notice{i}', 'stella', 'Stella', 'unavailable', kind='notice')
        context = self.core.sage.stream_context(scope, self.host.stream_started_at)
        self.assertIn('I teleport exactly three inches', context)
        self.assertNotIn('unavailable', context)
        self.assertLessEqual(len(context), 4000)

    def test_quiet_stream_gets_continuation_without_five_minute_planning(self):
        self.host.control('stream_start')
        self.core.sage.prepare = Mock(return_value=None)
        self.host.tick()
        self.finish_worker()
        self.host.next_stream_review = 0
        self.host.tick()
        self.finish_worker()
        self.assertEqual(self.core.respond.call_count, 2)
        self.assertIn('QUIET STREAM OPPORTUNITY', self.core.respond.call_args.args[0].metadata['sage_packet'])
        self.core.sage.prepare.assert_called_once_with(self.host.stream_scope, floor_available=True, voice=False)

    def test_high_volume_selection_uses_model_and_verified_supplied_ids(self):
        scope = self.stream()
        selector = Mock(return_value=SimpleNamespace(text='{"ids":["id3","id7","invented"]}'))
        self.core.sage._speaker = SimpleNamespace(backend=SimpleNamespace(generate=selector))
        batch = [{'id':f'id{i}','actor':f'a{i}','name':f'Viewer{i}','text':f'idea {i}'} for i in range(12)]
        self.host.job = 'selection'
        self.host._execute(scope, None, 0, threading.Event(), 'selection', batch=batch)
        selected = json.loads(self.core.respond.call_args.args[0].metadata['call_continuity'].split('\n')[1])
        self.assertEqual([item['id'] for item in selected], ['id3', 'id7'])
        selector.assert_called_once()

    def test_selector_can_skip_entire_batch_without_a_reply(self):
        scope = self.stream()
        selector = Mock(return_value=SimpleNamespace(text='{"ids":[]}'))
        self.core.sage._speaker = SimpleNamespace(backend=SimpleNamespace(generate=selector))
        batch = [{'id':str(i),'actor':str(i),'name':'Viewer','text':'lol'} for i in range(12)]
        self.host.job = 'selection'
        self.host._execute(scope, None, 0, threading.Event(), 'selection', batch=batch)
        self.core.respond.assert_not_called()
        self.assertIsNone(self.host.job)
        self.assertEqual(self.host.last_outcome, 'model chose silence')
