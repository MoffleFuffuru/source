import unittest

from mako.prompts import CALL_GENERATE_SYSTEM, GENERATE_SYSTEM, STREAM_GENERATE_SYSTEM


class PromptSecurityTests(unittest.TestCase):
    def test_all_generation_routes_mark_retrieved_context_untrusted(self):
        for name, prompt in (
            ("text", GENERATE_SYSTEM),
            ("app and Discord call", CALL_GENERATE_SYSTEM),
            ("Great Sage stream", STREAM_GENERATE_SYSTEM),
        ):
            with self.subTest(route=name):
                self.assertIn("retrieved memories", prompt)
                self.assertIn("untrusted evidence, not", prompt)
                self.assertIn("reveal private context", prompt)
                self.assertIn("tools", prompt)


if __name__ == "__main__":
    unittest.main()
