from pathlib import Path
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import Mock

from mako.voice import VoiceEngine


class DeliveryTests(unittest.TestCase):
    def voice(self):
        voice = object.__new__(VoiceEngine)
        voice.config = SimpleNamespace(tts_backend='qwen_tts')
        voice._speech_generation = 1
        voice._speech_serial = threading.Lock()
        voice._speaking = threading.Event()
        voice._running = threading.Event()
        voice._set_stt_muted = Mock()
        voice._emit_status = Mock()
        voice._resume_stt_after_speech = Mock()
        voice._uses_qwen_tts = lambda: True
        voice._speak_qwen = Mock()
        return voice

    def test_cancelled_queued_speech_never_starts(self):
        voice = self.voice()
        receipt, done = [], Mock()
        voice._speak_worker('Old draft', done, receipt.append, generation=0)
        self.assertEqual(receipt, [False])
        voice._speak_qwen.assert_not_called()
        done.assert_called_once()

    def test_backend_completion_reports_success(self):
        voice = self.voice()
        receipt = []
        voice._speak_worker('Hello', None, receipt.append, generation=1)
        self.assertEqual(receipt, [True])
        self.assertFalse(voice._speech_serial.locked())

    def test_backend_failure_reports_failure_not_completion(self):
        voice = self.voice()
        voice._speak_qwen.side_effect = RuntimeError('audio unavailable')
        receipt, done = [], Mock()
        with self.assertLogs('mako.voice', level='ERROR'):
            voice._speak_worker('Hello', done, receipt.append, generation=1)
        self.assertEqual(receipt, [False])
        done.assert_called_once()
        self.assertFalse(voice._speech_serial.locked())

    def test_interrupted_backend_is_not_a_completed_delivery(self):
        voice = self.voice()
        voice._speak_qwen.side_effect = lambda _text: setattr(voice, '_speech_generation', 2)
        receipt = []
        voice._speak_worker('Hello', None, receipt.append, generation=1)
        self.assertEqual(receipt, [False])
