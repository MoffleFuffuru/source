import unittest

from mako.prompts import CORE_IDENTITY, STREAM_IDENTITY, STREAM_GENERATE_SYSTEM, CALL_GENERATE_SYSTEM, GENERATE_SYSTEM


class StreamPersonaTests(unittest.TestCase):
    def test_stream_replaces_private_persona_instead_of_stacking(self):
        self.assertIn(STREAM_IDENTITY, STREAM_GENERATE_SYSTEM)
        self.assertNotIn(CORE_IDENTITY, STREAM_GENERATE_SYSTEM)
        self.assertIn(CORE_IDENTITY, CALL_GENERATE_SYSTEM)
        self.assertIn(CORE_IDENTITY, GENERATE_SYSTEM)
        self.assertNotIn(STREAM_IDENTITY, CALL_GENERATE_SYSTEM)
        self.assertNotIn(STREAM_IDENTITY, GENERATE_SYSTEM)

    def test_stream_has_grounded_life_topics_and_no_audience_pressure(self):
        self.assertIn("public-safe recent-life evidence", STREAM_GENERATE_SYSTEM)
        self.assertIn("never manufacture a remembered event", STREAM_GENERATE_SYSTEM)
        self.assertIn("not responsible for supplying all its content", STREAM_GENERATE_SYSTEM)

    def test_stream_uses_only_approved_public_name(self):
        self.assertIn('call your creator only "moffle"', STREAM_GENERATE_SYSTEM)
        self.assertIn("even when quoting", STREAM_GENERATE_SYSTEM)
