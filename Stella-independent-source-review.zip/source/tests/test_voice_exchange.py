from __future__ import annotations

import unittest

from mako.voice_exchange import VoiceContribution, VoiceExchangeBuffer


class VoiceExchangeBufferTests(unittest.TestCase):
    def make_turn(self, name: str, text: str) -> VoiceContribution:
        return VoiceContribution("1", name, text, "2026-10-05T18:00:00-04:00", {})

    def test_contributions_are_ordered_and_rendered_with_speaker_and_time(self) -> None:
        exchange = VoiceExchangeBuffer()
        exchange.append(self.make_turn("Jalty", "First thought."))
        exchange.append(self.make_turn("Prince", "Second thought."))
        revision, snapshot = exchange.snapshot()
        rendered = exchange.render(snapshot)
        self.assertEqual(revision, 2)
        self.assertLess(rendered.index("Jalty"), rendered.index("Prince"))
        self.assertIn("[2026-10-05T18:00:00-04:00]", rendered)

    def test_interrupted_snapshot_remains_available_with_new_context(self) -> None:
        exchange = VoiceExchangeBuffer()
        first = self.make_turn("Jalty", "A long setup with several points.")
        exchange.append(first)
        _, cancelled_snapshot = exchange.snapshot()
        second = self.make_turn("Prince", "And I have another question.")
        exchange.append(second)
        self.assertEqual(exchange.snapshot()[1], (*cancelled_snapshot, second))

    def test_failed_or_cancelled_draft_can_be_retried_from_same_snapshot(self) -> None:
        exchange = VoiceExchangeBuffer()
        item = self.make_turn("Jalty", "What do you think about this?")
        exchange.append(item)
        _, first = exchange.snapshot()
        _, retry = exchange.snapshot()
        self.assertEqual(first, retry)
        self.assertTrue(exchange.acknowledge(retry))
        self.assertEqual(exchange.snapshot()[1], ())


if __name__ == "__main__":
    unittest.main()
