from http.server import ThreadingHTTPServer
import json
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from mako.shell_server import ShellHandler


class SageHttpTests(unittest.TestCase):
    def setUp(self):
        self.host = SimpleNamespace(ingest=Mock(return_value={"accepted": True}),
            control=Mock(return_value={"enabled": True}), status=Mock(return_value={"enabled": True}),
            stream_scope="stream:local:main")
        runtime = SimpleNamespace(sage_host=self.host, core=SimpleNamespace(config=SimpleNamespace(
            sage=SimpleNamespace(stream_event_key_environment_variable="STELLA_SAGE_TEST_KEY"))))
        runtime.events_after = Mock(return_value={"last": 3, "events": [
            {"id": 1, "type": "message", "data": {"text": "Private owner text"}},
            {"id": 2, "type": "sage_stream_reply", "data": {"scope": "other", "text": "Other"}},
            {"id": 3, "type": "sage_stream_reply", "data": {"scope": "stream:local:main", "text": "Hello stream"}}]})
        class Handler(ShellHandler):
            pass
        Handler.runtime = runtime
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.url = f'http://127.0.0.1:{self.server.server_port}'
        self.env = patch.dict('os.environ', {'STELLA_SAGE_TEST_KEY': 'test-only-not-a-provider-key'})
        self.env.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        self.env.stop()

    def request(self, route, data=None, **headers):
        body = json.dumps(data).encode() if data is not None else None
        return urlopen(Request(self.url + route, data=body, headers=headers), timeout=2)

    def test_event_requires_authentication(self):
        with self.assertRaises(HTTPError) as error:
            self.request('/api/sage/event', {'id': 'event1'})
        self.assertEqual(error.exception.code, 401)
        self.host.ingest.assert_not_called()

    def test_authorized_adapter_event_is_forwarded(self):
        with self.request('/api/sage/event', {'id': 'event1'},
                          Authorization='Bearer test-only-not-a-provider-key') as response:
            self.assertEqual(json.load(response), {'accepted': True})
        self.host.ingest.assert_called_once_with({'id': 'event1'})

    def test_remote_web_page_cannot_change_sage_controls(self):
        with self.assertRaises(HTTPError):
            self.request('/api/sage/control', {'action': 'on'}, Origin='https://example.com')
        self.host.control.assert_not_called()

    def test_opaque_browser_origin_is_not_a_trusted_desktop_client(self):
        with self.assertRaises(HTTPError):
            self.request('/api/sage/control', {'action': 'on'}, Origin='null')
        self.host.control.assert_not_called()

    def test_local_desktop_control_does_not_need_stream_secret(self):
        with self.request('/api/sage/control', {'action': 'quiet'}) as response:
            self.assertEqual(response.status, 200)
        self.host.control.assert_called_once_with('quiet', voice=False)

    def test_stream_output_never_includes_private_desktop_messages(self):
        with self.request('/api/sage/stream?after=0',
                          Authorization='Bearer test-only-not-a-provider-key') as response:
            packet = json.load(response)
        self.assertEqual(len(packet['events']), 1)
        self.assertEqual(packet['events'][0]['data']['text'], 'Hello stream')
        self.assertEqual(packet['last'], 3)
