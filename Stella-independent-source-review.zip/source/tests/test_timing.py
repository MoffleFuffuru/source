from __future__ import annotations

import unittest

from mako.config import TimingConfig
from mako.timing import SocialClock


class TimingTests(unittest.TestCase):
    def test_larger_messages_take_longer_without_randomness(self) -> None:
        clock = SocialClock(TimingConfig())
        short = clock.schedule(
            received_at=100.0,
            model_ready_at=100.1,
            user_text="hi",
            response_text="hey",
            complexity=1,
        )
        long = clock.schedule(
            received_at=100.0,
            model_ready_at=100.1,
            user_text="this is a longer message with more words to read " * 4,
            response_text="this answer also has more words to type naturally",
            complexity=3,
        )
        self.assertGreater(long.delivery_at, short.delivery_at)
        self.assertGreater(long.read_seconds, short.read_seconds)
        self.assertGreater(long.type_seconds, short.type_seconds)

    def test_slow_generation_overlaps_typing_and_delivers_when_ready(self) -> None:
        clock = SocialClock(TimingConfig())
        schedule = clock.schedule(
            received_at=100.0,
            model_ready_at=145.0,
            user_text="hello",
            response_text="hey, i'm right here",
            complexity=1,
            typing_started_at=100.24,
        )

        self.assertEqual(schedule.typing_starts_at, 100.24)
        self.assertEqual(schedule.delivery_at, 145.0)

    def test_fast_generation_waits_for_human_typing_time(self) -> None:
        clock = SocialClock(TimingConfig())
        schedule = clock.schedule(
            received_at=100.0,
            model_ready_at=101.0,
            user_text="hello",
            response_text="hey, i'm right here",
            complexity=1,
            typing_started_at=100.24,
        )

        self.assertAlmostEqual(
            schedule.delivery_at,
            schedule.typing_starts_at + schedule.type_seconds,
        )

    def test_call_mode_has_no_social_delay(self) -> None:
        clock = SocialClock(TimingConfig())
        schedule = clock.schedule(
            received_at=100.0,
            model_ready_at=104.0,
            user_text="are you there",
            response_text="yeah",
            complexity=1,
            real_time=True,
        )
        self.assertEqual(schedule.delivery_at, 104.0)
        self.assertEqual(schedule.type_seconds, 0.0)


if __name__ == "__main__":
    unittest.main()
