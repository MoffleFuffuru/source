"""Synthetic retrieval probe for exact, privacy-scoped RMA recall."""
from __future__ import annotations

import unittest
from datetime import UTC, datetime, timedelta
from pathlib import Path
from tempfile import TemporaryDirectory

from mako.config import MemoryConfig
from mako.memory import MemoryEngine
from mako.models import ConversationEvent, EventSource, InteractionMode, ResponseResult, Expression, Visibility


FACTS = (
    ("favorite tea", "My favorite tea is jasmine tea from Kyoto."),
    ("coffee ritual", "I make a moka pot coffee before coding in the morning."),
    ("pet name", "My cat is named Juniper and likes sleeping on the blue chair."),
    ("travel plan", "I want to visit Reykjavik during the winter aurora season."),
    ("keyboard", "My daily keyboard has quiet linear switches and a split layout."),
    ("music", "I listen to ambient synth music while drawing concept art."),
    ("food", "My favorite noodle dish is spicy miso ramen with corn."),
    ("project", "The greenhouse dashboard uses a Raspberry Pi and soil sensors."),
)

QUERIES = (
    ("What tea from Kyoto is my favorite?", "jasmine tea from Kyoto"),
    ("Which tea do I like?", "jasmine tea from Kyoto"),
    ("Where was the tea I mentioned sourced?", "jasmine tea from Kyoto"),
    ("What do I make before coding?", "moka pot coffee before coding"),
    ("What coffee ritual do I follow before coding?", "moka pot coffee before coding"),
    ("What kind of coffee do I prepare in the morning?", "moka pot coffee before coding"),
    ("Where does Juniper like to sleep?", "Juniper and likes sleeping on the blue chair"),
    ("What is my cat called and where does it nap?", "Juniper and likes sleeping on the blue chair"),
    ("What is my cat Juniper's favorite spot?", "Juniper and likes sleeping on the blue chair"),
    ("Which city was I hoping to visit for the aurora?", "visit Reykjavik during the winter aurora season"),
    ("What winter trip did I mention?", "visit Reykjavik during the winter aurora season"),
    ("Where do I want to travel for auroras?", "visit Reykjavik during the winter aurora season"),
    ("What switch type and layout does my keyboard have?", "quiet linear switches and a split layout"),
    ("Describe the keyboard I use every day.", "quiet linear switches and a split layout"),
    ("Describe my keyboard layout and switches.", "quiet linear switches and a split layout"),
    ("What kind of music do I put on while drawing?", "ambient synth music while drawing concept art"),
    ("What soundtrack do I use for concept art?", "ambient synth music while drawing concept art"),
    ("What do I listen to while making concept art?", "ambient synth music while drawing concept art"),
    ("Which noodle meal is my favorite?", "spicy miso ramen with corn"),
    ("What did I say I like in my ramen?", "spicy miso ramen with corn"),
    ("Which ramen do I like?", "spicy miso ramen with corn"),
    ("What hardware did I choose for the greenhouse dashboard?", "Raspberry Pi and soil sensors"),
    ("What runs the greenhouse sensors?", "Raspberry Pi and soil sensors"),
    ("What hardware runs my greenhouse dashboard?", "Raspberry Pi and soil sensors"),
)


class RmaEvaluationTests(unittest.TestCase):
    def test_exact_topic_recall_returns_supporting_private_episode(self) -> None:
        with TemporaryDirectory() as temp:
            engine = MemoryEngine(Path(temp) / "rma.sqlite3", MemoryConfig())
            try:
                old = (datetime.now(UTC) - timedelta(days=90)).isoformat()
                for label, fact in FACTS:
                    event = ConversationEvent(
                        content=fact, source=EventSource.VOICE_CALL,
                        mode=InteractionMode.CALL, visibility=Visibility.PRIVATE,
                        user_id="owner", channel_id="call:private", created_at=old,
                    )
                    engine.record_turn(event, ResponseResult(
                        turn_id=f"turn-{event.id}", event_id=event.id,
                        text=f"I will remember this {label} detail.",
                        expression=Expression.NEUTRAL, move="respond", complexity=2,
                        mood_delta={}, relationship_delta={}, score=1.0, repaired=False,
                        attempts=1, model="fixture", generation_seconds=0.0,
                    ))

                hits = 0
                top_hits = 0
                misses = []
                top_misses = []
                for query, expected_evidence in QUERIES:
                    slots = engine.retrieve_rma_slots(
                        query, Visibility.PRIVATE, user_id="owner",
                        include_private_owner=True,
                    )
                    evidence = "\n".join(packet for slot in slots.values() for packet in slot).casefold()
                    if expected_evidence.casefold() in evidence:
                        hits += 1
                    else:
                        misses.append(query)
                    older = slots["L3 Older Episodes"]
                    if older and expected_evidence.casefold() in older[0].casefold():
                        top_hits += 1
                    else:
                        top_misses.append((query, older[0] if older else "<empty>"))
                accuracy = hits / len(QUERIES)
                self.assertGreaterEqual(accuracy, 0.90, f"{hits}/{len(QUERIES)}; misses={misses}")
                # Recall anywhere in the packet is not enough: the most relevant
                # older episode should lead the ranked evidence list.
                self.assertGreaterEqual(
                    top_hits / len(QUERIES), 0.90,
                    f"top-ranked older episode matched {top_hits}/{len(QUERIES)}; misses={top_misses}",
                )
            finally:
                engine.close_session()

    def test_public_rma_never_includes_private_owner_episode(self) -> None:
        with TemporaryDirectory() as temp:
            engine = MemoryEngine(Path(temp) / "privacy.sqlite3", MemoryConfig())
            try:
                fixtures = (
                    (Visibility.PRIVATE, "owner", "call:private", "My private cabin codeword is amber-otter."),
                    (Visibility.PUBLIC, "discord:7", "discord:general:shared", "Our public channel plans an amber-otter art night."),
                    (Visibility.PUBLIC, "discord:7", "discord:friends:shared", "In another channel, amber-otter is a surprise gift plan."),
                )
                for index, (visibility, user_id, channel_id, text) in enumerate(fixtures):
                    event = ConversationEvent(
                        content=text, source=EventSource.VOICE_CALL if visibility is Visibility.PRIVATE else EventSource.DISCORD,
                        mode=InteractionMode.CALL if visibility is Visibility.PRIVATE else InteractionMode.TEXT,
                        visibility=visibility, user_id=user_id, channel_id=channel_id,
                    )
                    engine.record_turn(event, ResponseResult(
                        turn_id=f"privacy-{index}", event_id=event.id, text="Noted.",
                        expression=Expression.NEUTRAL, move="respond", complexity=1,
                        mood_delta={}, relationship_delta={}, score=1.0, repaired=False,
                        attempts=1, model="fixture", generation_seconds=0.0,
                    ))

                public = engine.retrieve_rma_slots(
                    "What is the amber-otter plan?", Visibility.PUBLIC,
                    user_id="owner", include_private_owner=False,
                    shared_channel_id="general",
                )
                public_text = "\n".join(item for slot in public.values() for item in slot).casefold()
                self.assertIn("public channel plans an amber-otter art night", public_text)
                self.assertNotIn("private cabin codeword", public_text)
                self.assertNotIn("another channel", public_text)

                private = engine.retrieve_rma_slots(
                    "What is my amber-otter codeword?", Visibility.PRIVATE,
                    user_id="owner", include_private_owner=True,
                )
                private_text = "\n".join(item for slot in private.values() for item in slot).casefold()
                self.assertIn("private cabin codeword is amber-otter", private_text)
            finally:
                engine.close_session()


if __name__ == "__main__":
    unittest.main()
