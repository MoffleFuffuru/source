from __future__ import annotations

import json
import unittest
from datetime import UTC, datetime, timedelta
from pathlib import Path
from uuid import uuid4

from mako.config import MemoryConfig
from mako.memory import MemoryEngine, is_memory_recall_request
from mako.model_backend import Generation
from mako.models import ConversationEvent, EventSource, Expression, InteractionMode, ResponseResult, Visibility


class ConsolidationBackend:
    def generate(self, **_kwargs) -> Generation:
        return Generation(
            text=json.dumps(
                {
                    "memories": [
                        {
                            "label": "coffee ritual",
                            "summary": "the user likes making coffee before coding",
                            "topics": ["coffee", "coding"],
                            "importance": 0.7,
                            "emotional_weight": 0.2,
                            "relationship_relevance": 0.1,
                            "confidence": 0.8,
                        }
                    ],
                    "relationship_delta": {"familiarity": 0.01},
                }
            ),
            model="fake",
            elapsed_seconds=0.01,
        )


def result_for(event: ConversationEvent, text: str) -> ResponseResult:
    return ResponseResult(
        turn_id=f"turn-{event.id}",
        event_id=event.id,
        text=text,
        expression=Expression.NEUTRAL,
        move="respond",
        complexity=2,
        mood_delta={},
        relationship_delta={},
        score=1.0,
        repaired=False,
        attempts=1,
        model="fake",
        generation_seconds=0.01,
    )


class MemoryTests(unittest.TestCase):
    def setUp(self) -> None:
        runtime = Path(__file__).resolve().parent / "_runtime"
        runtime.mkdir(exist_ok=True)
        self.database_path = runtime / f"memory-{uuid4().hex}.sqlite3"
        self.engine = MemoryEngine(
            self.database_path,
            MemoryConfig(),
        )

    def tearDown(self) -> None:
        self.engine.close_session()
        for suffix in ("", "-wal", "-shm"):
            Path(f"{self.database_path}{suffix}").unlink(missing_ok=True)

    def test_call_or_text_turn_can_be_replaced_without_duplication(self) -> None:
        event = ConversationEvent(content="hello")
        self.engine.record_turn(event, result_for(event, "first"))
        self.assertTrue(self.engine.replace_turn(event, result_for(event, "second")))
        history = self.engine.recent_history()
        self.assertEqual(history, [("hello", "second")])

    def test_assistant_delay_notice_is_saved_as_stella_speech_once(self) -> None:
        args = dict(
            event_id="stella:delay-notice:1:2",
            text="Someone tell moffle there is a problem with my AI",
            user_id="discord:owner",
            display_name="Stella",
            channel_id="discord:123:speaker:discord:owner",
            shared_channel_id="123",
        )
        self.assertTrue(self.engine.record_assistant_notice(**args))
        self.assertFalse(self.engine.record_assistant_notice(**args))
        with self.engine._connect() as connection:
            rows = connection.execute(
                "SELECT user_text, mako_text FROM episodes WHERE event_id LIKE ?",
                ("stella:delay-notice:1:2%",),
            ).fetchall()
        self.assertEqual(len(rows), 2)
        self.assertTrue(all(row["mako_text"] == args["text"] for row in rows))
        self.assertTrue(all("system notice" in row["user_text"].lower() for row in rows))

    def test_natural_recall_phrasings_use_evidence_path(self) -> None:
        questions = (
            "What's the biggest thing you remember about our last Discord call?",
            "What did I say I wanted to add so you could see my screen?",
            "Who was I talking about when we discussed toes?",
            "Can you pull up the implementation plan from earlier?",
            "What do you know about Jalty?",
            "Quote something from your core memory about me.",
            "Do you remember any older Discord conversations about toes?",
            "Can she not remember names and stuff?",
            "I need you to tell me what you remember about.",
        )
        for question in questions:
            with self.subTest(question=question):
                self.assertTrue(is_memory_recall_request(question))

    def test_discord_memory_profiles_round_trip_by_guild_and_user(self) -> None:
        self.engine.save_discord_memory_profile(
            guild_id="1259638416019292262",
            user_id="discord:42",
            display_name="Prince",
            summary="I remember your AI companion project and the voice experiments we discussed.",
            source_digest="digest-a",
            source_turns=17,
        )
        profile = self.engine.get_discord_memory_profile("1259638416019292262", "discord:42")
        self.assertIsNotNone(profile)
        self.assertEqual(profile["source_turns"], 17)
        self.assertEqual(profile["model"], "openai/gpt-oss-120b")
        self.assertIsNone(self.engine.get_discord_memory_profile("999", "discord:42"))

    def test_discord_profile_chunk_checkpoint_round_trip(self) -> None:
        self.engine.save_discord_memory_profile_chunk(
            guild_id="123", user_id="discord:42", source_digest="digest-a",
            chunk_index=2, summary="They described a long-running project and a close friendship.",
        )
        self.assertEqual(
            self.engine.get_discord_memory_profile_chunks("123", "discord:42", "digest-a"),
            {2: "They described a long-running project and a close friendship."},
        )
        self.assertEqual(
            self.engine.get_discord_memory_profile_chunks("123", "discord:42", "digest-b"),
            {},
        )

    def test_public_discord_call_user_ids_are_guild_and_visibility_scoped(self) -> None:
        with self.engine._connect() as connection:
            for user_id, channel_id, mode, visibility in (
                ("discord:42", "discord:123:speaker:7", "call", "public"),
                ("discord:43", "discord:123:speaker:7", "call", "public"),
                ("discord:44", "discord:123:speaker:7", "text", "public"),
                ("discord:45", "discord:123:speaker:7", "call", "private"),
                ("discord:46", "discord:999:speaker:7", "call", "public"),
            ):
                connection.execute(
                    """INSERT INTO episodes (
                           id, session_id, event_id, created_at, source, mode, visibility,
                           user_id, channel_id, user_text, mako_text
                       ) VALUES (?, ?, ?, ?, 'discord', ?, ?, ?, ?, '', '')""",
                    (uuid4().hex, "session", uuid4().hex, "2026-10-06T00:00:00+00:00",
                     mode, visibility, user_id, channel_id),
                )
        self.assertEqual(
            self.engine.public_discord_call_user_ids("123"),
            ["discord:42", "discord:43"],
        )

    def test_current_or_general_questions_do_not_force_recall(self) -> None:
        for question in (
            "What's the weather like today?",
            "Can you explain how WebSockets work?",
            "How does your memory system work?",
            "What are you doing right now?",
            "Do you like this song?",
        ):
            with self.subTest(question=question):
                self.assertFalse(is_memory_recall_request(question))

    def test_suggestions_use_context_and_deduplicate_mirrors(self) -> None:
        for _ in range(2):
            event = ConversationEvent(content="I planted lavender beside the greenhouse.")
            self.engine.record_turn(event, result_for(event, "That sounds lovely."))
        memories = self.engine.retrieve(
            "yeah", Visibility.PRIVATE, user_id="owner",
            suggestion_context=[("The lavender greenhouse project is progressing.", "nice")],
        )
        self.assertEqual(len(memories), 1)
        self.assertIn("planted lavender", memories[0])
        with self.engine._connect() as connection:
            row = connection.execute(
                "SELECT SUM(recalled_count) AS total FROM episodes WHERE user_text LIKE '%lavender%'"
            ).fetchone()
        recalled = row["total"]
        self.assertEqual(recalled, 1)

    def test_associative_recall_returns_several_strong_distinct_memories(self) -> None:
        memories = (
            "We picked a bronze mirror for the Orion telescope project.",
            "The Orion telescope project needs a hilltop observing site.",
            "The Orion telescope project team is planning a summer launch.",
            "We compared cameras for the Orion telescope project.",
            "The Orion telescope project budget includes a new mount.",
            "I baked sourdough bread for dinner last night.",
        )
        for text in memories:
            event = ConversationEvent(content=text)
            self.engine.record_turn(event, result_for(event, "I'll keep that in mind."))

        recalled = self.engine.retrieve(
            "Orion telescope project updates", Visibility.PRIVATE, user_id="owner",
            suggestion_context=None,
        )

        self.assertEqual(5, len(recalled))
        self.assertTrue(all("Orion telescope project" in item for item in recalled))
        self.assertFalse(any("sourdough" in item for item in recalled))

    def test_suggestions_do_not_force_unrelated_or_assistant_only_evidence(self) -> None:
        event = ConversationEvent(content="I bought groceries.")
        self.engine.record_turn(event, result_for(event, "Your lavender greenhouse is flourishing."))
        self.assertEqual(self.engine.retrieve(
            "lavender greenhouse", Visibility.PRIVATE, user_id="owner", suggestion_context=[]), [])
        self.assertEqual(self.engine.retrieve(
            "orbital telescope", Visibility.PRIVATE, user_id="owner", suggestion_context=[]), [])

    def test_suggestions_skip_context_already_visible(self) -> None:
        event = ConversationEvent(content="I planted lavender beside the greenhouse.")
        self.engine.record_turn(event, result_for(event, "lovely"))
        self.assertEqual(self.engine.retrieve(
            "lavender greenhouse", Visibility.PRIVATE, user_id="owner",
            suggestion_context=[(event.content, "lovely")]), [])

    def test_suggestions_do_not_follow_old_topic_after_topic_change(self) -> None:
        event = ConversationEvent(content="I planted lavender beside the greenhouse.")
        self.engine.record_turn(event, result_for(event, "lovely"))
        self.assertEqual(self.engine.retrieve(
            "repairing orbital telescope mirrors", Visibility.PRIVATE, user_id="owner",
            suggestion_context=[("lavender greenhouse", "lovely")]), [])

    def test_public_suggestions_do_not_expose_private_owner_evidence(self) -> None:
        event = ConversationEvent(content="I planted lavender beside the greenhouse.")
        self.engine.record_turn(event, result_for(event, "lovely"))
        self.assertEqual(self.engine.retrieve(
            "lavender greenhouse", Visibility.PUBLIC, user_id="stranger",
            suggestion_context=[]), [])

    def test_channel_recall_can_read_another_speaker_and_inspect_evidence(self) -> None:
        event = ConversationEvent(
            content="I planted lavender beside the greenhouse.", source=EventSource.DISCORD,
            visibility=Visibility.PUBLIC, user_id="discord:alice", display_name="Alice",
            channel_id="discord:123:speaker:discord:alice", metadata={"discord_channel_id": "123"},
        )
        self.engine.record_turn(event, result_for(event, "lovely"))
        scope = dict(user_id="discord:bob", shared_channel_id="123", include_private_owner=False)
        for memories in (
            self.engine.retrieve("lavender greenhouse", Visibility.PUBLIC, suggestion_context=[], **scope),
            self.engine.retrieve_for_recall("lavender greenhouse", Visibility.PUBLIC, **scope),
        ):
            self.assertTrue(memories)
            self.assertIn("Alice", " ".join(memories))
            self.assertIn("planted lavender", " ".join(memories))
        with self.engine._connect() as connection:
            handle = connection.execute(
                "SELECT id FROM episodes WHERE channel_id = ?", ("discord:123:shared",)
            ).fetchone()["id"]
        self.assertIn("planted lavender", self.engine.inspect_memory(handle, Visibility.PUBLIC, **scope))
        self.assertTrue(self.engine.related_memories(handle, Visibility.PUBLIC, **scope))
        scope["shared_channel_id"] = "456"
        self.assertEqual("No memory is available in this scope.", self.engine.inspect_memory(handle, Visibility.PUBLIC, **scope))

    def test_inspect_memory_reads_bounded_same_channel_context(self) -> None:
        turns = [
            ("before turn", "before reply"),
            ("anchor memory detail", "anchor reply detail"),
            ("after turn", "after reply"),
            ("later unrelated turn", "later unrelated reply"),
        ]
        anchor_id = ""
        for index, (user_text, assistant_text) in enumerate(turns):
            event = ConversationEvent(
                content=user_text,
                created_at=f"2026-10-22T12:00:0{index}+00:00",
            )
            self.engine.record_turn(event, result_for(event, assistant_text))
            if index == 1:
                with self.engine._connect() as connection:
                    anchor_id = str(connection.execute(
                        "SELECT id FROM episodes WHERE event_id = ?", (event.id,)
                    ).fetchone()["id"])

        inspected = self.engine.inspect_memory(
            anchor_id, Visibility.PRIVATE, user_id="owner", include_private_owner=False,
            context_radius=1,
        )
        self.assertIn("before turn", inspected)
        self.assertIn("anchor memory detail", inspected)
        self.assertIn("after turn", inspected)
        self.assertNotIn("later unrelated turn", inspected)

    def test_inspect_memory_context_never_crosses_channel_scope(self) -> None:
        public = ConversationEvent(
            content="public channel anchor evidence", source=EventSource.DISCORD,
            visibility=Visibility.PUBLIC, user_id="discord:alice",
            channel_id="discord:123:speaker:discord:alice",
            metadata={"discord_channel_id": "123"},
            created_at="2026-10-22T12:00:01+00:00",
        )
        private = ConversationEvent(
            content="private neighboring secret", source=EventSource.DISCORD,
            visibility=Visibility.PRIVATE, user_id="discord:alice",
            channel_id="discord:dm:alice", created_at="2026-10-22T12:00:02+00:00",
        )
        self.engine.record_turn(public, result_for(public, "public response"))
        self.engine.record_turn(private, result_for(private, "private response"))
        with self.engine._connect() as connection:
            anchor_id = str(connection.execute(
                "SELECT id FROM episodes WHERE event_id = ?", (f"{public.id}:shared",)
            ).fetchone()["id"])
        inspected = self.engine.inspect_memory(
            anchor_id, Visibility.PUBLIC, user_id="discord:bob",
            shared_channel_id="123", include_private_owner=False, context_radius=4,
        )
        self.assertIn("public channel anchor evidence", inspected)
        self.assertNotIn("private neighboring secret", inspected)

    def test_rma_slots_target_seven_and_keep_hot_slot_largest(self) -> None:
        now = datetime.now(UTC)
        for index in range(12):
            recent = ConversationEvent(
                content=f"recent robot memory {index}", source=EventSource.VOICE_CALL,
                mode=InteractionMode.CALL, channel_id="call:recent",
                created_at=(now - timedelta(days=1, seconds=index)).isoformat(),
            )
            older = ConversationEvent(
                content=f"older robot memory {index}", source=EventSource.VOICE_CALL,
                mode=InteractionMode.CALL, channel_id="call:older",
                created_at=(now - timedelta(days=90, seconds=index)).isoformat(),
            )
            self.engine.record_turn(recent, result_for(recent, f"recent reply {index}"))
            self.engine.record_turn(older, result_for(older, f"older reply {index}"))
        with self.engine._connect() as connection:
            for index in range(8):
                connection.execute(
                    """INSERT INTO concepts (
                        key, label, summary, topics_json, visibility, strength, confidence,
                        recurrence, emotional_weight, relationship_relevance, core,
                        protection_cycles, last_seen
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        f"core-{index}", f"Identity {index}", f"Stable identity fact {index}", "[]",
                        "private", 0.9, 0.9, 1, 0.1, 0.9, 1, 0, now.isoformat(),
                    ),
                )
                connection.execute(
                    """INSERT INTO concepts (
                        key, label, summary, topics_json, visibility, strength, confidence,
                        recurrence, emotional_weight, relationship_relevance, core,
                        protection_cycles, last_seen
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        f"topic-{index}", f"Robot topic {index}", f"Robot topic summary {index}",
                        json.dumps([f"robot discussion {index}"]), "private", 0.8, 0.8,
                        1, 0.1, 0.7, 0, 0, now.isoformat(),
                    ),
                )
        slots = self.engine.retrieve_rma_slots(
            "robot", Visibility.PRIVATE, user_id="owner", include_private_owner=True,
            context_history=[(f"current robot context {index}", "reply", now.isoformat()) for index in range(8)],
            seed_memories=[f"retrieved evidence {index}" for index in range(8)], per_slot=7,
        )
        self.assertEqual(len(slots["L0 Core Identity"]), 7)
        self.assertEqual(len(slots["L1 Hot Memory"]), 10)
        self.assertEqual(len(slots["L2 Topic Threads"]), 7)
        self.assertEqual(len(slots["L3 Older Episodes"]), 7)
        self.assertEqual(len(slots["L4 Current Context"]), 7)
        self.assertIn("memory:", slots["L2 Topic Threads"][0])

    def test_owner_can_page_full_personal_call_without_crossing_call_boundary(self) -> None:
        call_channel = "call:owner:full-audit"
        anchor_id = ""
        for index in range(17):
            event = ConversationEvent(
                content=f"personal call user turn {index}", source=EventSource.VOICE_CALL,
                mode=InteractionMode.CALL, channel_id=call_channel,
                created_at=f"2026-10-22T12:{index // 60:02d}:{index % 60:02d}+00:00",
            )
            self.engine.record_turn(event, result_for(event, f"personal call Stella turn {index}"))
            if index == 8:
                with self.engine._connect() as connection:
                    anchor_id = str(connection.execute(
                        "SELECT id FROM episodes WHERE event_id = ?", (event.id,)
                    ).fetchone()["id"])
        other_call = ConversationEvent(
            content="separate call should not appear", source=EventSource.VOICE_CALL,
            mode=InteractionMode.CALL, channel_id="call:owner:separate",
        )
        self.engine.record_turn(other_call, result_for(other_call, "separate response"))

        first_page = self.engine.inspect_memory(
            anchor_id, Visibility.PRIVATE, user_id="owner", include_private_owner=True,
            full_call=True, page_size=12,
        )
        second_page = self.engine.inspect_memory(
            anchor_id, Visibility.PRIVATE, user_id="owner", include_private_owner=True,
            full_call=True, call_offset=12, page_size=12,
        )
        self.assertIn("turns 1-12 of 17", first_page)
        self.assertIn("turns 13-17 of 17", second_page)
        self.assertIn("personal call user turn 0", first_page)
        self.assertIn("personal call Stella turn 16", second_page)
        self.assertNotIn("separate call should not appear", first_page + second_page)

    def test_full_call_inspection_stays_unavailable_to_non_owner_scope(self) -> None:
        event = ConversationEvent(
            content="owner personal call memory", source=EventSource.VOICE_CALL,
            mode=InteractionMode.CALL, channel_id="call:owner:private",
        )
        self.engine.record_turn(event, result_for(event, "owner response"))
        with self.engine._connect() as connection:
            anchor_id = str(connection.execute(
                "SELECT id FROM episodes WHERE event_id = ?", (event.id,)
            ).fetchone()["id"])
        result = self.engine.inspect_memory(
            anchor_id, Visibility.PRIVATE, user_id="discord:someone",
            include_private_owner=False, full_call=True,
        )
        self.assertEqual("That memory is unavailable in this conversation's scope.", result)

    def test_channel_recall_excludes_other_channels_and_private_history(self) -> None:
        for visibility, channel, user in (
            (Visibility.PUBLIC, "456", "discord:alice"),
            (Visibility.PRIVATE, "dm", "discord:alice"),
            (Visibility.PRIVATE, "desktop", "owner"),
        ):
            event = ConversationEvent(
                content="I planted lavender beside the greenhouse.", source=EventSource.DISCORD,
                visibility=visibility, user_id=user, channel_id=f"discord:{channel}:speaker:{user}",
                metadata={"discord_channel_id": channel},
            )
            self.engine.record_turn(event, result_for(event, "lovely"))
        scope = dict(user_id="discord:bob", shared_channel_id="123", include_private_owner=False)
        self.assertEqual(self.engine.retrieve("lavender greenhouse", Visibility.PUBLIC, **scope), [])
        self.assertEqual(self.engine.retrieve_for_recall("lavender greenhouse", Visibility.PUBLIC, **scope), [])
        self.assertEqual(self.engine.retrieve(
            "lavender greenhouse", Visibility.PUBLIC, suggestion_context=[], **scope), [])

    def test_person_targeted_channel_recall_stays_with_that_speakers_evidence(self) -> None:
        for speaker_id, name, fact in (
            ("discord:alice", "Alice", "I am restoring an old motorcycle."),
            ("discord:bob", "Bob", "I am learning to bake sourdough."),
        ):
            event = ConversationEvent(
                content=fact, source=EventSource.DISCORD, mode=InteractionMode.CALL,
                visibility=Visibility.PUBLIC, user_id=speaker_id, display_name=name,
                channel_id=f"discord:123:speaker:{speaker_id}",
                metadata={"discord_channel_id": "123"},
            )
            self.engine.record_turn(event, result_for(event, "That sounds like a fun project."))
        results = self.engine.retrieve_for_recall(
            "what do you remember about me Alice", Visibility.PUBLIC,
            user_id="discord:bob", shared_channel_id="123", target_user_id="discord:alice",
        )
        combined = " ".join(results)
        self.assertIn("restoring an old motorcycle", combined)
        self.assertNotIn("learning to bake", combined)

    def test_full_session_history_ignores_recent_turn_limit(self) -> None:
        self.engine.config.recent_turns = 2
        for index in range(5):
            event = ConversationEvent(content=f"turn {index}", created_at="2026-10-16T12:00:00+00:00")
            self.engine.record_turn(event, result_for(event, f"reply {index}"))

        self.assertEqual(len(self.engine.recent_history()), 2)
        self.assertEqual(
            self.engine.full_session_history(),
            [(f"turn {index}", f"reply {index}") for index in range(5)],
        )

    def test_public_retrieval_cannot_read_private_concepts(self) -> None:
        now = "2026-01-01T00:00:00+00:00"
        with self.engine._connect() as connection:
            connection.executemany(
                """
                INSERT INTO concepts (
                    key, label, summary, topics_json, visibility, strength, confidence,
                    recurrence, emotional_weight, relationship_relevance, last_seen
                ) VALUES (?, ?, ?, '[]', ?, 0.8, 0.8, 2, 0.2, 0.2, ?)
                """,
                [
                    ("private:coffee", "private coffee", "secret coffee preference", "private", now),
                    ("public:coffee", "public coffee", "coffee is discussed publicly", "public", now),
                ],
            )
        public = self.engine.retrieve("coffee", Visibility.PUBLIC, limit=10)
        private = self.engine.retrieve("coffee", Visibility.PRIVATE, limit=10)
        self.assertFalse(any("secret" in item for item in public))
        self.assertTrue(any("secret" in item for item in private))

    def test_consolidation_creates_semantic_memory_and_relationship_evidence(self) -> None:
        event = ConversationEvent(content="i make coffee before coding")
        self.engine.record_turn(event, result_for(event, "that explains the ritual"))
        outcome = self.engine.consolidate(ConsolidationBackend())
        self.assertEqual(outcome.processed, 1)
        self.assertEqual(outcome.relationship_delta["familiarity"], 0.01)
        self.assertEqual(self.engine.stats()["concepts"], 1)


if __name__ == "__main__":
    unittest.main()
