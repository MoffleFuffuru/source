from __future__ import annotations

import json
import unittest
from pathlib import Path
from uuid import uuid4

from mako.config import load_config


class ConfigMigrationTests(unittest.TestCase):
    def test_old_config_moves_calls_to_continuous_realtime_pipeline(self) -> None:
        runtime = Path(__file__).resolve().parent / "_runtime"
        runtime.mkdir(exist_ok=True)
        path = runtime / f"config-{uuid4().hex}.json"
        path.write_text(
            json.dumps(
                {
                    "config_version": 2,
                    "model": {
                        "primary": "gemma4:12b",
                        "call_model": "qwen3:8b",
                    },
                }
            ),
            encoding="utf-8",
        )

        try:
            config = load_config(path)
            saved = json.loads(path.read_text(encoding="utf-8"))

            self.assertEqual(config.config_version, 12)
            self.assertEqual(config.model.call_model, "openai/gpt-oss-120b")
            self.assertEqual(config.model.call_max_attempts, 1)
            self.assertEqual(config.model.call_context_tokens, 4096)
            self.assertEqual(config.model.call_max_output_tokens, 64)
            self.assertEqual(config.model.call_recent_turns, 3)
            self.assertEqual(config.model.call_memory_limit, 2)
            self.assertEqual(config.memory.retrieval_limit, 2)
            self.assertEqual(config.memory.associative_packet_size, 2)
            self.assertEqual(config.voice.transcription_window_seconds, 1.6)
            self.assertEqual(config.voice.transcription_overlap_seconds, 0.75)
            self.assertEqual(config.voice.tts_backend, "kokoro")
            self.assertEqual(config.voice.voice, "af_sky")
            self.assertEqual(config.voice.kokoro_speed, 1.08)
            self.assertEqual(saved["config_version"], 12)
            self.assertEqual(saved["model"]["call_model"], "openai/gpt-oss-120b")
        finally:
            path.unlink(missing_ok=True)


if __name__ == "__main__":
    unittest.main()
