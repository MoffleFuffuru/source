from __future__ import annotations

import unittest

from mako.recall_bridge import deep_recall_bridge


class RecallBridgeTests(unittest.TestCase):
    def test_automatic_filler_is_disabled_for_memory_requests(self) -> None:
        self.assertIsNone(deep_recall_bridge("Do you remember our old Discord call?"))

    def test_non_recall_turns_also_have_no_bridge(self) -> None:
        self.assertIsNone(deep_recall_bridge("How was your day?"))


if __name__ == "__main__":
    unittest.main()
