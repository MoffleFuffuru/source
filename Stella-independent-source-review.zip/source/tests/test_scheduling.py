from __future__ import annotations

import unittest

from mako.scheduling import parse_scheduled_call


class ScheduledCallParsingTests(unittest.TestCase):
    def test_parses_natural_filler_before_relative_callback_time(self) -> None:
        call = parse_scheduled_call("Can you call me back in like one minute?", now=1000)

        self.assertIsNotNone(call)
        assert call is not None
        self.assertEqual(call.due_at, 1060)
        self.assertEqual(call.time_label, "in one minute")

