import asyncio
from pathlib import Path
import queue
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from mako.cartesia_voice import speech_payload, stream_dialogue
from mako.config import VoiceConfig
from mako.voice import VoiceEngine


class Response:
    status = 200

    def __init__(self, blocks):
        self.blocks = blocks
        self.content = self

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        pass

    async def iter_chunked(self, size):
        for block in self.blocks:
            await asyncio.sleep(0)
            yield block


class Session:
    def __init__(self, responses):
        self.responses = iter(responses)
        self.payloads = []

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        pass

    def post(self, url, *, json):
        self.payloads.append(json)
        return next(self.responses)


class CartesiaTests(unittest.IsolatedAsyncioTestCase):
    def config(self):
        return VoiceConfig(tts_backend="cartesia_tts", cartesia_tts_voice="4dd4630e-19e0-4243-bca0-676ff85119b7")

    async def test_pcm_boundaries_and_clause_order(self):
        session = Session([Response([b"\x01", b"\x02\x03\x04"]), Response([b"\x05\x06"])])
        chunks = queue.Queue()
        for text in ("First.", "Second.", None):
            chunks.put(text)
        with patch("mako.cartesia_voice.cartesia_key", return_value="test"), patch("aiohttp.ClientSession", return_value=session):
            audio = [block async for block in stream_dialogue(self.config(), chunks)]
        self.assertEqual(b"".join(audio), bytes(range(1, 7)))
        self.assertTrue(all(len(block) % 2 == 0 for block in audio))
        self.assertEqual([p["transcript"] for p in session.payloads], ["First.", "Second."])
        self.assertTrue(all(p["language"] == "en" and p["model_id"] == "sonic-3.6" for p in session.payloads))

    async def test_cancellation_before_network(self):
        with patch("aiohttp.ClientSession") as session:
            result = [b async for b in stream_dialogue(self.config(), queue.Queue(), cancelled=lambda: True)]
        session.assert_not_called()
        self.assertEqual(result, [])

    async def test_cancel_during_pending_network(self):
        class Stalled(Response):
            async def iter_chunked(self, size):
                await asyncio.sleep(60)
                yield b""
        stop = asyncio.Event()
        chunks = queue.Queue()
        chunks.put("Hello")
        async def cancel():
            await asyncio.sleep(.02)
            stop.set()
        with patch("mako.cartesia_voice.cartesia_key", return_value="test"), patch("aiohttp.ClientSession", return_value=Session([Stalled([])])):
            task = asyncio.create_task(cancel())
            async with asyncio.timeout(.3):
                result = [b async for b in stream_dialogue(self.config(), chunks, cancelled=stop.is_set)]
            await task
        self.assertEqual(result, [])

    async def test_incomplete_audio_is_failure(self):
        chunks = queue.Queue()
        chunks.put("Hello")
        with patch("mako.cartesia_voice.cartesia_key", return_value="test"), patch("aiohttp.ClientSession", return_value=Session([Response([b"\x01"])])):
            with self.assertRaisesRegex(RuntimeError, "incomplete"):
                async for _ in stream_dialogue(self.config(), chunks):
                    pass

    async def test_provider_failure_has_no_secret_or_transcript(self):
        response = Response([])
        response.status = 401
        chunks = queue.Queue()
        chunks.put("private transcript")
        with patch("mako.cartesia_voice.cartesia_key", return_value="secret-key"), patch("aiohttp.ClientSession", return_value=Session([response])):
            with self.assertRaisesRegex(RuntimeError, "HTTP 401") as caught:
                async for _ in stream_dialogue(self.config(), chunks):
                    pass
        self.assertNotIn("secret-key", str(caught.exception))
        self.assertNotIn("private transcript", str(caught.exception))

    def test_voice_dispatch_uses_cloud_playback_without_local_engine(self):
        engine = object.__new__(VoiceEngine)
        engine.config = self.config()
        engine.capabilities = SimpleNamespace(can_speak=False)
        engine._uses_inworld_tts = lambda: False
        engine._schedule_elevenlabs = Mock()
        engine.speak("Hello")
        chunks = engine._schedule_elevenlabs.call_args.args[0]
        self.assertEqual(chunks.get_nowait(), "Hello")
        self.assertIsNone(chunks.get_nowait())

    def test_payload_english_and_voice(self):
        payload = speech_payload(self.config(), "Hello")
        self.assertEqual(payload["language"], "en")
        self.assertEqual(payload["voice"], self.config().cartesia_tts_voice)
