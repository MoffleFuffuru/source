import json
from pathlib import Path
from tempfile import TemporaryDirectory
import threading
import unittest

from mako.config import AppConfig
from mako.core import MakoCore
from mako.dialogue import DialogueManager
from mako.models import ConversationEvent, EventSource, InteractionMode
from tests.test_dialogue import FakeBackend, candidate


class CoreIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        config = AppConfig()
        config.body.enabled = False
        config.memory.enabled = False
        config.sage.enabled = True
        config.model.critic_mode = 'never'
        config.model.call_reasoning_effort = 'none'
        self.core = MakoCore(Path(self.tmp.name), config=config)
        self.addCleanup(self.core.close)
        self.backend = FakeBackend([candidate('How did those rewards turn out?')])
        self.core.sage._speaker = DialogueManager(config, self.backend, self.core.ledger)

    def event(self, mode=InteractionMode.TEXT):
        return ConversationEvent(content='Internal SAGE expression opportunity; no human said this.',
            source=EventSource.SYSTEM, mode=mode, metadata={
                'sage_initiated': True, 'sage_packet': 'Ask about the actual rewards.',
                'call_continuity': '[turn1] Jalty: I got rewards.', 'sage_scene': 'desktop:chat:owner'})

    def test_real_core_isolated_generation_defers_state_until_delivery(self):
        event = self.event()
        result = self.core.respond(event, defer_commit=True)
        self.assertEqual(self.core._temporary_history, [])
        self.assertIn('Jalty: I got rewards', self.backend.prompts[0])
        self.core.commit_deferred_call_response(event, result)
        self.assertIn('Stella: How did those rewards turn out?', self.core._temporary_history)

    def test_speculative_turn_does_not_wait_on_foreground_model_lock(self):
        done = threading.Event()
        errors = []
        def run():
            try:
                self.core.respond(self.event(), defer_commit=True)
            except Exception as error:
                errors.append(error)
            finally:
                done.set()
        with self.core._model_lock:
            thread = threading.Thread(target=run, daemon=True)
            thread.start()
            finished_independently = done.wait(2)
        thread.join(timeout=2)
        self.assertTrue(finished_independently)
        self.assertEqual(errors, [])

    def test_autonomous_voice_schema_allows_model_chosen_silence(self):
        self.backend.responses = [json.dumps({'text': '', 'respond': False})]
        result = self.core.respond(self.event(InteractionMode.CALL), defer_commit=True)
        self.assertEqual(result.text, '')
        schema = self.backend.calls[0]['json_schema']
        self.assertIn('respond', schema['required'])
        self.assertNotIn('enum', schema['properties']['respond'])
        self.assertEqual(self.backend.calls[0]['reasoning_effort'], 'none')

    def test_normal_turn_does_not_inherit_sage_context(self):
        self.core.respond(self.event(), defer_commit=True)
        normal = FakeBackend([candidate('Morning. How did you sleep?')])
        self.core.dialogue = DialogueManager(self.core.config, normal, self.core.ledger)
        self.core.respond(ConversationEvent(content='Good morning.'), defer_commit=True)
        self.assertNotIn('Ask about the actual rewards', normal.prompts[0])
        self.assertNotIn('Jalty: I got rewards', normal.prompts[0])
