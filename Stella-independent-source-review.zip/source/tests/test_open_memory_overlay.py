from __future__ import annotations

import unittest
from types import SimpleNamespace

from mako.core import MakoCore
from mako.models import ConversationEvent, EventSource, InteractionMode, Visibility


class OpenMemoryOverlayTests(unittest.TestCase):
    def setUp(self) -> None:
        self.core = MakoCore.__new__(MakoCore)
        self.core.config = SimpleNamespace(
            discord=SimpleNamespace(open_memory_test_guild_ids=["1259638416019292262"])
        )
        self.core.memory = SimpleNamespace(
            public_discord_call_archive=lambda _guild, **_kwargs: [
                {
                    "time": "2026-10-04T20:00:00-04:00", "session_id": "call-a",
                    "user_id": "discord:42", "user": "I have been working on a voice companion.",
                    "stella": "You have been tuning its low-latency voice path.",
                },
                {
                    "time": "2026-10-04T20:02:00-04:00", "session_id": "call-a",
                    "user_id": "discord:99", "user": "Alex has been helping with the project.",
                    "stella": "Alex sounds like a useful collaborator.",
                },
            ]
        )
        self.core._curate_memory_chunk = lambda evidence, *_args: evidence
        self.core._curate_memory_final = lambda notes, target, question, instruction: (
            f"{target}: {len(notes)} evidence batches; {instruction}"
        )

    def make_event(self, **kwargs):
        metadata = {
            "discord_voice": True,
            "discord_guild_id": "1259638416019292262",
            "discord_participants": [
                {"user_id": "discord:42", "name": "Prince Moffle"},
                {"user_id": "discord:99", "name": "Alex"},
            ],
        }
        metadata.update(kwargs.pop("metadata", {}))
        return ConversationEvent(
            content=kwargs.pop("content", "What do you know about me?"),
            source=kwargs.pop("source", EventSource.DISCORD),
            mode=kwargs.pop("mode", InteractionMode.CALL),
            visibility=kwargs.pop("visibility", Visibility.PUBLIC),
            user_id="discord:42", display_name="Prince Moffle", metadata=metadata, **kwargs,
        )

    def test_profile_recall_builds_one_turn_person_overlay(self) -> None:
        event = self.make_event()
        result = self.core._prepare_open_memory_overlay(event)
        self.assertEqual(result["target"], "Prince Moffle")
        self.assertIn("500-700 words", event.metadata["turn_memory_overlay"])
        self.assertIn("all text-mode memory are excluded", event.metadata["turn_memory_overlay"])

    def test_explicit_person_name_resolves_to_that_participant(self) -> None:
        event = self.make_event(content="What do you remember about Alex?")
        result = self.core._prepare_open_memory_overlay(event)
        self.assertEqual(result["target"], "Alex")
        self.assertIn("Alex:", event.metadata["turn_memory_overlay"])

    def test_app_call_text_and_unlisted_guilds_never_activate_overlay(self) -> None:
        app_event = self.make_event(source=EventSource.VOICE_CALL)
        text_event = self.make_event(mode=InteractionMode.TEXT)
        other_guild = self.make_event(metadata={"discord_guild_id": "1495790417336205473"})
        for event in (app_event, text_event, other_guild):
            self.assertEqual(self.core._prepare_open_memory_overlay(event), {})
            self.assertNotIn("turn_memory_overlay", event.metadata)


if __name__ == "__main__":
    unittest.main()
