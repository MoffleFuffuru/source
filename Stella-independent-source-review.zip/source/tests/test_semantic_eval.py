"""Regression evaluation for deterministic semantic-act routing."""
from __future__ import annotations

import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from mako.semantic import SemanticEngine


CASES = {
    "correction": ("we are already talking", "you got that backwards"),
    "leave_return": ("i am back", "goodnight for now"),
    "affection_reassurance": ("i missed you", "you are safe here"),
    "relationship_reflection": ("are we close", "what do i mean to you"),
    "conversation_recap": ("what did we just talk about", "what have we said"),
    "emotional_disclosure": ("i feel overwhelmed", "today was awful", "work has been exhausting"),
    "call_invitation": ("wanna call", "can we talk on a call", "call me when you can"),
    "feedback_or_test": ("i am testing you", "you keep repeating yourself"),
    "topic_boundary": ("not right now", "leave that topic alone"),
    "clarification_repair": ("what do you mean", "i did not hear that"),
    "shared_work_update": ("i am fixing your code", "i am improving your call model"),
    "availability_check": ("are you still there", "stay with me"),
    "closed_acknowledgment": ("yes, thanks", "thank you"),
    "unknown": ("the blue mug is on the desk", "we might play later"),
}


class SemanticEvaluationTests(unittest.TestCase):
    def test_labeled_semantic_act_cases(self) -> None:
        with TemporaryDirectory() as temp:
            engine = SemanticEngine(Path(temp) / "semantic.sqlite3")
            correct = 0
            total = 0
            mismatches: list[str] = []
            for expected, phrases in CASES.items():
                for phrase in phrases:
                    actual = engine._rules(phrase, "").act
                    total += 1
                    correct += actual == expected
                    if actual != expected:
                        mismatches.append(f"{phrase!r}: expected {expected}, got {actual}")

        accuracy = correct / total
        self.assertGreaterEqual(accuracy, 0.90, "\n".join(mismatches))

    def test_compliment_acceptance_uses_previous_turn_context(self) -> None:
        with TemporaryDirectory() as temp:
            engine = SemanticEngine(Path(temp) / "semantic-context.sqlite3")
            # analyze() lowercases both current and previous turns before routing.
            previous = "you keep making me smile."
            self.assertEqual(engine._rules("thanks", previous).act, "accept_compliment")
            self.assertEqual(engine._rules("thanks", "How was your day?").act, "closed_acknowledgment")


if __name__ == "__main__":
    unittest.main()
