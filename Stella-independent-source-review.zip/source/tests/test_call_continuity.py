from __future__ import annotations

import unittest
import threading
import time
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

from mako.call_continuity import (
    CallContinuity, SileroSpeechOnsetGate, SustainedSpeechGate,
    interrupt_confirmation_ready,
)
from mako.conversation_tracker import ConversationTracker
from mako.config import AppConfig
from mako.dialogue import DialogueManager
from mako.models import ConversationEvent, InteractionMode


class ConversationAwarenessTests(unittest.TestCase):
    def test_third_person_self_reference_uses_recent_stella_branch(self) -> None:
        tracker = ConversationTracker()
        tracker.observe(
            speaker_id="1", speaker_name="Owner", text="Stella, do you remember the call?",
            timestamp="20:00:00", participant_names=("Owner", "Jalty"),
        )
        turn = tracker.observe(
            speaker_id="2", speaker_name="Jalty", text="she remembers the whole conversation",
            timestamp="20:00:02", participant_names=("Owner", "Jalty"),
        )
        self.assertEqual(turn.likely_referent, "Stella")
        self.assertTrue(turn.self_reference_likely)

    def test_referent_uses_last_name_mentioned_not_participant_set_order(self) -> None:
        outcomes = []
        for participants in (("Owner", "Jalty"), ("Jalty", "Owner")):
            tracker = ConversationTracker()
            turn = tracker.observe(
                speaker_id="1", speaker_name="Owner", text="she told Owner about Jalty",
                timestamp="20:00:00", participant_names=participants,
            )
            outcomes.append(turn.likely_referent)
        self.assertEqual(outcomes, ["jalty", "jalty"])

    def test_group_you_is_not_automatically_assumed_to_mean_stella(self) -> None:
        tracker = ConversationTracker()
        turn = tracker.observe(
            speaker_id="2", speaker_name="Jalty", text="what do you think about that?",
            timestamp="20:00:02", participant_names=("Owner", "Jalty"),
        )
        self.assertEqual(turn.likely_referent, "unclear")
        self.assertFalse(turn.self_reference_likely)

    def test_follow_up_question_remains_probabilistic_tracker_evidence(self) -> None:
        tracker = ConversationTracker()
        tracker.observe_assistant(text="I remember the Discord call now.", timestamp="20:00:01")
        turn = tracker.observe(
            speaker_id="2", speaker_name="Jalty", text="what else do you remember?",
            timestamp="20:00:02", participant_names=("Owner", "Jalty"),
        )
        self.assertEqual(turn.likely_addressee, "uncertain")
        self.assertNotEqual(turn.addressee_basis, "follow_up_to_stella")

    def test_unrelated_group_turn_is_not_admitted(self) -> None:
        tracker = ConversationTracker()
        state = tracker.observe(
            speaker_id="2", speaker_name="Jalty", text="did you see the new game update?",
            timestamp="20:00:02", participant_names=("Owner", "Jalty"),
        ).to_dict()
        self.assertNotEqual(state["likely_addressee"], "Stella")
        self.assertFalse(state["self_reference_likely"])

    def test_named_greeting_remains_human_to_human(self) -> None:
        tracker = ConversationTracker()
        turn = tracker.observe(
            speaker_id="2", speaker_name="Owner", text="Yo, Jalty, what's up?",
            timestamp="20:00:02", participant_names=("Owner", "Jalty"),
        )
        self.assertEqual(turn.likely_addressee, "Jalty")
        self.assertTrue(turn.human_to_human)

    def test_assistant_name_at_end_of_question_is_a_direct_vocative(self) -> None:
        tracker = ConversationTracker()
        turn = tracker.observe(
            speaker_id="1", speaker_name="Owner",
            text="What do you think about the topic, Stella?", timestamp="20:00:00",
            participant_names=("Owner", "Jalty"),
        )
        self.assertEqual(turn.likely_addressee, "Stella")
        self.assertTrue(turn.response_expected)

    def test_following_explanation_inherits_open_direct_address(self) -> None:
        tracker = ConversationTracker()
        tracker.observe(
            speaker_id="2", speaker_name="Jalty",
            text="Hey, Stella, I have a dilemma for you, okay? So imagine...",
            timestamp="20:00:00", participant_names=("Owner", "Jalty"),
        )
        turn = tracker.observe(
            speaker_id="2", speaker_name="Jalty",
            text="The premise is that humanity becomes overpopulated.",
            timestamp="20:00:08", participant_names=("Owner", "Jalty"),
        )
        self.assertEqual(turn.likely_addressee, "Stella")
        self.assertEqual(turn.addressee_basis, "continuation_of_direct_address")
        self.assertTrue(turn.continuation_of_direct_address)
        self.assertTrue(turn.response_expected)

    def test_assistant_reply_consumes_open_direct_address(self) -> None:
        tracker = ConversationTracker()
        tracker.observe(
            speaker_id="1", speaker_name="Owner",
            text="Stella, I wanted to explain something.", timestamp="20:00:00",
            participant_names=("Owner", "Jalty"),
        )
        tracker.observe_assistant(text="Sure, go ahead.", timestamp="20:00:03")
        turn = tracker.observe(
            speaker_id="1", speaker_name="Owner", text="Also, Jalty said the match is later.",
            timestamp="20:00:05", participant_names=("Owner", "Jalty"),
        )
        self.assertNotEqual(turn.likely_addressee, "Stella")
        self.assertFalse(turn.continuation_of_direct_address)

    def test_third_person_assistant_mention_is_not_a_direct_address(self) -> None:
        tracker = ConversationTracker()
        turn = tracker.observe(
            speaker_id="1", speaker_name="Owner",
            text="Stella doesn't know whether people are talking to her.", timestamp="20:00:00",
            participant_names=("Owner", "Jalty"),
        )
        self.assertNotEqual(turn.likely_addressee, "Stella")
        self.assertTrue(turn.self_reference_likely)


class DiscordInputGateTests(unittest.TestCase):
    def test_interrupt_confirmation_requires_one_second_transcript_and_recent_speech(self) -> None:
        self.assertFalse(interrupt_confirmation_ready(10.0, 10.99, "Please wait", 10.9))
        self.assertFalse(interrupt_confirmation_ready(10.0, 11.0, "  ", 10.9))
        self.assertFalse(interrupt_confirmation_ready(10.0, 11.0, "Please wait", 10.64))
        self.assertTrue(interrupt_confirmation_ready(10.0, 11.0, "Please wait", 10.7))

    def test_sustained_speech_timestamp_is_available_without_silero(self) -> None:
        gate = SustainedSpeechGate(attack_seconds=0.1, calibration_seconds=0.0)
        gate.observe("speaker", 1600, 10.0)
        gate.observe("speaker", 1600, 10.1)
        self.assertEqual(gate.last_speech_at("speaker"), 10.1)
        gate.observe("speaker", 0, 10.7)
        self.assertIsNone(gate.last_speech_at("speaker"))

    def test_short_transcript_fragments_are_suppressed_but_social_acts_pass(self) -> None:
        from mako.discord_service import _is_valid_short_voice_turn

        for fragment in ("Yeah.", "Oh.", "Clears throat", "Oh. Oh."):
            with self.subTest(fragment=fragment):
                self.assertFalse(_is_valid_short_voice_turn(fragment))
        for complete in ("Hey, Stella!", "Why?", "I'm good.", "Sounds good.", "Wait!"):
            with self.subTest(complete=complete):
                self.assertTrue(_is_valid_short_voice_turn(complete))

    def test_single_reaction_partial_does_not_interrupt_but_a_phrase_does(self) -> None:
        from mako.discord_service import _partial_is_interrupt_worthy

        self.assertFalse(_partial_is_interrupt_worthy("Oh."))
        self.assertFalse(_partial_is_interrupt_worthy("Yeah."))
        for fragment in ("Mm-hmm.", "Uh...", "Y-", "I think I", "It-- I--"):
            with self.subTest(fragment=fragment):
                self.assertFalse(_partial_is_interrupt_worthy(fragment))
        self.assertTrue(_partial_is_interrupt_worthy("there"))
        self.assertTrue(_partial_is_interrupt_worthy("I thought"))
        self.assertTrue(_partial_is_interrupt_worthy("Stella?"))

    def test_barge_in_stops_output_without_stopping_discord_receive(self) -> None:
        from mako.discord_service import _stop_voice_playback

        class ReceiveVoiceClient:
            def __init__(self):
                self.output_stopped = False
                self.receive_stopped = False

            def stop_playing(self):
                self.output_stopped = True

            def stop_listening(self):
                self.receive_stopped = True

            def stop(self):
                self.stop_playing()
                self.stop_listening()

        voice = ReceiveVoiceClient()
        _stop_voice_playback(voice)
        self.assertTrue(voice.output_stopped)
        self.assertFalse(voice.receive_stopped)

    def test_discord_stream_holds_text_until_model_says_respond(self) -> None:
        from mako.discord_service import _DiscordReplyStream

        stream = _DiscordReplyStream(require_response_decision=True)
        stream.prefix = "[annoyed]"
        stream.on_token('{"respond":')
        stream.on_token('true,"floor_action":"claim","text":"hello there. how are you?"}')
        self.assertEqual(stream.floor_action, "claim")
        self.assertEqual(stream.chunks.get_nowait(), "[annoyed] hello there. ")

    def test_discord_stream_waits_for_floor_policy_before_speaking(self) -> None:
        from mako.discord_service import _DiscordReplyStream

        stream = _DiscordReplyStream(require_response_decision=True)
        stream.on_token('{"respond":true,"text":"A concise reply. ')
        self.assertTrue(stream.chunks.empty())
        stream.on_token('Next.","floor_action":"yield"}')
        self.assertEqual(stream.chunks.get_nowait(), "A concise reply. ")

    def test_discord_stream_uses_stellas_expression_not_users_mood(self) -> None:
        from mako.discord_service import _DiscordReplyStream

        stream = _DiscordReplyStream(
            require_response_decision=True,
            expressive_tts=True,
            user_text="The bug is so frustrating.",
        )
        stream.on_token(
            '{"respond":true,"floor_action":"yield","expression":"concerned",'
            '"text":"I can see why. Let me help."}'
        )
        self.assertEqual(stream.expression, "concerned")
        self.assertEqual(stream.chunks.get_nowait(), "I can see why. ")

    def test_discord_stream_normalizes_annoyed_when_frustration_targets_a_bug(self) -> None:
        from mako.discord_service import _DiscordReplyStream

        stream = _DiscordReplyStream(
            require_response_decision=True,
            expressive_tts=True,
            user_text="This broken menu is frustrating.",
        )
        stream.on_token(
            '{"respond":true,"floor_action":"yield","expression":"annoyed",'
            '"text":"That sounds rough. We can fix it."}'
        )
        self.assertEqual(stream.expression, "neutral")
        self.assertEqual(stream.chunks.get_nowait(), "That sounds rough. ")

    def test_claim_floor_is_capped_and_defers_cancel_without_dropping_transcript(self) -> None:
        from mako.discord_service import DiscordService

        service = object.__new__(DiscordService)
        service._voice_lock = threading.RLock()
        cancel = threading.Event()
        service._voice_generation_cancel = {7: cancel}
        journal = Mock()
        service._voice_journals = {7: journal}
        service._voice_floor_claim_until = {}
        member = SimpleNamespace(id=42, display_name="Speaker")

        self.assertTrue(service._activate_voice_floor_claim(7, cancel, duration=20.0))
        self.assertLessEqual(service._voice_floor_claim_until[7][1] - time.monotonic(), 3.0)
        service._interrupt_voice_turn(
            7, member, recognized_text="I need to say something", pcm_to_partial_seconds=1.2
        )

        self.assertFalse(cancel.is_set())
        self.assertTrue(any(call.kwargs.get("action") == "claim_floor_briefly; transcript_retained"
                            for call in journal.record.call_args_list))

    def test_expired_floor_claim_no_longer_blocks_confirmed_interrupt(self) -> None:
        from mako.discord_service import DiscordService

        service = object.__new__(DiscordService)
        service._voice_lock = threading.RLock()
        cancel = threading.Event()
        service._voice_generation_cancel = {7: cancel}
        service._voice_floor_claim_until = {7: (cancel, 10.0)}
        service._voice_interruption_pending = set()
        service._voice_response_required = set()
        service._voice_streams = {}
        service._voice_playback_trace = {}
        service._voice_interrupted_text = {7: []}
        service._voice_sage_intents = {}
        service._voice_journals = {}
        service._voice_exchanges = {7: SimpleNamespace(snapshot=lambda: (0, []))}
        service._client = None
        service.core = SimpleNamespace(sage=None)
        service._schedule_voice_response = Mock()
        member = SimpleNamespace(id=42, display_name="Speaker")

        with patch("mako.discord_service.monotonic", return_value=10.01):
            service._interrupt_voice_turn(
                7, member, recognized_text="Wait, stop.", pcm_to_partial_seconds=1.2
            )

        self.assertTrue(cancel.is_set())
        self.assertIn(7, service._voice_interruption_pending)

    def test_discord_stream_never_plays_text_when_model_selects_silence(self) -> None:
        from mako.discord_service import _DiscordReplyStream

        stream = _DiscordReplyStream(require_response_decision=True)
        stream.on_token('{"respond":false,"floor_action":"yield","text":""}')
        self.assertFalse(stream.finish(""))
        self.assertIsNone(stream.chunks.get_nowait())

    def test_steady_noisy_mic_floor_does_not_interrupt(self) -> None:
        gate = SustainedSpeechGate(attack_seconds=0.12)
        for step in range(30):
            self.assertFalse(gate.observe("noisy", 1200, step * 0.02))

    def test_speech_burst_above_noisy_floor_interrupts_after_attack(self) -> None:
        gate = SustainedSpeechGate(attack_seconds=0.12)
        for step in range(30):
            gate.observe("noisy", 1200, step * 0.02)
        fired = False
        for step in range(10):
            fired = gate.observe("noisy", 4000, 0.60 + step * 0.02) or fired
        self.assertTrue(fired)

    def test_interrupt_gate_bridges_natural_word_gaps_without_restarting_attack(self) -> None:
        gate = SustainedSpeechGate(
            attack_seconds=0.18, calibration_seconds=0.0, hangover_seconds=0.45
        )
        self.assertFalse(gate.observe("speaker", 1600, 0.00))
        self.assertFalse(gate.observe("speaker", 1600, 0.10))
        self.assertTrue(gate.observe("speaker", 1600, 0.19))
        self.assertFalse(gate.observe("speaker", 0, 0.25))
        self.assertFalse(gate.observe("speaker", 1600, 0.31))
        self.assertFalse(gate.observe("speaker", 1600, 0.50))


class CallContinuityTests(unittest.TestCase):
    def test_silero_onset_requires_two_positive_frames_and_rearms_after_silence(self) -> None:
        class FakeModel:
            def __init__(self):
                self.probability = 0.9

            def __call__(self, frame, sample_rate):
                import torch
                return torch.tensor([[self.probability]])

        import numpy as np

        model = FakeModel()
        gate = SileroSpeechOnsetGate(model, required_frames=2, release_frames=2)
        frame = np.ones(512, dtype=np.float32)
        self.assertFalse(gate.observe("a", frame[:400]))
        self.assertFalse(gate.observe("a", frame[400:]))
        self.assertTrue(gate.observe("a", frame))
        self.assertFalse(gate.observe("a", frame))
        model.probability = 0.0
        self.assertFalse(gate.observe("a", frame))
        self.assertFalse(gate.observe("a", frame))
        model.probability = 0.9
        self.assertFalse(gate.observe("a", frame))
        self.assertTrue(gate.observe("a", frame))

    def test_silero_onset_state_is_independent_per_speaker(self) -> None:
        created = []

        class SpeechModel:
            def __call__(self, frame, sample_rate):
                import torch
                return torch.tensor([[0.9]])

        def make_model():
            model = SpeechModel()
            created.append(model)
            return model

        import numpy as np

        gate = SileroSpeechOnsetGate(model_factory=make_model, required_frames=2)
        frame = np.ones(512, dtype=np.float32)
        self.assertFalse(gate.observe("a", frame))
        self.assertFalse(gate.observe("b", frame))
        self.assertTrue(gate.observe("a", frame))
        self.assertTrue(gate.observe("b", frame))
        self.assertEqual(len(created), 2)
        self.assertIsNot(created[0], created[1])

    def test_interrupted_reply_deadline_is_1_5_seconds_after_endpoint_or_vad_speech(self) -> None:
        from mako.discord_service import _post_interrupt_resume_deadline

        self.assertAlmostEqual(_post_interrupt_resume_deadline(10.0, 9.8, None), 11.3)
        self.assertAlmostEqual(_post_interrupt_resume_deadline(10.0, 9.8, 9.9), 11.45)
        self.assertAlmostEqual(_post_interrupt_resume_deadline(10.0, None, None), 11.5)

    def test_explicit_discord_address_is_evidence_not_a_forced_response(self) -> None:
        manager = DialogueManager(AppConfig(), None, None)
        prompt = manager._generation_prompt(
            event=ConversationEvent(
                content="What do you think about the topic, Stella?",
                mode=InteractionMode.CALL,
                metadata={
                    "discord_voice": True,
                    "conversation_state": {
                        "likely_addressee": "Stella",
                        "addressee_basis": "explicit_name_or_discord_reference",
                        "response_expected": True,
                    },
                },
            ),
            history=[], memories=[], mood_summary="", semantic_guidance="",
            lessons=[], rejected=[], private_feedback="", exhausted_topics=set(), forbidden_topics=set(),
        )
        self.assertIn("not a participation command", prompt)
        self.assertNotIn("do not choose silence", prompt)
        self.assertNotIn("Set respond=true", prompt)

    def test_open_direct_address_explanation_is_kept_as_one_conversational_branch(self) -> None:
        manager = DialogueManager(AppConfig(), None, None)
        prompt = manager._generation_prompt(
            event=ConversationEvent(
                content="The premise is that humanity becomes overpopulated.",
                mode=InteractionMode.CALL,
                metadata={
                    "discord_voice": True,
                    "conversation_state": {"continuation_of_direct_address": True},
                    "discord_voice_group_context": (
                        "Jalty: Hey, Stella, I have a dilemma for you, okay? So imagine...\\n"
                        "Jalty: The premise is that humanity becomes overpopulated."
                    ),
                },
            ),
            history=[], memories=[], mood_summary="", semantic_guidance="",
            lessons=[], rejected=[], private_feedback="", exhausted_topics=set(), forbidden_topics=set(),
        )
        self.assertIn("same turn, not as unrelated human-to-human talk", prompt)
        self.assertIn("full accumulated setup", prompt)

    def test_current_call_rolls_into_frozen_previous_call_on_finish(self) -> None:
        first = CallContinuity(Path("unused"), "guild")
        first.start()
        first.record_user(speaker_id="1", speaker_name="Owner", text="remember the blue car", state={"thread": "memory"})
        first.record_assistant(text="the blue car, right")
        first._previous = {
            "summary": "Owner: remember the blue car. Stella: the blue car, right.",
            "events": list(first._current),
        }
        first.start()
        prompt = first.prompt_block()
        self.assertIn("FROZEN RECAP OF PREVIOUS CALL", prompt)
        self.assertIn("remember the blue car", prompt)
        self.assertIn("CURRENT CALL", prompt)

    def test_interrupted_generated_text_is_not_misrepresented_as_heard(self) -> None:
        continuity = CallContinuity(Path("unused"), "guild")
        continuity.start()
        continuity.record_assistant(text="unheard response", interrupted=True)
        self.assertIn("generated wording omitted", continuity.prompt_block())
        self.assertNotIn("unheard response", continuity.prompt_block())

    def test_discord_retry_prompt_prevents_repeating_interrupted_opening(self) -> None:
        manager = DialogueManager(AppConfig(), None, None)
        prompt = manager._generation_prompt(
            event=ConversationEvent(
                content="Jalty: The next part is actually pretty decent.",
                mode=InteractionMode.CALL,
                metadata={
                    "discord_voice": True,
                    "discord_voice_exchange": [{
                        "speaker_name": "Jalty", "timestamp": "8:42:10", "text": "The next part is actually pretty decent.",
                    }],
                    "discord_voice_interrupted_text": ["That is a surprisingly good deal."],
                    "discord_voice_resume_after_interruption": True,
                },
            ),
            history=[], memories=[], mood_summary="", semantic_guidance="",
            lessons=[], rejected=[], private_feedback="", exhausted_topics=set(), forbidden_topics=set(),
        )
        self.assertIn("That is a surprisingly good deal.", prompt)
        self.assertIn("Do not restart with or repeat those opening phrases", prompt)
        self.assertIn("at least 1.5 seconds of post-speech quiet", prompt)

    def test_interrupt_gate_does_not_spend_calibration_time_before_scribe(self) -> None:
        gate = SustainedSpeechGate(attack_seconds=0.18, calibration_seconds=0.0)
        self.assertFalse(gate.observe("speaker", 1600, 0.0))
        self.assertFalse(gate.observe("speaker", 1600, 0.10))
        self.assertTrue(gate.observe("speaker", 1600, 0.19))

    def test_sustained_speech_threshold_ignores_short_ack(self) -> None:
        gate = SustainedSpeechGate(attack_seconds=0.35)
        for step in range(6):
            self.assertFalse(gate.observe("1", 0, step * 0.1))
        self.assertFalse(gate.observe("1", 1000, 0.60))
        self.assertFalse(gate.observe("1", 1000, 0.70))
        self.assertFalse(gate.observe("1", 1000, 0.80))
        self.assertFalse(gate.observe("1", 1000, 0.90))
        self.assertTrue(gate.observe("1", 1000, 0.96))
        self.assertFalse(gate.observe("1", 1000, 1.00))

    def test_call_continuity_is_at_the_prompt_tail_before_current_transcript(self) -> None:
        manager = DialogueManager(AppConfig(), None, None)
        prompt = manager._generation_prompt(
            event=ConversationEvent(
                content="and what about that?", mode=InteractionMode.CALL,
                metadata={"call_continuity": "TIMESTAMPED CALL LEDGER"},
            ),
            history=[], memories=[], mood_summary="", semantic_guidance="",
            lessons=[], rejected=[], private_feedback="", exhausted_topics=set(), forbidden_topics=set(),
        )
        self.assertLess(prompt.index("TIMESTAMPED CALL LEDGER"), prompt.index("Current transcript:"))
        self.assertNotIn("MEMORY BOARD", prompt)

    def test_turn_memory_overlay_is_before_continuity_and_transcript(self) -> None:
        manager = DialogueManager(AppConfig(), None, None)
        prompt = manager._generation_prompt(
            event=ConversationEvent(
                content="what do you remember?", mode=InteractionMode.CALL,
                metadata={
                    "turn_memory_overlay": "ONE TURN FACTS",
                    "call_continuity": "TIMESTAMPED CALL LEDGER",
                },
            ),
            history=[], memories=[], mood_summary="", semantic_guidance="",
            lessons=[], rejected=[], private_feedback="", exhausted_topics=set(), forbidden_topics=set(),
        )
        self.assertLess(prompt.index("ONE TURN FACTS"), prompt.index("TIMESTAMPED CALL LEDGER"))
        self.assertLess(prompt.index("TIMESTAMPED CALL LEDGER"), prompt.index("Current transcript:"))


if __name__ == "__main__":
    unittest.main()
