import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from mako.sage.stream_memory import StreamMemory


class StreamMemoryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / "approved.json"

    def test_only_reviewed_excerpts_are_returned_not_denials_or_raw_neighbors(self):
        self.path.write_text(json.dumps({"version": 1, "approved": [
            {"id": "cat", "text": "Moffle has a black cat", "sources": ["episode:1"]}],
            "withheld_source_examples": [{"text": "PRIVATE DISCLOSURE"}],
            "policy": "PRIVATE POLICY"}), encoding="utf-8")
        result = "\n".join(StreamMemory(self.path).retrieve("cat", limit=3))
        self.assertIn("black cat", result)
        self.assertIn("creator, developer and owner", result)
        self.assertNotIn("PRIVATE", result)

    def test_missing_malformed_or_unversioned_file_fails_closed(self):
        memory = StreamMemory(self.path)
        self.assertEqual(memory.retrieve(), [])
        for text in ("{", "{}", '{"version": 2}'):
            self.path.write_text(text, encoding="utf-8")
            self.assertEqual(memory.retrieve(), [])

    def test_generic_requests_rotate_material(self):
        self.path.write_text(json.dumps({"version": 1, "approved": [
            {"id": str(i), "text": "A different event " + str(i), "sources": ["episode:" + str(i)]}
            for i in range(12)]}), encoding="utf-8")
        memory = StreamMemory(self.path)
        self.assertNotEqual(memory.retrieve(limit=3), memory.retrieve(limit=3))

    def test_unsourced_record_is_not_approved(self):
        self.path.write_text(json.dumps({"version": 1, "approved": [
            {"id": "invented", "text": "An invented event"}]}), encoding="utf-8")
        self.assertEqual(StreamMemory(self.path).retrieve(), [])

    def test_repository_approvals_have_unique_ids_and_provenance(self):
        path = Path(__file__).resolve().parents[1] / "data" / "stream_memory_approved.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        records = data["approved"]
        self.assertGreaterEqual(len(records), 50)
        self.assertEqual(len({r["id"] for r in records}), len(records))
        for record in records:
            self.assertTrue(record["sources"])
            self.assertTrue(record["text"].strip())
