import unittest
from mako.sage.chat_queue import StreamChatQueue


class QueueTests(unittest.TestCase):
    def test_flood_is_bounded_and_does_not_discard_other_people_for_one_spammer(self):
        queue = StreamChatQueue()
        queue.add('other', 'mira', 'Mira', 'A real question')
        for i in range(1000):
            queue.add(str(i), 'spam', 'Spam', f'noise {i}')
        self.assertLessEqual(len(queue.items), 128)
        sample = queue.take()
        self.assertTrue(any(item['actor'] == 'mira' for item in sample))
        self.assertLessEqual(sum(item['actor'] == 'spam' for item in sample), 8)

    def test_many_people_receive_a_bounded_round_robin_sample(self):
        queue = StreamChatQueue()
        for i in range(200):
            queue.add(str(i), f'user{i%30}', f'User{i%30}', f'message {i}')
        self.assertEqual(len(queue.items), 128)
        sample = queue.take()
        self.assertEqual(len(sample), 24)
        self.assertEqual(len({item['actor'] for item in sample}), 24)
        self.assertEqual(len(queue.items), 0)

    def test_exact_repetition_is_coalesced_without_semantic_classification(self):
        queue = StreamChatQueue()
        queue.add('1', 'a', 'A', 'LOL')
        queue.add('2', 'a', 'A', ' lol ')
        self.assertEqual(len(queue.items), 1)
