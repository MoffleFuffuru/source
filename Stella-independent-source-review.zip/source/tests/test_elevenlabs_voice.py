import unittest

from mako.elevenlabs_voice import expressive_text, mood_tag


class ElevenLabsExpressivenessTests(unittest.TestCase):
    def test_per_user_mood_tags_are_optional_and_do_not_change_neutral_text(self):
        self.assertEqual(mood_tag("neutral"), "")
        self.assertEqual(expressive_text("Hello."), "Hello.")
        self.assertEqual(expressive_text("I hear you.", mood="annoyed"), "[annoyed] I hear you.")
        self.assertEqual(expressive_text("That is wonderful.", mood="joy"), "[excited] That is wonderful.")

    def test_response_expression_labels_map_to_supported_voice_tags(self):
        self.assertEqual(expressive_text("That's great!", mood="excited"), "[excited] That's great!")
        self.assertEqual(expressive_text("I hear you.", mood="concerned"), "I hear you.")


if __name__ == "__main__":
    unittest.main()
