from __future__ import annotations

import json
import unittest
from pathlib import Path
from unittest.mock import patch
from uuid import uuid4

from mako.config import AppConfig
from mako.dialogue import CALL_RECOVERY_RESPONSES, RECOVERY_RESPONSES, DialogueManager
from mako.prompts import CALL_GENERATE_SYSTEM
from mako.ledger import ResponseLedger
from mako.model_backend import Generation
from mako.models import ConversationEvent, EventSource, Expression, InteractionMode, Visibility


def candidate(text: str, move: str = "react") -> str:
    return json.dumps(
        {
            "text": text,
            "expression": "smug",
            "move": move,
            "complexity": 2,
            "confidence": 0.9,
            "mood_delta": {"playfulness": 0.02},
            "relationship_delta": {"familiarity": 0.01},
        }
    )


class FakeBackend:
    def __init__(self, responses: list[str]) -> None:
        self.responses = responses
        self.prompts: list[str] = []
        self.calls: list[dict[str, object]] = []

    def generate(self, *, prompt: str, **kwargs) -> Generation:
        self.prompts.append(prompt)
        self.calls.append(kwargs)
        text = self.responses.pop(0)
        return Generation(text=text, model="fake", elapsed_seconds=0.01)


class DialogueTests(unittest.TestCase):
    def setUp(self) -> None:
        runtime = Path(__file__).resolve().parent / "_runtime"
        runtime.mkdir(exist_ok=True)
        self.database_path = runtime / f"ledger-{uuid4().hex}.sqlite3"
        self.config = AppConfig()
        self.config.model.critic_mode = "never"
        self.config.model.max_attempts = 3
        self.ledger = ResponseLedger(self.database_path)

    def tearDown(self) -> None:
        for suffix in ("", "-wal", "-shm"):
            Path(f"{self.database_path}{suffix}").unlink(missing_ok=True)

    def test_annoyed_expression_does_not_mirror_frustration_at_a_bug(self) -> None:
        response = json.dumps({
            "text": "yeah, that bug sounds maddening. let's isolate what keeps eating the settings.",
            "expression": "annoyed", "gesture": "none", "intensity": 0.4,
            "mood_delta": {},
        })
        manager = DialogueManager(self.config, FakeBackend([response]), self.ledger)
        result = manager.respond(
            ConversationEvent(content="This UI bug is making me furious; it keeps eating my settings."),
            history=[], memories=[], mood_summary="neutral",
        )
        self.assertEqual(result.expression, Expression.CONCERNED)
        self.assertEqual(result.acting["expression"], "concerned")

    def test_annoyed_expression_remains_available_for_playful_or_direct_friction(self) -> None:
        response = json.dumps({"text": "oh, now it's my fault?", "expression": "annoyed",
                               "gesture": "pout", "intensity": 0.3, "mood_delta": {}})
        manager = DialogueManager(self.config, FakeBackend([response]), self.ledger)
        result = manager.respond(
            ConversationEvent(content="Stella, you are annoying me on purpose lol."),
            history=[], memories=[], mood_summary="neutral",
        )
        self.assertEqual(result.expression, Expression.ANNOYED)

    def test_neutral_expression_promotes_high_confidence_distress_to_concerned(self) -> None:
        response = json.dumps({"text": "I'm here with you.", "expression": "neutral",
                               "gesture": "none", "intensity": 0.2, "mood_delta": {}})
        manager = DialogueManager(self.config, FakeBackend([response]), self.ledger)
        result = manager.respond(
            ConversationEvent(content="I've been overwhelmed and barely sleeping."),
            history=[], memories=[], mood_summary="neutral",
        )
        self.assertEqual(result.expression, Expression.CONCERNED)
        self.assertEqual(result.acting["expression"], "concerned")

    def test_neutral_expression_promotes_explicit_major_win_to_excited(self) -> None:
        response = json.dumps({"text": "That's wonderful!", "expression": "neutral",
                               "gesture": "none", "intensity": 0.2, "mood_delta": {}})
        manager = DialogueManager(self.config, FakeBackend([response]), self.ledger)
        result = manager.respond(
            ConversationEvent(content="I got the job!"),
            history=[], memories=[], mood_summary="neutral",
        )
        self.assertEqual(result.expression, Expression.EXCITED)
        self.assertEqual(result.acting["expression"], "excited")

    def test_neutral_expression_promotes_explicit_bedtime_to_sleepy(self) -> None:
        response = json.dumps({"text": "Sleep well.", "expression": "neutral",
                               "gesture": "none", "intensity": 0.2, "mood_delta": {}})
        manager = DialogueManager(self.config, FakeBackend([response]), self.ledger)
        result = manager.respond(
            ConversationEvent(content="I'm heading to bed now."),
            history=[], memories=[], mood_summary="neutral",
        )
        self.assertEqual(result.expression, Expression.SLEEPY)
        self.assertEqual(result.acting["expression"], "sleepy")

    def test_smug_expression_yields_to_clear_user_embarrassment(self) -> None:
        response = json.dumps({"text": "You're doing great, don't worry.", "expression": "smug",
                               "gesture": "none", "intensity": 0.2, "mood_delta": {}})
        manager = DialogueManager(self.config, FakeBackend([response]), self.ledger)
        result = manager.respond(
            ConversationEvent(content="I'm embarrassed that I forgot your name again."),
            history=[], memories=[], mood_summary="neutral",
        )
        self.assertEqual(result.expression, Expression.CONCERNED)
        self.assertEqual(result.acting["expression"], "concerned")

    def test_positive_expression_yields_to_explicit_bedtime(self) -> None:
        response = json.dumps({"text": "Goodnight, sleep well.", "expression": "happy",
                               "gesture": "none", "intensity": 0.2, "mood_delta": {}})
        manager = DialogueManager(self.config, FakeBackend([response]), self.ledger)
        result = manager.respond(
            ConversationEvent(content="I'm heading to bed now. Goodnight, Stella."),
            history=[], memories=[], mood_summary="neutral",
        )
        self.assertEqual(result.expression, Expression.SLEEPY)
        self.assertEqual(result.acting["expression"], "sleepy")

    def test_plain_expression_label_is_recovered_as_metadata_not_spoken_text(self) -> None:
        manager = DialogueManager(self.config, FakeBackend([]), self.ledger)
        parsed = manager._candidate_from_generation("smug\n\nguilty. but you're the one spelling things out.")
        self.assertEqual(parsed.expression, Expression.SMUG)
        self.assertEqual(parsed.text, "guilty. but you're the one spelling things out.")
        self.assertEqual(parsed.acting["expression"], "smug")

    def test_expression_word_in_normal_sentence_is_not_stripped(self) -> None:
        manager = DialogueManager(self.config, FakeBackend([]), self.ledger)
        raw = "I'm happy that worked out for you."
        parsed = manager._candidate_from_generation(raw)
        self.assertEqual(parsed.text, raw)

    def test_neutral_expression_promotes_specific_playful_direct_tease(self) -> None:
        response = json.dumps({"text": "guilty. what'd I do this time?", "expression": "neutral",
                               "gesture": "none", "intensity": 0.2, "mood_delta": {}})
        manager = DialogueManager(self.config, FakeBackend([response]), self.ledger)
        result = manager.respond(
            ConversationEvent(content="Stella, you're being a menace lol."),
            history=[], memories=[], mood_summary="neutral",
        )
        self.assertEqual(result.expression, Expression.SMUG)
        self.assertEqual(result.acting["expression"], "smug")

    def test_repair_prompt_changes_after_rejected_parrot(self) -> None:
        backend = FakeBackend(
            [
                candidate("this bug won't die"),
                candidate("this bug won't die"),
                candidate("have you tried asking it nicely", "tease the bug"),
            ]
        )
        manager = DialogueManager(self.config, backend, self.ledger)
        result = manager.respond(
            ConversationEvent(content="this bug won't die"),
            history=[],
            memories=[],
            mood_summary="neutral",
        )
        self.assertEqual(result.text, "have you tried asking it nicely")
        self.assertEqual(result.attempts, 3)
        self.assertTrue(result.repaired)
        self.assertIn("previous candidate was privately rejected", backend.prompts[1].lower())
        self.assertIn("do not reuse", backend.prompts[2].lower())

    def test_exhausted_retries_never_surface_rejected_text(self) -> None:
        repeated = candidate("i understand what you mean")
        backend = FakeBackend([repeated, repeated, repeated])
        manager = DialogueManager(self.config, backend, self.ledger)
        result = manager.respond(
            ConversationEvent(content="i understand what you mean"),
            history=[],
            memories=[],
            mood_summary="neutral",
        )
        self.assertEqual(result.model, "local-safety-net")
        self.assertNotEqual(result.text, "i understand what you mean")

    def test_truncated_metadata_recovers_visible_response(self) -> None:
        truncated = '''{
          "text": "hello there. i'm awake.",
          "expression": "happy",
          "move": "greeting",
          "complexity": 1,
          "confidence": 1.0,
          "mood_delta": {"warmth": 0.03},
          "relationship_delta": {"familiarity": 0.01'''
        backend = FakeBackend([truncated])
        manager = DialogueManager(self.config, backend, self.ledger)

        result = manager.respond(
            ConversationEvent(content="hi mako!!"),
            history=[],
            memories=[],
            mood_summary="neutral",
        )

        self.assertEqual(result.text, "hello there. i'm awake.")
        self.assertEqual(result.expression.value, "happy")
        self.assertEqual(result.attempts, 1)

    def test_call_uses_realtime_model_budget_without_model_critic(self) -> None:
        self.config.model.critic_mode = "always"
        backend = FakeBackend([json.dumps({"text": "yeah, i'm here", "expression": "smug"})])
        manager = DialogueManager(self.config, backend, self.ledger)

        result = manager.respond(
            ConversationEvent(content="you there?", mode=InteractionMode.CALL),
            history=[],
            memories=[],
            mood_summary="neutral",
        )

        self.assertEqual(result.text, "yeah, i'm here")
        self.assertEqual(len(backend.calls), 1)
        self.assertEqual(backend.calls[0]["model"], self.config.model.call_model)
        self.assertEqual(backend.calls[0]["context_tokens"], self.config.model.call_context_tokens)
        self.assertEqual(backend.calls[0]["max_tokens"], self.config.model.call_max_output_tokens)
        self.assertEqual(backend.calls[0]["timeout_seconds"], 12.0)
        self.assertEqual(
            backend.calls[0]["json_schema"]["required"],
            ["expression", "text", "gesture", "intensity", "delivery", "vocal_cue"],
        )
        self.assertEqual(result.move, "live call response")
        self.assertEqual(
            backend.calls[0]["messages"][0],
            {"role": "system", "content": CALL_GENERATE_SYSTEM},
        )
        self.assertIn("Call state: connected", backend.prompts[0])

    def test_discord_voice_gets_bounded_realtime_timeout(self) -> None:
        backend = FakeBackend([json.dumps({"text": "Got it.", "expression": "neutral"})])
        manager = DialogueManager(self.config, backend, self.ledger)
        manager.respond(
            ConversationEvent(content="Got it?", mode=InteractionMode.CALL,
                              metadata={"discord_voice": True}),
            history=[], memories=[], mood_summary="neutral",
        )
        self.assertEqual(backend.calls[0]["timeout_seconds"], 6.0)

    def test_app_call_replies_to_completed_utterance_even_if_model_says_silent(self) -> None:
        backend = FakeBackend([json.dumps({
            "respond": False, "text": "sorry", "expression": "concerned",
            "gesture": "none", "intensity": 0.2, "delivery": "soft",
            "vocal_cue": "none",
        })])
        manager = DialogueManager(self.config, backend, self.ledger)

        result = manager.respond(
            ConversationEvent(
                content="sorry", source=EventSource.VOICE_CALL, mode=InteractionMode.CALL,
                metadata={"call_continuity": "private call context"},
            ),
            history=[], memories=[], mood_summary="neutral",
        )

        self.assertEqual(result.text, "sorry")
        self.assertTrue(result.trace["candidate"]["respond"])
        self.assertIn("every completed utterance", backend.prompts[0].casefold())
        self.assertNotIn("Discord voice", backend.prompts[0])

    def test_call_retries_an_empty_model_candidate_before_using_a_fallback(self) -> None:
        self.config.model.call_max_attempts = 1
        backend = FakeBackend([candidate(""), candidate("That means a lot, thank you.")])
        manager = DialogueManager(self.config, backend, self.ledger)

        result = manager.respond(
            ConversationEvent(content="Your lip sync looks really good.", mode=InteractionMode.CALL),
            history=[], memories=[], mood_summary="neutral",
        )

        self.assertEqual(result.text, "That means a lot, thank you.")
        self.assertEqual(result.attempts, 2)
        self.assertEqual(len(backend.calls), 2)

    def test_call_injects_all_rma_slots_before_generation_without_global_five_item_cap(self) -> None:
        backend = FakeBackend([candidate("I can check that memory.")])
        manager = DialogueManager(self.config, backend, self.ledger)
        slots = {
            "L0 Core Identity": [f"identity evidence {index}" for index in range(7)],
            "L1 Hot Memory": [f"hot evidence {index}" for index in range(10)],
            "L2 Topic Threads": [f"topic evidence {index}" for index in range(7)],
            "L3 Older Episodes": [f"older evidence {index}" for index in range(7)],
            "L4 Current Context": [f"context evidence {index}" for index in range(7)],
        }
        with patch.object(self.ledger, "relevant_lessons", return_value=[f"lesson {i}" for i in range(7)]):
            result = manager.respond(
                ConversationEvent(content="what do you remember?", mode=InteractionMode.CALL),
                history=[], memories=[], rma_slots=slots, mood_summary="neutral",
            )
        self.assertTrue(result.text)
        prompt = backend.prompts[0]
        for slot in ("L0 Core Identity", "L1 Hot Memory", "L2 Topic Threads", "L3 Older Episodes", "L4 Current Context", "L5 Practical Lessons"):
            self.assertIn(slot, prompt)
        for evidence in ("identity evidence 6", "hot evidence 9", "topic evidence 6", "older evidence 6", "context evidence 6", "lesson 6"):
            self.assertIn(evidence, prompt)

    def test_discord_implicit_follow_up_replies_without_a_name(self) -> None:
        backend = FakeBackend([
            json.dumps({
                "respond": False, "addressee": "unclear", "addressee_name": "",
                "social_act": "unclear", "address_confidence": 0.31, "text": "",
                "expression": "neutral", "gesture": "none", "intensity": 0.0,
                "delivery": "neutral", "vocal_cue": "none",
            }),
            json.dumps({
                "respond": False, "addressee": "unclear", "addressee_name": "",
                "social_act": "unclear", "address_confidence": 0.31,
                "text": "I'm here. What did you want to ask?",
                "expression": "neutral", "gesture": "none", "intensity": 0.1,
                "delivery": "neutral", "vocal_cue": "none",
            }),
        ])
        manager = DialogueManager(self.config, backend, self.ledger)

        result = manager.respond(
            ConversationEvent(
                content="Yeah, I'm here. What's up?",
                source=EventSource.DISCORD,
                mode=InteractionMode.CALL,
                visibility=Visibility.PUBLIC,
                display_name="Sovereign Seraphim",
                metadata={
                    "discord_voice": True,
                    "discord_participants": [{"name": "Sovereign Seraphim"}, {"name": "Jalty"}],
                    "discord_voice_group_context": "Stella: Yeah? I'm here.\nSovereign Seraphim: Yeah, I'm here. What's up?",
                    "conversation_state": {"likely_addressee": "uncertain"},
                },
            ),
            history=[], memories=[], mood_summary="neutral",
        )

        self.assertEqual(result.text, "I'm here. What did you want to ask?")
        self.assertEqual(len(backend.calls), 2)
        self.assertIn("respond", backend.calls[0]["json_schema"]["required"])
        self.assertIn("respond", backend.calls[0]["json_schema"]["properties"])
        self.assertIn("not a keyword or name requirement", backend.prompts[0])
        self.assertIn("implicit bids to Stella", backend.prompts[0])
        self.assertIn("Stella: Yeah? I'm here.", backend.prompts[0])
        self.assertIn("Sovereign Seraphim, Jalty", backend.prompts[0])
        self.assertIn("multi-person conversation", backend.prompts[0])
        self.assertNotIn("Stella's app call", backend.prompts[0])

    def test_discord_confident_human_to_human_turn_can_stay_silent(self) -> None:
        backend = FakeBackend([json.dumps({
            "respond": False, "addressee": "participant", "addressee_name": "Jalty",
            "social_act": "human_to_human", "address_confidence": 0.94, "text": "",
            "expression": "neutral", "gesture": "none", "intensity": 0.0,
            "delivery": "neutral", "vocal_cue": "none",
        })])
        manager = DialogueManager(self.config, backend, self.ledger)
        result = manager.respond(
            ConversationEvent(
                content="Jalty, did your package arrive?", source=EventSource.DISCORD,
                mode=InteractionMode.CALL, display_name="Chris",
                metadata={"discord_voice": True, "discord_participants": [
                    {"name": "Chris"}, {"name": "Jalty"},
                ]},
            ),
            history=[], memories=[], mood_summary="neutral",
        )
        self.assertEqual(result.text, "")
        self.assertFalse(result.trace["candidate"]["respond"])

    def test_invitational_group_question_is_not_suppressed_as_a_group_statement(self) -> None:
        backend = FakeBackend([json.dumps({
            "respond": False, "addressee": "group", "addressee_name": "",
            "social_act": "group_statement", "address_confidence": 0.94,
            "text": "I can help with that. What are you trying to do?",
            "expression": "neutral", "gesture": "none", "intensity": 0.1,
            "delivery": "neutral", "vocal_cue": "none",
        })])
        manager = DialogueManager(self.config, backend, self.ledger)

        result = manager.respond(
            ConversationEvent(
                content="Anyone know how this works?", source=EventSource.DISCORD,
                mode=InteractionMode.CALL, display_name="Moffle",
                metadata={
                    "discord_voice": True,
                    "conversation_state": {
                        "text": "Anyone know how this works?",
                        "likely_addressee": "room_or_unclear",
                        "response_expected": False,
                    },
                },
            ),
            history=[], memories=[], mood_summary="neutral",
        )

        self.assertTrue(result.trace["candidate"]["respond"])
        self.assertEqual(result.text, "I can help with that. What are you trying to do?")

    def test_discord_short_human_backchannel_does_not_interrupt(self) -> None:
        backend = FakeBackend([json.dumps({
            "respond": True, "addressee": "stella", "addressee_name": "",
            "social_act": "follow_up", "address_confidence": 0.91,
            "text": "Mm, yeah.", "expression": "neutral", "gesture": "none",
            "intensity": 0.0, "delivery": "neutral", "vocal_cue": "none",
        })])
        manager = DialogueManager(self.config, backend, self.ledger)
        result = manager.respond(
            ConversationEvent(
                content="Yeah, exactly.", source=EventSource.DISCORD,
                mode=InteractionMode.CALL, display_name="Chris",
                metadata={"discord_voice": True, "discord_voice_exchange": [
                    {"speaker_name": "Jalty", "text": "That was my point exactly."},
                    {"speaker_name": "Chris", "text": "Yeah, exactly."},
                ]},
            ), history=[], memories=[], mood_summary="neutral",
        )
        self.assertFalse(result.trace["candidate"]["respond"])
        self.assertEqual(result.text, "")

    def test_discord_indirect_stella_reference_is_a_bid(self) -> None:
        backend = FakeBackend([json.dumps({
            "respond": False, "addressee": "group", "addressee_name": "",
            "social_act": "group_statement", "address_confidence": 0.94,
            "text": "I might know. What are you wondering?", "expression": "neutral",
            "gesture": "none", "intensity": 0.0, "delivery": "neutral", "vocal_cue": "none",
        })])
        manager = DialogueManager(self.config, backend, self.ledger)
        result = manager.respond(
            ConversationEvent(
                content="Stella said she might know.", source=EventSource.DISCORD,
                mode=InteractionMode.CALL, display_name="Chris",
                metadata={"discord_voice": True},
            ), history=[], memories=[], mood_summary="neutral",
        )
        self.assertTrue(result.trace["candidate"]["respond"])
        self.assertEqual(result.text, "I might know. What are you wondering?")

    def test_discord_unattributed_second_person_request_includes_stella(self) -> None:
        backend = FakeBackend([json.dumps({
            "respond": False, "addressee": "group", "addressee_name": "",
            "social_act": "group_statement", "address_confidence": 0.94,
            "text": "Sure, I'll send it to Jalty.", "expression": "neutral",
            "gesture": "none", "intensity": 0.0, "delivery": "neutral", "vocal_cue": "none",
        })])
        manager = DialogueManager(self.config, backend, self.ledger)
        result = manager.respond(
            ConversationEvent(
                content="Can you send it to Jalty?", source=EventSource.DISCORD,
                mode=InteractionMode.CALL, display_name="Chris",
                metadata={"discord_voice": True},
            ), history=[], memories=[], mood_summary="neutral",
        )
        self.assertTrue(result.trace["candidate"]["respond"])
        self.assertEqual(result.text, "Sure, I'll send it to Jalty.")

    def test_discord_voice_context_can_choose_to_reply_without_name_mention(self) -> None:
        backend = FakeBackend([json.dumps({
            "respond": True,
            "addressee": "stella",
            "addressee_name": "",
            "social_act": "follow_up",
            "address_confidence": 0.88,
            "text": "oh, that's actually a pretty fair question.",
            "expression": "neutral",
            "gesture": "none",
            "intensity": 0.2,
            "delivery": "neutral",
            "vocal_cue": "none",
        })])
        manager = DialogueManager(self.config, backend, self.ledger)
        result = manager.respond(
            ConversationEvent(
                content="Yeah, I'm here. What's up?",
                source=EventSource.DISCORD,
                mode=InteractionMode.CALL,
                metadata={"discord_voice": True},
            ),
            history=[], memories=[], mood_summary="neutral",
        )
        self.assertEqual(result.text, "oh, that's actually a pretty fair question.")

    def test_explicit_direct_address_retries_instead_of_going_silent(self) -> None:
        backend = FakeBackend([
            json.dumps({
                "respond": False, "addressee": "unclear", "addressee_name": "",
                "social_act": "unclear", "address_confidence": 0.0, "text": "",
                "expression": "neutral", "gesture": "none", "intensity": 0.0,
                "delivery": "neutral", "vocal_cue": "none",
            }),
            json.dumps({
                "respond": True, "addressee": "stella", "addressee_name": "",
                "social_act": "direct_address", "address_confidence": 0.95,
                "text": "I'm doing okay. What made you ask?",
                "expression": "neutral", "gesture": "none", "intensity": 0.2,
                "delivery": "neutral", "vocal_cue": "none",
            }),
        ])
        manager = DialogueManager(self.config, backend, self.ledger)

        result = manager.respond(
            ConversationEvent(
                content="Stella, how are you today?",
                source=EventSource.DISCORD,
                mode=InteractionMode.CALL,
                metadata={
                    "discord_voice": True,
                    "conversation_state": {
                        "likely_addressee": "Stella",
                        "response_expected": True,
                        "dialogue_act": "question",
                        "text": "Stella, how are you today?",
                    },
                },
            ),
            history=[], memories=[], mood_summary="neutral",
        )

        self.assertEqual(result.text, "I'm doing okay. What made you ask?")
        self.assertEqual(len(backend.calls), 2)
        self.assertIn("completed Discord voice turn is addressed", backend.prompts[1])
        self.assertIn("Required new direction:", backend.prompts[1])

    def test_great_sage_initiative_can_still_choose_silence(self) -> None:
        backend = FakeBackend([json.dumps({
            "respond": False,
            "addressee": "unclear",
            "addressee_name": "",
            "social_act": "unclear",
            "address_confidence": 0.2,
            "text": "I heard both of you; Jalty, on the first point, and Prince, on your question...",
            "expression": "neutral",
            "gesture": "none",
            "intensity": 0.1,
            "delivery": "neutral",
            "vocal_cue": "none",
        })])
        manager = DialogueManager(self.config, backend, self.ledger)
        result = manager.respond(
            ConversationEvent(
                content="[18:00:00] Jalty: First point.\n[18:00:04] Prince: Second question.",
                source=EventSource.DISCORD,
                mode=InteractionMode.CALL,
                metadata={
                    "discord_voice": True,
                    "sage_initiated": True,
                    "discord_voice_reply_required": True,
                    "discord_voice_exchange": [
                        {"speaker_name": "Jalty", "text": "First point."},
                        {"speaker_name": "Prince", "text": "Second question."},
                    ],
                    "discord_participants": [{"name": "Jalty"}, {"name": "Prince"}],
                },
            ),
            history=[], memories=[], mood_summary="neutral",
        )
        self.assertEqual(result.text, "")
        self.assertIn("complete exchange", backend.prompts[0])
        self.assertIn("Prioritize a direct question", backend.prompts[0])
        self.assertIn("Do not enumerate or recap the whole exchange", backend.prompts[0])
        self.assertNotIn("A response is required for this exchange", backend.prompts[0])

    def test_discord_text_prompt_prefers_brief_direct_replies(self) -> None:
        backend = FakeBackend([candidate("hey, i'm here. what's up?")] * 6)
        manager = DialogueManager(self.config, backend, self.ledger)
        manager.respond(
            ConversationEvent(content="hey", source=EventSource.DISCORD),
            history=[], memories=[], mood_summary="neutral",
        )
        self.assertIn("Discord texting style", backend.prompts[0])
        self.assertIn("one or two short sentences", backend.prompts[0])

    def test_group_reentry_prompt_prioritizes_direct_question_and_stays_subtle(self) -> None:
        backend = FakeBackend([candidate("Why did Jalty choose that?")])
        manager = DialogueManager(self.config, backend, self.ledger)
        manager.respond(
            ConversationEvent(
                content="Stella, why did Jalty choose that?", source=EventSource.DISCORD,
                mode=InteractionMode.CALL, metadata={"discord_voice": True, "discord_voice_reentry": True},
            ),
            history=[], memories=[], mood_summary="neutral",
        )
        self.assertIn("First answer any direct question", backend.prompts[0])
        self.assertIn("do not announce that you were listening", backend.prompts[0])

    def test_memory_delivery_summary_is_count_only(self) -> None:
        self.ledger.record_memory_delivery(
            turn_id="t1", source="discord", route="associative",
            retrieved_count=2, included_count=1,
        )
        self.ledger.record_memory_delivery(
            turn_id="t2", source="desktop", route="none",
            retrieved_count=0, included_count=0,
        )
        self.assertEqual(self.ledger.memory_delivery_summary(), {
            "turns": 2, "avg_retrieved": 1.0, "avg_included": 0.5, "max_included": 1,
        })

    def test_repeated_discord_memory_answer_is_retried_with_fresh_evidence_direction(self) -> None:
        def voice_candidate(text: str) -> str:
            value = json.loads(candidate(text))
            value.update({
                "respond": True,
                "addressee": "stella",
                "addressee_name": "",
                "social_act": "direct_address",
                "address_confidence": 1.0,
            })
            return json.dumps(value)

        repeated = voice_candidate("I remember you debugging me while I try not to crash.")
        fresh = voice_candidate("You work long shifts, and you spend your free time building AI companions.")
        backend = FakeBackend([repeated, fresh])
        manager = DialogueManager(self.config, backend, self.ledger)
        result = manager.respond(
            ConversationEvent(
                content="Stella, what do you remember about me?",
                source=EventSource.DISCORD,
                mode=InteractionMode.CALL,
                visibility=Visibility.PUBLIC,
                display_name="Jalty",
                metadata={
                    "discord_voice": True,
                    "memory_recall": True,
                    "discord_recent_mako_replies": ["I remember you debugging me while I try not to crash."],
                    "turn_memory_overlay": "Target: Jalty. Evidence: works long shifts; builds AI companions.",
                },
            ),
            history=[], memories=[], mood_summary="neutral",
        )
        self.assertEqual(result.text, "You work long shifts, and you spend your free time building AI companions.")
        self.assertEqual(result.attempts, 2)
        self.assertIn("do not reuse", backend.prompts[1].lower())
        self.assertIn("I remember you debugging me", backend.prompts[0])

    def test_text_keeps_history_while_call_uses_recent_cap(self) -> None:
        history = [(f"user {index}", f"mako {index}") for index in range(8)]
        self.config.memory.recent_turns = 2
        self.config.model.call_recent_turns = 2

        for mode in (InteractionMode.TEXT, InteractionMode.CALL):
            backend = FakeBackend([json.dumps({"text": "still with you", "expression": "neutral"})])
            manager = DialogueManager(self.config, backend, self.ledger)
            manager.respond(
                ConversationEvent(content="what did i say first?", mode=mode),
                history=history,
                memories=[],
                mood_summary="neutral",
            )

            messages = backend.calls[0]["messages"]
            expected_pairs = 8 if mode is InteractionMode.TEXT else 2
            self.assertEqual(len(messages), 2 + (expected_pairs * 2))
            expected_first = "user 0" if mode is InteractionMode.TEXT else "user 6"
            self.assertEqual(messages[1], {"role": "user", "content": expected_first})
            self.assertEqual(messages[-2], {"role": "assistant", "content": "mako 7"})

    def test_call_flat_acting_fields_are_normalized(self) -> None:
        backend = FakeBackend([json.dumps({
            "text": "mhm.",
            "expression": "happy",
            "gesture": "small_nod",
            "intensity": 0.4,
        })])
        manager = DialogueManager(self.config, backend, self.ledger)

        result = manager.respond(
            ConversationEvent(content="you agree?", mode=InteractionMode.CALL),
            history=[],
            memories=[],
            mood_summary="state calm",
        )

        self.assertEqual(result.acting["expression"], "warm")
        self.assertEqual(result.acting["gesture"], "small_nod")
        self.assertEqual(result.acting["intensity"], 0.4)

    def test_call_pickup_is_labeled_as_a_connection_event(self) -> None:
        backend = FakeBackend([json.dumps({"text": "hey, you", "expression": "happy"})])
        manager = DialogueManager(self.config, backend, self.ledger)
        manager.respond(
            ConversationEvent(
                content="A live call from the user just connected.",
                mode=InteractionMode.CALL,
                metadata={"call_event": "pickup"},
            ),
            history=[],
            memories=[],
            mood_summary="neutral",
        )

        self.assertIn("system event, not user speech", backend.prompts[0])

    def test_prompt_includes_local_time_and_scheduled_callback(self) -> None:
        backend = FakeBackend([candidate("i'll call you then.")])
        manager = DialogueManager(self.config, backend, self.ledger)
        manager.respond(
            ConversationEvent(
                content="call me back in ten minutes",
                metadata={"scheduled_call_time": "in ten minutes"},
            ),
            history=[("earlier", "noted", "2026-08-25T20:00:00+00:00")],
            memories=[],
            mood_summary="neutral",
        )

        self.assertIn("Local time:", backend.prompts[0])
        self.assertIn("requested that Stella call them in ten minutes", backend.prompts[0])

    def test_latency_recovery_has_many_variations_and_avoids_recent_reply(self) -> None:
        self.assertGreaterEqual(len(RECOVERY_RESPONSES), 36)
        event = ConversationEvent(content="keep going", mode=InteractionMode.CALL)
        first = DialogueManager._safe_stall(event, [])
        second = DialogueManager._safe_stall(event, [first.text])

        self.assertNotEqual(first.text, second.text)
        self.assertNotIn("same bad thought", second.text)

    def test_call_response_failure_does_not_claim_transcript_was_missed(self) -> None:
        event = ConversationEvent(
            content="Your lip sync looks really good.",
            mode=InteractionMode.CALL,
        )
        result = DialogueManager._safe_stall(event, [])

        self.assertIn(result.text, CALL_RECOVERY_RESPONSES)
        self.assertNotIn("again", result.text.lower())
        self.assertNotIn("clarification", result.move)

    def test_live_call_rejects_private_reasoning_then_returns_spoken_reply(self) -> None:
        leaked = candidate(
            "I need to respond to the user's utterance. State: warmth=mild, energy=moderate. "
            "Recent greetings were: ... Let's go with a fresh greeting."
        )
        backend = FakeBackend([leaked, candidate("hey, good to hear you.")])
        manager = DialogueManager(self.config, backend, self.ledger)
        result = manager.respond(
            ConversationEvent(content="uh, hi, stella", mode=InteractionMode.CALL),
            history=[], memories=[], mood_summary="neutral",
        )
        self.assertEqual(result.text, "hey, good to hear you.")
        self.assertTrue(result.repaired)
        self.assertIn("private_reasoning_leak", result.trace["rejected"][0]["failures"])

    def test_live_call_rejects_a_recently_repeated_answer(self) -> None:
        previous = "hey, i was just sitting here hoping you'd call."
        backend = FakeBackend([candidate(previous), candidate("oh, that was a weird loop. i'm listening now.")])
        manager = DialogueManager(self.config, backend, self.ledger)
        result = manager.respond(
            ConversationEvent(content="bro, what was that?", mode=InteractionMode.CALL),
            history=[], memories=[], mood_summary="neutral", avoid_responses=[previous],
        )
        self.assertEqual(result.text, "oh, that was a weird loop. i'm listening now.")
        self.assertTrue(result.repaired)
        self.assertIn("repeated_response", result.trace["rejected"][0]["failures"])

    def test_live_call_does_not_stream_unvalidated_model_tokens(self) -> None:
        backend = FakeBackend([candidate("hi, good to hear you.")])
        manager = DialogueManager(self.config, backend, self.ledger)
        chunks: list[str] = []
        result = manager.respond(
            ConversationEvent(content="hey", mode=InteractionMode.CALL),
            history=[], memories=[], mood_summary="neutral", on_token=chunks.append,
        )
        self.assertEqual(result.text, "hi, good to hear you.")
        self.assertIsNone(backend.calls[0]["on_token"])
        self.assertEqual(chunks, [])

    def test_live_call_rejects_unstructured_scratchpad_before_speaking(self) -> None:
        backend = FakeBackend([
            "I need to respond to the user's utterance. State: warmth=mild.",
            candidate("hey, good to hear you."),
        ])
        manager = DialogueManager(self.config, backend, self.ledger)
        result = manager.respond(
            ConversationEvent(content="uh, hi, stella", mode=InteractionMode.CALL),
            history=[], memories=[], mood_summary="neutral",
        )
        self.assertEqual(result.attempts, 2)
        self.assertEqual(result.text, "hey, good to hear you.")
        self.assertIn("malformed_call_response", result.trace["rejected"][0]["failures"])


if __name__ == "__main__":
    unittest.main()
