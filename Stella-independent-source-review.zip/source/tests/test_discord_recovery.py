from collections import defaultdict
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from mako.discord_service import DiscordService
from mako.voice_exchange import VoiceContribution, VoiceExchangeBuffer


class DiscordRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.service = object.__new__(DiscordService)
        self.service.core = SimpleNamespace(sage=None)
        self.member = SimpleNamespace(id=7, display_name="Jalty")
        service = self.service
        service._voice_lock = threading.RLock()
        service._voice_generation_active = {1}
        service._voice_generation_cancel = {1: threading.Event()}
        service._voice_generation_revision = {1: 1}
        service._voice_interruption_pending = set()
        service._voice_response_required = set()
        service._voice_floor_claim_until = {}
        service._voice_streams = {}
        service._voice_active_reply_text = {}
        service._voice_interrupted_text = defaultdict(list)
        service._voice_journals = {}
        service._voice_interrupt_partial_text = {}
        service._voice_last_speech_at = {}
        service._voice_response_timers = {}
        service._voice_quiet_until = {}
        service._voice_sage_intents = {}
        service._voice_playback_trace = {}
        service._voice_delay_notice_revision = {}
        service._voice_exchanges = defaultdict(VoiceExchangeBuffer)
        service._voice_exchanges[1].append(
            VoiceContribution("7", "Jalty", "What do you think?", "now", {})
        )
        service._client = None

    def test_vad_without_followup_transcript_retries_pending_exchange(self):
        service = self.service
        with patch("mako.discord_service.threading.Timer") as timer, patch(
            "mako.discord_service.monotonic", return_value=10.0
        ):
            service._interrupt_voice_turn(
                1, self.member, recognized_text="", pcm_to_partial_seconds=0,
                detector="silero_vad_local_speech_onset",
            )
            self.assertTrue(service._voice_generation_cancel[1].is_set())
            self.assertIn(1, service._voice_response_timers)
            self.assertTrue(service._voice_exchanges[1].snapshot()[1])
            service._voice_generation_active.clear()
            service._respond_to_voice = Mock()
            with patch("mako.discord_service.threading.current_thread", return_value=timer.return_value), patch(
                "mako.discord_service.monotonic", return_value=12.0
            ):
                service._flush_voice_response_after_quiet(1, self.member, "", "", {}, 11.5)
            service._respond_to_voice.assert_called_once_with(
                1, self.member, "", voice_profile="", social_state={}
            )

    def test_recovery_waits_for_cancelled_worker_to_release_slot(self):
        service = self.service
        current = object()
        service._voice_response_timers[1] = current
        service._voice_interruption_pending.add(1)
        service._respond_to_voice = Mock()
        with patch("mako.discord_service.threading.Timer") as timer, patch(
            "mako.discord_service.threading.current_thread", return_value=current
        ), patch("mako.discord_service.monotonic", return_value=12.0):
            service._flush_voice_response_after_quiet(1, self.member, "", "", {}, 11.5)
            self.assertIs(service._voice_response_timers[1], timer.return_value)
            service._respond_to_voice.assert_not_called()
            timer.return_value.start.assert_called_once()

    def test_short_committed_turn_reaches_model_pipeline(self):
        service = self.service
        service._voice_interrupt_candidates = {}
        service._voice_endpointed_at = {}
        service._handle_voice_turn = Mock()
        service._on_discord_scribe_turn(1, self.member, "Yeah.", "", 10.0)
        service._handle_voice_turn.assert_called_once_with(
            1, self.member, "Yeah.", "", occurred_at=10.0
        )

    def test_live_floor_claim_preserves_final_human_transcript(self):
        service = self.service
        service._voice_interrupt_candidates = { (1, "7"): time.monotonic() - 1.1 }
        service._voice_endpointed_at = {}
        cancel = service._voice_generation_cancel[1]
        service._voice_floor_claim_until[1] = (cancel, time.monotonic() + 3.0)
        service._handle_voice_turn = Mock()

        service._on_discord_scribe_turn(1, self.member, "Wait, I have a point.", "", 10.0)

        self.assertFalse(cancel.is_set())
        service._handle_voice_turn.assert_called_once_with(
            1, self.member, "Wait, I have a point.", "", occurred_at=10.0
        )

    def test_rapid_committed_transcripts_coalesce_to_latest_quiet_timer(self):
        service = self.service
        first_timer, second_timer = Mock(), Mock()
        service._voice_last_speech_at[1] = 0.0
        with patch("mako.discord_service.threading.Timer", side_effect=[first_timer, second_timer]) as timer_factory:
            service._schedule_voice_response(
                1, self.member, "first transcript", voice_profile="", social_state={},
                occurred_at=time.monotonic() + 100.0,
            )
            service._schedule_voice_response(
                1, self.member, "latest transcript", voice_profile="", social_state={},
                occurred_at=time.monotonic() + 101.0,
            )

        first_timer.cancel.assert_called_once()
        second_timer.start.assert_called_once()
        self.assertIs(service._voice_response_timers[1], second_timer)
        self.assertEqual(timer_factory.call_args_list[1].kwargs["args"][2], "latest transcript")

    def test_spoken_delay_notice_follows_pending_exchange_revisions(self):
        service = self.service
        service._voice_delay_notice_revision[1] = 4

        self.assertTrue(service._voice_delay_notice_was_spoken(1, 4))
        self.assertTrue(service._voice_delay_notice_was_spoken(1, 5))
        self.assertFalse(service._voice_delay_notice_was_spoken(1, 3))

    def test_spoken_delay_notice_clears_only_when_its_exchange_is_consumed(self):
        service = self.service
        service._voice_delay_notice_revision[1] = 4

        service._clear_voice_delay_notice(1, 3)
        self.assertEqual(service._voice_delay_notice_revision[1], 4)
        service._clear_voice_delay_notice(1, 5)
        self.assertNotIn(1, service._voice_delay_notice_revision)

    def test_committed_interrupt_uses_played_prefix_not_generated_draft(self):
        service = self.service
        service._voice_generation_revision[1] = 0
        service._voice_streams[1] = SimpleNamespace(sent="Unheard generated draft", abort=Mock())
        service._voice_playback_trace[1] = SimpleNamespace(
            snapshot=lambda: {"text": "Already played", "audio_seconds": 1.0})
        service._schedule_voice_response = Mock()
        service._respond_to_voice(1, self.member, "Wait.")
        self.assertEqual(service._voice_interrupted_text[1], ["Already played"])
        service._schedule_voice_response.assert_called_once()

    def test_committed_interrupt_releases_autonomous_slot(self):
        service = self.service
        service._voice_generation_revision[1] = 0
        service._voice_sage_intents[1] = ("discord:voice:1:1", "idea")
        service._schedule_voice_response = Mock()
        cancel = service._voice_generation_cancel[1]
        service._respond_to_voice(1, self.member, "Wait.")
        self.assertTrue(cancel.is_set())
        self.assertNotIn(1, service._voice_generation_active)
        self.assertNotIn(1, service._voice_generation_cancel)
        self.assertNotIn(1, service._voice_sage_intents)
