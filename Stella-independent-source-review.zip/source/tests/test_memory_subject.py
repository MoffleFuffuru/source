from __future__ import annotations

import unittest

from mako.memory_subject import is_personal_memory_summary_request, resolve_memory_subject


class MemorySubjectTests(unittest.TestCase):
    def setUp(self) -> None:
        self.participants = [
            {"user_id": "discord:1", "name": "Jalty"},
            {"user_id": "owner", "name": "Sovereign Seraphim"},
            {"user_id": "discord:3", "name": "Chelsea"},
        ]

    def test_first_person_subject_wins_over_a_trailing_participant_name(self) -> None:
        subject = resolve_memory_subject(
            "Stella, what do you remember about me, Chelsea?",
            current_user_id="discord:1",
            current_display_name="Jalty",
            participants=self.participants,
        )
        self.assertEqual(subject, {"user_id": "discord:1", "name": "Jalty"})

    def test_explicit_subject_name_resolves_to_that_participant(self) -> None:
        subject = resolve_memory_subject(
            "What do you remember about Sovereign Seraphim?",
            current_user_id="discord:1",
            current_display_name="Jalty",
            participants=self.participants,
        )
        self.assertEqual(subject, {"user_id": "owner", "name": "Sovereign Seraphim"})

    def test_name_outside_subject_relation_is_not_mistaken_for_target(self) -> None:
        subject = resolve_memory_subject(
            "What do you remember about me? Chelsea asked too.",
            current_user_id="discord:1",
            current_display_name="Jalty",
            participants=self.participants,
        )
        self.assertEqual(subject, {"user_id": "discord:1", "name": "Jalty"})

    def test_person_history_questions_are_distinguished_from_event_recall(self) -> None:
        self.assertTrue(is_personal_memory_summary_request("What do you remember about me?"))
        self.assertTrue(is_personal_memory_summary_request(
            "What do you know about Jalty?", self.participants
        ))
        self.assertFalse(is_personal_memory_summary_request(
            "What do you remember about the last call?", self.participants
        ))
        self.assertFalse(is_personal_memory_summary_request(
            "What happened in our last conversation?", self.participants
        ))


if __name__ == "__main__":
    unittest.main()
