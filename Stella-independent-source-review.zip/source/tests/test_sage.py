import tempfile,unittest
from pathlib import Path
from mako.sage import SageExecutive,InitiativeConfig,Event,EventKind,Intent,MemoryEvidence,Commitment,CommitmentStatus
from mako.sage.memory_adapter import MemoryAdapter
from mako.sage.persistence import SageStore
from mako.sage.temporal_coordinator import TemporalCoordinator
from mako.sage.embodiment import EmbodimentDirector
from mako.sage.models import MotionIntent

class SageTests(unittest.TestCase):
    def test_disabled_by_default(self):
        s=SageExecutive();s.queue(Intent('test',evidence_ids=['ep1']))
        self.assertIsNone(s.try_autonomous_turn(floor_available=True,now=1000))
    def test_floor_and_claim(self):
        s=SageExecutive(config=InitiativeConfig(enabled=True,minimum_quiet_seconds=5))
        s.queue(Intent('Recall earlier joke',evidence_ids=['ep1']))
        self.assertIsNone(s.try_autonomous_turn(floor_available=False,now=100))
        self.assertIsNone(s.try_autonomous_turn(floor_available=True,now=2))
        result=s.try_autonomous_turn(floor_available=True,now=100)
        self.assertIsNotNone(result)
        self.assertIn('ep1',result[1]);self.assertIsNone(s.try_autonomous_turn(floor_available=True,now=100))
    def test_private_memory_filtered(self):
        m=MemoryAdapter(lambda q,n:[MemoryEvidence('private1','secret','private'),MemoryEvidence('public1','safe','public')])
        self.assertEqual([x.id for x in m.retrieve('x')],['public1'])
    def test_commitment_requires_evidence_and_transition(self):
        t=TemporalCoordinator(); c=Commitment('collab',['a','b'],evidence_ids=['ep1']);t.add(c)
        with self.assertRaises(ValueError):t.transition(c.id,CommitmentStatus.CONFIRMED,evidence_id='ep2')
        t.transition(c.id,CommitmentStatus.INVITED,evidence_id='ep2')
        t.transition(c.id,CommitmentStatus.ACCEPTED,evidence_id='ep3')
        with self.assertRaises(ValueError):t.transition(c.id,CommitmentStatus.CONFIRMED,evidence_id='ep4')
        c.due_at=1000;t.transition(c.id,CommitmentStatus.CONFIRMED,evidence_id='ep4')
        self.assertEqual(t.due(1001),[c])
    def test_atomic_persistence(self):
        with tempfile.TemporaryDirectory() as d:
            store=SageStore(Path(d)/'state.json');store.save([Intent('hi')],[Commitment('meeting',['a'],evidence_ids=['e'])])
            a,b=store.load();self.assertEqual(a[0].summary,'hi');self.assertEqual(b[0].title,'meeting')
    def test_motion_clamping(self):
        payload=EmbodimentDirector().set_intent(MotionIntent(engagement=5,duration_ms=100000))
        self.assertEqual(payload['payload']['engagement'],1.)
        self.assertEqual(payload['payload']['duration_ms'],30000)
    def test_event_state(self):
        s=SageExecutive();s.publish(Event(EventKind.USER_JOIN,actor_id='viewer'))
        self.assertIn('viewer',s.state.active_people)
    def test_ungrounded_intent_does_not_speak(self):
        s=SageExecutive(config=InitiativeConfig(enabled=True,minimum_quiet_seconds=0))
        s.queue(Intent('Invent something'))
        self.assertIsNone(s.try_autonomous_turn(floor_available=True,now=100))

if __name__=='__main__':unittest.main()
