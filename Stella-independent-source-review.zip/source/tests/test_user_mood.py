import unittest

from mako.sage.user_mood import active_mood, advance_mood, mood_prompt


class UserMoodTests(unittest.TestCase):
    def test_only_explicit_direct_hostility_creates_irritation(self):
        state = advance_mood(None, "That damn update is awful.", 100.0)
        self.assertEqual(state["label"], "neutral")
        state = advance_mood(state, "You are stupid.", 101.0)
        self.assertEqual(state["label"], "annoyed")

    def test_apology_and_topic_change_accelerate_recovery(self):
        state = advance_mood(None, "You're stupid.", 100.0)
        before = state["irritation"]
        self.assertIn("may ease it quickly", mood_prompt(active_mood(state, 101.0)))
        state = advance_mood(state, "I'm sorry. I shouldn't have said that.", 110.0)
        self.assertLess(state["irritation"], before)

    def test_mood_soft_expiry_and_hard_ceiling(self):
        state = None
        for tick in range(7):
            state = advance_mood(state, "You're stupid.", 100.0 + tick * 100.0)
        self.assertEqual(state["label"], "angry")
        self.assertEqual(state["hard_expires_at"], 100.0 + 780.0)
        self.assertEqual(active_mood(state, 879.0)["label"], "angry")
        self.assertEqual(active_mood(state, 881.0)["label"], "neutral")
        self.assertEqual(active_mood(state, state["expires_at"] + 1)["label"], "neutral")

    def test_positive_interactions_build_warmth_but_not_a_rigid_script(self):
        state = None
        for tick in range(3):
            state = advance_mood(state, "I appreciate you, Stella.", 100.0 + tick * 20.0)
        self.assertEqual(state["label"], "joy")
        self.assertLessEqual(state["expires_at"] - state["last_update"], 300.0)
        self.assertEqual(active_mood(state, state["expires_at"] + 1)["label"], "neutral")

    def test_interpersonal_mood_survives_one_topic_shift_but_apology_eases_it(self):
        state = advance_mood(None, "You never listen to what I asked.", 100.0)
        self.assertEqual(state["label"], "annoyed")
        state = advance_mood(state, "Anyway, what is the next step?", 110.0)
        self.assertEqual(state["label"], "annoyed")
        state = advance_mood(state, "I'm sorry, I shouldn't have said that.", 120.0)
        self.assertEqual(state["label"], "neutral")

    def test_mood_expires_after_inactivity_and_does_not_resume(self):
        state = advance_mood(None, "Thank you, I appreciate you.", 100.0)
        self.assertEqual(state["label"], "happy")
        expired = advance_mood(state, "Morning.", state["expires_at"] + 1)
        self.assertEqual(expired["label"], "neutral")


if __name__ == "__main__":
    unittest.main()
