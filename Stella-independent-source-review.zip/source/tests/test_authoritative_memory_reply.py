from __future__ import annotations

import threading
import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock
from uuid import uuid4

from mako.core import MakoCore
from mako.models import (
    ConversationEvent,
    EventSource,
    Expression,
    InteractionMode,
    ResponseResult,
    Visibility,
)


class AuthoritativeMemoryReplyTests(unittest.TestCase):
    def test_owner_personal_call_tool_can_search_the_private_call_archive(self) -> None:
        core = MakoCore.__new__(MakoCore)
        core._active_memory_event = ConversationEvent(
            content="Where did that come from?", source=EventSource.VOICE_CALL,
            mode=InteractionMode.CALL, channel_id="call:owner:1",
        )
        core.memory = MagicMock()
        core.memory.inspect_memory.return_value = "full personal call page"

        result = core._handle_dynamic_tool("inspect_memory", {
            "handle": "01234567", "full_call": True, "call_offset": 12, "page_size": 12,
        })

        self.assertEqual(result, "full personal call page")
        core.memory.inspect_memory.assert_called_once_with(
            "01234567", Visibility.PRIVATE, user_id="owner", shared_channel_id=None,
            include_private_owner=True, context_radius=2, full_call=True,
            call_offset=12, page_size=12,
        )

    def test_cached_profile_cannot_replace_model_answer_or_disable_streaming(self) -> None:
        profile = "I remember your long-running AI companion project and the people you build it with."
        qwen_result = ResponseResult(
            turn_id="qwen-turn",
            event_id="event",
            text="I cannot decide whether to answer.",
            expression=Expression.NEUTRAL,
            move="draft",
            complexity=1,
            mood_delta={},
            relationship_delta={},
            score=0.0,
            repaired=False,
            attempts=1,
            model="qwen-test",
            generation_seconds=0.1,
        )
        dialogue_calls = {}

        class Dialogue:
            def respond(self, event, **kwargs):
                dialogue_calls["event"] = event
                dialogue_calls["kwargs"] = kwargs
                return qwen_result

        core = MakoCore.__new__(MakoCore)
        core._closed = False
        core.config = SimpleNamespace(model=SimpleNamespace(), memory=SimpleNamespace(enabled=True))
        core.memory = SimpleNamespace(
            full_session_history_with_times=lambda **_kwargs: [],
            retrieve_for_recall=lambda *_args, **_kwargs: [],
            retrieve_rma_slots=lambda *_args, **_kwargs: {"L0 Core Identity": ["owner fact"]},
        )
        core._prepare_open_memory_overlay = lambda _event: None
        core._expand_owner_recall = lambda _event, memories: memories
        core.semantic = SimpleNamespace(
            analyze=lambda **_kwargs: SimpleNamespace(act="question", confidence=1.0),
            guidance_ready=lambda _semantic: False,
        )
        core.body = SimpleNamespace(
            observe_event=lambda *_args, **_kwargs: None,
            processing=lambda: None,
        )
        core.mood = SimpleNamespace(prompt_summary=lambda **_kwargs: "")
        core.dialogue = Dialogue()
        core._model_lock = threading.Lock()
        core._state_lock = threading.RLock()
        core._deferred_call_responses = {}
        core._ensure_open = lambda: None
        core.schedule_call_request = lambda _text: None
        event = ConversationEvent(
            content="What do you remember about me?",
            source=EventSource.DISCORD,
            mode=InteractionMode.CALL,
            visibility=Visibility.PUBLIC,
            user_id="discord:42",
            display_name="Jalty",
            metadata={
                "discord_voice": True,
                "memory_recall": True,
                "discord_memory_target": {"user_id": "discord:42", "name": "Jalty"},
                "authoritative_discord_memory_reply": profile,
                "discord_profile_updated_at": "2026-10-06T00:00:00+00:00",
                "discord_profile_source_turns": 12,
                "turn_memory_overlay": "Cached profile: " + profile,
            },
        )

        on_token = lambda _token: None
        result = core.respond(event, on_token=on_token, defer_commit=True)

        self.assertEqual(result.text, "I cannot decide whether to answer.")
        self.assertEqual(result.move, "draft")
        self.assertEqual(result.mood_delta, {})
        self.assertEqual(result.relationship_delta, {})
        self.assertNotIn("authoritative_memory_profile", result.trace)
        self.assertNotIn("memory_board", dialogue_calls["kwargs"])
        self.assertEqual(dialogue_calls["kwargs"]["rma_slots"], {"L0 Core Identity": ["owner fact"]})
        self.assertIs(dialogue_calls["kwargs"]["on_token"], on_token)
        self.assertIn(profile, dialogue_calls["event"].metadata["turn_memory_overlay"])
        self.assertIn(event.id, core._deferred_call_responses)


if __name__ == "__main__":
    unittest.main()
