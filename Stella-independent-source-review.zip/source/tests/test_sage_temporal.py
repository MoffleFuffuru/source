import unittest
from datetime import datetime
from zoneinfo import ZoneInfo

from mako.sage.models import Commitment, CommitmentStatus
from mako.sage.temporal_coordinator import TemporalCoordinator


class TemporalTests(unittest.TestCase):
    def item(self, **kwargs):
        return Commitment('Game night', ['viewer'], evidence_ids=['actual-turn'],
                          status=CommitmentStatus.CONFIRMED, **kwargs)

    def test_due_reminder_is_delivered_once(self):
        ledger = TemporalCoordinator()
        item = self.item(due_at=100)
        ledger.add(item)
        self.assertEqual(ledger.due(110), [item])
        ledger.mark_reminded(item.id, 110)
        self.assertEqual(ledger.due(120), [])

    def test_weekly_recurrence_retains_local_hour_across_dst(self):
        ledger = TemporalCoordinator()
        zone = ZoneInfo('America/New_York')
        initial = datetime(2026, 10, 30, 18, tzinfo=zone).timestamp()
        item = self.item(due_at=initial, timezone='America/New_York', recurrence='weekly')
        ledger.add(item)
        ledger.mark_reminded(item.id, initial + 60)
        next_local = datetime.fromtimestamp(item.due_at, zone)
        self.assertEqual((next_local.month, next_local.day, next_local.hour), (11, 6, 18))

    def test_expired_plan_cannot_trigger_reminder(self):
        ledger = TemporalCoordinator()
        item = self.item(due_at=100, expires_at=105)
        ledger.add(item)
        self.assertEqual(ledger.due(110), [])
        self.assertEqual(item.status, CommitmentStatus.EXPIRED)

    def test_conflicts_require_shared_participant(self):
        ledger = TemporalCoordinator()
        first, second = self.item(due_at=100), self.item(due_at=200)
        ledger.add(first)
        ledger.add(second)
        self.assertEqual(ledger.conflicts(first.id), [second.id])
        second.participants = ['different-viewer']
        self.assertEqual(ledger.conflicts(first.id), [])

    def test_nonexistent_dst_time_is_not_silently_shifted(self):
        with self.assertRaisesRegex(ValueError, 'nonexistent'):
            TemporalCoordinator.to_epoch('2026-03-08T02:30:00', 'America/New_York')

    def test_ambiguous_dst_time_requires_clarification(self):
        with self.assertRaisesRegex(ValueError, 'ambiguous'):
            TemporalCoordinator.to_epoch('2026-11-01T01:30:00', 'America/New_York')

    def test_invalid_recurrence_rejected(self):
        with self.assertRaises(ValueError):
            TemporalCoordinator().add(self.item(due_at=100, recurrence='whenever'))
