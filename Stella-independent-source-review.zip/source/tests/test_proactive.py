from __future__ import annotations

import unittest
from pathlib import Path
from uuid import uuid4

from mako.config import ProactiveCallConfig
from mako.proactive import ProactiveCallPolicy


class ProactiveCallPolicyTests(unittest.TestCase):
    def setUp(self) -> None:
        runtime = Path(__file__).resolve().parent / "_runtime"
        runtime.mkdir(exist_ok=True)
        self.state_path = runtime / f"proactive-{uuid4().hex}.json"
        self.config = ProactiveCallConfig(
            minimum_idle_seconds=100.0,
            decision_cooldown_seconds=50.0,
            offer_cooldown_seconds=500.0,
            quiet_hours_start=23,
            quiet_hours_end=9,
        )
        self.policy = ProactiveCallPolicy(self.config, self.state_path)

    def tearDown(self) -> None:
        self.state_path.unlink(missing_ok=True)

    def test_requires_idle_time_and_respects_quiet_hours(self) -> None:
        self.assertFalse(self.policy.can_consider(99.0, now=1000.0, local_hour=12))
        self.assertFalse(self.policy.can_consider(200.0, now=1000.0, local_hour=2))
        self.assertTrue(self.policy.can_consider(200.0, now=1000.0, local_hour=12))

    def test_decision_and_offer_cooldowns_persist(self) -> None:
        self.policy.mark_considered(now=1000.0)
        self.assertFalse(self.policy.can_consider(200.0, now=1049.0, local_hour=12))
        self.assertTrue(self.policy.can_consider(200.0, now=1051.0, local_hour=12))

        self.policy.mark_offered(now=1100.0)
        restored = ProactiveCallPolicy(self.config, self.state_path)
        self.assertFalse(restored.can_consider(200.0, now=1599.0, local_hour=12))
        self.assertTrue(restored.can_consider(200.0, now=1601.0, local_hour=12))


if __name__ == "__main__":
    unittest.main()
