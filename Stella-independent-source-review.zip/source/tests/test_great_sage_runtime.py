import json
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import threading
import time
import unittest
from unittest.mock import Mock, patch

from mako.config import AppConfig
from mako.sage.runtime import GreatSage
from mako.sage.playback import PlaybackTrace


class RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        config = AppConfig()
        config.discord.sage_enabled = True
        config.discord.sage_quiet_seconds = 0
        config.discord.sage_initiative_cooldown_seconds = 0
        config.memory_model.provider = "lithos"
        config.memory_model.model = "deepseek-ai/DeepSeek-V4.1-Flash-ultra"
        self.core = SimpleNamespace(config=config, paths=SimpleNamespace(data=Path(self.tmp.name)),
                                    memory=SimpleNamespace(retrieve=Mock(return_value=[])), usage=None)
        self.sage = GreatSage(self.core)
        self.scope = "discord:voice:1:2"

    def proposal(self):
        return json.dumps({"intent": {"summary": "Ask Jalty how the game rewards turned out",
                          "target_id": "discord:7", "evidence_ids": ["turn1"]},
                          "relationships": [{"actor_id": "discord:7", "fact": "Plays War Robots",
                                             "evidence_id": "turn1"}], "commitments": []})

    def seed(self):
        self.sage.observe(self.scope, "turn1", "discord:7", "Jalty", "I got game rewards.", at=time.time()-30)
        self.sage.backend = SimpleNamespace(generate=Mock(return_value=SimpleNamespace(text=self.proposal())))

    def test_user_mood_persists_per_person_across_discord_scopes(self):
        self.sage.observe(self.scope, "irritated-turn", "discord:7", "Jalty", "You're stupid.", at=1000.0)
        self.assertEqual(self.sage.user_mood("discord:text:1:99", "discord:7", at=1001.0)["label"], "annoyed")
        self.assertEqual(self.sage.user_mood(self.scope, "discord:8", at=1001.0)["label"], "neutral")

    def test_model_mood_delta_persists_for_the_addressee(self):
        self.sage.apply_user_mood_delta(
            self.scope, "discord:7", {"warmth": 0.12, "irritation": 0.0}, at=1000.0
        )
        mood = self.sage.user_mood("discord:text:1:99", "discord:7", at=1001.0)
        self.assertEqual(mood["label"], "happy")
        self.assertEqual(mood["intensity"], 0.24)

    def test_full_proposal_admission_and_delivery_lifecycle(self):
        self.seed()
        result = self.sage.prepare(self.scope, floor_available=True, voice=True)
        self.assertIsNotNone(result)
        intent_id, packet, revision = result
        self.assertIn("I got game rewards", packet)
        self.assertIn("discord:7", packet)
        self.assertLessEqual(len(packet), 1600)
        self.assertIsNone(self.sage.prepare(self.scope, floor_available=True))
        self.sage.started(self.scope, intent_id)
        self.sage.observe(self.scope, "reply1", "stella", "Stella", "How did those rewards turn out?", kind="assistant")
        self.sage.finish(self.scope, intent_id, True)
        self.assertEqual(self.sage.scene(self.scope).board.items[intent_id].status.value, "completed")
        self.assertIn("How did those rewards", self.sage.context(self.scope))
        kwargs = self.sage.backend.generate.call_args.kwargs
        self.assertEqual(kwargs["reasoning_effort"], "none")
        self.assertEqual(self.core.memory.retrieve.call_args.kwargs["include_private_owner"], False)

    def test_text_planning_uses_low_effort(self):
        self.seed()
        self.sage.prepare(self.scope, floor_available=True, voice=False)
        self.assertEqual(self.sage.backend.generate.call_args.kwargs["reasoning_effort"], "low")

    def test_sage_fast_expression_does_not_change_normal_models(self):
        original = self.core.config.model.primary, self.core.config.model.call_model
        self.core.config.sage.model = 'deepseek-ai/DeepSeek-V4.1-Flash-fast'
        self.core.ledger = Mock()
        with patch('mako.sage.runtime.OpenAICompatibleBackend'):
            speaker = self.sage.speaker
        self.assertEqual(speaker.config.model.primary, self.core.config.sage.model)
        self.assertEqual(speaker.config.model.call_model, self.core.config.sage.model)
        self.assertEqual((self.core.config.model.primary, self.core.config.model.call_model), original)

    def test_sage_speaker_inherits_lithos_provider_for_normal_and_call_routes(self):
        self.core.config.model.provider = "lithos"
        self.core.config.model.call_provider = "lithos"
        self.core.config.model.endpoint = "https://api.lithosai.cloud/v1"
        self.core.config.model.call_endpoint = "https://api.lithosai.cloud/v1"
        self.core.ledger = Mock()
        with patch('mako.sage.runtime.OpenAICompatibleBackend') as backend:
            self.sage.speaker
        self.assertEqual(backend.call_args.args[0].provider, "lithos")
        self.assertEqual(backend.call_args.args[0].call_provider, "lithos")
        self.assertEqual(backend.call_args.args[0].endpoint, "https://api.lithosai.cloud/v1")
    def test_sage_fast_planning_overrides_only_its_own_client(self):
        self.seed()
        self.sage.backend = None
        self.core.config.sage.model = 'deepseek-ai/DeepSeek-V4.1-Flash-fast'
        original = self.core.config.memory_model.model
        with patch('mako.sage.runtime.OpenAICompatibleBackend') as backend:
            backend.return_value.generate.return_value.text = '{"intent":null}'
            self.sage._develop(self.scope, voice=True)
        self.assertEqual(backend.call_args.args[0].primary, self.core.config.sage.model)
        self.assertEqual(self.core.config.memory_model.model, original)

    def test_evidenced_confirmed_commitment_imports_with_date_and_timezone(self):
        self.seed()
        self.sage.observe(self.scope, "turn2", "discord:7", "Jalty",
                          "I'll be there tomorrow night.", at=time.time())
        value = json.loads(self.proposal())
        value["commitments"] = [{"id": "game-night", "title": "Play tomorrow",
            "participants": ["discord:7"], "status": "confirmed", "due_at": 1800000000,
            "timezone": "America/New_York", "evidence_ids": ["turn2"]}]
        self.sage.backend.generate.return_value.text = json.dumps(value)
        self.sage._develop(self.scope, voice=True)
        item = self.sage.scene(self.scope).temporal.items["game-night"]
        self.assertEqual(item.status.value, "confirmed")
        self.assertEqual(item.timezone, "America/New_York")
        self.assertEqual(item.due_at, 1800000000)

    def test_model_cannot_confirm_commitment_from_unrelated_human_line(self):
        self.seed()
        value = json.loads(self.proposal())
        value["commitments"] = [{"id": "invented-plan", "title": "Play tomorrow",
            "participants": ["discord:7"], "status": "confirmed", "due_at": 1800000000,
            "timezone": "UTC", "evidence_ids": ["turn1"]}]
        self.sage.backend.generate.return_value.text = json.dumps(value)
        self.sage._develop(self.scope, voice=True)
        self.assertEqual(self.sage.scene(self.scope).temporal.items, {})

    def test_confirmation_phrase_gate_distinguishes_acceptance_from_proposals(self):
        from mako.sage.runtime import _explicit_commitment
        accepted = ["I'll be there tomorrow.", "Count me in for Friday.",
                    "I'm in.", "I can join tomorrow.", "We agreed to meet."]
        proposals = ["We should meet tomorrow.", "Maybe I can join.",
                     "I got game rewards.", "Are you free tomorrow?"]
        self.assertTrue(all(_explicit_commitment(text) for text in accepted))
        self.assertFalse(any(_explicit_commitment(text) for text in proposals))

    def test_confirmed_commitment_without_date_is_rejected(self):
        self.seed()
        value = json.loads(self.proposal())
        value["commitments"] = [{"title": "Undated promise", "participants": ["discord:7"],
            "status": "confirmed", "evidence_ids": ["turn1"]}]
        self.sage.backend.generate.return_value.text = json.dumps(value)
        self.sage._develop(self.scope, voice=True)
        self.assertEqual(self.sage.scene(self.scope).temporal.items, {})

    def test_commitments_cannot_use_assistant_or_observation_evidence(self):
        self.seed()
        self.sage.observe(self.scope, "assistant-claim", "stella", "Stella",
                          "We should play tomorrow.", kind="assistant")
        value = json.loads(self.proposal())
        value["commitments"] = [{"id": "unsupported-plan", "title": "Play tomorrow",
            "participants": ["discord:7", "stella"], "status": "confirmed",
            "due_at": 1800000000, "timezone": "America/New_York",
            "evidence_ids": ["assistant-claim"]}]
        self.sage.backend.generate.return_value.text = json.dumps(value)
        self.sage._develop(self.scope, voice=True)
        self.assertEqual(self.sage.scene(self.scope).temporal.items, {})

    def test_relationship_fact_cannot_be_attributed_from_another_persons_evidence(self):
        self.seed()
        self.sage.observe(self.scope, "turn2", "discord:8", "Mira", "I collect rare maps.", at=time.time())
        self.sage.backend.generate.return_value.text = json.dumps({
            "intent": None,
            "relationships": [{"actor_id": "discord:7", "fact": "Collects rare maps",
                               "evidence_id": "turn2"}],
            "commitments": [],
        })
        self.sage._develop(self.scope, voice=True)
        self.assertEqual(self.sage.scene(self.scope).relationships.context("discord:7", public_only=False), [])

    def test_no_inference_while_humans_hold_floor(self):
        self.seed()
        self.assertIsNone(self.sage.prepare(self.scope, floor_available=False))
        self.sage.backend.generate.assert_not_called()

    def test_overload_pauses_background_inference(self):
        self.seed()
        with patch("mako.sage.runtime.provider_cooling_down", return_value=True):
            self.assertIsNone(self.sage.prepare(self.scope, floor_available=True))
        self.sage.backend.generate.assert_not_called()

    def test_scopes_do_not_leak_transcripts(self):
        self.seed()
        self.sage.observe("discord:voice:9:10", "private-scope", "other", "Other", "Different server secret")
        self.assertNotIn("Different server secret", self.sage.context(self.scope))

    def test_duplicate_input_is_idempotent(self):
        self.seed()
        self.sage.observe(self.scope, "turn1", "discord:7", "Jalty", "Duplicate")
        self.assertEqual(self.sage.context(self.scope).count("turn1"), 1)

    def test_presence_events_are_available_to_the_next_turn_and_track_departures(self):
        self.sage.set_people(self.scope, {"discord:7": "Jalty"})
        joined = self.sage.context(self.scope)
        self.assertIn("Jalty", joined)
        self.assertIn("user_join", joined)
        self.sage.set_people(self.scope, {})
        departed = self.sage.context(self.scope)
        self.assertIn("user_leave", departed)
        self.assertIn("Left the voice call", departed)

    def test_new_human_turn_during_planning_invalidates_admission(self):
        self.seed()
        def generate(**kwargs):
            self.sage.observe(self.scope, "new", "owner", "Moffle", "Wait, I have a question.")
            return SimpleNamespace(text=self.proposal())
        self.sage.backend.generate = generate
        self.assertIsNone(self.sage.prepare(self.scope, floor_available=True))

    def test_restart_keeps_timeline_and_does_not_replay_claimed_turn(self):
        self.seed()
        result = self.sage.prepare(self.scope, floor_available=True)
        self.sage.close()
        restored = GreatSage(self.core)
        self.assertIn("I got game rewards", restored.context(self.scope))
        self.assertEqual(restored.scene(self.scope).board.items[result[0]].status.value, "cancelled")

    def test_unverifiable_evidence_cannot_create_intent(self):
        self.seed()
        self.sage.backend.generate.return_value.text = json.dumps({
            "intent": {"summary": "Invented callback", "evidence_ids": ["nonexistent"]}})
        self.assertIsNone(self.sage.prepare(self.scope, floor_available=True))

    def test_disabled_runtime_records_no_new_activity(self):
        self.core.config.discord.sage_enabled = False
        self.sage.observe(self.scope, "ignored", "owner", "Moffle", "Hello")
        self.assertEqual(self.sage.context(self.scope), "")


class PlaybackTests(unittest.TestCase):
    def test_without_alignment_does_not_invent_heard_words(self):
        trace = PlaybackTrace()
        trace.consumed(96000)
        value = trace.snapshot()
        self.assertEqual(value["text"], "")
        self.assertEqual(value["audio_seconds"], .5)
        self.assertFalse(value["alignment_available"])

    def test_mid_word_cutoff_is_not_logged_as_a_complete_word(self):
        trace = PlaybackTrace()
        text = "I already know"
        trace.alignment({"characters": list(text),
                         "character_start_times_seconds": [i*.1 for i in range(len(text))],
                         "character_end_times_seconds": [(i+1)*.1 for i in range(len(text))]})
        trace.consumed(int(.65*192000))
        self.assertEqual(trace.snapshot()["text"], "I")

    def test_padding_is_not_counted_as_synthesized_audio(self):
        from mako.elevenlabs_discord import PcmBuffer
        buffer = PcmBuffer()
        buffer.read()
        self.assertEqual(buffer.consumed_bytes, 0)
        buffer.put(bytes(100))
        buffer.read()
        self.assertEqual(buffer.consumed_bytes, 100)
