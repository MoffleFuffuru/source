from __future__ import annotations

import unittest

from mako.inworld_stt import summarize_voice_profile
from mako.voice import inworld_expressive_text


class InworldVoiceTests(unittest.TestCase):
    def test_profile_summary_filters_weak_and_unclear_labels(self) -> None:
        profile = {
            "emotion": [{"label": "tender", "confidence": 0.91}],
            "vocalStyle": [{"label": "whispering", "confidence": 0.84}],
            "pitch": [{"label": "high", "confidence": 0.31}],
            "age": [{"label": "unclear", "confidence": 0.98}],
        }

        summary = summarize_voice_profile(profile, threshold=0.55)

        self.assertIn("emotion=tender (91%)", summary)
        self.assertIn("vocal style=whispering (84%)", summary)
        self.assertNotIn("pitch", summary)
        self.assertNotIn("age", summary)

    def test_native_tts_tags_are_kept_outside_visible_text(self) -> None:
        spoken = inworld_expressive_text(
            "you really did that.", vocal_cue="soft_laugh", delivery="soft"
        )

        self.assertEqual(spoken, "[Speak softly] [laugh] you really did that.")


if __name__ == "__main__":
    unittest.main()
