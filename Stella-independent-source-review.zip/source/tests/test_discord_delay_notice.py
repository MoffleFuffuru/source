from concurrent.futures import Future
import threading
import unittest
from unittest.mock import Mock

from mako.discord_delay_notice import DiscordDelayNotice, WARNING, WARNING_DELAY_SECONDS, RESOLVED


class DiscordDelayNoticeTests(unittest.TestCase):
    def setUp(self):
        self.now = 100.0
        self.cancel = threading.Event()
        self.timer = Mock()
        self.playback = Future()
        self.playback.set_result(None)
        self.play = Mock(return_value=self.playback)
        self.notice = DiscordDelayNotice(
            99.0, self.cancel, self.play, clock=lambda: self.now,
            timer_factory=self.timer,
        )

    def warn(self):
        self.now = 102.0
        self.timer.call_args.args[1]()

    def test_deadline_counts_generation_time_not_floor_wait(self):
        self.assertEqual(self.timer.call_args.args[0], WARNING_DELAY_SECONDS - 1.0)
        self.notice.start()
        self.timer.return_value.start.assert_called_once()

    def test_fast_output_cancels_warning_and_preserves_streaming(self):
        self.assertTrue(self.notice.token('{"respond":true'))
        self.warn()
        self.play.assert_not_called()
        self.assertEqual(self.notice.finish("Hello."), "Hello.")

    def test_delayed_output_has_one_warning_and_committed_recovery_prefix(self):
        self.warn()
        self.play.assert_called_once_with(WARNING)
        self.now = 114.0
        self.assertFalse(self.notice.token("Yes"))
        self.assertEqual(self.notice.finish("Yes, you could do that."),
                         f"{RESOLVED} Yes, you could do that.")

    def test_no_resolution_note_after_thirty_seconds(self):
        self.warn()
        self.now = 132.001
        self.assertEqual(self.notice.finish("An answer."), "An answer.")

    def test_thirty_second_boundary_is_inclusive(self):
        self.warn()
        self.now = 132.0
        self.assertEqual(self.notice.finish("An answer."), f"{RESOLVED} An answer.")

    def test_user_interruption_prevents_warning_or_recovery_note(self):
        self.cancel.set()
        self.warn()
        self.play.assert_not_called()
        self.assertEqual(self.notice.finish("Answer."), "Answer.")

    def test_no_spoken_recovery_for_model_silence(self):
        self.warn()
        self.assertEqual(self.notice.finish(""), "")

    def test_completed_request_cannot_trigger_late_warning(self):
        self.assertEqual(self.notice.finish("Hello."), "Hello.")
        self.warn()
        self.play.assert_not_called()

    def test_cancel_after_warning_prevents_recovery_note(self):
        self.warn()
        self.cancel.set()
        self.assertEqual(self.notice.finish("Hello."), "Hello.")

    def test_warning_playback_failure_does_not_claim_resolution(self):
        failed = Future()
        failed.set_exception(RuntimeError("TTS unavailable"))
        self.play.return_value = failed
        self.warn()
        with self.assertLogs("mako.discord_delay_notice", level="ERROR"):
            self.assertEqual(self.notice.finish("Hello."), "Hello.")

    def test_notice_is_only_submitted_once(self):
        self.warn()
        self.warn()
        self.play.assert_called_once_with(WARNING)
