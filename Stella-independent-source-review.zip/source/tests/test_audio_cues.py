from __future__ import annotations

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from mako.call_audio import CallSounds
from mako.typing_audio import TypingSound


class FakeWinSound(SimpleNamespace):
    SND_FILENAME = 1
    SND_ASYNC = 2
    SND_LOOP = 4

    def __init__(self) -> None:
        super().__init__()
        self.calls: list[tuple[str | None, int]] = []

    def PlaySound(self, path: str | None, flags: int) -> None:
        self.calls.append((path, flags))


class AudioCueTests(unittest.TestCase):
    def setUp(self) -> None:
        self.assets = Path(__file__).resolve().parents[1] / "assets" / "sounds"
        self.fake = FakeWinSound()
        self.patcher = patch.dict(sys.modules, {"winsound": self.fake})
        self.patcher.start()

    def tearDown(self) -> None:
        self.patcher.stop()

    def test_typing_audio_loops_once_and_stops(self) -> None:
        sound = TypingSound(self.assets / "Type2.wav")
        sound.start()
        sound.start()
        sound.stop()
        self.assertEqual(len(self.fake.calls), 2)
        self.assertTrue(self.fake.calls[0][1] & self.fake.SND_LOOP)
        self.assertEqual(self.fake.calls[1], (None, 0))

    def test_answered_cue_replaces_ringing_loop(self) -> None:
        sounds = CallSounds(
            self.assets / "calling.wav",
            self.assets / "call answered.wav",
        )
        sounds.start_ringing()
        sounds.answered()
        self.assertTrue(self.fake.calls[0][1] & self.fake.SND_LOOP)
        self.assertTrue(self.fake.calls[1][0].endswith("call answered.wav"))
        self.assertFalse(self.fake.calls[1][1] & self.fake.SND_LOOP)


if __name__ == "__main__":
    unittest.main()
