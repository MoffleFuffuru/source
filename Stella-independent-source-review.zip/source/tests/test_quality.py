from __future__ import annotations

import unittest

from mako.quality import evaluate_candidate, fatigued_topics, user_rejected_topics


class QualityTests(unittest.TestCase):
    def test_internal_response_planning_is_blocked_as_private_reasoning(self) -> None:
        report = evaluate_candidate(
            user_text="uh, hi, stella",
            candidate=(
                "I need to respond to the user's utterance. State: warmth=mild, "
                "energy=moderate. Recent greetings were: ... Let's go with a fresh greeting."
            ),
            recent_responses=[],
        )
        self.assertIn("private_reasoning_leak", report.blocking_issues)

    def test_call_artifacts_and_private_system_talk_are_blocked(self) -> None:
        for candidate in (
            "*chuckles softly* you're trouble.",
            "i don't know my hidden response filters.",
            "that came out \ufffd weird.",
        ):
            report = evaluate_candidate(
                user_text="hello",
                candidate=candidate,
                recent_responses=[],
            )
            self.assertFalse(report.accepted)

    def test_reflective_paraphrase_is_blocked(self) -> None:
        report = evaluate_candidate(
            user_text="i feel kind of shitty today",
            candidate="so you're feeling stuck in the weeds right now?",
            recent_responses=[],
        )
        self.assertIn("reflective_paraphrase", report.blocking_issues)

    def test_exact_parrot_is_blocked(self) -> None:
        report = evaluate_candidate(
            user_text="i finally fixed the bug",
            candidate="i finally fixed the bug",
            recent_responses=[],
        )
        self.assertFalse(report.accepted)
        self.assertIn("parroting", report.blocking_issues)

    def test_recent_response_reuse_is_blocked(self) -> None:
        report = evaluate_candidate(
            user_text="what do you think",
            candidate="that is a dangerous amount of confidence",
            recent_responses=["that's a dangerous amount of confidence"],
        )
        self.assertFalse(report.accepted)
        self.assertIn("repeated_response", report.blocking_issues)

    def test_single_natural_move_passes_local_filter(self) -> None:
        report = evaluate_candidate(
            user_text="this bug won't die",
            candidate="have you tried asking it nicely",
            recent_responses=[],
        )
        self.assertTrue(report.accepted)

    def test_semantic_topic_fixation_is_blocked_across_different_wording(self) -> None:
        recent = [
            "just waiting for your next keyboard smash",
            "so you're the typo catcher now?",
            "your voice is the quiet before a keyboard click",
        ]
        exhausted = fatigued_topics(recent)
        report = evaluate_candidate(
            user_text="maybe i am",
            candidate="i'm listening for the next keypress",
            recent_responses=recent,
            exhausted_topics=exhausted,
        )

        self.assertFalse(report.accepted)
        self.assertIn("topic_fixation", report.blocking_issues)

    def test_explicit_topic_boundary_blocks_a_callback_joke(self) -> None:
        recent = ["just waiting for your next keyboard smash"]
        user_text = "we are not mentioning my keyboard anymore"
        forbidden = user_rejected_topics(user_text, recent)
        report = evaluate_candidate(
            user_text=user_text,
            candidate="got it, the keyboard is officially on vacation",
            recent_responses=recent,
            forbidden_topics=forbidden,
        )

        self.assertFalse(report.accepted)
        self.assertIn("ignored_topic_boundary", report.blocking_issues)

    def test_generic_repetition_correction_targets_previous_topic(self) -> None:
        recent = ["so your voice is the typo catcher now?"]

        self.assertEqual(
            user_rejected_topics("you've said that too many times", recent),
            {"keyboard, typing, and typo jokes", "voice and hearing observations"},
        )


if __name__ == "__main__":
    unittest.main()
