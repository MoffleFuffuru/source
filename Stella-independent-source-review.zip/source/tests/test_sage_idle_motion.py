import unittest
from unittest.mock import patch

from mako.body import BodyController, BodyState


class SageIdleMotionTests(unittest.TestCase):
    def test_quiet_cue_is_silent_bounded_and_expires(self):
        body = BodyController()
        body._next_stream_motion = 0
        self.assertTrue(body.stream_idle())
        cue = body.snapshot()
        self.assertEqual(cue.state, BodyState.IDLE)
        self.assertFalse(cue.speaking)
        self.assertNotEqual(cue.intent.gesture, "none")
        self.assertFalse(body.stream_idle())
        with patch("mako.body.time.monotonic", return_value=body._ambient_until + .1):
            body.tick()
        self.assertEqual(body.snapshot().intent.gesture, "none")

    def test_quiet_cue_cannot_override_speech_or_processing(self):
        body = BodyController()
        body._next_stream_motion = 0
        body.processing()
        self.assertFalse(body.stream_idle())
        body._state = BodyState.SPEAKING
        body._speaking = True
        self.assertFalse(body.stream_idle())

    def test_old_cue_expiry_does_not_clear_new_intent(self):
        body = BodyController()
        body._next_stream_motion = 0
        body.stream_idle()
        body.processing()
        expected = body.snapshot().intent
        with patch("mako.body.time.monotonic", return_value=body._ambient_until + .1):
            body.tick()
        self.assertEqual(body.snapshot().intent, expected)
