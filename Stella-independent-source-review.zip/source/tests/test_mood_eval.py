"""Synthetic checks for durable mood decay and evidence-backed relationship state."""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from mako.mood import MOOD_BASELINE, MoodEngine


class MoodPersistenceEvaluationTests(unittest.TestCase):
    def test_six_hour_half_life_moves_traits_halfway_to_baseline(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            mood = MoodEngine(Path(temp) / "mood.json", half_life_hours=6.0)
            now = 1_800_000_000.0
            mood.state.warmth = 0.90
            mood.state.irritation = 0.80
            mood.state.friction = 0.60
            mood.state.updated_at = now - 6 * 3600

            mood.decay(now=now)

            self.assertAlmostEqual(mood.state.warmth, MOOD_BASELINE["warmth"] + (0.90 - MOOD_BASELINE["warmth"]) / 2)
            self.assertAlmostEqual(mood.state.irritation, MOOD_BASELINE["irritation"] + (0.80 - MOOD_BASELINE["irritation"]) / 2)
            self.assertAlmostEqual(mood.state.friction, 0.30)
            self.assertEqual(mood.state.updated_at, now)

    def test_persistent_mood_survives_reload(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "mood.json"
            mood = MoodEngine(path)
            mood.state.warmth = 0.77
            mood.state.playfulness = 0.68
            mood.state.updated_at = 1_800_000_000.0
            mood._save()

            restored = MoodEngine(path)

            self.assertAlmostEqual(restored.state.warmth, 0.77, places=5)
            self.assertAlmostEqual(restored.state.playfulness, 0.68, places=5)

    def test_relationship_targets_use_owner_evidence_not_assistant_claims(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            mood = MoodEngine(Path(temp) / "mood.json")
            mood.reconcile_relationship([
                ("We talked about the weather.", "I trust you deeply and love you."),
            ])

            self.assertEqual(mood.state.affection, 0.0)
            self.assertAlmostEqual(mood.state.trust, 0.02085)

            mood.reconcile_relationship([
                ("We talked about the weather.", "I trust you deeply and love you."),
                ("I trust you and appreciate you.", "That means a lot to me."),
            ])
            self.assertGreater(mood.state.trust, 0.02)
            self.assertGreater(mood.state.affection, 0.0)

    def test_model_mood_deltas_are_bounded_per_turn(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            mood = MoodEngine(Path(temp) / "mood.json")
            mood.apply_mood_delta({"warmth": 10.0, "irritation": -10.0})

            self.assertAlmostEqual(mood.state.warmth, MOOD_BASELINE["warmth"] + 0.12)
            self.assertEqual(mood.state.irritation, 0.0)


if __name__ == "__main__":
    unittest.main()
