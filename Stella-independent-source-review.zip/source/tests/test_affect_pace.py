from __future__ import annotations

import unittest
from pathlib import Path
from unittest.mock import patch

from mako.affect import AffectState, LiveAffectAnalyzer, _normalize_emotion_label


class AffectPaceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.analyzer = LiveAffectAnalyzer(Path("unused"), enabled=False)

    def test_partial_transcript_growth_estimates_fast_pace(self) -> None:
        with patch("mako.affect.time.monotonic", side_effect=[100.0, 102.0, 104.0]):
            self.analyzer.set_partial_text("speaker", "")
            self.analyzer.set_partial_text("speaker", "one two three four five")
            self.analyzer.set_partial_text(
                "speaker", "one two three four five six seven eight nine ten eleven twelve thirteen"
            )
        self.assertGreater(self.analyzer._pace_scores["speaker"], 0.72)

    def test_partial_transcript_growth_estimates_slow_pace(self) -> None:
        with patch("mako.affect.time.monotonic", side_effect=[100.0, 103.0]):
            self.analyzer.set_partial_text("speaker", "")
            self.analyzer.set_partial_text("speaker", "one two")
        self.assertLess(self.analyzer._pace_scores["speaker"], 0.22)

    def test_audio_prosody_uses_transcript_pace_estimate(self) -> None:
        with patch("mako.affect.time.monotonic", side_effect=[100.0, 103.0]):
            self.analyzer.set_partial_text("speaker", "")
            self.analyzer.set_partial_text("speaker", "one two")
        self.analyzer._states["speaker"] = AffectState(
            prosody={"energy": 0.5, "peak": 0.5,
                     "pace": self.analyzer._pace_scores["speaker"]}
        )
        self.assertIn("prosody: slow pace", self.analyzer.snapshot("speaker").compact())

    def test_model_emotion_labels_are_normalized(self) -> None:
        for raw, expected in (
            ("生气/angry", "angry"), ("开心/happy", "happy"),
            ("中立/neutral", "neutral"), ("hap", "happy"),
            ("neu", "neutral"), ("ang", "angry"),
            ("<unk>", "uncertain"),
        ):
            with self.subTest(raw=raw):
                self.assertEqual(_normalize_emotion_label(raw), expected)

    def test_unvalidated_experimental_label_never_enters_live_prompt_summary(self) -> None:
        state = AffectState(
            emotion2vec={"label": "happy", "confidence": 0.91},
            experimental={"label": "angry", "confidence": 0.99},
        )
        summary = state.compact()
        self.assertIn("emotion2vec+ base: happy", summary)
        self.assertNotIn("experimental classifier", summary)

    def test_stale_audio_affect_is_not_reused_for_later_turns(self) -> None:
        state = AffectState(
            emotion2vec={"label": "angry", "confidence": 0.95},
            prosody={"energy": 0.95, "peak": 0.95, "pace": 0.9},
            updated_at=90.0,
        )
        with patch("mako.affect.time.time", return_value=101.0):
            self.assertEqual(state.compact(), "")
        with patch("mako.affect.time.time", return_value=99.0):
            self.assertIn("emotion2vec+ base: angry", state.compact())


if __name__ == "__main__":
    unittest.main()
