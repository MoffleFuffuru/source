from __future__ import annotations

import queue
import threading
import unittest
from pathlib import Path

import numpy as np

from mako.config import VoiceConfig
from mako.voice import CallReflexes, CompletedTurn, SpeechEndpoint, TranscriptAssembler, VoiceEngine


class VoiceBehaviorTests(unittest.TestCase):
    def test_continuous_windows_remain_provisional_until_endpoint(self) -> None:
        config = VoiceConfig(
            sample_rate=10,
            transcription_window_seconds=0.7,
            transcription_overlap_seconds=0.0,
            transcript_idle_windows=1,
        )
        voice = VoiceEngine(config, Path(__file__).resolve().parent / "_runtime")
        transcriptions = iter(("hey Mako", ""))
        received: list[str] = []
        voice._transcribe_window = lambda samples: next(transcriptions)
        voice._utterance_callback = received.append
        voice._audio_queue = queue.Queue()
        voice._running.set()
        worker = threading.Thread(target=voice._transcription_loop)
        worker.start()

        voice._audio_queue.put(np.zeros(7, dtype="float32"))
        voice._audio_queue.put(np.zeros(7, dtype="float32"))
        voice._audio_queue.put(None)
        worker.join(timeout=1.0)

        self.assertFalse(worker.is_alive())
        self.assertEqual(received, [])

    def test_overlapping_whisper_windows_merge_without_parroting(self) -> None:
        transcript = TranscriptAssembler()

        self.assertTrue(transcript.add("hey Mako, I was thinking"))
        self.assertTrue(transcript.add("I was thinking about tomorrow"))
        self.assertFalse(transcript.add("about tomorrow"))
        self.assertEqual(
            transcript.pop(),
            "hey Mako, I was thinking about tomorrow",
        )

    def test_completed_turn_delivers_one_authoritative_transcript_immediately(self) -> None:
        config = VoiceConfig(sample_rate=10)
        voice = VoiceEngine(config, Path(__file__).resolve().parent / "_runtime")
        voice._transcribe_final_utterance = lambda _samples: "i was not done talking"
        received: list[str] = []
        voice._utterance_callback = received.append

        voice._flush_final_turn(CompletedTurn(np.zeros(3, dtype="float32"), endpointed_at=0.0))
        self.assertEqual(received, ["i was not done talking"])

    def test_completed_turns_are_not_held_by_a_clause_classifier(self) -> None:
        voice = VoiceEngine(VoiceConfig(), Path(__file__).resolve().parent / "_runtime")
        received: list[str] = []
        voice._utterance_callback = received.append

        voice._deliver_completed_utterance("i'm flustered because")
        voice._deliver_completed_utterance("you're cute")

        self.assertEqual(received, ["i'm flustered because", "you're cute"])

    def test_presence_checks_are_narrow(self) -> None:
        reflexes = CallReflexes()
        self.assertTrue(reflexes.is_presence_check("you there?"))
        self.assertTrue(reflexes.is_presence_check("mako"))
        self.assertFalse(reflexes.is_presence_check("you there because i changed the plan"))

    def test_reflexes_rotate_instead_of_repeating(self) -> None:
        reflexes = CallReflexes()
        first = reflexes.presence_response("neutral")
        second = reflexes.presence_response("neutral")
        self.assertNotEqual(first, second)

    def test_isolated_noise_spike_does_not_start_recording(self) -> None:
        config = VoiceConfig(
            noise_calibration_seconds=0.2,
            speech_start_seconds=0.1,
        )
        endpoint = SpeechEndpoint(config)
        endpoint.process(0.002, 0.0)
        endpoint.process(0.002, 0.2)

        self.assertEqual(endpoint.process(0.04, 0.23), "activating")
        self.assertEqual(endpoint.process(0.002, 0.26), "idle")
        self.assertFalse(endpoint.recording)

    def test_sustained_speech_finishes_after_silence(self) -> None:
        config = VoiceConfig(
            noise_calibration_seconds=0.2,
            speech_start_seconds=0.1,
            minimum_speech_seconds=0.1,
            silence_seconds=0.3,
        )
        endpoint = SpeechEndpoint(config)
        endpoint.process(0.002, 0.0)
        endpoint.process(0.002, 0.2)
        endpoint.process(0.04, 0.3)
        self.assertEqual(endpoint.process(0.04, 0.41), "start")
        endpoint.process(0.04, 0.55)

        self.assertEqual(endpoint.process(0.002, 0.86), "finish")
        self.assertFalse(endpoint.recording)

    def test_noise_spikes_do_not_extend_an_active_utterance(self) -> None:
        config = VoiceConfig(
            noise_calibration_seconds=0.1,
            speech_start_seconds=0.05,
            speech_hold_seconds=0.09,
            minimum_speech_seconds=0.05,
            silence_seconds=0.3,
        )
        endpoint = SpeechEndpoint(config)
        endpoint.process(0.001, 0.0)
        endpoint.process(0.001, 0.1)
        endpoint.process(0.04, 0.2)
        endpoint.process(0.04, 0.26)
        endpoint.process(0.04, 0.38)
        endpoint.process(0.001, 0.5)

        self.assertEqual(endpoint.process(0.05, 0.58), "recording")
        self.assertEqual(endpoint.process(0.001, 0.69), "finish")

    def test_maximum_utterance_duration_forces_endpoint(self) -> None:
        config = VoiceConfig(
            noise_calibration_seconds=0.1,
            speech_start_seconds=0.05,
            minimum_speech_seconds=0.05,
            maximum_utterance_seconds=0.5,
        )
        endpoint = SpeechEndpoint(config)
        endpoint.process(0.001, 0.0)
        endpoint.process(0.001, 0.1)
        endpoint.process(0.04, 0.2)
        endpoint.process(0.04, 0.26)

        self.assertEqual(endpoint.process(0.04, 0.77), "finish")


if __name__ == "__main__":
    unittest.main()
