"""Small, explicit regression set for unambiguous Discord addressee cues.

This is a deterministic component check, not a measure of end-to-end model quality.
Ambiguous contextual turns intentionally remain labeled as uncertain/room-level.
"""
from __future__ import annotations

import unittest

from mako.conversation_tracker import ConversationTracker


CASES = [
    ("Stella, how are you?", "Stella"),
    ("Hey Stella!", "Stella"),
    ("What do you think about this, Stella?", "Stella"),
    ("Jalty, did your package arrive?", "Jalty"),
    ("Hey, Jalty, what do you think?", "Jalty"),
    ("Thanks, Jalty.", "Jalty"),
    ("I sent that to Jalty yesterday.", "room_or_unclear"),
    ("Stella said she might know.", "room_or_unclear"),
    ("Did you see the update?", "uncertain"),
    ("What do you think?", "uncertain"),
    ("That was funny.", "room_or_unclear"),
    ("Okay.", "room_or_unclear"),
    ("Stella doesn't know whether we are talking to her.", "room_or_unclear"),
    ("Mhm, that's right.", "room_or_unclear"),
    ("Yo, Chris, are you joining us?", "Chris"),
    ("Thanks, Stella.", "Stella"),
    ("Sorry, Stella.", "Stella"),
    ("I agree, Stella.", "Stella"),
    ("Good point, Stella.", "Stella"),
    ("Wait, Stella.", "Stella"),
    ("Hey Stella can you hear me?", "Stella"),
    ("Thank you Stella", "Stella"),
    ("Did you ask Stella?", "uncertain"),
    ("Did Stella ask you?", "uncertain"),
    ("I told Stella about it.", "room_or_unclear"),
    ("We should ask Stella later.", "room_or_unclear"),
    ("Stella said she might know.", "room_or_unclear"),
    ("Jalty, what did Stella say?", "Jalty"),
    ("Moffle, what do you think?", "Moffle"),
    ("Stella?", "Stella"),
    # ASR often omits the comma after a direct vocative. The narrow verb/frame
    # cues below must recover direct address without treating third-person
    # statements about Stella as addressed to her.
    ("Stella can you hear me", "Stella"),
    ("Stella could you explain that", "Stella"),
    ("Stella what do you think", "Stella"),
    ("Stella how do you feel about it", "Stella"),
    ("Stella tell me what happened", "Stella"),
    ("Stella please listen", "Stella"),
    ("Stella I need help with this", "Stella"),
    ("Stella I wanted to ask you something", "Stella"),
    ("Stella sorry about that", "Stella"),
    ("Stella said she might know", "room_or_unclear"),
    ("Stella told Jalty about it", "room_or_unclear"),
    ("Did Stella hear me", "uncertain"),
    ("Did Stella say that already?", "uncertain"),
]


class ConversationTrackerEvaluationTests(unittest.TestCase):
    def test_unambiguous_labeled_discord_addressee_cases(self) -> None:
        correct = 0
        mismatches: list[str] = []
        participants = ("Owner", "Chris", "Jalty", "Moffle")
        for index, (text, expected) in enumerate(CASES):
            turn = ConversationTracker().observe(
                speaker_id="owner", speaker_name="Owner", text=text,
                timestamp=f"00:00:{index:02d}", participant_names=participants,
            )
            if turn.likely_addressee == expected:
                correct += 1
            else:
                mismatches.append(
                    f"{text!r}: expected {expected}, got {turn.likely_addressee}"
                )

        accuracy = correct / len(CASES)
        self.assertGreaterEqual(accuracy, 0.90, "\n".join(mismatches))


if __name__ == "__main__":
    unittest.main()
