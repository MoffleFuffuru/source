# Stella V5 Engineering Build

This is the local Stella V5 development/test copy. It retains Stella's Python
conversation, memory, voice, Discord, and avatar systems, with an Electron
desktop shell and a local account/credits prototype. It is **not a commercial
installer or a public multi-user service** yet. See
[`docs/CONSUMER_ARCHITECTURE.md`](docs/CONSUMER_ARCHITECTURE.md) for the retained
systems, service boundaries, release plan, and explicit blockers.

## Launch

Use `Start Mako with Avatar.bat` from this folder. It opens the Electron avatar
shell; Electron starts the local Python runtime and account-service process.
Keep this folder in place while running the development copy. The launcher is
not an installer and the Python virtual environment is not relocatable.

If the interface remains on **BOOTING**, the renderer retries runtime state
hydration until the local runtime is available. Check
`data/stella_runtime.log` for backend startup errors. The Electron shell and
runtime are separate processes; closing the window requests call shutdown and
then closes the window.

## Current local-test features

- The default engineering config uses Qwen through Cerebras for the fast
  conversation path, with provider selection behind the existing model
  backend. Text, memory, and call orchestration remain in the local Python core.
- Existing local app-call and ElevenLabs voice integrations remain available
  when their environment credentials and dependencies are installed.
- The account prototype supports local signup/login, a 50-credit trial grant,
  an append-only credit ledger, account lookup and audited admin adjustments,
  and an account/usage panel in the desktop shell.
- The account prototype does not yet deduct credits from live provider calls.
  Its quote endpoint is an estimate, not a charge or bill.
- The avatar shell retains VRM rendering, motion, and interface reactions.

## Private data and credentials

- Keep `config.json`, `data/`, `.env`, logs, databases, and saved sessions private.
  They contain owner-specific configuration, conversation/memory state, or
  account data and must not be copied into a test/customer package.
- Provider API keys are read from environment variables in this development
  copy. Never put them in source control or a distributed desktop client.
- The local account service binds to loopback. Do not expose it to the public
  internet or treat its local admin token as production admin security.
- Do not use real customer/payment data in this prototype.

## Tests

Python suite:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Account-service suite:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s backend\tests -v
```

Avatar suite (run each file directly if Node's test runner cannot spawn child
processes under the current Windows policy):

```powershell
node .\avatar\tests\embodiment.test.cjs
node .\avatar\tests\motion.test.cjs
node .\avatar\tests\protocol.test.cjs
```

Do not build or distribute an installer until the release blockers in the
architecture document are closed and a clean-Windows-profile install test
passes.
