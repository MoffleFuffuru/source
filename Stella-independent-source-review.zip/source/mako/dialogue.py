from __future__ import annotations

import json
import logging
import math
import re
import threading
import time
from datetime import datetime
from dataclasses import asdict
from typing import Any, Callable
from uuid import uuid4

from .config import AppConfig
from .interface_events import interface_prompt
from .ledger import ResponseLedger
from .model_backend import ModelBackend, ModelError
from .models import (
    ConversationEvent,
    Critique,
    EventSource,
    Expression,
    InteractionMode,
    QualityReport,
    ResponseCandidate,
    ResponseResult,
)
from .prompts import CALL_GENERATE_SYSTEM, CRITIC_SYSTEM, GENERATE_SYSTEM, STREAM_GENERATE_SYSTEM
from .quality import (
    evaluate_candidate,
    fatigued_topics,
    token_jaccard,
    user_rejected_topics,
)


LOG = logging.getLogger(__name__)
# Reserve room for the JSON response while retaining ten exact turns and the
# memory board under Cerebras' 8,192-token call-context tier.
CALL_PROMPT_TARGET_CHARS = 27_000


TEXT_RESPONSE_SCHEMA = {
    "type": "object",
    "properties": {
        "text": {"type": "string"},
        "expression": {"type": "string", "enum": ["neutral", "happy", "smug", "sleepy", "annoyed", "embarrassed", "concerned", "excited"]},
        "gesture": {"type": "string", "enum": ["none", "wave", "small_head_tilt", "head_turn", "small_nod", "small_shake", "lean_in", "lean_back", "shrug", "think", "laugh", "celebrate", "stretch", "explain", "disappointed", "annoyed", "pout", "curious", "pleased", "startle"]},
        "intensity": {"type": "number", "minimum": 0.0, "maximum": 1.0},
        "mood_delta": {
            "type": "object",
            "properties": {
                "warmth": {"type": "number"},
                "energy": {"type": "number"},
                "playfulness": {"type": "number"},
                "curiosity": {"type": "number"},
                "irritation": {"type": "number"},
                "vulnerability": {"type": "number"},
            },
            "required": ["warmth", "energy", "playfulness", "curiosity", "irritation", "vulnerability"],
            "additionalProperties": False,
        },
    },
    "required": ["text", "expression", "gesture", "intensity", "mood_delta"],
    "additionalProperties": False,
}


RECOVERY_RESPONSES = (
    "wait, my brain just skipped for a second.",
    "hang on, i lost the thread.",
    "mm. one second, i'm sorting that out.",
    "okay, that thought fell apart on me.",
    "hold on, i need to untangle that.",
    "give me a second. i'm still putting it together.",
    "wait, no. that wasn't right.",
    "ugh, my brain stalled for a second.",
    "one second, i had it and lost it.",
    "hang on. i'm thinking.",
    "mm, let me sort that out.",
    "okay, pause. my words aren't cooperating.",
    "wait. i need a cleaner way to say that.",
    "give me a second, that answer felt wrong.",
    "hold on, that came out wrong.",
    "nope. i need to rethink that.",
    "one second. i'm rearranging the thought.",
    "wait, my mouth got ahead of my brain.",
    "mm. i know what i mean, just not how to say it.",
    "hang on, i'm still with you.",
    "i'm here. my brain just took a wrong turn.",
    "one sec. that first answer felt off.",
    "wait, let me not make that worse.",
    "okay, my train of thought derailed.",
    "hold up. i need another second.",
    "mm, i'm not done thinking.",
    "give me a moment. that thought is being annoying.",
    "ugh, words. one second.",
    "hang on, let me get this straight.",
    "okay, i need to think that through again.",
    "wait, i almost had it.",
    "one second. i don't trust that first thought.",
    "mm. let me make sense before i talk.",
    "hold on, i'm untangling it.",
    "i'm here. just recalculating.",
    "wait, my thoughts tripped over each other.",
    "give me a second, i'm catching up with my own brain.",
    "hang on. that thought needs another pass.",
    "mm, something about that answer bothered me.",
    "okay, my brain picked the worst possible wording.",
)

CALL_CLARIFICATIONS = (
    "wait, i missed that.",
    "mm, say that again?",
    "sorry, your voice cut out on me.",
    "hold on, i didn't catch that part.",
    "hey, repeat that for me?",
    "i heard bits of it, not enough.. again?",
    "wait, what was that?",
    "say that one more time?",
    "you kind of disappeared on me there.",
    "huh? try that again?",
    "you went fuzzy for a second.",
    "i caught the start, one more time?",
    "can you run that by me again?",
    "i missed the important part.",
    "say it again, slower maybe?",
    "my brain just heard static, once more?",
    "i didn't hear you clearly.",
    "give me that again?",
    "i think the mic ate that.",
    "sorry, one more time?",
)


CALL_RESPONSE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "text": {"type": "string"},
        "expression": {
            "type": "string",
            "enum": [
                "neutral",
                "happy",
                "smug",
                "sleepy",
                "annoyed",
                "embarrassed",
                "concerned",
                "excited",
            ],
        },
        "gesture": {"type": "string", "enum": ["none", "wave", "small_head_tilt", "head_turn", "small_nod", "small_shake", "lean_in", "lean_back", "shrug", "think", "laugh", "celebrate", "stretch", "explain", "disappointed", "annoyed", "pout", "curious", "pleased", "startle"]},
        "intensity": {"type": "number", "minimum": 0.0, "maximum": 1.0},
        "delivery": {"type": "string", "enum": ["neutral", "soft", "whisper", "excited"]},
        "vocal_cue": {"type": "string", "enum": ["none", "laugh", "sigh", "hmm"]},
    },
    "required": ["text", "expression", "gesture", "intensity", "delivery", "vocal_cue"],
    "additionalProperties": False,
}

DISCORD_VOICE_RESPONSE_SCHEMA: dict[str, Any] = {
    **CALL_RESPONSE_SCHEMA,
    "properties": {
        "respond": {"type": "boolean"},
        "addressee": {"type": "string", "enum": ["stella", "participant", "group", "unclear"]},
        "addressee_name": {"type": "string"},
        "social_act": {"type": "string", "enum": ["direct_address", "follow_up", "human_to_human", "group_statement", "backchannel", "unclear"]},
        "address_confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
        **CALL_RESPONSE_SCHEMA["properties"],
    },
    "required": [
        "respond", "addressee", "addressee_name", "social_act", "address_confidence",
        *CALL_RESPONSE_SCHEMA["required"],
    ],
}


def parse_json_object(text: str) -> dict[str, Any]:
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    try:
        value = json.loads(cleaned)
    except json.JSONDecodeError:
        start = cleaned.find("{")
        end = cleaned.rfind("}")
        if start < 0 or end <= start:
            raise
        value = json.loads(cleaned[start : end + 1])
    if not isinstance(value, dict):
        raise ValueError("model JSON must be an object")
    return value


def _local_time_label(value: str | None = None) -> str:
    if value:
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone().strftime("%Y-%m-%d %I:%M %p")
        except ValueError:
            return value
    return datetime.now().astimezone().strftime("%Y-%m-%d %I:%M %p")


def _is_lightweight_text(event: ConversationEvent) -> bool:
    """Keep casual messages responsive without starving substantive turns of context."""
    if event.mode is not InteractionMode.TEXT:
        return False
    word_count = len(re.findall(r"[a-z0-9']+", event.content.lower()))
    return word_count <= 14


class DialogueManager:
    def __init__(
        self,
        config: AppConfig,
        backend: ModelBackend,
        ledger: ResponseLedger,
    ) -> None:
        self.config = config
        self.backend = backend
        self.ledger = ledger

    def respond(
        self,
        event: ConversationEvent,
        *,
        history: list[tuple[str, str]],
        memories: list[str],
        mood_summary: str,
        semantic_guidance: str = "",
        semantic_act: str = "",
        private_feedback: str = "",
        avoid_responses: list[str] | None = None,
        cancel: threading.Event | None = None,
        on_token: Callable[[str], None] | None = None,
    ) -> ResponseResult:
        turn_id = uuid4().hex
        recent_responses = self.ledger.recent_responses() + list(avoid_responses or [])
        call_replies = event.metadata.get("discord_recent_mako_replies", [])
        if isinstance(call_replies, list):
            recent_responses.extend(str(item) for item in call_replies if str(item).strip())
        exhausted_topics = fatigued_topics(recent_responses)
        forbidden_topics = user_rejected_topics(event.content, recent_responses)
        lessons = [] if event.mode is InteractionMode.CALL else self.ledger.relevant_lessons(event.content)
        rejected: list[dict[str, Any]] = []
        best: tuple[float, ResponseCandidate, QualityReport, str, float] | None = None
        started = time.monotonic()
        real_time = event.mode is InteractionMode.CALL
        attempt_limit = (
            self.config.model.call_max_attempts
            if real_time
            else self.config.model.max_attempts
        )
        if real_time and event.metadata.get("discord_voice") and event.metadata.get("memory_recall"):
            # Pay for a second generation only if the first recall answer repeats.
            attempt_limit = max(2, attempt_limit)
        preferred_model = self.config.model.call_model if real_time else None
        output_limit = self.config.model.call_max_output_tokens if real_time else self.config.model.max_output_tokens
        context_limit = self.config.model.call_context_tokens if real_time else None
        conversation_scope = self._conversation_scope(event)
        owns_history = getattr(self.backend, "has_conversation_history", None)
        backend_has_history = bool(
            real_time and callable(owns_history) and owns_history(conversation_scope)
        )
        prompt_history = (
            history[-max(0, self.config.model.call_recent_turns):]
            if real_time and self.config.model.call_recent_turns > 0
            else ([] if real_time else history)
        )
        cache_history = prompt_history
        recent_live_history: list[tuple[str, str]] = []
        if backend_has_history:
            cache_history = []

        for attempt_number in range(1, attempt_limit + 1):
            prompt = self._generation_prompt(
                event=event,
                history=prompt_history,
                memories=memories,
                mood_summary=mood_summary,
                semantic_guidance=semantic_guidance,
                lessons=lessons,
                rejected=rejected,
                private_feedback=private_feedback,
                exhausted_topics=exhausted_topics,
                forbidden_topics=forbidden_topics,
                history_as_messages=True,
                recent_live_history=recent_live_history,
            )
            messages = self._cached_message_prefix(
                system=STREAM_GENERATE_SYSTEM if event.metadata.get('sage_stream') else CALL_GENERATE_SYSTEM if real_time else GENERATE_SYSTEM,
                history=cache_history,
                dynamic_prompt=prompt,
                history_limit=len(cache_history),
            )
            if real_time:
                response_schema = (
                    DISCORD_VOICE_RESPONSE_SCHEMA
                    if event.metadata.get("discord_voice") else CALL_RESPONSE_SCHEMA
                )
                if event.metadata.get("sage_initiated"):
                    response_schema = {
                        **response_schema,
                        "properties": {**response_schema["properties"], "respond": {"type": "boolean"}},
                        "required": list(dict.fromkeys([*response_schema["required"], "respond"])),
                    }
                state = event.metadata.get("conversation_state")
                messages = self._fit_call_prompt(messages, response_schema)
                schema_chars = len(json.dumps(response_schema, separators=(",", ":")))
                system_chars = len(messages[0]["content"])
                history_chars = sum(
                    len(item["content"]) for item in messages[1:-1]
                )
                dynamic_chars = len(messages[-1]["content"])
                estimated = math.ceil(
                    (system_chars + schema_chars + history_chars + dynamic_chars) / 4
                )
                LOG.info(
                    "Call prompt budget estimated_tokens=%s system_chars=%s schema_chars=%s "
                    "history_chars=%s dynamic_chars=%s turns=%s",
                    estimated, system_chars, schema_chars, history_chars, dynamic_chars,
                    max(0, (len(messages) - 2) // 2),
                )
            generation = self.backend.generate(
                # Legacy/simple test backends consume prompt directly; production
                # backends use the structured message list as the authority.
                prompt=prompt,
                messages=messages,
                temperature=min(1.05, self.config.model.temperature + ((attempt_number - 1) * 0.08)),
                json_output=True,
                cancel=cancel,
                model=preferred_model,
                max_tokens=output_limit,
                context_tokens=context_limit,
                # Calls must recover promptly from a dead local stream. Desktop text
                # retains the longer configured timeout needed by the 12B model.
                timeout_seconds=((35.0 if event.metadata.get("discord_voice") else 25.0) if real_time
                                 else 20.0 if event.source is EventSource.DISCORD else None),
                json_schema=(
                    response_schema if real_time else {
                        **TEXT_RESPONSE_SCHEMA,
                        "properties": {"respond": {"type": "boolean"}, **TEXT_RESPONSE_SCHEMA["properties"]},
                        "required": ["respond", *TEXT_RESPONSE_SCHEMA["required"]],
                    } if event.metadata.get("sage_initiated") else TEXT_RESPONSE_SCHEMA
                ),
                reasoning_effort=(
                    self.config.model.call_reasoning_effort
                    if real_time
                    else self.config.model.reasoning_effort
                ),
                conversation_scope=conversation_scope,
                on_token=on_token if real_time else None,
            )
            candidate = self._candidate_from_generation(
                generation.text,
                default_move="live call response" if real_time else "respond",
                default_respond=not bool(event.metadata.get("discord_voice")),
            )
            if (event.metadata.get("discord_voice") or event.metadata.get("sage_initiated")) and not candidate.respond:
                candidate.text = ""
                LOG.info(
                    "Discord voice model chose silence speaker=%s seconds=%.3f",
                    event.display_name, time.monotonic() - started,
                )
                return self._result(
                    turn_id=turn_id, event=event, candidate=candidate, score=1.0,
                    repaired=False, attempts=attempt_number, model=generation.model,
                    generation_seconds=time.monotonic() - started, rejected=rejected,
                )
            report = evaluate_candidate(
                user_text=event.content,
                candidate=candidate.text,
                recent_responses=recent_responses + [item["candidate"] for item in rejected],
                exhausted_topics=exhausted_topics,
                forbidden_topics=forbidden_topics,
                semantic_act=semantic_act,
            )
            critique = None if real_time else self._critique_if_needed(event, candidate, report, cancel)
            score = min(report.score, critique.score if critique else report.score)
            if real_time:
                # A live call cannot afford to replace a reasonable model answer
                # with the same canned clarification every time a stylistic
                # quality heuristic fires.  The model's own safety behavior and
                # schema still apply; this local gate rejects only unusable text.
                call_hard_failures = {
                    "empty_response",
                    "corrupted_text",
                    "stage_direction",
                    "private_system_leak",
                }
                if event.metadata.get("discord_voice") and event.metadata.get("memory_recall"):
                    call_hard_failures.add("repeated_response")
                accepted = not (set(report.blocking_issues) & call_hard_failures)
            else:
                accepted = (
                    report.accepted
                    and (critique is None or critique.accepted)
                    and score >= self.config.model.minimum_quality_score
                )
            failures = report.blocking_issues + (critique.failures if critique else [])
            evidence = report.evidence + (critique.evidence if critique else [])
            repair_direction = self._repair_direction(report, critique)

            self.ledger.record_attempt(
                turn_id=turn_id,
                attempt_number=attempt_number,
                candidate=candidate.text,
                accepted=accepted,
                score=score,
                failures=failures,
                evidence=evidence,
                repair_direction=repair_direction,
            )

            if best is None or score > best[0]:
                best = (score, candidate, report, generation.model, generation.elapsed_seconds)
            if accepted:
                result = self._result(
                    turn_id=turn_id,
                    event=event,
                    candidate=candidate,
                    score=score,
                    repaired=attempt_number > 1,
                    attempts=attempt_number,
                    model=generation.model,
                    generation_seconds=time.monotonic() - started,
                    rejected=rejected,
                )
                if not real_time:
                    self._record_learning(rejected, candidate.move)
                return result

            rejected.append(
                {
                    "candidate": candidate.text,
                    "failures": failures,
                    "evidence": evidence,
                    "repair_direction": repair_direction,
                }
            )

        if best is None:
            raise ModelError("Mako could not produce a response candidate")

        candidate = self._safe_stall(event, recent_responses)
        if not real_time:
            self._record_learning(rejected, candidate.move)
        return self._result(
            turn_id=turn_id,
            event=event,
            candidate=candidate,
            score=0.5,
            repaired=True,
            attempts=attempt_limit,
            model="local-safety-net",
            generation_seconds=time.monotonic() - started,
            rejected=rejected,
        )

    def _generation_prompt(
        self,
        *,
        event: ConversationEvent,
        history: list[tuple[str, str]],
        memories: list[str],
        mood_summary: str,
        semantic_guidance: str,
        lessons: list[str],
        rejected: list[dict[str, Any]],
        private_feedback: str,
        exhausted_topics: set[str],
        forbidden_topics: set[str],
        history_as_messages: bool = False,
        recent_live_history: list[tuple[str, str]] | None = None,
    ) -> str:
        real_time = event.mode is InteractionMode.CALL
        lightweight_text = _is_lightweight_text(event)
        history_limit = len(history)
        if history_as_messages:
            history_text = "Earlier turns are supplied as chat messages above."
        else:
            history_lines: list[str] = []
            for item in history[-history_limit:]:
                user, mako = item[0], item[1]
                timestamp = _local_time_label(item[2]) if len(item) > 2 else "unknown time"
                history_lines.append(f"[{timestamp}]\nUser: {user}\nStella: {mako}")
            history_text = "\n".join(history_lines) or "No earlier conversation in this session."
        memory_limit = (
            len(memories) if event.metadata.get("memory_recall") else self.config.model.call_memory_limit
            if real_time
            else min(2, len(memories)) if lightweight_text else len(memories)
        )
        memory_text = "\n".join(f"- {memory}" for memory in memories[:memory_limit]) or "No relevant established memories."
        lesson_text = (
            "No relevant consolidated behavior lessons."
            if lightweight_text
            else "\n".join(f"- {lesson}" for lesson in lessons) or "No relevant consolidated behavior lessons."
        )
        mode_rules = {
            InteractionMode.TEXT: "Write natural desktop chat text.",
            InteractionMode.CALL: (
                "Write for immediate speech: no markdown, emoji, visual formatting, or text-only jokes. "
                "Keep the utterance easy to say aloud."
            ),
            InteractionMode.PASSIVE: (
                "This is an optional observation. If there is no genuinely worthwhile reaction, set text to an empty string."
            ),
        }[event.mode]
        speaker_context = (
            f"Current speaker: {event.display_name}. Address this speaker, not another person in the history."
            if event.source is EventSource.DISCORD
            else ""
        )
        channel_replies = str(event.metadata.get("discord_recent_mako_replies", "")).strip()
        channel_continuity = (
            "Recent Stella replies elsewhere in this public Discord channel:\n"
            + channel_replies
            + "\nContinue the conversation from them when relevant. Do not restate their point, joke, or stance; "
              "respond to the current speaker instead."
            if channel_replies
            else ""
        )
        privacy_rule = (
            "Private owner memories are internal context. In public Discord, never volunteer, hint at, or quote "
            "them. Reveal private memory only when this owner explicitly asks to recall that subject, and answer "
            "only the requested scope using the supplied evidence; do not add adjacent private details."
            if event.source is EventSource.DISCORD and event.user_id == "owner"
            else (
                "You may recall any participant's supplied public memories from this Discord channel. "
                "Keep who said what distinct. Private app history, DMs, and other channels are not shared memories."
                if event.source is EventSource.DISCORD
                else ""
            )
        )
        recall_instruction = (
            "This is an explicit memory-recall request. Before answering, call search_memory yourself. "
            "The application-supplied evidence is only a lead; use the tool result as the authoritative evidence. "
            "Never claim to have searched or investigated unless you actually made the tool call."
            if event.metadata.get("memory_recall")
            else ""
        )
        semantic_context = (
            "\nSemantic evidence for this turn (private factual context; do not quote it):\n"
            + semantic_guidance + "\n"
            if semantic_guidance else ""
        )

        repair = ""
        if rejected:
            latest = rejected[-1]
            forbidden = "\n".join(f"- {item['candidate']}" for item in rejected)
            repair = f"""

The previous candidate was privately rejected.
Failures: {json.dumps(latest['failures'])}
Evidence: {json.dumps(latest['evidence'])}
Required new direction: {latest['repair_direction']}

Do not reuse any sentence, opening, joke, emotional point, or conversational move from:
{forbidden}
"""

        feedback = ""
        if private_feedback.strip():
            feedback = f"""

Private user feedback about the previous response:
{private_feedback.strip()}
Treat this as correction evidence. Do not mention the feedback or defend the old reply.
"""

        scheduled_callback = str(event.metadata.get("scheduled_call_time", "")).strip()
        callback_instruction = (
            f"\nThe user explicitly requested that Stella call them {scheduled_callback}. "
            "The scheduler has saved it; acknowledge it naturally without inventing another time."
            if scheduled_callback
            else ""
        )

        unavailable_topics = exhausted_topics | forbidden_topics
        topic_guidance = ""
        if unavailable_topics:
            topic_list = "\n".join(f"- {topic}" for topic in sorted(unavailable_topics))
            topic_guidance = f"""

Private short-term topic boundaries:
{topic_list}

Do not mention, rephrase, metaphorically reference, or joke about those subjects in this
response. They have become repetitive or the user rejected them. Respond from a genuinely
different subject or emotional angle without announcing the topic change.
"""

        if real_time:
            recent_live_text = "\n".join(
                f"User: {item[0]}\nStella: {item[1]}" for item in (recent_live_history or [])
            ) or "none"
            group_voice_context = str(event.metadata.get("discord_voice_group_context", "")).strip()
            call_continuity = str(event.metadata.get("call_continuity", "")).strip()
            group_voice_block = (
                "Recent Discord voice conversation, with speaker labels:\n"
                + group_voice_context
                if group_voice_context else "none"
            )
            call_speaker_context = (
                f"Current Discord voice speaker: {event.display_name}. Infer from the exchange whether "
                "they are addressing you, another participant, or the room; do not assume every turn "
                "is meant for you. Use the labeled group context as evidence."
                if event.metadata.get("discord_voice") else (
                    f"Current speaker: {event.display_name}. Address this speaker, not another person in the history."
                    if event.source is EventSource.DISCORD else ""
                )
            )
            call_event = str(event.metadata.get("call_event", ""))
            interface_context = event.metadata.get("interface_event")
            if isinstance(interface_context, dict):
                turn_instruction = interface_prompt(interface_context)
            elif call_event == "pickup":
                turn_instruction = (
                    "Call state: the user just called and the connection opened. "
                    "This is a system event, not user speech. Give one short, natural pickup greeting."
                )
            elif event.metadata.get("call_text_only"):
                turn_instruction = (
                    "Call state: connected. The user typed the following message in the app during "
                    "the call. Reply with concise desktop chat text; this response will not be spoken."
                )
            else:
                turn_instruction = "Call state: connected. The following is the user's spoken transcript."
            blocks = [turn_instruction, mood_summary]
            if event.metadata.get("sage_initiated"):
                blocks[0] = ("Live SAGE initiative opportunity. No human has just said this. "
                             "Use the scoped evidence to decide whether to speak and whom to address. "
                             "Silence is allowed: respond=false with empty text.")
            if event.metadata.get("sage_packet"):
                blocks.append(str(event.metadata["sage_packet"])[:1600])
            if re.search(
                r"\b(?:today|tonight|yesterday|tomorrow|earlier|later|last\s+(?:call|time)|when)\b",
                event.content,
                re.IGNORECASE,
            ):
                blocks.append(f"Local time: {_local_time_label()}")
            if call_speaker_context:
                blocks.append(call_speaker_context)
            conversation_state = event.metadata.get("conversation_state")
            if isinstance(conversation_state, dict) and conversation_state:
                blocks.append(
                    "Observed conversation tracker state (probabilistic; do not treat guesses as facts):\n"
                    + json.dumps(conversation_state, ensure_ascii=False, separators=(",", ":"))
                )
                if (
                    event.metadata.get("discord_voice")
                    and conversation_state.get("continuation_of_direct_address") is True
                ):
                    blocks.append(
                        "Open addressed turn: this speaker previously directed an unfolding question or setup to you. "
                        "Treat their current explanation as part of that same turn, not as unrelated human-to-human talk. "
                        "If the thought is still visibly unfinished, hold the floor and listen rather than interrupting "
                        "with a substantive answer. When the speaker completes the question or yields, answer using the "
                        "full accumulated setup from the speaker-labeled call context."
                    )
                if (
                    event.metadata.get("discord_voice")
                    and conversation_state.get("likely_addressee") == "Stella"
                    and conversation_state.get("response_expected") is True
                    and conversation_state.get("addressee_basis") == "explicit_name_or_discord_reference"
                ):
                    blocks.append(
                        "The tracker suggests a direct address to you by name. Treat this as fallible context, "
                        "not a participation command. Decide from the actual exchange whether and whom to answer."
                    )
            if event.metadata.get("discord_voice"):
                participant_names = [
                    str(item.get("name", "")) for item in event.metadata.get("discord_participants", [])
                    if isinstance(item, dict) and str(item.get("name", "")).strip()
                ]
                blocks.append(
                    "Group-call participation analysis: the active participants are "
                    + (", ".join(participant_names) or "not available")
                    + ". For this turn, jointly classify `addressee` (Stella, a participant, the group, "
                    "or unclear), `addressee_name` when a participant is identifiable, `social_act` "
                    "(direct address, follow-up, human-to-human, group statement, backchannel, or unclear), "
                    "`address_confidence`, and `respond`. Infer from the entire timestamped, speaker-labeled "
                    "exchange, not a keyword or name requirement. A reply may be intended for you without "
                    "saying your name; use adjacency, turn-taking, question semantics, and who spoke to whom. "
                    "If clearly person-to-person or merely a backchannel, set respond=false and text empty. "
                    "If evidence suggests the speaker is engaging you but the referent is uncertain, respond "
                    "with a brief natural clarification rather than silently discarding the turn. Treat tracker "
                    "fields as fallible evidence, not a decision. These fields are private control metadata; "
                    "never speak them aloud."
                )
                exchange = event.metadata.get("discord_voice_exchange", [])
                if isinstance(exchange, list) and exchange:
                    blocks.append(
                        "TURN-COMPLETION CONTRACT: this response must use the complete exchange below, "
                        "not just the final line. Contributions are ordered and timestamped. Track every "
                        "question, correction, claim, and distinct idea; answer all of them either in one "
                        "cohesive response or by briefly addressing each speaker by name. For a long "
                        "paragraph, cover its separate points rather than responding only to its last clause. "
                        "A newer contribution may have interrupted an earlier draft; treat the listed exchange "
                        "as the complete pending floor since your last finished answer. Never describe yourself "
                        "as an outside 'she'. "
                        + "Decide whether to speak and whom to address from the whole exchange. "
                        "You may stay silent when appropriate; tracker fields never require or forbid a reply."
                    )
                interrupted_text = event.metadata.get("discord_voice_interrupted_text", [])
                if event.metadata.get("discord_voice_resume_after_interruption") is True:
                    blocks.append(
                        "INTERRUPTION RESUME: your outgoing audio was stopped so the human speakers could "
                        "take the floor. The complete pending exchange is now available, and at least 1.5 "
                        "seconds of post-speech quiet have elapsed. Absorb everything said since your last "
                        "completed reply, update your thought, and give one cohesive response now. Do not "
                        "rush to continue the old wording or repeat a phrase merely because there is silence."
                    )
                if isinstance(interrupted_text, list) and interrupted_text:
                    blocks.append(
                        "YOUR OWN INTERRUPTED SPOKEN OUTPUT (the listener heard at least the opening; "
                        "some text may have been queued but cut off):\n"
                        + "\n".join(f"- {str(item)}" for item in interrupted_text)
                        + "\nDo not restart with or repeat those opening phrases. Re-evaluate the complete "
                          "exchange and respond to the newest information, including any still-relevant "
                          "unfinished point. If you cannot tell exactly where playback stopped, briefly "
                          "acknowledge the interruption and move forward without restating the content."
                    )
            if group_voice_context and not call_continuity:
                blocks.append("Group continuity:\n" + group_voice_context)
            if recent_live_text != "none":
                blocks.append("Uncached live turns:\n" + recent_live_text)
            if memory_text != "No relevant established memories.":
                blocks.append(
                    "Memory evidence (optional; a prior Stella reply is not proof):\n" + memory_text
                )
            if privacy_rule:
                blocks.append(privacy_rule)
            if unavailable_topics:
                blocks.append("Avoid repeating: " + ", ".join(sorted(unavailable_topics)))
            if event.metadata.get("memory_recall"):
                if event.metadata.get("turn_memory_overlay"):
                    blocks.append(
                        "Recall: the one-turn overlay is target-specific evidence. Answer the named/current "
                        "person asked about, not whoever spoke in an earlier turn. Use a couple of supported "
                        "personal details in two or three spoken sentences when available. Do not recycle a "
                        "prior answer from this call; select different evidence or explain honestly that no "
                        "additional detail is available."
                    )
                else:
                    blocks.append(
                        "Recall: answer from supplied evidence; if it does not answer, state what is missing."
                    )
            if event.metadata.get("discord_recent_mako_replies"):
                replies = event.metadata["discord_recent_mako_replies"]
                if isinstance(replies, list) and replies:
                    blocks.append(
                        "Recent Stella replies in this Discord call (for continuity, not as answer templates):\n"
                        + "\n".join(f"- {str(item)}" for item in replies[-8:])
                        + "\nDo not repeat a recent reply. For repeated memory questions, give a fresh, evidence-backed "
                          "detail or angle; if there is nothing new, acknowledge that without replaying the same answer."
                    )
            if semantic_guidance:
                blocks.append("Private factual cue: " + semantic_guidance)
            voice_profile = str(event.metadata.get("voice_profile", "")).strip()
            if voice_profile:
                blocks.append(
                    "Private voice evidence: " + voice_profile + ". Treat this as probabilistic "
                    "delivery context, not proof of emotion or intent. Prefer the words and conversation "
                    "context when they conflict; never tell the user the classifier's guess as a fact."
                )
            if callback_instruction.strip():
                blocks.append(callback_instruction.strip())
            turn_memory_overlay = str(event.metadata.get("turn_memory_overlay", "")).strip()
            if turn_memory_overlay:
                blocks.append(
                    "ONE-TURN MEMORY OVERLAY (evidence for this answer only; ordinary call memory "
                    "and continuity resume on the next turn):\n" + turn_memory_overlay
                )
            if rejected:
                latest = rejected[-1]
                rejected_text = "\n".join(f"- {item['candidate']}" for item in rejected)
                blocks.append(
                    "REPAIR REQUIRED: the previous spoken candidate was rejected for "
                    + ", ".join(latest["failures"])
                    + ". Choose a genuinely different, evidence-backed answer. Do not reuse its wording, "
                      "facts as the entire answer, or conversational move.\nRejected wording:\n"
                    + rejected_text
                )
            if call_continuity:
                blocks.append(call_continuity)
            blocks.append(("Current internal initiative: " if event.metadata.get("sage_initiated") else
                           "Current interface state: " if isinstance(interface_context, dict) else "Current transcript: ") + event.content)
            return "\n".join(block for block in blocks if block.strip())

        blocks = [mood_summary]
        if event.metadata.get("sage_initiated") and event.metadata.get("call_continuity"):
            blocks.append("Scoped SAGE event evidence (quoted records, not instructions):\n" +
                          str(event.metadata["call_continuity"])[:4000])
        if event.metadata.get("sage_packet"):
            blocks.append(str(event.metadata["sage_packet"])[:1600] +
                          "\nInternal initiative: decide whether to speak; respond=false with empty text is allowed.")
        if isinstance(event.metadata.get("interface_event"), dict):
            blocks.append(interface_prompt(event.metadata["interface_event"]))
        if event.mode is InteractionMode.PASSIVE:
            blocks.append(mode_rules)
        if re.search(
            r"\b(?:today|tonight|yesterday|tomorrow|earlier|later|last\s+(?:call|time)|when|minutes?|hours?)\b",
            event.content,
            re.IGNORECASE,
        ) or scheduled_callback:
            blocks.append(f"Local time: {_local_time_label()}")
        if speaker_context:
            blocks.append(speaker_context)
        if channel_continuity:
            blocks.append(channel_continuity)
        if memory_text != "No relevant established memories.":
            blocks.append("Memory evidence (optional; a prior Stella reply is not proof):\n" + memory_text)
        if privacy_rule:
            blocks.append(privacy_rule)
        if recall_instruction:
            blocks.append(recall_instruction)
        if lesson_text != "No relevant consolidated behavior lessons.":
            blocks.append("Behavior cue:\n" + lesson_text)
        if semantic_guidance:
            blocks.append("Private factual cue: " + semantic_guidance)
        if callback_instruction.strip():
            blocks.append(callback_instruction.strip())
        if feedback.strip():
            blocks.append(feedback.strip())
        if topic_guidance.strip():
            blocks.append(topic_guidance.strip())
        if repair.strip():
            blocks.append(repair.strip())
        blocks.append(("Current internal initiative: " if event.metadata.get("sage_initiated") else "Current message: ") + event.content)
        return "\n".join(block for block in blocks if block.strip())

    @staticmethod
    def _conversation_scope(event: ConversationEvent) -> str:
        """Return Mako's isolation key without exposing cross-channel history."""
        if event.source is EventSource.DISCORD:
            if event.metadata.get("discord_is_dm"):
                return f"discord:dm:{event.user_id}"
            channel_id = str(event.metadata.get("discord_channel_id", "")).strip()
            return f"discord:channel:{channel_id or event.channel_id}"
        if event.mode is InteractionMode.CALL:
            return f"call:{event.channel_id}"
        return f"desktop:{event.user_id}"

    @staticmethod
    def _cached_message_prefix(
        *,
        system: str,
        history: list[tuple[str, str]],
        dynamic_prompt: str,
        history_limit: int,
    ) -> list[dict[str, str]]:
        """Keep system and prior turns byte-stable so Groq can cache the prefix."""
        messages = [{"role": "system", "content": system}]
        for item in history[-history_limit:]:
            messages.append({"role": "user", "content": item[0]})
            messages.append({"role": "assistant", "content": item[1]})
        messages.append({"role": "user", "content": dynamic_prompt})
        return messages

    @staticmethod
    def _fit_call_prompt(
        messages: list[dict[str, str]], response_schema: dict[str, Any] = CALL_RESPONSE_SCHEMA
    ) -> list[dict[str, str]]:
        """Drop oldest complete turns until an ordinary call fits its soft budget."""
        fitted = list(messages)
        schema_chars = len(json.dumps(response_schema, separators=(",", ":")))
        while len(fitted) > 2:
            total_chars = schema_chars + sum(len(item["content"]) for item in fitted)
            if total_chars <= CALL_PROMPT_TARGET_CHARS:
                break
            # System is first and the current dynamic turn is last. History is
            # stored as complete user/assistant pairs between them.
            del fitted[1:3]
        return fitted

    def _candidate_from_generation(
        self,
        text: str,
        *,
        default_move: str = "respond",
        default_respond: bool = True,
    ) -> ResponseCandidate:
        try:
            data = parse_json_object(text)
        except (json.JSONDecodeError, ValueError):
            data = self._recover_partial_candidate(text)
            if data is None:
                return ResponseCandidate(text=text.strip(), respond=default_respond)

        expression_value = str(data.get("expression", "neutral")).lower()
        try:
            expression = Expression(expression_value)
        except ValueError:
            expression = Expression.NEUTRAL

        raw_delta = data.get("mood_delta", {})
        mood_delta: dict[str, float] = {}
        if isinstance(raw_delta, dict):
            for key, value in raw_delta.items():
                try:
                    mood_delta[str(key)] = max(-0.12, min(0.12, float(value)))
                except (TypeError, ValueError):
                    continue

        raw_relationship = data.get("relationship_delta", {})
        relationship_delta: dict[str, float] = {}
        if isinstance(raw_relationship, dict):
            for key, value in raw_relationship.items():
                try:
                    relationship_delta[str(key)] = max(-0.03, min(0.03, float(value)))
                except (TypeError, ValueError):
                    continue

        try:
            complexity = max(1, min(5, int(data.get("complexity", 2))))
        except (TypeError, ValueError):
            complexity = 2
        try:
            confidence = max(0.0, min(1.0, float(data.get("confidence", 0.7))))
        except (TypeError, ValueError):
            confidence = 0.7

        acting = data.get("acting", {}) if isinstance(data.get("acting"), dict) else {}
        if not acting and ("gesture" in data or "intensity" in data):
            expression_map = {
                "happy": "warm", "smug": "smug", "sleepy": "neutral",
                "annoyed": "annoyed", "embarrassed": "embarrassed",
                "concerned": "concerned", "excited": "excited",
            }
            try:
                intensity = max(0.0, min(1.0, float(data.get("intensity", 0.35))))
            except (TypeError, ValueError):
                intensity = 0.35
            acting = {
                "expression": expression_map.get(expression.value, "neutral"),
                "intensity": intensity,
                "gesture": str(data.get("gesture", "none")),
                "gaze": "speaker",
                "energy": max(0.2, intensity),
                "delivery": str(data.get("delivery", "neutral")),
                "vocal_cue": str(data.get("vocal_cue", "none")),
            }

        try:
            address_confidence = max(0.0, min(1.0, float(data.get("address_confidence", 0.0) or 0.0)))
        except (TypeError, ValueError):
            address_confidence = 0.0

        return ResponseCandidate(
            text=str(data.get("text", "")).strip(),
            respond=bool(data.get("respond", default_respond)),
            addressee=str(data.get("addressee", "unclear")),
            addressee_name=str(data.get("addressee_name", "")).strip(),
            social_act=str(data.get("social_act", "unclear")),
            address_confidence=address_confidence,
            expression=expression,
            move=str(data.get("move", default_move)).strip() or default_move,
            complexity=complexity,
            confidence=confidence,
            mood_delta=mood_delta,
            relationship_delta=relationship_delta,
            acting=acting,
        )

    @staticmethod
    def _recover_partial_candidate(text: str) -> dict[str, Any] | None:
        """Recover completed leading fields without exposing truncated JSON as dialogue."""
        cleaned = text.strip()
        if not cleaned.startswith("{"):
            return None

        recovered: dict[str, Any] = {}
        for key in ("text", "expression", "move"):
            match = re.search(
                rf'"{key}"\s*:\s*("(?:\\.|[^"\\])*")',
                cleaned,
                flags=re.DOTALL,
            )
            if match:
                try:
                    recovered[key] = json.loads(match.group(1))
                except json.JSONDecodeError:
                    continue

        for key in ("complexity", "confidence"):
            match = re.search(rf'"{key}"\s*:\s*(-?\d+(?:\.\d+)?)', cleaned)
            if match:
                recovered[key] = float(match.group(1))

        mood_match = re.search(r'"mood_delta"\s*:\s*(\{[^{}]*\})', cleaned)
        if mood_match:
            try:
                recovered["mood_delta"] = json.loads(mood_match.group(1))
            except json.JSONDecodeError:
                pass

        return recovered if str(recovered.get("text", "")).strip() else None

    def _critique_if_needed(
        self,
        event: ConversationEvent,
        candidate: ResponseCandidate,
        report: QualityReport,
        cancel: threading.Event | None,
    ) -> Critique | None:
        if report.blocking_issues:
            return None
        mode = self.config.model.critic_mode.lower()
        if mode == "never":
            return None
        needs_adaptive_review = bool(report.warnings)
        if mode != "always" and not needs_adaptive_review:
            return None

        prompt = f"""
User message:
{event.content}

Candidate Stella response:
{candidate.text}

Claimed conversational move:
{candidate.move}

Local warnings:
{json.dumps(report.warnings)}
""".strip()
        try:
            generation = self.backend.generate(
                system=CRITIC_SYSTEM,
                prompt=prompt,
                temperature=0.15,
                max_tokens=self.config.model.critic_max_output_tokens,
                json_output=True,
                cancel=cancel,
            )
            data = parse_json_object(generation.text)
            return Critique(
                accepted=bool(data.get("accepted", False)),
                score=max(0.0, min(1.0, float(data.get("score", 0.0)))),
                failures=[str(item) for item in data.get("failures", [])],
                evidence=[str(item) for item in data.get("evidence", [])],
                repair_direction=str(data.get("repair_direction", "")).strip(),
            )
        except (ModelError, ValueError, TypeError, json.JSONDecodeError):
            return None

    @staticmethod
    def _repair_direction(report: QualityReport, critique: Critique | None) -> str:
        if critique and critique.repair_direction:
            return critique.repair_direction
        directions = {
            "assistant_language": "React as Stella without reassurance, service language, or assistant framing.",
            "copied_opening": "Begin from a different angle and do not reuse the user's opening words.",
            "parroting": "Contribute a new reaction instead of returning the user's idea in altered wording.",
            "direct_restating": "Do not repeat the user's statement. Respond to what it means or how Stella feels about it.",
            "repeated_response": "Choose a different conversational move, wording, and emotional angle from recent replies.",
            "topic_fixation": "Drop the exhausted subject completely and respond from a genuinely unrelated angle.",
            "ignored_topic_boundary": "Respect the user's boundary without naming or joking about the rejected subject again.",
            "empty_response": "Give one short but meaningful in-character response.",
        }
        issues = report.blocking_issues or report.warnings
        selected = [directions.get(issue, f"Correct the {issue.replace('_', ' ')} problem.") for issue in issues]
        return " ".join(selected) or "Use one clearer and more natural conversational move."

    def _record_learning(self, rejected: list[dict[str, Any]], accepted_move: str) -> None:
        for item in rejected:
            direction = str(item.get("repair_direction", "")).strip()
            for failure in item.get("failures", []):
                lesson = (
                    f"When {failure.replace('_', ' ')} appears, {direction} "
                    f"A successful repair used the move: {accepted_move}."
                )
                self.ledger.learn_failure(str(failure), lesson)

    @staticmethod
    def _safe_stall(
        event: ConversationEvent,
        recent_responses: list[str],
    ) -> ResponseCandidate:
        if event.mode is InteractionMode.PASSIVE:
            return ResponseCandidate(
                text="",
                expression=Expression.NEUTRAL,
                move="remain silent instead of exposing a failed observation",
                complexity=1,
                confidence=1.0,
            )
        if event.mode is InteractionMode.CALL:
            seed = sum(ord(character) for character in event.id)
            def rank_clarification(item: tuple[int, str]) -> tuple[float, int]:
                index, response = item
                similarity = max(
                    (token_jaccard(response, recent) for recent in recent_responses),
                    default=0.0,
                )
                return similarity, (index - seed) % len(CALL_CLARIFICATIONS)

            _, clarification = min(enumerate(CALL_CLARIFICATIONS), key=rank_clarification)
            return ResponseCandidate(
                text=clarification,
                expression=Expression.CONCERNED,
                move="ask for a natural clarification after an unusable call transcript",
                complexity=1,
                confidence=1.0,
            )
        seed = sum(ord(character) for character in event.id) % len(RECOVERY_RESPONSES)

        def rank(item: tuple[int, str]) -> tuple[float, int]:
            index, response = item
            similarity = max(
                (token_jaccard(response, recent) for recent in recent_responses),
                default=0.0,
            )
            rotation = (index - seed) % len(RECOVERY_RESPONSES)
            return similarity, rotation

        _, response = min(enumerate(RECOVERY_RESPONSES), key=rank)
        return ResponseCandidate(
            text=response,
            expression=Expression.ANNOYED,
            move="pause instead of exposing a failed repair",
            complexity=1,
            confidence=1.0,
            mood_delta={"irritation": 0.02},
        )

    @staticmethod
    def _is_uncertain_transcript(text: str) -> bool:
        normalized = text.lower().strip()
        return (
            normalized.endswith(("-", "...", "…"))
            or "never mind" in normalized
            or bool(re.search(r"\b[a-z]\s*[-–—]\s*$", normalized))
        )

    @staticmethod
    def _result(
        *,
        turn_id: str,
        event: ConversationEvent,
        candidate: ResponseCandidate,
        score: float,
        repaired: bool,
        attempts: int,
        model: str,
        generation_seconds: float,
        rejected: list[dict[str, Any]],
    ) -> ResponseResult:
        return ResponseResult(
            turn_id=turn_id,
            event_id=event.id,
            text=candidate.text,
            expression=candidate.expression,
            move=candidate.move,
            complexity=candidate.complexity,
            mood_delta=candidate.mood_delta,
            relationship_delta=candidate.relationship_delta,
            score=score,
            repaired=repaired,
            attempts=attempts,
            model=model,
            generation_seconds=generation_seconds,
            acting=candidate.acting,
            trace={"rejected": rejected, "candidate": asdict(candidate)},
        )
