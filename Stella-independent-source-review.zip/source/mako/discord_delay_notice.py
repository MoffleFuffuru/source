"""One-shot spoken notice while a Discord model request has no output."""
from __future__ import annotations

import threading
import logging
from time import monotonic


WARNING = "Someone tell moffle there is a problem with my AI"
RESOLVED = "The issue has been resolved."
WARNING_DELAY_SECONDS = 10.0
LOG = logging.getLogger(__name__)


class DiscordDelayNotice:
    def __init__(self, started_at, cancel, play, *, clock=monotonic, timer_factory=threading.Timer):
        self.cancel = cancel
        self.play = play
        self.clock = clock
        self.lock = threading.RLock()
        self.output_started = False
        self.finished = False
        self.warning_at = None
        self.playback = None
        # Start after the voice worker begins, not at the user's earlier turn commit.
        self.timer = timer_factory(
            max(0.0, started_at + WARNING_DELAY_SECONDS - clock()), self._warn
        )
        self.timer.daemon = True

    def start(self):
        self.timer.start()

    def _warn(self):
        with self.lock:
            if self.finished or self.output_started or self.warning_at is not None or self.cancel.is_set():
                return
            self.warning_at = self.clock()
            self.playback = self.play(WARNING)

    def token(self, token):
        """Return whether this token may enter the original streaming TTS."""
        with self.lock:
            self.output_started = True
            self.timer.cancel()
            return self.warning_at is None

    def finish(self, text):
        arrived_at = self.clock()
        with self.lock:
            self.finished = True
            self.timer.cancel()
            warning_at, playback = self.warning_at, self.playback
        if playback is not None:
            try:
                playback.result(timeout=20.0)
            except Exception:
                LOG.exception("Discord delay notice playback failed")
                return text
        if (text.strip() and warning_at is not None and playback is not None
                and 0 <= arrived_at - warning_at <= 30.0 and not self.cancel.is_set()):
            return f"{RESOLVED} {text}"
        return text

    def close(self):
        with self.lock:
            self.finished = True
            self.timer.cancel()
