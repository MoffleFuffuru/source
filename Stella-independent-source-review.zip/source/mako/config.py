from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field, fields, is_dataclass
from pathlib import Path
from typing import Any


@dataclass(slots=True)
class ModelConfig:
    provider: str = "groq"
    endpoint: str = "https://api.groq.com/openai/v1"
    api_key_environment_variable: str = "GROQ_API_KEY"
    primary: str = "openai/gpt-oss-120b"
    fallback: str = "openai/gpt-oss-20b"
    daily_request_limit: int = 1000
    minute_token_limit: int = 8000
    daily_token_limit: int = 200000
    reserve_daily_token_ratio: float = 0.15
    context_tokens: int = 8192
    max_output_tokens: int = 512
    temperature: float = 0.82
    top_p: float = 0.92
    repeat_penalty: float = 1.08
    timeout_seconds: float = 45.0
    keep_alive: str = ""
    think: bool = False
    reasoning_effort: str = "low"
    call_reasoning_effort: str = "low"
    max_attempts: int = 2
    critic_mode: str = "adaptive"
    critic_max_output_tokens: int = 70
    minimum_quality_score: float = 0.62
    call_model: str = "openai/gpt-oss-120b"
    call_provider: str = ""
    call_endpoint: str = ""
    call_api_key_environment_variable: str = ""
    call_fallback_provider: str = ""
    call_fallback_endpoint: str = ""
    call_fallback_api_key_environment_variable: str = ""
    call_fallback_model: str = ""
    call_context_tokens: int = 4096
    call_max_output_tokens: int = 96
    call_max_attempts: int = 1
    call_recent_turns: int = 3
    call_memory_limit: int = 5
    call_streaming_tts: bool = False
    call_speculative_generation: bool = False
    codex_executable: str = ""
    codex_home: str = ""
    codex_personality: str = "none"


@dataclass(slots=True)
class MemoryModelConfig:
    """Independent curator lane; empty fields inherit the configured call model."""
    provider: str = ""
    endpoint: str = ""
    api_key_environment_variable: str = ""
    model: str = ""
    reasoning_effort: str = ""
    timeout_seconds: float = 90.0
    max_output_tokens: int = 2200


@dataclass(slots=True)
class TimingConfig:
    reading_wpm: float = 250.0
    minimum_reading_seconds: float = 3.0
    typing_wpm: float = 90.0
    thinking_base_seconds: float = 0.55
    thinking_per_complexity: float = 0.32
    minimum_typing_seconds: float = 0.25
    message_batch_seconds: float = 0.25


@dataclass(slots=True)
class MemoryConfig:
    enabled: bool = True
    recent_turns: int = 12
    retrieval_limit: int = 5
    consolidation_idle_seconds: float = 300.0
    meaningful_session_turns: int = 4
    major_cycle_sessions: int = 10
    # Zero keeps the complete local turn archive; retrieval remains bounded.
    max_episodes: int = 0
    max_concepts: int = 160
    associative_candidate_limit: int = 48
    explicit_recall_candidate_limit: int = 320
    associative_packet_size: int = 5
    consolidation_batch_size: int = 16
    core_min_recurrence: int = 3
    core_min_strength: float = 0.58
    core_min_confidence: float = 0.72


@dataclass(slots=True)
class VoiceConfig:
    enabled: bool = True
    # "pipeline" retains the local Kyutai -> text model -> TTS call path.
    # "xai_realtime" is an opt-in experimental end-to-end voice path.
    call_backend: str = "pipeline"
    stt_backend: str = "auto"
    tts_backend: str = "kokoro"
    cartesia_api_key_environment_variable: str = "CARTESIA_API_KEY"
    cartesia_tts_model: str = "sonic-3.6"
    cartesia_tts_voice: str = ""
    cartesia_tts_language: str = "en"
    elevenlabs_api_key_environment_variable: str = "ELEVENLABS_API_KEY"
    elevenlabs_tts_model: str = "eleven_v4_turbo"
    elevenlabs_tts_voice: str = ""
    elevenlabs_keyterms: list[str] = field(default_factory=lambda: ["Stella", "Ghoul", "Moffle", "War Robots"])
    elevenlabs_vad_silence_seconds: float = 0.45
    vocal_context_provider: str = "inworld_stt"
    elevenlabs_stt_fallback: str = "inworld_stt"
    elevenlabs_tts_fallback: str = "inworld_tts"
    qwen_tts_model: str = "Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice"
    qwen_tts_speaker: str = "Ono_Anna"
    qwen_tts_device: str = "cpu"
    deepgram_tts_api_key_environment_variable: str = "DEEPGRAM_API_KEY"
    deepgram_flux_model: str = "flux-haley-en"
    deepgram_flux_sample_rate: int = 24000
    inworld_tts_api_key_environment_variable: str = "INWORLD_API_KEY"
    inworld_tts_model: str = "inworld-tts-2"
    inworld_tts_voice: str = "Selene"
    inworld_tts_sample_rate: int = 22050
    inworld_tts_delivery_mode: str = "STABLE"
    inworld_tts_instruction: str = (
        "Warm, natural conversational delivery with a consistent voice identity. Follow supplied "
        "steering tags and non-verbal cues naturally without exaggeration."
    )
    inworld_stt_api_key_environment_variable: str = "INWORLD_API_KEY"
    inworld_stt_profile_threshold: float = 0.55
    inworld_stt_eot_confidence_threshold: float = 0.60
    inworld_stt_min_eot_silence_ms: int = 220
    inworld_stt_max_turn_silence_ms: int = 450
    live_affect_enabled: bool = True
    live_affect_experimental_enabled: bool = False
    live_affect_window_seconds: float = 3.0
    xai_voice_api_key_environment_variable: str = "XAI_API_KEY"
    xai_voice_model: str = "grok-voice-think-fast-2.0"
    xai_voice_name: str = "eve"
    xai_voice_silence_duration_ms: int = 400
    language: str = "en_us"
    voice: str = "af_sky"
    kokoro_speed: float = 1.08
    kokoro_cpu_threads: int = 8
    kokoro_device: str = "cuda"
    pickup_min_seconds: float = 0.0
    pickup_max_seconds: float = 10.0
    raw_audio_retained: bool = False
    call_transcript_visible: bool = False
    allow_barge_in: bool = False
    input_enabled: bool = True
    input_device: int | None = None
    output_device: int | None = None
    output_volume: float = 1.0
    sample_rate: int = 16000
    block_milliseconds: int = 30
    noise_calibration_seconds: float = 0.8
    noise_floor_multiplier: float = 2.5
    speech_start_seconds: float = 0.12
    speech_hold_seconds: float = 0.09
    speech_release_multiplier: float = 1.25
    minimum_speech_seconds: float = 0.18
    maximum_utterance_seconds: float = 20.0
    silence_seconds: float = 1.15
    speech_threshold: float = 0.006
    whisper_model: str = "base"
    transcription_window_seconds: float = 1.6
    transcription_overlap_seconds: float = 0.75
    transcript_idle_windows: int = 1
    rolling_transcription_enabled: bool = False
    kyutai_server_url: str = "ws://127.0.0.1:8090"
    kyutai_api_key: str = "public_token"
    kyutai_vad_head_index: int = 2
    kyutai_vad_threshold: float = 0.81
    kyutai_model_delay_seconds: float = 0.5
    kyutai_startup_timeout_seconds: float = 8.0
    kyutai_worker_startup_timeout_seconds: float = 600.0
    parakeet_library_path: str = "tools/parakeet-runtime/parakeet.dll"
    parakeet_model_path: str = "data/models/realtime_eou_120m-v1-f16.gguf"
    parakeet_chunk_milliseconds: int = 40
    livekit_turn_detection_enabled: bool = False
    livekit_probe_silence_seconds: float = 0.3
    livekit_max_endpoint_seconds: float = 2.5
    livekit_transcript_grace_seconds: float = 0.75


@dataclass(slots=True)
class BodyConfig:
    enabled: bool = True
    adapter: str = "debug"
    warudo_host: str = "127.0.0.1"
    warudo_port: int = 39539
    # The Warudo Playground node writes its per-session channel ID here.
    # Empty means VMC facial animation still works but discrete body events
    # remain disabled.
    warudo_bridge_file: str = "data/warudo-bridge.json"
    update_hz: float = 20.0


@dataclass(slots=True)
class ProactiveCallConfig:
    enabled: bool = True
    minimum_idle_seconds: float = 900.0
    decision_cooldown_seconds: float = 1800.0
    offer_cooldown_seconds: float = 14400.0
    ring_timeout_seconds: float = 30.0
    quiet_hours_start: int = 23
    quiet_hours_end: int = 9


@dataclass(slots=True)
class VisionConfig:
    enabled: bool = True
    passive_enabled: bool = True
    poll_seconds: float = 20.0
    minimum_confidence: float = 0.86
    minimum_comment_interval_seconds: float = 600.0
    novelty_threshold: float = 0.13
    denied_window_terms: list[str] = field(
        default_factory=lambda: [
            "1password",
            "bitwarden",
            "keepass",
            "password",
            "private browsing",
            "incognito",
        ]
    )


@dataclass(slots=True)
class DiscordConfig:
    enabled: bool = False
    token_environment_variable: str = "MAKO_DISCORD_TOKEN"
    owner_user_ids: list[str] = field(default_factory=list)
    allowed_guild_ids: list[str] = field(default_factory=list)
    # Experimental open-memory scope. Empty by default; only public Discord-call
    # memories in explicitly listed guilds may be used by this feature.
    open_memory_test_guild_ids: list[str] = field(default_factory=list)
    allowed_channel_ids: list[str] = field(default_factory=list)
    ignored_channel_ids: list[str] = field(default_factory=list)
    direct_response_channel_ids: list[str] = field(default_factory=list)
    require_mention_channel_ids: list[str] = field(default_factory=list)
    proactive_channel_ids: list[str] = field(default_factory=list)
    allow_direct_messages: bool = True
    proactive_reply_cooldown_seconds: float = 120.0
    autonomy_enabled: bool = False
    sage_enabled: bool = False
    sage_quiet_seconds: float = 12.0
    sage_review_seconds: float = 300.0
    sage_initiative_cooldown_seconds: float = 90.0
    sage_max_in_ten_minutes: int = 3
    autonomy_review_seconds: float = 1800.0
    autonomy_context_messages: int = 80
    autonomy_history_messages: int = 80
    autonomy_mention_cooldown_seconds: float = 45.0
    post_read_delay_seconds: float = 3.0
    voice_enabled: bool = True
    voice_receive_enabled: bool = True


@dataclass(slots=True)
class UiConfig:
    width: int = 430
    height: int = 820
    x: int = 1400
    y: int = 180
    always_on_top: bool = True
    transparent: bool = False
    avatar_max_width: int = 340
    avatar_max_height: int = 390
    borderless: bool = True


@dataclass(slots=True)
class SageConfig:
    enabled: bool = False
    model: str = ""
    desktop_enabled: bool = True
    call_enabled: bool = True
    stream_review_seconds: float = 10.0
    stream_event_key_environment_variable: str = "STELLA_SAGE_EVENT_KEY"


@dataclass(slots=True)
class AppConfig:
    config_version: int = 12
    model: ModelConfig = field(default_factory=ModelConfig)
    memory_model: MemoryModelConfig = field(default_factory=MemoryModelConfig)
    timing: TimingConfig = field(default_factory=TimingConfig)
    memory: MemoryConfig = field(default_factory=MemoryConfig)
    voice: VoiceConfig = field(default_factory=VoiceConfig)
    body: BodyConfig = field(default_factory=BodyConfig)
    proactive_calls: ProactiveCallConfig = field(default_factory=ProactiveCallConfig)
    vision: VisionConfig = field(default_factory=VisionConfig)
    discord: DiscordConfig = field(default_factory=DiscordConfig)
    sage: SageConfig = field(default_factory=SageConfig)
    ui: UiConfig = field(default_factory=UiConfig)
    debug_traces: bool = True

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _merge_dataclass(instance: Any, values: dict[str, Any]) -> None:
    valid_fields = {item.name for item in fields(instance)}
    for key, value in values.items():
        if key not in valid_fields:
            continue
        current = getattr(instance, key)
        if is_dataclass(current) and isinstance(value, dict):
            _merge_dataclass(current, value)
        else:
            setattr(instance, key, value)


def load_config(path: Path) -> AppConfig:
    config = AppConfig()
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(config.to_dict(), indent=2), encoding="utf-8")
        return config

    raw = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError("config.json must contain a JSON object")
    raw_version = int(raw.get("config_version", 1))
    _merge_dataclass(config, raw)
    migrated = False
    if raw_version < 2:
        config.voice.allow_barge_in = False
        config.voice.block_milliseconds = 30
        config.voice.noise_calibration_seconds = 0.8
        config.voice.noise_floor_multiplier = 2.5
        config.voice.speech_start_seconds = 0.12
        config.voice.speech_hold_seconds = 0.09
        config.voice.speech_release_multiplier = 1.25
        config.voice.minimum_speech_seconds = 0.18
        config.voice.maximum_utterance_seconds = 20.0
        config.voice.silence_seconds = 0.7
        config.voice.speech_threshold = 0.006
        migrated = True
    if raw_version < 3:
        config.model.call_model = "qwen3:4b"
        config.model.call_context_tokens = 4096
        config.model.call_max_output_tokens = 120
        config.model.call_max_attempts = 1
        migrated = True
    if raw_version < 4:
        config.model.call_max_attempts = 2
        config.voice.transcription_window_seconds = 1.1
        config.voice.transcription_overlap_seconds = 0.18
        config.voice.transcript_idle_windows = 1
        migrated = True
    if raw_version < 5:
        config.voice.tts_backend = "kokoro"
        config.voice.voice = "af_sky"
        config.voice.kokoro_speed = 1.08
        migrated = True
    if raw_version < 6:
        config.model.call_context_tokens = 2048
        config.model.call_max_output_tokens = 64
        config.model.call_max_attempts = 1
        config.model.call_recent_turns = 5
        config.model.call_memory_limit = 1
        config.voice.transcription_window_seconds = 1.6
        config.voice.transcription_overlap_seconds = 0.75
        migrated = True
    if raw_version < 7:
        # Qwen 2.5 7B was more coherent than Qwen 3 4B in sustained live calls.
        config.model.call_model = "qwen2.5:7b-instruct"
        migrated = True
    if raw_version < 8:
        config.voice.silence_seconds = 1.15
        migrated = True
    if raw_version < 9:
        config.model.call_recent_turns = 3
        config.voice.kokoro_cpu_threads = 8
        migrated = True
    if raw_version < 11:
        # The frontier build is intentionally remote-only. The original local
        # runtime remains independent, so this migration cannot alter it.
        config.model.provider = "groq"
        config.model.endpoint = "https://api.groq.com/openai/v1"
        config.model.api_key_environment_variable = "GROQ_API_KEY"
        config.model.primary = "openai/gpt-oss-120b"
        config.model.fallback = ""
        config.model.call_model = "openai/gpt-oss-120b"
        config.model.reasoning_effort = "medium"
        config.model.call_reasoning_effort = "low"
        config.model.context_tokens = 8192
        config.model.call_context_tokens = 4096
        config.model.timeout_seconds = 45.0
        migrated = True
    if raw_version < 12:
        config.model.call_recent_turns = 3
        config.model.call_memory_limit = 2
        config.memory.retrieval_limit = 2
        config.memory.associative_packet_size = 2
        migrated = True
    if migrated:
        config.config_version = 12
        save_config(config, path)
    return config


def save_config(config: AppConfig, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(config.to_dict(), indent=2), encoding="utf-8")
    temporary.replace(path)
