from __future__ import annotations

import random
import queue
import re
import threading
import time
import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Callable
from uuid import uuid4

from .core import MakoCore
from .call_journal import CallJournal
from .model_backend import ModelError
from .recall_bridge import deep_recall_bridge
from .models import (
    ConversationEvent,
    EventSource,
    InteractionMode,
    OutboundCallPlan,
    ResponseResult,
)
from .voice import CallReflexes, VoiceEngine, VoiceUnavailable
from .xai_realtime_voice import XaiRealtimeVoiceSession, XaiVoiceCallbacks
from .prompts import XAI_VOICE_SYSTEM


LOG = logging.getLogger(__name__)


def _streamed_json_text(raw: str) -> str:
    match = re.search(r'"text"\s*:\s*"', raw)
    if match is None:
        return ""
    source = raw[match.end():]
    decoded: list[str] = []
    index = 0
    escapes = {'"': '"', "\\": "\\", "/": "/", "b": "\b", "f": "\f", "n": "\n", "r": "\r", "t": "\t"}
    while index < len(source):
        char = source[index]
        if char == '"':
            break
        if char != "\\":
            decoded.append(char)
            index += 1
            continue
        if index + 1 >= len(source):
            break
        escaped = source[index + 1]
        if escaped == "u":
            if index + 6 > len(source):
                break
            try:
                decoded.append(chr(int(source[index + 2:index + 6], 16)))
            except ValueError:
                break
            index += 6
            continue
        decoded.append(escapes.get(escaped, escaped))
        index += 2
    return "".join(decoded)


def _first_streaming_phrase(text: str) -> str:
    for match in re.finditer(r"[.!?](?:\s|$)", text):
        if len(re.findall(r"\S+", text[:match.end()])) >= 4:
            return text[:match.end()].strip()
    for match in re.finditer(r"[,;](?:\s|$)", text):
        if len(re.findall(r"\S+", text[:match.end()])) >= 5:
            return text[:match.end()].strip()
    words = list(re.finditer(r"\S+", text))
    if len(words) >= 3:
        # Some providers delay punctuation beyond the first useful clause. Starting at
        # three complete words keeps short call replies from waiting on full JSON.
        return text[:words[2].end()].strip()
    return ""


def _tts_acting(result: ResponseResult) -> tuple[str, str, str]:
    """Treat absent acting metadata as neutral instead of dropping live speech."""
    acting = result.acting if isinstance(result.acting, dict) else {}
    expression = getattr(result.expression, "value", result.expression)
    return (
        str(acting.get("vocal_cue", "none")),
        str(acting.get("delivery", "neutral")),
        str(expression or "neutral"),
    )


class _CallSpeechStream:
    def __init__(
        self,
        voice: VoiceEngine,
        on_done: Callable[[], None],
        on_started: Callable[[], None] | None = None,
    ) -> None:
        self.voice = voice
        self.on_done = on_done
        self.on_started = on_started
        self.raw = ""
        self.prefix = ""
        self.chunks: queue.Queue[str | None] = queue.Queue()
        self.started = False
        self._lock = threading.Lock()

    def on_token(self, token: str) -> None:
        with self._lock:
            if self.voice.config.tts_backend in {"elevenlabs_tts", "cartesia_tts"}:
                self.raw += token
                decoded = _streamed_json_text(self.raw)
                pending = decoded[len(self.prefix):]
                # Send complete clauses, never an arbitrary three-word fragment.
                boundary = re.search(r"[.!?;,]\s+", pending)
                if boundary is None:
                    return
                phrase = pending[:boundary.end()]
                if not phrase.strip():
                    return
                self.prefix += phrase
                if not self.started:
                    self.started = True
                    self.voice.speak_stream(
                        self.chunks, on_done=self.on_done, on_started=self.on_started
                    )
                self.chunks.put(phrase)
                return
            if self.started:
                return
            self.raw += token
            phrase = _first_streaming_phrase(_streamed_json_text(self.raw))
            if not phrase:
                return
            self.prefix = phrase
            self.started = True
            self.voice.speak_stream(
                self.chunks, on_done=self.on_done, on_started=self.on_started
            )
            self.chunks.put(phrase)
            LOG.info("Call streaming TTS started chars=%s", len(phrase))

    def finish(self, text: str) -> bool:
        with self._lock:
            if not self.started:
                return False
        # Flux treats adjacent streamed chunks as continuous text, so retain the
        # boundary whitespace instead of turning e.g. "hello." + "next" into "hello.next".
        if self.voice.config.tts_backend in {"elevenlabs_tts", "cartesia_tts"} and not text.startswith(self.prefix.rstrip()):
            LOG.warning("Final reply diverged from streamed speech; refusing to repeat the reply")
            self.abort()
            return True
        if self.voice.config.tts_backend in {"elevenlabs_tts", "cartesia_tts"}:
            remainder = text[min(len(text), len(self.prefix)):]
        else:
            remainder = text[len(self.prefix):] if text.startswith(self.prefix) else text
        if remainder and re.search(r"[\w]", remainder):
            if self.prefix and not self.prefix[-1].isspace() and not remainder[0].isspace():
                remainder = f" {remainder}"
            self.chunks.put(remainder)
        self.chunks.put(None)
        return True

    def abort(self) -> None:
        with self._lock:
            if self.started:
                self.chunks.put(None)
                if self.voice.config.tts_backend in {"elevenlabs_tts", "cartesia_tts"}:
                    self.voice.stop_speaking()


@dataclass(slots=True)
class _SpeculativeCall:
    provisional: str
    event: ConversationEvent
    cancel: threading.Event
    tokens: list[str]
    started_at: float
    finalized_at: float | None = None
    result: ResponseResult | None = None
    error: Exception | None = None
    final_text: str = ""
    validated: bool = False
    delivered: bool = False
    speech_stream: _CallSpeechStream | None = None


CALL_INVITATION_WORDS = frozenset(
    {"wanna", "want", "would", "could", "can", "should", "shall", "lets", "let's"}
)


def is_call_invitation(text: str) -> bool:
    """Recognize a direct request to move this desktop chat into a live call."""
    words = re.findall(r"[a-z]+", text.lower().replace("’", "'"))
    if "call" not in words:
        return False
    if {"me", "you"} & set(words):
        return True
    return bool(CALL_INVITATION_WORDS & set(words))


@dataclass(frozen=True, slots=True)
class CallCallbacks:
    on_state: Callable[[str], None]
    on_response: Callable[[ResponseResult], None]
    on_error: Callable[[str], None]
    on_offer: Callable[[OutboundCallPlan], None]
    # Finalized STT only: shell clients can show the same user turn the model receives.
    on_transcript: Callable[[str], None] = lambda _text: None
    # A recall cue is a first response segment, not a separate assistant turn.
    on_response_prefix: Callable[[str, str], None] = lambda _event_id, _text: None
    on_activity: Callable[[], None] = lambda: None


class CallSession:
    def __init__(
        self,
        core: MakoCore,
        voice: VoiceEngine,
        callbacks: CallCallbacks,
    ) -> None:
        self.core = core
        self.voice = voice
        self.callbacks = callbacks
        self.reflexes = CallReflexes()
        self._lock = threading.RLock()
        self._active = False
        self._connected = False
        self._pickup_timer: threading.Timer | None = None
        self._ring_timeout_timer: threading.Timer | None = None
        self._generation_thread: threading.Thread | None = None
        self._generation_cancel: threading.Event | None = None
        self._active_text = ""
        self._active_is_greeting = False
        self._active_text_only = False
        self._awaiting_replacement = False
        self._pending_inputs: list[tuple] = []
        self._outbound_pending = False
        self._outbound_plan: OutboundCallPlan | None = None
        self._channel_id = ""
        self._partial_text = ""
        self._voice_profile = ""
        self._speculative: _SpeculativeCall | None = None
        self._speculative_timer: threading.Timer | None = None
        self._xai_voice: XaiRealtimeVoiceSession | None = None
        self._journal: CallJournal | None = None
        warm_affect = getattr(self.voice, "start_affect_monitor", None)
        if callable(warm_affect):
            warm_affect()

    def _open_journal(self, transport: str) -> None:
        data_path = getattr(getattr(self.core, "paths", None), "data", None)
        self._journal = CallJournal(data_path, self._channel_id.replace(":", "_")) if data_path else None
        if self._journal is not None:
            self._journal.record("session_start", transport=transport)

    def _using_xai_realtime(self) -> bool:
        voice = getattr(getattr(self.core, "config", None), "voice", None)
        return str(getattr(voice, "call_backend", "pipeline")).lower() == "xai_realtime"

    @property
    def active(self) -> bool:
        with self._lock:
            return self._active

    @property
    def outbound_pending(self) -> bool:
        with self._lock:
            return self._outbound_pending

    def submit_text(self, text: str) -> bool:
        """Queue an in-app text turn on the active call conversation."""
        clean = text.strip()
        if not clean:
            return False
        with self._lock:
            if not self._active or not self._connected:
                return False
            realtime_voice = self._xai_voice
            if realtime_voice is not None:
                return realtime_voice.submit_text(clean)
            generation_busy = bool(
                self._generation_thread and self._generation_thread.is_alive()
            )
            if generation_busy:
                if not self._active_is_greeting and self._active_text:
                    self._pending_inputs.append(
                        (self._active_text, self._active_text_only)
                    )
                self._pending_inputs.append((clean, True))
                if self._generation_cancel:
                    self._generation_cancel.set()
                self.callbacks.on_state("updating thought")
                return True
        self._start_generation(clean, text_only=True)
        return True

    def start(self) -> None:
        with self._lock:
            if self._active:
                return
            self._active = True
            self._connected = False
            self._outbound_pending = False
            self._outbound_plan = None
            self._awaiting_replacement = False
            self._channel_id = f"call:{uuid4().hex}"
            self._open_journal("desktop_call")
            delay = random.uniform(
                self.core.config.voice.pickup_min_seconds,
                self.core.config.voice.pickup_max_seconds,
            )
            self._pickup_timer = threading.Timer(delay, self._pickup)
            self._pickup_timer.daemon = True
            self._pickup_timer.start()
        self._prewarm_call_model()
        self.callbacks.on_state("ringing")

    def offer_outbound(self, plan: OutboundCallPlan) -> bool:
        with self._lock:
            if self._active:
                return False
            self._active = True
            self._connected = False
            self._outbound_pending = True
            self._outbound_plan = plan
            self._channel_id = f"call:{uuid4().hex}"
            self._open_journal("outbound_call")
            timeout = self.core.config.proactive_calls.ring_timeout_seconds
            self._ring_timeout_timer = threading.Timer(
                timeout,
                lambda: self.decline_outbound("unanswered"),
            )
            self._ring_timeout_timer.daemon = True
            self._ring_timeout_timer.start()
        self._prewarm_call_model()
        self.callbacks.on_state("mako calling")
        self.callbacks.on_offer(plan)
        return True

    def _prewarm_call_model(self) -> None:
        channel_id = self._channel_id

        def warm() -> None:
            begin = getattr(self.core, "begin_call_conversation", None)
            if callable(begin):
                begin(channel_id)
            if not self.active:
                end = getattr(self.core, "end_call_conversation", None)
                if callable(end):
                    end(channel_id)
                return
            prewarm = getattr(self.core, "prewarm_call_model", None)
            if callable(prewarm) and not self._using_xai_realtime():
                prewarm()

        threading.Thread(target=warm, daemon=True).start()

    def accept_outbound(self) -> None:
        with self._lock:
            if not self._active or not self._outbound_pending or not self._outbound_plan:
                return
            plan = self._outbound_plan
            self._outbound_pending = False
            self._connected = True
            if self._ring_timeout_timer:
                self._ring_timeout_timer.cancel()
                self._ring_timeout_timer = None
        self.callbacks.on_state("connecting voice")
        threading.Thread(
            target=self._connect_outbound,
            args=(plan,),
            daemon=True,
        ).start()

    def decline_outbound(self, reason: str = "declined") -> None:
        with self._lock:
            if not self._active or not self._outbound_pending:
                return
            plan = self._outbound_plan
            self._active = False
            self._connected = False
            self._outbound_pending = False
            self._outbound_plan = None
            self._awaiting_replacement = False
            if self._ring_timeout_timer:
                self._ring_timeout_timer.cancel()
                self._ring_timeout_timer = None
            channel_id = self._channel_id
            journal = self._journal
            self._journal = None
        end = getattr(self.core, "end_call_conversation", None)
        if callable(end):
            end(channel_id)
        event = ConversationEvent(
            content=(
                "Mako called the user, but the call was not answered."
                if reason == "unanswered"
                else "Mako called the user, and the user declined the call."
            ),
            source=EventSource.VOICE_CALL,
            mode=InteractionMode.CALL,
            channel_id=self._channel_id,
            metadata={
                "call_event": f"outbound_{reason}",
                "prepared_reason": plan.reason if plan else "",
            },
        )
        self.core.record_call_reflex(event, "maybe another time.")
        if journal is not None:
            journal.close(connected=False, end_reason=reason)
        self.callbacks.on_state("offline")

    def hang_up(self) -> None:
        with self._lock:
            if not self._active:
                return
            was_connected = self._connected
            was_outbound = self._outbound_plan is not None
            self._active = False
            self._connected = False
            self._outbound_pending = False
            self._outbound_plan = None
            if self._pickup_timer:
                self._pickup_timer.cancel()
            if self._generation_cancel:
                self._generation_cancel.set()
            if self._speculative:
                self._speculative.cancel.set()
                self.core.discard_deferred_call_response(self._speculative.event.id)
                self._speculative = None
            if self._speculative_timer:
                self._speculative_timer.cancel()
                self._speculative_timer = None
            if self._ring_timeout_timer:
                self._ring_timeout_timer.cancel()
                self._ring_timeout_timer = None
            self._pending_inputs.clear()
            self._partial_text = ""
            channel_id = self._channel_id
            journal = self._journal
            self._journal = None
        realtime_voice = self._xai_voice
        self._xai_voice = None
        if realtime_voice is not None:
            realtime_voice.stop()
        self.voice.stop()
        if journal is not None:
            journal.close(connected=was_connected, transport="desktop_call")
        end = getattr(self.core, "end_call_conversation", None)
        if callable(end):
            end(channel_id)
        if not was_connected and not was_outbound:
            event = ConversationEvent(
                content="The user called and hung up before Mako answered.",
                source=EventSource.VOICE_CALL,
                mode=InteractionMode.CALL,
                channel_id=self._channel_id,
                metadata={"call_event": "missed_call"},
            )
            self.core.record_call_reflex(event, "i missed the call.")
        self.callbacks.on_state("offline")

    def _connect_outbound(self, plan: OutboundCallPlan) -> None:
        if self._using_xai_realtime():
            self._start_xai_realtime(
                "Mako initiated this call. Greet the user naturally and briefly."
            )
            return
        try:
            self._configure_continuous_transcript()
            self.voice.start(self._on_utterance, self.callbacks.on_state)
        except VoiceUnavailable as exc:
            self.callbacks.on_error(str(exc))
            self.hang_up()
            return
        self._speak_outbound_greeting(plan)

    def _speak_outbound_greeting(self, plan: OutboundCallPlan) -> None:
        if not self.active:
            return
        event = ConversationEvent(
            content="Mako initiated a live call and the user answered.",
            source=EventSource.VOICE_CALL,
            mode=InteractionMode.CALL,
            channel_id=self._channel_id,
            metadata={"call_event": "outbound_greeting", "prepared_reason": plan.reason},
        )
        result = self.core.record_call_reflex(
            event,
            plan.greeting,
            expression=plan.expression,
        )
        self.callbacks.on_response(result)
        try:
            self.voice.speak(
                plan.greeting,
                on_done=lambda: self._speak_outbound_opener(plan),
            )
        except VoiceUnavailable as exc:
            self.callbacks.on_error(str(exc))

    def _speak_outbound_opener(self, plan: OutboundCallPlan) -> None:
        if not self.active:
            return
        event = ConversationEvent(
            content=f"Mako called with a prepared callback: {plan.memory_basis}",
            source=EventSource.VOICE_CALL,
            mode=InteractionMode.CALL,
            channel_id=self._channel_id,
            metadata={
                "call_event": "outbound_opener",
                "prepared_reason": plan.reason,
                "memory_basis": plan.memory_basis,
            },
        )
        result = self.core.record_call_reflex(
            event,
            plan.opener,
            expression=plan.expression,
        )
        self.callbacks.on_response(result)
        try:
            body = getattr(self.core, "body", None)
            self.voice.speak(plan.opener, on_done=getattr(body, "speech_finished", None))
        except VoiceUnavailable as exc:
            self.callbacks.on_error(str(exc))

    def _pickup(self) -> None:
        with self._lock:
            if not self._active:
                return
            self._connected = True
        self.callbacks.on_state("connecting voice")
        if self._using_xai_realtime():
            self._start_xai_realtime(
                "A live call from the user just connected. Give one short, natural pickup greeting."
            )
            return
        try:
            self._configure_continuous_transcript()
            self.voice.start(self._on_utterance, self.callbacks.on_state)
        except VoiceUnavailable as exc:
            self.callbacks.on_error(str(exc))
            self.hang_up()
            return
        self._start_generation(
            "A live call from the user just connected. Give one short, natural pickup greeting.",
            is_greeting=True,
        )

    def _start_xai_realtime(self, opening_text: str) -> None:
        callbacks = XaiVoiceCallbacks(
            on_state=self.callbacks.on_state,
            on_turn=self._on_xai_voice_turn,
            on_error=self.callbacks.on_error,
        )
        try:
            # Kyutai stays responsible for capture and semantic endpointing;
            # xAI receives only completed text turns and supplies its own voice.
            self.voice.start(self._on_utterance, self.callbacks.on_state)
        except VoiceUnavailable as exc:
            self.callbacks.on_error(str(exc))
            self.hang_up()
            return
        session = XaiRealtimeVoiceSession(
            self.core.config.voice,
            callbacks,
            capture_microphone=False,
        )
        with self._lock:
            if not self._active or not self._connected:
                return
            self._xai_voice = session
        self.voice.set_stt_muted(True)
        session.start(XAI_VOICE_SYSTEM, opening_text)

    def _on_xai_voice_turn(
        self, user_text: str, response_text: str, elapsed: float, remaining_audio: float
    ) -> None:
        with self._lock:
            if not self._active or not self._connected:
                return
            channel_id = self._channel_id
        event = ConversationEvent(
            content=user_text,
            source=EventSource.VOICE_CALL,
            mode=InteractionMode.CALL,
            channel_id=channel_id,
            metadata={"call_event": "xai_realtime", "external_voice": True},
        )
        try:
            result = self.core.record_external_call_response(
                event,
                response_text,
                model=self.core.config.voice.xai_voice_model,
                generation_seconds=elapsed,
            )
        except Exception as exc:
            self.callbacks.on_error(f"couldn't save xAI voice turn: {exc}")
            return
        self.callbacks.on_response(result)
        threading.Timer(max(0.2, remaining_audio + 0.15), self.voice.set_stt_muted, args=(False,)).start()
        threading.Timer(max(0.8, remaining_audio + 0.15), self.core.body.speech_finished).start()

    def _configure_continuous_transcript(self) -> None:
        warm_affect = getattr(self.voice, "start_affect_monitor", None)
        if callable(warm_affect):
            warm_affect()
        setter = getattr(self.voice, "set_partial_transcript_callback", None)
        if callable(setter):
            setter(self._on_partial_transcript)
        semantic_eot_setter = getattr(self.voice, "set_semantic_eot_callback", None)
        if callable(semantic_eot_setter):
            semantic_eot_setter(self._on_semantic_eot)
        profile_setter = getattr(self.voice, "set_voice_profile_callback", None)
        if callable(profile_setter):
            profile_setter(self._on_voice_profile)

    def _on_voice_profile(self, summary: str) -> None:
        with self._lock:
            if self._active and self._connected:
                self._voice_profile = summary
                body = self.core.body
            else:
                body = None
        if body is not None:
            # Profile updates arrive while the user is still speaking. Drive a
            # lightweight listener reaction now; the text model still receives
            # the same evidence only when the turn is finalized.
            body.apply_listener_profile(summary)

    def _take_voice_profile(self) -> str:
        with self._lock:
            summary = self._voice_profile
            self._voice_profile = ""
            return summary

    @staticmethod
    def _normalize_speculative_text(text: str) -> str:
        return " ".join(text.casefold().split()).rstrip(".!? ")

    def _on_semantic_eot(self, text: str) -> None:
        """Start speculative generation that can only survive exact STT validation."""
        provisional = text.strip()
        if not provisional or not self.core.config.model.call_speculative_generation:
            return
        with self._lock:
            if (
                not self._active
                or not self._connected
                or self._speculative is not None
                or (self._generation_thread and self._generation_thread.is_alive())
            ):
                return
            event = ConversationEvent(
                content=provisional,
                source=EventSource.VOICE_CALL,
                mode=InteractionMode.CALL,
                channel_id=self._channel_id,
                metadata={"call_event": "utterance", "speculative": True},
            )
            speculative = _SpeculativeCall(
                provisional=provisional,
                event=event,
                cancel=threading.Event(),
                tokens=[],
                started_at=time.monotonic(),
            )
            self._speculative = speculative
        LOG.info("Call speculative generation started chars=%s", len(provisional))
        self.callbacks.on_state("thinking")
        threading.Thread(
            target=self._speculative_worker,
            args=(speculative,),
            daemon=True,
        ).start()

    def _speculative_worker(self, speculative: _SpeculativeCall) -> None:
        def on_token(token: str) -> None:
            with self._lock:
                if speculative is not self._speculative:
                    return
                speculative.tokens.append(token)
                stream = speculative.speech_stream if speculative.validated else None
            if stream:
                stream.on_token(token)

        try:
            result = self.core.respond(
                speculative.event,
                cancel=speculative.cancel,
                on_token=on_token,
                defer_commit=True,
            )
        except Exception as exc:
            fallback_text = ""
            with self._lock:
                speculative.error = exc
                if (
                    speculative is self._speculative
                    and speculative.validated
                    and self._active
                    and not speculative.cancel.is_set()
                ):
                    fallback_text = speculative.final_text
                    self._speculative = None
            self.core.discard_deferred_call_response(speculative.event.id)
            if not speculative.cancel.is_set():
                LOG.warning("Call speculative generation failed: %s", exc)
            if fallback_text:
                self._start_generation(fallback_text, finalized_at=speculative.finalized_at)
        else:
            with self._lock:
                speculative.result = result
            LOG.info(
                "Call speculative generation complete wall=%.3fs model=%.3fs",
                time.monotonic() - speculative.started_at,
                result.generation_seconds,
            )
        self._deliver_speculative_if_ready(speculative)

    def _deliver_speculative_if_ready(self, speculative: _SpeculativeCall) -> None:
        with self._lock:
            if (
                speculative is not self._speculative
                or not speculative.validated
                or speculative.delivered
                or speculative.result is None
                or speculative.cancel.is_set()
                or not self._active
            ):
                return
            speculative.delivered = True
            self._speculative = None
            result = speculative.result
            stream = speculative.speech_stream
        try:
            self.core.commit_deferred_call_response(speculative.event, result)
            result.trace["call_text_only"] = False
            result.trace["speculative_call_generation"] = True
            self.callbacks.on_response(result)
            if stream and stream.finish(result.text):
                return
            vocal_cue, delivery, mood = _tts_acting(result)
            self.voice.speak(
                result.text,
                on_done=self.core.body.speech_finished,
                vocal_cue=vocal_cue,
                delivery=delivery,
                mood=mood,
                on_started=lambda: self._log_call_audio_start(speculative.finalized_at),
            )
        except Exception as exc:
            LOG.exception("Call speculative speech dispatch failed")
            self.callbacks.on_error(str(exc))

    def _validate_speculative(self, text: str, *, voice_profile: str = "") -> bool:
        with self._lock:
            speculative = self._speculative
            if speculative is None:
                return False
            matches = (
                self._normalize_speculative_text(speculative.provisional)
                == self._normalize_speculative_text(text)
            )
            if not matches:
                speculative.cancel.set()
                self.core.discard_deferred_call_response(speculative.event.id)
                self._speculative = None
                LOG.info("Call speculative generation discarded: finalized transcript changed")
                return False
            if speculative.error is not None:
                self.core.discard_deferred_call_response(speculative.event.id)
                self._speculative = None
                return False
            speculative.event.content = text
            # Final transcript-derived affect arrives after speculative
            # generation starts. Attach it before validation can deliver a
            # result that finished early, avoiding a timing-dependent loss of
            # the user's vocal/emotional context.
            if voice_profile:
                speculative.event.metadata["voice_profile"] = voice_profile
            speculative.final_text = text
            speculative.finalized_at = time.monotonic()
            speculative.validated = True
            stream = (
                _CallSpeechStream(
                    self.voice,
                    self.core.body.speech_finished,
                    on_started=lambda: self._log_call_audio_start(speculative.finalized_at),
                )
                if self.core.config.model.call_streaming_tts
                else None
            )
            speculative.speech_stream = stream
            tokens = list(speculative.tokens)
        LOG.info(
            "Call speculative generation validated seconds=%.3f buffered_tokens=%s",
            time.monotonic() - speculative.started_at,
            len(tokens),
        )
        if stream:
            for token in tokens:
                stream.on_token(token)
        self._deliver_speculative_if_ready(speculative)
        return True

    def _on_partial_transcript(self, text: str) -> None:
        """Track revised STT continuously without committing unfinished speech."""
        provisional = text.strip()
        with self._lock:
            if not self._active or not self._connected or text == self._partial_text:
                return
            self._partial_text = text
            if self._speculative_timer:
                self._speculative_timer.cancel()
                self._speculative_timer = None
            speculative = self._speculative
            if speculative and self._normalize_speculative_text(speculative.provisional) != self._normalize_speculative_text(provisional):
                speculative.cancel.set()
                self.core.discard_deferred_call_response(speculative.event.id)
                self._speculative = None
            # Scribe has no semantic-EOT callback. A stable, punctuated partial
            # is its conservative equivalent; the final transcript still must
            # match before any speculative answer can be committed or spoken.
            if (
                provisional
                and self.core.config.model.call_speculative_generation
                and re.search(r"[.!?]$", provisional)
            ):
                timer = threading.Timer(
                    0.12, self._start_stable_partial_speculation, args=(provisional,)
                )
                timer.daemon = True
                self._speculative_timer = timer
                timer.start()
            journal = self._journal
            generation_busy = bool(
                self._generation_thread and self._generation_thread.is_alive()
            )
            if generation_busy and not self._active_is_greeting and self._generation_cancel:
                self._generation_cancel.set()
                self.callbacks.on_state("updating thought")
        self.callbacks.on_activity()
        set_affect_text = getattr(self.voice, "set_affect_partial_text", None)
        if callable(set_affect_text):
            set_affect_text("owner", text)
        if journal is not None:
            journal.record(
                "transcript_partial", speaker_id="owner", speaker_name="Prince Moffle",
                text=text,
            )

    def _start_stable_partial_speculation(self, provisional: str) -> None:
        with self._lock:
            if self._speculative_timer is not None:
                self._speculative_timer = None
            if (
                not self._active
                or not self._connected
                or self._partial_text.strip() != provisional
            ):
                return
        self._on_semantic_eot(provisional)

    def _on_utterance(self, text: str) -> None:
        finalized_at = time.monotonic()
        with self._lock:
            if not self._active or not self._connected:
                return
            self._partial_text = ""
            if self._speculative_timer:
                self._speculative_timer.cancel()
                self._speculative_timer = None
            realtime_voice = self._xai_voice
        self.callbacks.on_transcript(text)
        voice_profile = self._take_voice_profile()
        snapshot_affect = getattr(self.voice, "affect_snapshot", None)
        if callable(snapshot_affect):
            affect = snapshot_affect("owner")
        else:
            from .affect import AffectState
            affect = AffectState()
        affect_text = affect.compact()
        if affect_text:
            voice_profile = "; ".join(part for part in (voice_profile, affect_text) if part)
        with self._lock:
            journal = self._journal
        if journal is not None:
            journal.record(
                "user_turn", speaker_id="owner", speaker_name="Prince Moffle", text=text,
                affect=affect.to_dict(), voice_profile=voice_profile,
            )
        if realtime_voice is not None:
            self.voice.set_stt_muted(True)
            if realtime_voice.submit_text(text):
                self.callbacks.on_state("thinking")
                return
            self.voice.set_stt_muted(False)
            self.callbacks.on_error("xAI voice is not ready for this Kyutai turn.")
            return
        if self._validate_speculative(text, voice_profile=voice_profile):
            return
        with self._lock:
            if not self._active or not self._connected:
                return
            generation_busy = bool(
                self._generation_thread and self._generation_thread.is_alive()
            )
            awaiting_replacement = self._awaiting_replacement
            if awaiting_replacement:
                self._awaiting_replacement = False
                self._pending_inputs.clear()
            if generation_busy and self.reflexes.is_presence_check(text):
                response = self.reflexes.presence_response(self.core.mood.prompt_summary())
                event = ConversationEvent(
                    content=text,
                    source=EventSource.VOICE_CALL,
                    mode=InteractionMode.CALL,
                    channel_id=self._channel_id,
                    metadata={"call_event": "presence_check", "local_reflex": True},
                )
                result = self.core.record_call_reflex(event, response)
                self.callbacks.on_response(result)
                try:
                    self.voice.speak(response)
                except VoiceUnavailable as exc:
                    self.callbacks.on_error(str(exc))
                return

            if generation_busy:
                if not self._active_is_greeting and self._active_text:
                    self._pending_inputs.append(
                        (self._active_text, self._active_text_only)
                    )
                self._pending_inputs.append((text, False, finalized_at))
                if self._generation_cancel:
                    self._generation_cancel.set()
                self.callbacks.on_state("updating thought")
                return

        self._start_generation(text, voice_profile=voice_profile, finalized_at=finalized_at)

    @staticmethod
    def _log_call_audio_start(finalized_at: float | None) -> None:
        if finalized_at is None:
            return
        elapsed = max(0.0, time.monotonic() - finalized_at)
        LOG.info("Call finalized-utterance to first-audio seconds=%.3f", elapsed)

    def _start_generation(
        self,
        text: str,
        *,
        is_greeting: bool = False,
        text_only: bool = False,
        voice_profile: str = "",
        interface_context: dict | None = None,
        social_state: dict | None = None,
        finalized_at: float | None = None,
    ) -> None:
        with self._lock:
            if not self._active or not self._connected:
                return
            self._active_text = text
            self._active_is_greeting = is_greeting
            self._active_text_only = text_only
            cancel = threading.Event()
            self._generation_cancel = cancel
            thread = threading.Thread(
                target=self._generation_worker,
                args=(text, is_greeting, text_only, voice_profile, cancel, interface_context, social_state, finalized_at),
                daemon=True,
            )
            self._generation_thread = thread
            thread.start()
        self.callbacks.on_state("thinking")

    def submit_interface_event(self, context: dict) -> bool:
        """Admit a UI comment only between human turns and speech playback."""
        with self._lock:
            if not self._active or not self._connected or self._xai_voice is not None:
                return False
            if (self._generation_thread and self._generation_thread.is_alive()) or self._partial_text:
                return False
            if getattr(self.voice, "_speaking", threading.Event()).is_set():
                return False
            self._start_generation(str(context["summary"]), interface_context=context)
            return True

    def _generation_worker(
        self,
        text: str,
        is_greeting: bool,
        text_only: bool,
        voice_profile: str,
        cancel: threading.Event,
        interface_context: dict | None = None,
        social_state: dict | None = None,
        finalized_at: float | None = None,
    ) -> None:
        event = ConversationEvent(
            content=text,
            source=EventSource.SYSTEM if interface_context else EventSource.DESKTOP if text_only else EventSource.VOICE_CALL,
            mode=InteractionMode.CALL,
            channel_id=self._channel_id,
            metadata={
                "call_event": (
                    "pickup" if is_greeting else "typed_message" if text_only else "utterance"
                ),
                "call_text_only": text_only,
                "voice_profile": voice_profile,
                "conversation_state": social_state or {},
            },
        )
        if interface_context:
            event.metadata["interface_event"] = interface_context
        result: ResponseResult | None = None
        # The cue starts only after normal fast-generation budget has elapsed.
        # If it starts, Core folds it into the one persisted assistant response.
        recall_bridge = None if text_only or is_greeting or interface_context else deep_recall_bridge(text)
        generation_started_at = time.monotonic()
        response_ready = threading.Event()
        bridge_started = threading.Event()
        bridge_finished = threading.Event()

        def begin_recall_bridge() -> None:
            if response_ready.is_set() or cancel.is_set() or not recall_bridge:
                return
            bridge_started.set()
            event.metadata["response_prefix"] = recall_bridge
            event.metadata["response_prefix_started_at"] = time.time()
            self.callbacks.on_state("remembering")
            self.callbacks.on_response_prefix(event.id, recall_bridge)
            self.core.body.processing()
            LOG.info(
                "Call recall cue started eot_to_cue=%.3fs text=%r",
                time.monotonic() - generation_started_at,
                recall_bridge,
            )
            try:
                self.voice.speak(
                    recall_bridge,
                    on_done=bridge_finished.set,
                    vocal_cue="hmm",
                    delivery="soft",
                )
            except VoiceUnavailable as exc:
                LOG.warning("Call recall cue unavailable: %s", exc)
                bridge_finished.set()

        bridge_timer = threading.Timer(0.7, begin_recall_bridge) if recall_bridge else None
        if bridge_timer:
            bridge_timer.daemon = True
            bridge_timer.start()
        speech_stream = (
            _CallSpeechStream(
                self.voice,
                self.core.body.speech_finished,
                on_started=lambda: self._log_call_audio_start(finalized_at),
            )
            if self.core.config.model.call_streaming_tts and not text_only and not recall_bridge and not interface_context
            else None
        )
        started_at = generation_started_at
        try:
            result = self.core.respond(
                event,
                cancel=cancel,
                on_token=speech_stream.on_token if speech_stream else None,
            )
        except ModelError as exc:
            if speech_stream:
                speech_stream.abort()
            if not cancel.is_set():
                self.callbacks.on_error(str(exc))
        except Exception as exc:
            if speech_stream:
                speech_stream.abort()
            self.callbacks.on_error(str(exc))
        finally:
            response_ready.set()
            if bridge_timer:
                bridge_timer.cancel()

        if result is not None:
            with self._lock:
                journal = self._journal
            if journal is not None:
                journal.record(
                    "assistant_turn", addressed_to=(social_state or {}).get("speaker_name", "Prince Moffle"),
                    text=result.text, model=result.model, generation_seconds=result.generation_seconds,
                    turn_id=result.turn_id, expression=str(result.expression), move=result.move,
                )
            LOG.info(
                "Call model timing wall=%.3fs model=%.3fs model_name=%s",
                time.monotonic() - started_at,
                result.generation_seconds,
                result.model,
            )

        with self._lock:
            should_deliver = bool(result and self._active and not cancel.is_set())
            pending_items = list(dict.fromkeys(self._pending_inputs))
            pending = "\n".join(item[0] for item in pending_items).strip()
            pending_text_only = pending_items[-1][1] if pending_items else False
            pending_finalized_at = (
                pending_items[-1][2]
                if pending_items and len(pending_items[-1]) > 2
                else None
            )
            self._pending_inputs.clear()
            self._generation_thread = None
            self._generation_cancel = None
            self._active_text = ""
            self._active_is_greeting = False
            self._active_text_only = False

        if should_deliver and result:
            result.trace["call_text_only"] = text_only
            self.callbacks.on_response(result)
            try:
                if bridge_started.is_set():
                    # Retrieval ran during the cue. Do not let two speech streams
                    # overlap if Qwen returns before it has finished playing.
                    bridge_finished.wait(timeout=5.0)
                spoken_text = result.text
                if recall_bridge and result.trace.get("response_prefix") == recall_bridge:
                    # The prefix is already audible. Keep the persisted/UI turn
                    # whole, but do not say that first sentence twice.
                    spoken_text = result.text[len(recall_bridge):].lstrip()
                if text_only:
                    self.callbacks.on_state("call connected")
                elif result.model == "local-safety-net":
                    # A rejected transcript is discarded. Wait for the user to replace it.
                    with self._lock:
                        self._awaiting_replacement = True
                    if speech_stream:
                        speech_stream.abort()
                    self.voice.speak(
                        spoken_text,
                        on_done=self.core.body.speech_finished,
                        on_started=lambda: self._log_call_audio_start(finalized_at),
                    )
                    return
                elif not speech_stream or not speech_stream.finish(spoken_text):
                    vocal_cue, delivery, mood = _tts_acting(result)
                    self.voice.speak(
                        spoken_text,
                        on_done=self.core.body.speech_finished,
                        vocal_cue=vocal_cue,
                        delivery=delivery,
                        mood=mood,
                        on_started=lambda: self._log_call_audio_start(finalized_at),
                    )
            except Exception as exc:
                LOG.exception("Call speech dispatch failed")
                self.callbacks.on_error(str(exc))
        elif speech_stream:
            speech_stream.abort()
        if pending and self.active:
            self._start_generation(
                pending,
                text_only=pending_text_only,
                finalized_at=pending_finalized_at,
            )
        elif self.active and not should_deliver:
            self.callbacks.on_state("call connected")
