from __future__ import annotations

import asyncio
import base64
import json
import logging
import os
import queue
import threading
from collections.abc import Callable
from typing import Any


LOG = logging.getLogger(__name__)
SAMPLE_RATE = 16_000
CHUNK_SAMPLES = 1_600  # 100 ms at 16 kHz, matching Inworld's reference client.


class InworldSTTError(RuntimeError):
    pass


def inworld_api_key(environment_variable: str) -> str:
    key = os.getenv(environment_variable, "").strip()
    if not key and os.name == "nt":
        try:
            import winreg

            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as registry_key:
                value, _ = winreg.QueryValueEx(registry_key, environment_variable)
            key = str(value).strip()
        except OSError:
            pass
    if not key:
        raise InworldSTTError(f"Inworld STT needs {environment_variable}.")
    return key


def summarize_voice_profile(profile: dict[str, Any], threshold: float = 0.55) -> str:
    """Return only useful, high-confidence paralinguistic evidence for the LLM."""
    labels: list[str] = []
    field_names = (
        ("emotion", "emotion"),
        ("vocalStyle", "vocal style"),
        ("vocal_style", "vocal style"),
        ("pitch", "pitch"),
        ("age", "apparent age range"),
        ("accent", "possible accent"),
    )
    seen: set[str] = set()
    for source_name, display_name in field_names:
        if display_name in seen:
            continue
        values = profile.get(source_name)
        if not isinstance(values, list) or not values:
            continue
        best = values[0] if isinstance(values[0], dict) else {}
        label = str(best.get("label", "")).strip()
        try:
            confidence = float(best.get("confidence", 0.0))
        except (TypeError, ValueError):
            confidence = 0.0
        if not label or label == "unclear" or confidence < threshold:
            continue
        labels.append(f"{display_name}={label} ({confidence:.0%})")
        seen.add(display_name)
    return ", ".join(labels)


class InworldSTTClient:
    """Persistent Inworld STT-1 stream for microphone or injected mono audio."""

    def __init__(
        self,
        *,
        api_key_environment_variable: str,
        input_device: int | None,
        language: str,
        profile_threshold: float,
        eot_confidence_threshold: float,
        min_eot_silence_ms: int,
        max_turn_silence_ms: int,
        on_utterance: Callable[[str], None],
        on_partial: Callable[[str], None] | None,
        on_voice_profile: Callable[[str], None] | None,
        on_status: Callable[[str], None],
        on_audio: Callable[[object, int], None] | None = None,
        capture_microphone: bool = True,
    ) -> None:
        self.api_key_environment_variable = api_key_environment_variable
        self.input_device = input_device
        self.language = language
        self.profile_threshold = profile_threshold
        self.eot_confidence_threshold = eot_confidence_threshold
        self.min_eot_silence_ms = min_eot_silence_ms
        self.max_turn_silence_ms = max_turn_silence_ms
        self.on_utterance = on_utterance
        self.on_partial = on_partial
        self.on_voice_profile = on_voice_profile
        self.on_status = on_status
        self.on_audio = on_audio
        self.capture_microphone = capture_microphone

        self._loop = asyncio.new_event_loop()
        self._ready = threading.Event()
        self._startup_error: BaseException | None = None
        self._thread: threading.Thread | None = None
        self._stream = None
        self._audio_queue: asyncio.Queue[bytes | dict[str, object] | None] | None = None
        self._native_rate = SAMPLE_RATE
        self._capture_buffer = None
        self._capture_lock = threading.Lock()
        self._muted = True

    def start(self, timeout_seconds: float = 10.0) -> None:
        import numpy as np
        import sounddevice as sd

        self._capture_buffer = np.empty(0, dtype=np.float32)
        self._thread = threading.Thread(target=self._run_loop, name="inworld-stt", daemon=True)
        self._thread.start()
        if not self._ready.wait(timeout=timeout_seconds):
            self.stop()
            raise InworldSTTError("Inworld STT did not become ready in time")
        if self._startup_error is not None:
            error = self._startup_error
            self.stop()
            raise InworldSTTError(f"Could not connect to Inworld STT: {error}") from error

        if not self.capture_microphone:
            self._muted = False
            self.on_status("Inworld STT ready for injected audio")
            return

        self.on_status("starting microphone")
        try:
            device_info = sd.query_devices(self.input_device, "input")
            native_rate = int(round(float(device_info["default_samplerate"])))
            self._native_rate = native_rate if native_rate > 0 else SAMPLE_RATE
            blocksize = max(160, round(self._native_rate * 0.05))
            self._stream = sd.InputStream(
                callback=self._audio_callback,
                channels=1,
                device=self.input_device,
                samplerate=self._native_rate,
                blocksize=blocksize,
                dtype="float32",
            )
            self._stream.start()
        except Exception as exc:
            if self._stream is not None:
                try:
                    self._stream.close()
                except Exception:
                    pass
                self._stream = None
            raise InworldSTTError(
                f"Could not open microphone device {self.input_device}: {exc}"
            ) from exc
        self._muted = False
        self.on_status("call connected")

    def stop(self) -> None:
        self._muted = True
        if self._stream is not None:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception:
                pass
            self._stream = None
        queue_ref = self._audio_queue
        if queue_ref is not None and self._loop.is_running():
            self._loop.call_soon_threadsafe(self._enqueue_control, None)
        thread = self._thread
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=5)
        self._thread = None

    def set_muted(self, muted: bool) -> None:
        self._muted = muted
        if not muted:
            with self._capture_lock:
                if self._capture_buffer is not None:
                    self._capture_buffer = self._capture_buffer[:0]

    def push_audio(self, samples, sample_rate: int) -> None:
        if self.capture_microphone:
            raise InworldSTTError("push_audio is only available in injected-audio mode")
        self._feed_samples(samples, sample_rate)

    def end_turn(self) -> None:
        if self._loop.is_running():
            self._loop.call_soon_threadsafe(self._enqueue_control, {"endTurn": {}})

    def _run_loop(self) -> None:
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._run())
        except BaseException as exc:
            if not self._ready.is_set():
                self._startup_error = exc
            else:
                LOG.exception("Inworld STT connection failed")
                self.on_status(f"voice error: Inworld STT disconnected: {exc}")
        finally:
            self._ready.set()
            self._loop.close()

    async def _run(self) -> None:
        import aiohttp

        self._audio_queue = asyncio.Queue(maxsize=256)
        timeout = aiohttp.ClientTimeout(total=None, sock_connect=10, sock_read=None)
        headers = {"Authorization": f"Basic {inworld_api_key(self.api_key_environment_variable)}"}
        async with aiohttp.ClientSession(timeout=timeout, headers=headers) as session:
            async with session.ws_connect(
                "wss://api.inworld.ai/stt/v1/transcribe:streamBidirectional",
                max_msg_size=0,
                heartbeat=20,
            ) as websocket:
                await websocket.send_json(
                    {
                        "transcribeConfig": {
                            "modelId": "inworld/inworld-stt-1",
                            "audioEncoding": "LINEAR16",
                            "sampleRateHertz": SAMPLE_RATE,
                            "numberOfChannels": 1,
                            "language": "en" if self.language.lower().startswith("en") else self.language,
                            "endOfTurnConfidenceThreshold": self.eot_confidence_threshold,
                            "inworldSttV1Config": {
                                "minEndOfTurnSilenceWhenConfident": self.min_eot_silence_ms,
                                "maxTurnSilence": self.max_turn_silence_ms,
                            },
                            "voiceProfileConfig": {"enableVoiceProfile": True, "topN": 3},
                        }
                    }
                )
                LOG.info("Inworld STT websocket ready")
                self._ready.set()
                sender = asyncio.create_task(self._send_loop(websocket))
                receiver = asyncio.create_task(self._receive_loop(websocket))
                done, pending = await asyncio.wait(
                    {sender, receiver}, return_when=asyncio.FIRST_COMPLETED
                )
                for task in pending:
                    task.cancel()
                await asyncio.gather(*pending, return_exceptions=True)
                for task in done:
                    task.result()

    async def _send_loop(self, websocket) -> None:
        assert self._audio_queue is not None
        while True:
            item = await self._audio_queue.get()
            if item is None:
                await websocket.send_json({"closeStream": {}})
                return
            if isinstance(item, dict):
                await websocket.send_json(item)
                continue
            await websocket.send_json(
                {"audioChunk": {"content": base64.b64encode(item).decode("ascii")}}
            )

    async def _receive_loop(self, websocket) -> None:
        import aiohttp

        async for message in websocket:
            if message.type == aiohttp.WSMsgType.ERROR:
                raise InworldSTTError(str(websocket.exception()))
            if message.type != aiohttp.WSMsgType.TEXT:
                continue
            payload = json.loads(message.data)
            if payload.get("error"):
                raise InworldSTTError(str(payload["error"]))
            result = payload.get("result") or {}
            profile = result.get("voiceProfile") or result.get("voice_profile") or {}
            if isinstance(profile, dict) and self.on_voice_profile:
                summary = summarize_voice_profile(profile, self.profile_threshold)
                if summary:
                    self.on_voice_profile(summary)
            transcription = result.get("transcription") or {}
            text = str(transcription.get("transcript", "")).strip()
            if not text:
                continue
            if transcription.get("isFinal"):
                LOG.info("Inworld STT committed transcript chars=%s", len(text))
                self.on_utterance(text)
            elif self.on_partial:
                self.on_partial(text)

    def _audio_callback(self, in_data, frames, timing, status) -> None:
        del frames, timing
        if status:
            LOG.debug("Inworld microphone status: %s", status)
        if self._muted or in_data is None:
            return
        self._feed_samples(in_data, self._native_rate)

    def _feed_samples(self, input_samples, sample_rate: int) -> None:
        if self._muted or input_samples is None or not self._loop.is_running():
            return
        import numpy as np

        samples = np.asarray(input_samples, dtype=np.float32).reshape(-1)
        if self.on_audio:
            try:
                self.on_audio(samples.copy(), sample_rate)
            except Exception:
                LOG.debug("Inworld audio observer failed", exc_info=True)
        if sample_rate != SAMPLE_RATE and samples.size:
            target_size = max(1, round(samples.size * SAMPLE_RATE / sample_rate))
            samples = np.interp(
                np.linspace(0.0, samples.size - 1, num=target_size),
                np.arange(samples.size),
                samples,
            ).astype(np.float32)
        with self._capture_lock:
            self._capture_buffer = np.concatenate((self._capture_buffer, samples))
            while self._capture_buffer.size >= CHUNK_SAMPLES:
                frame = self._capture_buffer[:CHUNK_SAMPLES].copy()
                self._capture_buffer = self._capture_buffer[CHUNK_SAMPLES:]
                pcm = (np.clip(frame, -1.0, 1.0) * 32767.0).astype("<i2").tobytes()
                self._loop.call_soon_threadsafe(self._enqueue_control, pcm)

    def _enqueue_control(self, item: bytes | dict[str, object] | None) -> None:
        queue_ref = self._audio_queue
        if queue_ref is None:
            return
        if queue_ref.full():
            if isinstance(item, bytes):
                LOG.warning("Inworld STT audio queue overflow; dropping one chunk")
            return
        queue_ref.put_nowait(item)
