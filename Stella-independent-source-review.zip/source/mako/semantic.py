from __future__ import annotations

import json
import re
import sqlite3
from contextlib import contextmanager
import threading
from dataclasses import asdict, dataclass, field
from pathlib import Path
from time import perf_counter
from typing import Any


@dataclass(slots=True)
class SemanticAnalysis:
    act: str = "unknown"
    confidence: float = 0.0
    frame: str = "neutral"
    target: str = ""
    meaning: str = ""
    response_goal: str = "respond naturally"
    avoid: list[str] = field(default_factory=list)
    events: list[str] = field(default_factory=list)
    prior_mako_move: str = ""
    latency_ms: float = 0.0
    rule_ms: float = 0.0
    embedding_ms: float = 0.0
    syntax_ms: float = 0.0
    fusion_ms: float = 0.0

    def packet(self) -> str:
        """Compact factual guidance placed after the cached conversation prefix."""
        lines = [f"act: {self.act}", f"frame: {self.frame}"]
        if self.prior_mako_move:
            lines.append(f"prior_mako_move: {self.prior_mako_move}")
        for label, value in (("target", self.target), ("meaning", self.meaning), ("response_goal", self.response_goal)):
            if value:
                lines.append(f"{label}: {value}")
        if self.avoid:
            lines.append("avoid: " + "; ".join(self.avoid))
        return "SEMANTIC TURN:\n" + "\n".join(lines)


class SemanticEngine:
    """Fast, conservative conversation evidence. It never writes Mako's reply."""

    def __init__(self, database_path: Path) -> None:
        self.database_path = database_path
        self._lock = threading.RLock()
        self._state: dict[str, Any] = {"last_mako_act": "", "frame": "neutral", "age": 0}
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as connection:
            connection.execute(
                """CREATE TABLE IF NOT EXISTS semantic_turns (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    event_id TEXT, user_text TEXT NOT NULL, analysis_json TEXT NOT NULL,
                    response_text TEXT, validation_json TEXT
                )"""
            )
            connection.execute(
                """CREATE TABLE IF NOT EXISTS semantic_state (
                    state_key TEXT PRIMARY KEY, state_json TEXT NOT NULL
                )"""
            )
            row = connection.execute(
                "SELECT state_json FROM semantic_state WHERE state_key = 'dialogue'"
            ).fetchone()
            if row:
                self._state.update(json.loads(str(row[0])))

    def analyze(
        self,
        *,
        event_id: str,
        user_text: str,
        history: list[tuple[str, str]],
        channel_id: str = "",
    ) -> SemanticAnalysis:
        started = perf_counter()
        text = user_text.lower().strip()
        previous = history[-1][1].lower() if history else ""
        rule_started = perf_counter()
        analysis = self._rules(text, previous)
        analysis.prior_mako_move = self._infer_mako_move(previous)
        analysis.rule_ms = (perf_counter() - rule_started) * 1000
        analysis.fusion_ms = 0.0
        analysis.latency_ms = (perf_counter() - started) * 1000
        return analysis

    @staticmethod
    def guidance_ready(analysis: SemanticAnalysis) -> bool:
        """Only inject acts whose evidence is stronger than their harm profile."""
        thresholds = {
            "topic_boundary": 0.90,
            "availability_check": 0.90,
            "clarification_repair": 0.88,
            "call_invitation": 0.90,
            "shared_work_update": 0.88,
            "emotional_disclosure": 0.86,
            "relationship_reflection": 0.88,
            "affection_reassurance": 0.90,
            "correction": 0.92,
            "playful_boundary": 0.84,
            "conversation_recap": 0.94,
            "closed_acknowledgment": 0.94,
        }
        return analysis.confidence >= thresholds.get(analysis.act, 1.01)

    @staticmethod
    def _infer_mako_move(previous: str) -> str:
        if not previous:
            return ""
        if re.search(r"\b(?:watch|movie|show|game|activity|plan)\b", previous):
            return "suggested an activity"
        if "?" in previous:
            return "asked a question"
        if re.search(r"\b(?:i think|i meant|what i meant|because)\b", previous):
            return "made a claim or explanation"
        return ""

    def _rules(self, text: str, previous: str) -> SemanticAnalysis:
        playful = any(word in text for word in ("lol", "lmao", "goober", "dumb", "idiot", "bruh", "how dare", "creator"))
        correction_patterns = (
            r"\bwe(?:'re| are) (?:literally |already |in ).{0,36}\b(chat|talking|doing)\b",
            r"\b(?:that's not what|you got that|you got it) (?:i said|backwards|wrong)\b",
            r"\byou already (?:asked|said)\b",
            r"\bi said .{0,56}\b(?:not me|not you|not a code)\b",
        )
        if any(re.search(pattern, text) for pattern in correction_patterns):
            frame = "playful" if playful or "mako" in text else "direct"
            return SemanticAnalysis("correction", 0.96, frame, "mako_previous_claim", "user corrects Mako's immediately prior claim", "acknowledge the correction and play with being caught", ["ignore the correction", "repeat the incorrect claim"], ["USER_CORRECTED_MAKO", "MAKO_WAS_CAUGHT"])
        if re.search(r"\b(?:i(?:'m| am)|im) back\b|\b(?:i(?:'ll| will) be right back|be back soon)\b|\b(?:bye|goodbye|goodnight)\b", text):
            returning = bool(re.search(r"\b(?:i(?:'m| am)|im) back\b", text))
            return SemanticAnalysis(
                "leave_return", 0.92, "warm", "shared_presence",
                "user is " + ("returning to" if returning else "temporarily leaving") + " the conversation",
                "welcome them back or acknowledge the departure without guilt-tripping",
                ["pretend they abandoned Mako", "force a new topic"],
                ["USER_RETURNED" if returning else "USER_LEAVING"],
            )
        if re.search(r"\b(?:i love you|love spending time with you|miss you|missed you|you(?:'re| are) (?:cute|adorable)|you(?:'re| are) safe here|virtual hug|give you a hug)\b", text):
            return SemanticAnalysis(
                "affection_reassurance", 0.92, "warm", "relationship",
                "user offers affection, reassurance, or closeness",
                "receive it directly and naturally; reciprocate only at the current relationship pace",
                ["deflect into software metaphors", "manufacture friction", "make a grand declaration"],
                ["USER_OFFERED_AFFECTION"],
            )
        if re.search(r"\b(?:are we close|do you (?:remember|miss|trust|think about) me|how do you feel about me|do you feel (?:we are )?(?:familiar|close)|what do i mean to you)\b", text):
            return SemanticAnalysis(
                "relationship_reflection", 0.9, "personal", "relationship",
                "user asks directly about connection, memory, trust, or feelings",
                "answer the personal question plainly before teasing or expanding",
                ["hide behind code metaphors", "answer a different question", "generic assistant reassurance"],
                ["USER_ASKED_RELATIONSHIP_QUESTION"],
            )
        if re.search(r"\b(?:what have i said|what did i say|what have we (?:said|talked about)|what did we just (?:say|talk about))\b", text):
            return SemanticAnalysis(
                "conversation_recap", 0.96, "direct", "speaker_history",
                "speaker asks for a recap of the saved turns supplied in conversation context",
                "recap only the speaker's actual recent turns; never claim there is no history when turns are supplied",
                ["invent a recap", "claim no history when saved turns exist", "switch topics"],
                ["USER_REQUESTED_RECAP"],
            )
        if re.search(
            r"\b(?:rough|awful|terrible|bad|long|exhausting) day\b"
            r"|\b(?:i(?:'m| am)|im) (?:tired|exhausted|stressed|overwhelmed|upset|frustrated)\b"
            r"|\bi feel (?:tired|exhausted|stressed|overwhelmed|upset|frustrated|awful|terrible)\b"
            r"|\b(?:today|yesterday|tonight|work) (?:was|is|has been) "
            r"(?:rough|awful|terrible|bad|long|exhausting)\b",
            text,
        ):
            return SemanticAnalysis(
                "emotional_disclosure", 0.88, "supportive", "user_state",
                "user shares a difficult emotional state or day",
                "acknowledge the feeling first; do not immediately fix it, pitch an activity, or interrogate them",
                ["generic advice", "forced optimism", "activity suggestions"],
                ["USER_SHARED_DIFFICULT_STATE"],
            )
        if re.search(
            r"\b(?:wanna|want to|can we|should we) call\b"
            r"|\bcan we (?:talk|chat|speak) (?:on|over) a call\b"
            r"|\bcall me(?:\s|$)|\bcall (?:you|me) back\b",
            text,
        ):
            return SemanticAnalysis(
                "call_invitation", 0.92, "warm", "call",
                "user invites or requests a call",
                "acknowledge the call request directly and let the call flow handle any action",
                ["pretend a call is already connected", "ignore the request"],
                ["USER_REQUESTED_CALL"],
            )
        if re.search(r"\b(?:i(?:'m| am)|im) (?:testing|checking) you\b|\b(?:you(?:'re| are| keep) repeating|that (?:answer|response) was (?:good|bad|weird)|(?:great|good) (?:answer|response))\b", text):
            return SemanticAnalysis(
                "feedback_or_test", 0.86, "meta", "mako_behavior",
                "user evaluates, tests, or gives feedback about Mako's behavior",
                "receive the feedback plainly; adjust when it identifies a problem",
                ["ignore repeated-behavior feedback", "treat testing as personal rejection"],
                ["USER_GAVE_BEHAVIOR_FEEDBACK"],
            )
        if re.search(r"\b(?:i (?:do not|don't) want to|i (?:do not|don't) want|stop suggesting|not right now|leave (?:it|that|the topic)|drop (?:it|that))\b", text):
            return SemanticAnalysis(
                "topic_boundary", 0.94, "direct", "current_topic",
                "user declines the current suggestion or asks to leave a topic alone",
                "respect the no; do not substitute another activity or ask a replacement question",
                ["another suggestion", "persuasion", "repeating the declined topic"],
                ["USER_SET_TOPIC_BOUNDARY"],
            )
        if re.search(r"\b(?:what do you mean|say that again|can you (?:repeat|explain) that|what did you say|i (?:did not|didn't|could not|couldn't) hear)\b", text):
            return SemanticAnalysis(
                "clarification_repair", 0.91, "direct", "mako_previous_statement",
                "user did not understand or hear Mako's prior thought",
                "clarify or repeat the preceding thought; do not start a new topic",
                ["new activity suggestion", "claim the user is confused without explaining"],
                ["USER_REQUESTED_CLARIFICATION"],
            )
        if re.search(r"\b(?:working on you|fixing you|improving you|your (?:code|call|app|model)|architecture|latency)\b", text):
            return SemanticAnalysis(
                "shared_work_update", 0.9, "shared_work", "user_project",
                "user reports work specifically on Mako or her system",
                "recognize the user's effort and respond to the concrete change when one is named",
                ["generic encouragement", "act unaware that the work concerns Mako"],
                ["USER_WORKING_ON_MAKO"],
            )
        if re.search(r"\b(?:are you (?:still )?there|are you here with me|stay with me)\b", text):
            return SemanticAnalysis(
                "availability_check", 0.94, "present", "mako_presence",
                "user checks whether Mako is present and engaged",
                "answer presence directly, briefly, and without a stock reassurance speech",
                ["poetic filler", "unrelated topic shift"],
                ["USER_CHECKED_AVAILABILITY"],
            )
        if re.fullmatch(r"(thanks|thank you)[,! .]*(i try)?[.! ]*", text) and re.search(r"\b(you|your).{0,24}\b(keep|make|good|nice|warm|better)\b", previous):
            return SemanticAnalysis("accept_compliment", 0.95, "playful_warm", "mako_previous_statement", "user accepts Mako's compliment and signals the effect was intentional", "continue the existing playful thread", ["thank the user as if they complimented Mako", "reverse speaker roles", "generic reassurance"], ["USER_ACCEPTED_COMPLIMENT"])
        if re.fullmatch(r"(?:yes[,! .]*)?(?:thanks|thank you)[,! .]*", text):
            return SemanticAnalysis(
                "closed_acknowledgment", 0.96, "warm", "mako_previous_statement",
                "user closes the prior point with thanks or clear agreement",
                "respond briefly and personally; do not ask a question, check in, or launch a new topic",
                ["service language", "what is next question", "agenda framing", "topic fishing"],
                ["USER_CLOSED_PRIOR_POINT"],
            )
        technical_patterns = (
            r"\bspaghetti code\b", r"\bbug\b", r"\bprogramming\b", r"\bfeature\b",
            r"\b(?:working|improving|fixing|coding|building|implementing).{0,32}\b(?:code|app|program|feature|bug)\b",
            r"\bdo you code\b",
        )
        if any(re.search(pattern, text) for pattern in technical_patterns):
            return SemanticAnalysis("technical_discussion", 0.86, "shared_work", "user_project", "user is discussing technical work", "give a concrete opinion, tease, or offer to inspect the specific problem", ["generic encouragement"], ["USER_ASKED_TECHNICAL_QUESTION"])
        if re.search(r"\b(good job|excellent response|very nice response|proud of you)\b", text):
            return SemanticAnalysis("praise_response", 0.9, "warm", "mako_response", "user praises Mako's response", "receive the praise naturally and keep the current thread", ["over-explain", "immediate topic shift"], ["USER_PRAISED_RESPONSE"])
        if re.search(r"\b(deleting|uninstalling|stay out of my files|fight you)\b", text):
            return SemanticAnalysis("playful_threat", 0.78, "playful", "mako", "likely joking boundary play", "tease back without taking the threat literally", ["literal fear", "generic safety response"], ["USER_FAKE_THREATENED_MAKO"])
        if re.search(r"\b(?:stop (?:calling|being|saying)|quit (?:calling|being)|leave my (?:keyboard|files)|don't call me (?:code|that)|do not call me (?:code|that))\b", text):
            return SemanticAnalysis(
                "playful_boundary", 0.84, "playful" if playful else "direct", "mako_behavior",
                "user asks Mako to stop or adjust a specific running bit",
                "acknowledge the boundary and adjust without becoming defensive",
                ["repeat the unwanted bit", "turn it into a literal safety concern"],
                ["USER_SET_PLAYFUL_BOUNDARY"],
            )
        if re.fullmatch(r"(?:yeah|yes|yep|definitely|exactly|true|fair|sounds (?:good|nice)|i agree|that(?:'s| is) fair)(?:,?\s*(?:that(?:'s| is) fair|true|exactly))?[.! ]*", text):
            return SemanticAnalysis(
                "agreement_acknowledgment", 0.76, "neutral", "mako_previous_statement",
                "user affirms Mako's immediately prior point",
                "continue the current thread rather than restating the conclusion",
                ["repeat Mako's last point verbatim", "abrupt topic shift"],
                ["USER_AGREED"],
            )
        if re.search(r"^(?:what|why|how|where|who)\b|\b(?:do|are|can|would|will) you\b", text):
            return SemanticAnalysis(
                "direct_question", 0.74, "curious", "mako",
                "user asks Mako a direct question",
                "answer the question first and keep the response specific to it",
                ["generic filler", "answer a different question"],
                ["USER_ASKED_DIRECT_QUESTION"],
            )
        if playful:
            return SemanticAnalysis("teasing", 0.65, "playful", "mako", "user is probably teasing Mako", "push back lightly or continue the joke", [], ["USER_TEASED_MAKO"])
        return SemanticAnalysis()

    def record(
        self,
        *,
        event_id: str,
        user_text: str,
        analysis: SemanticAnalysis,
        response_text: str = "",
        channel_id: str = "",
    ) -> None:
        with self._lock, self._connect() as connection:
            connection.execute("INSERT INTO semantic_turns (event_id, user_text, analysis_json, response_text) VALUES (?, ?, ?, ?)", (event_id, user_text, json.dumps(asdict(analysis)), response_text))
            state_key = f"dialogue:{channel_id or 'default'}"
            state = {"last_mako_act": analysis.act, "frame": analysis.frame, "age": 1}
            row = connection.execute(
                "SELECT state_json FROM semantic_state WHERE state_key = ?", (state_key,)
            ).fetchone()
            if row:
                state["age"] = int(json.loads(str(row[0])).get("age", 0)) + 1
            self._state = state
            connection.execute(
                "INSERT OR REPLACE INTO semantic_state (state_key, state_json) VALUES (?, ?)",
                (state_key, json.dumps(state)),
            )

    def stats(self) -> dict[str, Any]:
        with self._lock, self._connect() as connection:
            rows = connection.execute("SELECT analysis_json FROM semantic_turns").fetchall()
        analyses = [json.loads(str(row[0])) for row in rows]
        latencies = sorted(float(item.get("latency_ms", 0.0)) for item in analyses)
        routes: dict[str, int] = {}
        for item in analyses:
            route = str(item.get("act", "unknown"))
            routes[route] = routes.get(route, 0) + 1
        return {
            "shadow_turns": len(analyses),
            "mean_latency_ms": round(sum(latencies) / len(latencies), 3) if latencies else 0.0,
            "p50_latency_ms": self._percentile(latencies, 50),
            "p95_latency_ms": self._percentile(latencies, 95),
            "p99_latency_ms": self._percentile(latencies, 99),
            "routes": routes,
            "state": dict(self._state),
        }

    @staticmethod
    def _percentile(values: list[float], percentile: int) -> float:
        if not values:
            return 0.0
        index = min(len(values) - 1, round((len(values) - 1) * percentile / 100))
        return round(values[index], 3)

    @contextmanager
    def _connect(self):
        connection = sqlite3.connect(self.database_path, timeout=20.0)
        try:
            with connection:
                yield connection
        finally:
            connection.close()
