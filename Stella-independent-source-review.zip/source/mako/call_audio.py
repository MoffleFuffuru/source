from __future__ import annotations

import threading
from pathlib import Path


class CallSounds:
    def __init__(self, ringing_path: Path, answered_path: Path) -> None:
        self.ringing_path = ringing_path
        self.answered_path = answered_path
        self._lock = threading.RLock()

    def start_ringing(self) -> None:
        if not self.ringing_path.exists():
            return
        with self._lock:
            try:
                import winsound

                winsound.PlaySound(
                    str(self.ringing_path),
                    winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_LOOP,
                )
            except RuntimeError:
                pass

    def answered(self) -> None:
        if not self.answered_path.exists():
            self.stop()
            return
        with self._lock:
            try:
                import winsound

                winsound.PlaySound(
                    str(self.answered_path),
                    winsound.SND_FILENAME | winsound.SND_ASYNC,
                )
            except RuntimeError:
                self.stop()

    def stop(self) -> None:
        with self._lock:
            try:
                import winsound

                winsound.PlaySound(None, 0)
            except RuntimeError:
                pass
