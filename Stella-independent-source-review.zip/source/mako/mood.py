from __future__ import annotations

import json
import math
import re
import threading
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path


MOOD_BASELINE = {
    "warmth": 0.28,
    "energy": 0.48,
    "playfulness": 0.36,
    "curiosity": 0.55,
    "irritation": 0.06,
    "vulnerability": 0.08,
}


@dataclass(slots=True)
class EmotionalState:
    warmth: float = MOOD_BASELINE["warmth"]
    energy: float = MOOD_BASELINE["energy"]
    playfulness: float = MOOD_BASELINE["playfulness"]
    curiosity: float = MOOD_BASELINE["curiosity"]
    irritation: float = MOOD_BASELINE["irritation"]
    vulnerability: float = MOOD_BASELINE["vulnerability"]
    familiarity: float = 0.0
    trust: float = 0.0
    affection: float = 0.0
    attraction: float = 0.0
    friction: float = 0.0
    updated_at: float = field(default_factory=time.time)


class MoodEngine:
    def __init__(self, path: Path, half_life_hours: float = 6.0) -> None:
        self.path = path
        self.half_life_hours = half_life_hours
        self._lock = threading.RLock()
        self.state = self._load()
        self.decay()

    def _load(self) -> EmotionalState:
        if not self.path.exists():
            return EmotionalState()
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            allowed = EmotionalState.__dataclass_fields__.keys()
            return EmotionalState(**{key: value for key, value in raw.items() if key in allowed})
        except (OSError, ValueError, TypeError):
            return EmotionalState()

    @staticmethod
    def _clamp(value: float) -> float:
        return max(0.0, min(1.0, value))

    def _save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(json.dumps(asdict(self.state), indent=2), encoding="utf-8")
        # Windows can briefly lock the destination while the local UI/runtime
        # observes it. Keep the atomic replace, but do not turn that tiny race
        # into a failed conversational turn.
        for attempt in range(5):
            try:
                temporary.replace(self.path)
                return
            except PermissionError:
                if attempt == 4:
                    return
                time.sleep(0.04 * (attempt + 1))

    def decay(self, now: float | None = None) -> None:
        with self._lock:
            current = now or time.time()
            elapsed_hours = max(0.0, (current - self.state.updated_at) / 3600.0)
            if elapsed_hours <= 0:
                return
            retention = math.pow(0.5, elapsed_hours / self.half_life_hours)
            for name, baseline in MOOD_BASELINE.items():
                value = getattr(self.state, name)
                setattr(self.state, name, baseline + ((value - baseline) * retention))
            self.state.friction *= retention
            self.state.updated_at = current
            self._save()

    def apply_mood_delta(self, delta: dict[str, float]) -> None:
        with self._lock:
            self.decay()
            for name in MOOD_BASELINE:
                if name not in delta:
                    continue
                change = max(-0.12, min(0.12, float(delta[name])))
                setattr(self.state, name, self._clamp(getattr(self.state, name) + change))
            self.state.updated_at = time.time()
            self._save()

    def apply_relationship_delta(self, delta: dict[str, float]) -> None:
        with self._lock:
            for name in ("familiarity", "trust", "affection", "attraction", "friction"):
                if name not in delta:
                    continue
                change = max(-0.05, min(0.05, float(delta[name])))
                setattr(self.state, name, self._clamp(getattr(self.state, name) + change))
            self.state.updated_at = time.time()
            self._save()

    @staticmethod
    def _phrase_count(text: str, phrases: tuple[str, ...]) -> int:
        return sum(len(re.findall(rf"(?<!\w){re.escape(phrase)}(?!\w)", text)) for phrase in phrases)

    def reconcile_relationship(self, history: list[tuple[str, str]]) -> None:
        """Derive relationship evidence from recorded interaction, never model self-reporting."""
        if not history:
            return

        user_text = "\n".join(user.lower() for user, _ in history)
        turns = len(history)
        affection_hits = self._phrase_count(
            user_text,
            (
                "love you", "love ya", "thinking about you", "missed you", "miss you",
                "proud of you", "you're cute", "you are cute", "good girl", "my dear",
                "care about you", "i care", "sweetheart", "darling",
            ),
        )
        trust_hits = self._phrase_count(
            user_text,
            (
                "i trust you", "being honest", "be honest", "open with you", "i feel",
                "rough day", "long day", "i'm sorry", "im sorry", "thank you",
                "appreciate you", "i need you",
            ),
        )
        romantic_hits = self._phrase_count(
            user_text,
            ("love you", "love ya", "want you", "date you", "be mine", "my girlfriend"),
        )
        return_hits = self._phrase_count(
            user_text,
            ("i'm back", "im back", "be back", "talk to you later", "call you back"),
        )

        # Repeated interaction establishes familiarity on its own. Stronger signals only
        # raise a floor; they never manufacture a label or override Mako's current mood.
        familiarity_target = min(0.82, 0.05 + (min(turns, 500) * 0.00145) + (return_hits * 0.01))
        trust_target = min(0.68, 0.02 + (min(turns, 500) * 0.00085) + (trust_hits * 0.025))
        affection_target = min(0.72, (affection_hits * 0.045) + (trust_hits * 0.012))
        # Mako starts gently predisposed toward the person who consistently shows up for her.
        # Attraction remains a slow burn, but sustained mutual familiarity can establish it
        # without demanding a single explicit romantic declaration.
        attraction_target = min(
            0.65,
            max(0.0, romantic_hits - 2) * 0.045
            + (max(0.0, familiarity_target - 0.35) * 0.30)
            + (max(0.0, trust_target - 0.25) * 0.35)
            + (max(0.0, affection_target - 0.20) * 0.30),
        )
        targets = {
            "familiarity": familiarity_target,
            "trust": trust_target,
            "affection": affection_target,
            "attraction": attraction_target,
        }
        with self._lock:
            for name, target in targets.items():
                # The state belongs to the evidence ledger, so it must converge back to
                # observed history instead of retaining an old model-generated increase.
                setattr(self.state, name, self._clamp(target))

            # Emotional openness and playfulness should grow with a safe, affectionate
            # relationship instead of decaying forever to a stranger's baseline.
            vulnerability_floor = self._clamp(
                MOOD_BASELINE["vulnerability"]
                + (self.state.familiarity * 0.14)
                + (self.state.trust * 0.18)
                + (self.state.affection * 0.20)
                - (self.state.friction * 0.12)
            )
            playfulness_floor = self._clamp(
                MOOD_BASELINE["playfulness"]
                + (self.state.familiarity * 0.08)
                + (self.state.affection * 0.08)
                - (self.state.irritation * 0.10)
            )
            self.state.vulnerability = max(self.state.vulnerability, vulnerability_floor)
            self.state.playfulness = max(self.state.playfulness, playfulness_floor)
            self.state.updated_at = time.time()
            self._save()

    def prompt_summary(
        self, *, include_owner_relationship: bool = True, compact: bool = False,
    ) -> str:
        self.decay()
        state = self.state

        def level(value: float) -> str:
            if value < 0.2:
                return "low"
            if value < 0.45:
                return "mild"
            if value < 0.7:
                return "moderate"
            return "high"

        mood_summary = (
            "Current private emotional tendencies: "
            f"warmth {level(state.warmth)}, energy {level(state.energy)}, "
            f"playfulness {level(state.playfulness)}, curiosity {level(state.curiosity)}, "
            f"irritation {level(state.irritation)}, vulnerability {level(state.vulnerability)}.\n"
        )
        if compact:
            mood = (
                f"state warmth={level(state.warmth)}, energy={level(state.energy)}, "
                f"playfulness={level(state.playfulness)}, curiosity={level(state.curiosity)}, "
                f"irritation={level(state.irritation)}, vulnerability={level(state.vulnerability)}"
            )
            if not include_owner_relationship:
                return mood + "; relationship=unfamiliar"
            return (
                mood + "; relationship "
                f"familiarity={level(state.familiarity)}, trust={level(state.trust)}, "
                f"affection={level(state.affection)}, attraction={level(state.attraction)}, "
                f"friction={level(state.friction)}"
            )
        if not include_owner_relationship:
            return (
                mood_summary
                + "Relationship evidence for the current speaker: unfamiliar. This speaker has no "
                "established familiarity, trust, affection, attraction, or friction yet."
            )
        return (
            mood_summary
            + "Relationship evidence: "
            f"familiarity {level(state.familiarity)}, trust {level(state.trust)}, "
            f"affection {level(state.affection)}, attraction {level(state.attraction)}, "
            f"friction {level(state.friction)}. Exact relationship values (0 to 1): "
            f"familiarity {state.familiarity:.2f}, trust {state.trust:.2f}, "
            f"affection {state.affection:.2f}, attraction {state.attraction:.2f}, "
            f"friction {state.friction:.2f}. These are uncertain tendencies, not labels or commands."
        )
