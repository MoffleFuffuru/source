from __future__ import annotations

from dataclasses import dataclass

from .config import TimingConfig


@dataclass(slots=True)
class SocialSchedule:
    read_seconds: float
    think_seconds: float
    type_seconds: float
    typing_starts_at: float
    delivery_at: float


class SocialClock:
    def __init__(self, config: TimingConfig) -> None:
        self.config = config

    @staticmethod
    def _word_count(text: str) -> int:
        return max(1, len(text.split()))

    def reading_seconds(self, text: str) -> float:
        calculated = (self._word_count(text) / self.config.reading_wpm) * 60.0
        return max(self.config.minimum_reading_seconds, calculated)

    def thinking_seconds(self, complexity: int = 2) -> float:
        return self.config.thinking_base_seconds + (
            max(1, min(5, complexity)) * self.config.thinking_per_complexity
        )

    def schedule(
        self,
        *,
        received_at: float,
        model_ready_at: float,
        user_text: str,
        response_text: str,
        complexity: int,
        typing_started_at: float | None = None,
        real_time: bool = False,
    ) -> SocialSchedule:
        if real_time:
            return SocialSchedule(0.0, 0.0, 0.0, received_at, model_ready_at)

        read_seconds = self.reading_seconds(user_text)
        think_seconds = self.thinking_seconds(complexity)
        type_seconds = (self._word_count(response_text) / self.config.typing_wpm) * 60.0
        type_seconds = max(self.config.minimum_typing_seconds, type_seconds)

        # Callers can provide the model-ready timestamp so visible typing starts
        # only after generation has genuinely finished.
        typing_starts_at = (
            received_at + read_seconds
            if typing_started_at is None
            else typing_started_at
        )
        delivery_at = max(model_ready_at, typing_starts_at + type_seconds)
        return SocialSchedule(
            read_seconds=read_seconds,
            think_seconds=think_seconds,
            type_seconds=type_seconds,
            typing_starts_at=typing_starts_at,
            delivery_at=delivery_at,
        )
