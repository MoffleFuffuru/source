"""ElevenLabs transports. Transcript, profile, and playback ownership stay separate."""
from __future__ import annotations

import asyncio
import base64
import json
import logging
import queue
import re
import threading
import time
from collections import deque
from urllib.parse import urlencode

from .inworld_stt import InworldSTTClient, inworld_api_key

LOG = logging.getLogger(__name__)
PCM_RATE = 24000


def validate_keyterms(terms):
    if not isinstance(terms, list) or any(not isinstance(term, str) for term in terms):
        raise ValueError("ElevenLabs keyterms must be a list of strings")
    result = list(dict.fromkeys(term.strip() for term in terms if term.strip()))
    if len(result) > 50 or any(len(term) > 20 for term in result):
        raise ValueError("Scribe realtime allows at most 50 keyterms of 20 characters each")
    return result


def elevenlabs_key(config):
    try:
        return inworld_api_key(config.elevenlabs_api_key_environment_variable)
    except RuntimeError:
        raise RuntimeError(f"ElevenLabs needs {config.elevenlabs_api_key_environment_variable}") from None


def mood_tag(mood="neutral"):
    return {"annoyed": "[annoyed]", "angry": "[angry]", "happy": "[happy]",
            "excited": "[excited]", "joy": "[excited]", "love": "[happy]"}.get(str(mood).casefold(), "")


def expressive_text(text, *, vocal_cue="none", delivery="neutral", mood="neutral"):
    tags = {"laugh": "[laughs]", "soft_laugh": "[chuckles]", "sigh": "[sighs]"}
    styles = {"whisper": "[whispers]", "excited": "[excited]"}
    return " ".join(part for part in (mood_tag(mood), styles.get(delivery), tags.get(vocal_cue), text) if part)


class ProfileMatcher:
    """Use a sidecar result once, only for the same ordinal and exact transcript.

    Different segmentation or wording means omitting a profile, never guessing.
    Neither late profiles nor sidecar transcripts can trigger a response.
    """

    def __init__(self):
        self._lock = threading.Lock()
        self.reset()

    def reset(self):
        with self._lock:
            self.primary = self.sidecar = 0
            self.pending = ""
            self.candidates = deque(maxlen=4)

    def profile(self, value):
        with self._lock:
            self.pending = value

    def commit(self, text):
        with self._lock:
            self.sidecar += 1
            self.candidates.append((self.sidecar, self.normalize(text), self.pending, time.monotonic()))
            self.pending = ""

    def take(self, text):
        with self._lock:
            self.primary += 1
            result = ""
            while self.candidates and self.candidates[0][0] <= self.primary:
                ordinal, candidate, profile, timestamp = self.candidates.popleft()
                if ordinal == self.primary and candidate == self.normalize(text) and time.monotonic() - timestamp < 2:
                    result = profile
            return result

    @staticmethod
    def normalize(text):
        return " ".join(re.findall(r"\w+", text.casefold()))


class ScribeSTTClient(InworldSTTClient):
    """Reuse existing capture/resampling; Scribe alone commits authoritative turns."""

    def __init__(self, config, *, on_utterance, on_partial=None, on_status=lambda _: None,
                 on_voice_profile=None, capture_microphone=True):
        self.config = config
        self.keyterms = validate_keyterms(config.elevenlabs_keyterms)
        self._stopped = threading.Event()
        self._connected = False
        self._primary_utterance = on_utterance
        self._profile_callback = on_voice_profile
        self._profiles = ProfileMatcher()
        self._sidecar = None
        super().__init__(
            api_key_environment_variable=config.elevenlabs_api_key_environment_variable,
            input_device=config.input_device, language=config.language,
            profile_threshold=config.inworld_stt_profile_threshold,
            eot_confidence_threshold=config.inworld_stt_eot_confidence_threshold,
            min_eot_silence_ms=config.inworld_stt_min_eot_silence_ms,
            max_turn_silence_ms=config.inworld_stt_max_turn_silence_ms,
            on_utterance=self._commit, on_partial=on_partial, on_voice_profile=None,
            on_status=lambda value: on_status(value.replace("Inworld STT", "Scribe STT")), capture_microphone=capture_microphone,
        )

    def start(self, timeout_seconds=10):
        elevenlabs_key(self.config)
        if self.config.vocal_context_provider == "inworld_stt":
            self._start_sidecar()
        try:
            super().start(timeout_seconds)
        except Exception as exc:
            self.stop()
            raise RuntimeError(str(exc).replace("Inworld STT", "Scribe STT")) from exc

    def _start_sidecar(self):
        c = self.config
        sidecar = InworldSTTClient(
            api_key_environment_variable=c.inworld_stt_api_key_environment_variable,
            input_device=None, language=c.language,
            profile_threshold=c.inworld_stt_profile_threshold,
            eot_confidence_threshold=c.inworld_stt_eot_confidence_threshold,
            min_eot_silence_ms=c.inworld_stt_min_eot_silence_ms,
            max_turn_silence_ms=c.inworld_stt_max_turn_silence_ms,
            on_utterance=self._profiles.commit, on_partial=None,
            on_voice_profile=self._profiles.profile,
            on_status=lambda status: LOG.debug("Vocal sidecar: %s", status),
            capture_microphone=False,
        )
        try:
            sidecar.start()
            self._sidecar = sidecar
        except Exception:
            sidecar.stop()
            self.on_status("Inworld vocal context unavailable; Scribe continues without profiles")

    def _commit(self, text):
        if self._stopped.is_set() or self._muted:
            return
        profile = self._profiles.take(text)
        if self._profile_callback:
            self._profile_callback(profile)
        self._primary_utterance(text)

    def _feed_samples(self, samples, sample_rate):
        if self._stopped.is_set() or not self._connected or self._muted:
            return
        if self._sidecar is not None:
            self._sidecar.push_audio(samples, sample_rate)
        super()._feed_samples(samples, sample_rate)

    def set_muted(self, muted):
        super().set_muted(muted)
        if self._sidecar is not None:
            self._sidecar.set_muted(muted)

    def end_turn(self):
        # VAD owns completion. External endpoint timers must not double-commit.
        pass

    def stop(self):
        self._stopped.set()
        sidecar, self._sidecar = self._sidecar, None
        if sidecar is not None:
            sidecar.stop()
        super().stop()

    def _run_loop(self):
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._run())
        except Exception as exc:
            if not self._ready.is_set():
                self._startup_error = exc
            elif not self._stopped.is_set():
                self.on_status("voice error: Scribe disconnected; restart the call")
                LOG.exception("Scribe connection failed")
        finally:
            self._connected = False
            self._ready.set()
            self.stop()
            self._loop.close()

    async def _run(self):
        import aiohttp
        params = [("model_id", "scribe_v2_realtime"), ("audio_format", "pcm_16000"),
                  ("commit_strategy", "vad"), ("language_code", self.language.split("_")[0]),
                  ("vad_silence_threshold_secs", str(self.config.elevenlabs_vad_silence_seconds)),
                  ("min_speech_duration_ms", "100"), ("include_timestamps", "false")]
        params.extend(("keyterms", term) for term in self.keyterms)
        url = "wss://api.elevenlabs.io/v1/speech-to-text/realtime?" + urlencode(params)
        retries = 0
        async with aiohttp.ClientSession(headers={"xi-api-key": elevenlabs_key(self.config)},
                                         timeout=aiohttp.ClientTimeout(total=None, sock_connect=10)) as session:
            while not self._stopped.is_set():
                self._audio_queue = asyncio.Queue(maxsize=40)
                with self._capture_lock:
                    if self._capture_buffer is not None:
                        self._capture_buffer = self._capture_buffer[:0]
                try:
                    async with session.ws_connect(url, heartbeat=10) as ws:
                        first = await ws.receive_json(timeout=10)
                        if first.get("message_type") != "session_started":
                            raise RuntimeError("Scribe initialization rejected: " + str(first.get("message_type", "unknown")))
                        while not self._audio_queue.empty():
                            self._audio_queue.get_nowait()
                        self._connected = True
                        self._ready.set()
                        self.on_status("Scribe realtime connected")
                        sender = asyncio.create_task(self._send_loop(ws))
                        receiver = asyncio.create_task(self._receive_loop(ws))
                        try:
                            done, _ = await asyncio.wait((sender, receiver), return_when=asyncio.FIRST_COMPLETED)
                            for task in done:
                                task.result()
                        finally:
                            sender.cancel()
                            receiver.cancel()
                            await asyncio.gather(sender, receiver, return_exceptions=True)
                        if not self._stopped.is_set():
                            raise ConnectionError("Scribe socket closed")
                except Exception:
                    self._connected = False
                    if self._stopped.is_set():
                        return
                    if not self._ready.is_set() or retries >= 2:
                        raise
                    retries += 1
                    # Never replay a disconnected stream's queued audio or profile.
                    self._profiles.reset()
                    if self._sidecar is not None:
                        self._sidecar.stop()
                        self._sidecar = None
                    self.on_status("Scribe reconnecting; interrupted input discarded")
                    await asyncio.sleep(.3 * retries)
                finally:
                    self._connected = False

    async def _send_loop(self, ws):
        while not self._stopped.is_set():
            try:
                item = await asyncio.wait_for(self._audio_queue.get(), timeout=.15)
            except asyncio.TimeoutError:
                item = bytes(4800)
            if item is None:
                return
            if self._muted:
                item = bytes(3200)
            await ws.send_json({"message_type": "input_audio_chunk", "audio_base_64": base64.b64encode(item).decode(), "sample_rate": 16000})

    def _enqueue_control(self, item):
        if self._audio_queue is None or self._stopped.is_set():
            return
        if self._audio_queue.full():
            self._stopped.set()
            self.on_status("voice error: Scribe input overflow; restart the call")
            return
        self._audio_queue.put_nowait(item)

    async def _receive_loop(self, ws):
        import aiohttp
        async for message in ws:
            if message.type != aiohttp.WSMsgType.TEXT:
                continue
            data = json.loads(message.data)
            kind = data.get("message_type", "")
            if data.get("error"):
                raise RuntimeError("Scribe stream failed: " + kind)
            if self._stopped.is_set() or self._muted:
                continue
            text = str(data.get("text", "")).strip()
            if kind == "committed_transcript" and text:
                self.on_utterance(text)
            elif kind == "partial_transcript" and text and self.on_partial:
                self.on_partial(text)


async def stream_dialogue(config, chunks, *, cancelled=lambda: False, on_alignment=None):
    """Yield sample-aligned mono PCM. Each reply owns its socket and cancellation."""
    import aiohttp
    voice = config.elevenlabs_tts_voice.strip()
    if not voice:
        raise ValueError("Choose an ElevenLabs voice ID before starting a call")
    url = "wss://api.elevenlabs.io/v1/text-to-dialogue/stream-input"
    params = {"model_id": config.elevenlabs_tts_model, "output_format": "pcm_24000"}
    started = time.monotonic()
    received_audio = False
    tail = b""
    async with aiohttp.ClientSession(headers={"xi-api-key": elevenlabs_key(config)},
                                     timeout=aiohttp.ClientTimeout(total=None, sock_connect=10)) as session:
        async with session.ws_connect(url, params=params, heartbeat=10) as ws:
            await ws.send_json({"voices": [voice]})

            async def send():
                last_send = time.monotonic()
                dirty = False
                while not cancelled():
                    try:
                        text = chunks.get_nowait()
                    except queue.Empty:
                        now = time.monotonic()
                        if dirty and now - last_send >= .18:
                            await ws.send_json({"flush": True})
                            last_send, dirty = now, False
                        elif now - last_send >= 8:
                            await ws.send_json({"keep_alive": True})
                            last_send = now
                        await asyncio.sleep(.01)
                        continue
                    if text is None:
                        await ws.send_json({"close_socket": True})
                        return
                    if text.strip():
                        await ws.send_json({"inputs": [{"text": text, "voice_id": voice}]})
                        last_send, dirty = time.monotonic(), True

            # Drain the socket independently of real-time playback. Otherwise a
            # long PCM chunk prevents receipt of subsequent audio/final markers.
            messages = asyncio.Queue(maxsize=256)

            async def receive():
                while True:
                    try:
                        message = await ws.receive()
                    except Exception as exc:
                        await messages.put(exc)
                        return
                    await messages.put(message)
                    if message.type != aiohttp.WSMsgType.TEXT:
                        return

            sender = asyncio.create_task(send())
            reader = asyncio.create_task(receive())
            receiver = asyncio.create_task(messages.get())
            last_receive = time.monotonic()
            try:
                while not cancelled():
                    if sender.done() and sender.exception():
                        raise sender.exception()
                    if time.monotonic() - last_receive > 30 or time.monotonic() - started > 180:
                        raise TimeoutError("ElevenLabs dialogue timed out")
                    done, _ = await asyncio.wait((receiver,), timeout=.05)
                    if not done:
                        continue
                    message = receiver.result()
                    if isinstance(message, Exception):
                        raise message
                    if message.type != aiohttp.WSMsgType.TEXT:
                        raise ConnectionError(
                            "ElevenLabs dialogue closed before its final marker "
                            f"(type={message.type}, code={getattr(ws, 'close_code', None)}, "
                            f"elapsed={time.monotonic() - started:.1f}s)"
                        )
                    data = json.loads(message.data)
                    last_receive = time.monotonic()
                    if data.get("error"):
                        raise RuntimeError("ElevenLabs rejected dialogue: " + str(data.get("error", "unknown"))[:300])
                    if on_alignment is not None and isinstance(data.get("alignment"), dict):
                        on_alignment(data["alignment"])
                    if data.get("audio"):
                        pcm = tail + base64.b64decode(data["audio"])
                        size = len(pcm) - len(pcm) % 2
                        tail = pcm[size:]
                        if size:
                            if not received_audio:
                                LOG.info("ElevenLabs TTD first_pcm_seconds=%.3f model=%s", time.monotonic() - started, config.elevenlabs_tts_model)
                            received_audio = True
                            yield pcm[:size]
                    if data.get("is_final"):
                        if not received_audio or tail:
                            raise RuntimeError("ElevenLabs returned empty or incomplete PCM")
                        return
                    receiver = asyncio.create_task(messages.get())
            finally:
                sender.cancel()
                reader.cancel()
                receiver.cancel()
                await asyncio.gather(sender, reader, receiver, return_exceptions=True)
