from __future__ import annotations

import os
import queue
import threading
import time
import tkinter as tk
from pathlib import Path
from typing import Any, Callable

from PIL import Image, ImageTk

from .call import CallCallbacks, CallSession, is_call_invitation
from .call_audio import CallSounds
from .core import MakoCore
from .model_backend import ModelError
from .models import ConversationEvent, Expression, OutboundCallPlan, ResponseResult
from .proactive import ProactiveCallPolicy
from .scheduling import parse_scheduled_call
from .typing_audio import TypingSound
from .vision import VisionObserver
from .voice import VoiceEngine


COLORS = {
    "window": "#17120f",
    "panel": "#241b17",
    "panel_alt": "#30231e",
    "line": "#5d4034",
    "cream": "#f8e8d2",
    "muted": "#bda792",
    "rose": "#d88478",
    "rose_active": "#ef9b8c",
    "user": "#382620",
    "mako": "#2d2520",
    "good": "#9eb78f",
    "warning": "#dda06e",
}

SCHEDULED_CALL_GREETINGS = (
    "hey. you wanted me to call you back?",
    "hi. you asked me to ring you, remember?",
    "there you are. you told me to call back.",
    "hey, your callback's here.",
    "mhm. i'm calling you back like you asked.",
)


EXPRESSION_FILES = {
    Expression.NEUTRAL: ("Neutral.png",),
    Expression.HAPPY: ("Happy.png", "Neutral.png"),
    Expression.SMUG: ("Smug.png", "Happy.png", "Neutral.png"),
    Expression.SLEEPY: ("Sleepy.png", "Neutral.png"),
    Expression.ANNOYED: ("Annoyed.png", "Neutral.png"),
    Expression.EMBARRASSED: ("Embarrassed.png", "Happy.png", "Neutral.png"),
    Expression.CONCERNED: ("Concerned.png", "Neutral.png"),
    Expression.EXCITED: ("Excited.png", "Happy.png", "Neutral.png"),
}


class DesktopCompanion:
    def __init__(self, core: MakoCore, discord_service: Any = None, *, hidden: bool = False) -> None:
        self.core = core
        self.discord_service = discord_service
        self._hidden = hidden
        self.root = tk.Tk()
        self.root.title("Mako V4")
        self.root.configure(bg=COLORS["window"])
        self.root.attributes("-topmost", self.core.config.ui.always_on_top)
        if self.core.config.ui.borderless:
            self.root.overrideredirect(True)
        self._place_window()
        if hidden:
            self.root.withdraw()

        self._ui_queue: queue.Queue[tuple[Callable, tuple[object, ...]]] = queue.Queue()
        self._pending_messages: list[tuple[str, float]] = []
        self._batch_after_id: str | None = None
        self._reading_ready_at = 0.0
        self._typing_after_id: str | None = None
        self._typing_animation_id: str | None = None
        self._delivery_after_id: str | None = None
        self._delivery_payload: tuple[ConversationEvent, ResponseResult] | None = None
        self._call_invitation_after_id: str | None = None
        self._typing_frame = 0
        self._busy = False
        self._typing = False
        self._text_cancel: threading.Event | None = None
        self._last_event: ConversationEvent | None = None
        self._last_result: ResponseResult | None = None
        self._last_user_activity = time.monotonic()
        self._closed = False
        self._drag_origin = (0, 0)
        self._microphone_window: tk.Toplevel | None = None
        self._microphone_choices: list[tuple[int | None, str]] = []
        self._incoming_call_window: tk.Toplevel | None = None
        self._proactive_thread: threading.Thread | None = None
        self.proactive_calls = ProactiveCallPolicy(
            self.core.config.proactive_calls,
            self.core.paths.data / "proactive_calls.json",
        )

        self.typing_sound = TypingSound(
            self.core.paths.root / "assets" / "sounds" / "Type2.wav"
        )
        self.call_sounds = CallSounds(
            self.core.paths.root / "assets" / "sounds" / "calling.wav",
            self.core.paths.root / "assets" / "sounds" / "call answered.wav",
        )
        self.voice = VoiceEngine(
            self.core.config.voice,
            self.core.paths.temporary,
            on_playback_level=self.core.body.set_speech_level,
        )
        self.call = CallSession(
            self.core,
            self.voice,
            CallCallbacks(
                on_state=lambda state: self.dispatch(self._set_call_state, state),
                on_response=lambda result: self.dispatch(self._on_call_response, result),
                on_error=lambda error: self.dispatch(self._show_error, error),
                on_offer=lambda plan: self.dispatch(self._show_outbound_call, plan),
            ),
        )
        self.vision = VisionObserver(
            self.core,
            on_response=lambda result: self.dispatch(self._on_vision_response, result),
            on_status=lambda status: self.dispatch(self._set_status, status),
            can_comment=lambda: not self._busy and not self.call.active and not self._closed,
        )

        self._build_ui()
        self._set_expression(Expression.NEUTRAL)
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.bind("<Return>", self._on_enter)
        self.root.bind("<Escape>", lambda _event: self.close())
        self.root.after(40, self._drain_ui_queue)
        self.root.after(1000, self._start_background_services)
        self.root.after(30000, self._maintenance_tick)
        self.root.after(1000, self._scheduled_call_tick)

    def run(self) -> None:
        self.root.mainloop()

    def close(self) -> None:
        if self._closed:
            return
        import logging

        logging.getLogger(__name__).warning("Desktop UI close requested")
        self._closed = True
        threading.Thread(target=self._force_exit_watchdog, daemon=True).start()
        if self._text_cancel:
            self._text_cancel.set()
        if self._call_invitation_after_id:
            self.root.after_cancel(self._call_invitation_after_id)
            self._call_invitation_after_id = None
        self.typing_sound.stop()
        self.call_sounds.stop()
        self.vision.stop()
        if self.call.active:
            self.call.hang_up()
        self.voice.shutdown()
        if not self._hidden:
            self.core.config.ui.x = self.root.winfo_x()
            self.core.config.ui.y = self.root.winfo_y()
            self.core.save_ui_placement(self.core.config.ui.x, self.core.config.ui.y)
        self.core.close()
        self.root.destroy()

    @staticmethod
    def _force_exit_watchdog() -> None:
        time.sleep(5)
        os._exit(0)

    def dispatch(self, function: Callable, *args: object) -> None:
        self._ui_queue.put((function, args))

    def _build_ui(self) -> None:
        shell = tk.Frame(
            self.root,
            bg=COLORS["window"],
            highlightthickness=1,
            highlightbackground=COLORS["line"],
        )
        shell.pack(fill="both", expand=True)

        header = tk.Frame(shell, bg=COLORS["window"], height=48)
        header.pack(fill="x", padx=12, pady=(8, 2))
        header.pack_propagate(False)
        header.bind("<ButtonPress-1>", self._start_move)
        header.bind("<B1-Motion>", self._move_window)

        name = tk.Label(
            header,
            text="MAKO V4",
            font=("Georgia", 15, "bold"),
            fg=COLORS["cream"],
            bg=COLORS["window"],
        )
        name.pack(side="left", padx=(4, 10))
        name.bind("<ButtonPress-1>", self._start_move)
        name.bind("<B1-Motion>", self._move_window)

        self.status_label = tk.Label(
            header,
            text="waking up",
            font=("Segoe UI", 9),
            fg=COLORS["muted"],
            bg=COLORS["window"],
            anchor="w",
        )

        # Pack controls before the flexible status label so long status text
        # can never push call or window controls beyond the header edge.
        close_button = self._header_button(header, "x", self.close, width=3)
        close_button.pack(side="right", padx=(4, 0))
        minimize_button = self._header_button(header, "-", self._minimize, width=3)
        minimize_button.pack(side="right")
        self.call_button = self._header_button(header, "call", self._toggle_call, width=7)
        self.call_button.pack(side="right", padx=(0, 6))
        self.discord_test_button = self._header_button(
            header, "test", self._trigger_discord_test, width=5
        )
        self.discord_test_button.pack(side="right", padx=(0, 6))
        microphone_button = self._header_button(
            header, "mic", self._open_microphone_settings, width=5
        )
        microphone_button.pack(side="right", padx=(0, 6))
        self.status_label.pack(side="left", fill="x", expand=True)

        portrait_frame = tk.Frame(shell, bg=COLORS["panel"], height=300)
        portrait_frame.pack(fill="x", padx=14, pady=(0, 10))
        portrait_frame.pack_propagate(False)
        self.avatar_label = tk.Label(portrait_frame, bg=COLORS["panel"], bd=0)
        self.avatar_label.pack(fill="both", expand=True)
        self.avatar_label.bind("<ButtonPress-1>", self._start_move)
        self.avatar_label.bind("<B1-Motion>", self._move_window)

        transcript_frame = tk.Frame(
            shell,
            bg=COLORS["panel"],
            highlightthickness=1,
            highlightbackground=COLORS["line"],
        )
        self.transcript = tk.Text(
            transcript_frame,
            height=1,
            wrap="word",
            bg=COLORS["panel"],
            fg=COLORS["cream"],
            insertbackground=COLORS["cream"],
            selectbackground=COLORS["line"],
            relief="flat",
            borderwidth=0,
            padx=12,
            pady=10,
            font=("Segoe UI", 10),
            cursor="arrow",
        )
        scrollbar = tk.Scrollbar(
            transcript_frame,
            command=self.transcript.yview,
            bg=COLORS["panel_alt"],
            troughcolor=COLORS["panel"],
            activebackground=COLORS["rose"],
            relief="flat",
            borderwidth=0,
        )
        scrollbar.pack(side="right", fill="y")
        self.transcript.pack(side="left", fill="both", expand=True)
        self.transcript.configure(yscrollcommand=scrollbar.set)
        self.transcript.tag_configure(
            "user_name", foreground=COLORS["rose_active"], font=("Segoe UI", 8, "bold")
        )
        self.transcript.tag_configure(
            "mako_name", foreground=COLORS["good"], font=("Segoe UI", 8, "bold")
        )
        self.transcript.tag_configure(
            "user_body",
            foreground=COLORS["cream"],
            background=COLORS["user"],
            lmargin1=8,
            lmargin2=8,
            rmargin=18,
            spacing1=3,
            spacing3=6,
        )
        self.transcript.tag_configure(
            "mako_body",
            foreground=COLORS["cream"],
            background=COLORS["mako"],
            lmargin1=8,
            lmargin2=8,
            rmargin=18,
            spacing1=3,
            spacing3=6,
        )
        self.transcript.tag_configure("system", foreground=COLORS["muted"], justify="center")
        self.transcript.insert("end", "mako is waking up\n\n", "system")
        self.transcript.configure(state="disabled")

        activity = tk.Frame(shell, bg=COLORS["window"], height=30)
        activity.pack_propagate(False)
        self.typing_label = tk.Label(
            activity,
            text="",
            font=("Segoe UI", 9, "italic"),
            fg=COLORS["muted"],
            bg=COLORS["window"],
            anchor="w",
        )
        self.typing_label.pack(side="left", fill="x", expand=True)

        input_frame = tk.Frame(shell, bg=COLORS["window"])
        self.input = tk.Entry(
            input_frame,
            font=("Segoe UI", 11),
            bg=COLORS["panel_alt"],
            fg=COLORS["cream"],
            insertbackground=COLORS["cream"],
            relief="flat",
            borderwidth=0,
        )
        self.input.pack(side="left", fill="x", expand=True, ipady=10, padx=(0, 8))
        send = tk.Button(
            input_frame,
            text="send",
            command=self._send_message,
            font=("Segoe UI", 9, "bold"),
            fg=COLORS["window"],
            bg=COLORS["rose"],
            activeforeground=COLORS["window"],
            activebackground=COLORS["rose_active"],
            relief="flat",
            borderwidth=0,
            cursor="hand2",
            width=7,
        )
        send.pack(side="right", ipady=8)

        # Reserve the fixed controls first so the expanding transcript cannot
        # push the composer below the edge of the window.
        input_frame.pack(side="bottom", fill="x", padx=14, pady=(0, 14))
        activity.pack(side="bottom", fill="x", padx=18, pady=(4, 0))
        transcript_frame.pack(fill="both", expand=True, padx=14)
        self.input.focus_set()

    def _place_window(self) -> None:
        ui = self.core.config.ui
        self.root.update_idletasks()
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        x = max(0, min(ui.x, screen_width - ui.width))
        y = max(0, min(ui.y, screen_height - ui.height))
        self.root.geometry(f"{ui.width}x{ui.height}+{x}+{y}")

    def _header_button(
        self,
        parent: tk.Widget,
        text: str,
        command: Callable[[], None],
        *,
        width: int,
    ) -> tk.Button:
        return tk.Button(
            parent,
            text=text,
            command=command,
            width=width,
            font=("Segoe UI", 9, "bold"),
            fg=COLORS["cream"],
            bg=COLORS["panel_alt"],
            activeforeground=COLORS["cream"],
            activebackground=COLORS["line"],
            relief="flat",
            borderwidth=0,
            cursor="hand2",
        )

    def _small_button(
        self,
        parent: tk.Widget,
        text: str,
        command: Callable[[], None],
    ) -> tk.Button:
        return tk.Button(
            parent,
            text=text,
            command=command,
            font=("Segoe UI", 8),
            fg=COLORS["muted"],
            bg=COLORS["window"],
            activeforeground=COLORS["cream"],
            activebackground=COLORS["panel_alt"],
            relief="flat",
            borderwidth=0,
            cursor="hand2",
            padx=6,
        )

    def _on_enter(self, _event: tk.Event) -> str:
        self._send_message()
        return "break"

    def _trigger_discord_test(self) -> None:
        if self.discord_service is None:
            self._show_error("Discord service is not available")
            return
        self._set_status("discord test")
        future = self.discord_service.trigger_autonomy_review()
        future.add_done_callback(
            lambda completed: self.dispatch(self._finish_discord_test, completed)
        )

    def _finish_discord_test(self, future: Any) -> None:
        try:
            future.result()
        except Exception as exc:
            self._show_error(str(exc))
        else:
            self._set_status("discord review sent")

    def _send_message(self) -> None:
        text = self.input.get().strip()
        if not text:
            return
        self.input.delete(0, "end")
        self._add_message("user", text)
        now = time.monotonic()
        self._last_user_activity = now
        if (
            not self.call.active
            and is_call_invitation(text)
            and parse_scheduled_call(text) is None
        ):
            self._start_text_invited_call_after_reading(text, now)
            return
        if self.call.active and self.call.submit_text(text):
            self._set_status("thinking")
            return
        self._pending_messages.append((text, now))
        reading_starts_at = max(now, self._reading_ready_at)
        self._reading_ready_at = reading_starts_at + self.core.clock.reading_seconds(text)
        if not self._busy and not self.call.active:
            self._set_status("reading")
            self.typing_label.configure(text="mako is reading...")
        self._schedule_pending_flush()

    def _start_text_invited_call_after_reading(self, text: str, received_at: float) -> None:
        """A direct call invitation skips text generation and becomes a real incoming call."""
        event = ConversationEvent(
            content=text,
            metadata={"call_event": "text_invitation"},
        )
        self.core.record_call_reflex(event, "")
        self._set_status("reading")
        delay = max(0, int(self.core.clock.reading_seconds(text) * 1000))
        self._call_invitation_after_id = self.root.after(
            delay,
            self._start_text_invited_call,
        )

    def _start_text_invited_call(self) -> None:
        self._call_invitation_after_id = None
        if self._closed or self.call.active or self._busy:
            return
        self._last_user_activity = time.monotonic()
        self.call.offer_outbound(
            OutboundCallPlan(
                greeting="hey. you wanted to call?",
                opener="so, what's up?",
                reason="user invited Mako to call",
                memory_basis="The user asked Mako to call from desktop chat.",
                expression=Expression.HAPPY,
            )
        )

    def _schedule_pending_flush(self) -> None:
        if self._batch_after_id:
            self.root.after_cancel(self._batch_after_id)
            self._batch_after_id = None
        if self._busy or self.call.active or not self._pending_messages:
            return
        batch_ready_at = (
            self._pending_messages[-1][1]
            + self.core.config.timing.message_batch_seconds
        )
        delay = max(0, int((batch_ready_at - time.monotonic()) * 1000))
        self._batch_after_id = self.root.after(delay, self._flush_batch)

    def _flush_batch(self) -> None:
        self._batch_after_id = None
        if self._busy or self.call.active or not self._pending_messages:
            return
        pending = self._pending_messages
        self._pending_messages = []
        combined = "\n".join(text for text, _ in pending)
        received_at = pending[0][1]
        typing_started_at = self._reading_ready_at
        event = ConversationEvent(content=combined)
        self._busy = True
        self._hide_feedback()
        cancel = threading.Event()
        self._text_cancel = cancel
        self._schedule_typing(typing_started_at)
        threading.Thread(
            target=self._response_worker,
            args=(event, received_at, typing_started_at, cancel),
            daemon=True,
        ).start()

    def _response_worker(
        self,
        event: ConversationEvent,
        received_at: float,
        typing_started_at: float,
        cancel: threading.Event,
    ) -> None:
        try:
            result = self.core.respond(event, cancel=cancel)
            if cancel.is_set():
                self.dispatch(self._generation_cancelled)
                return
            ready_at = time.monotonic()
            schedule = self.core.clock.schedule(
                received_at=received_at,
                model_ready_at=ready_at,
                user_text=event.content,
                response_text=result.text,
                complexity=result.complexity,
                typing_started_at=typing_started_at,
            )
            self.dispatch(self._queue_delivery, event, result, schedule.typing_starts_at, schedule.delivery_at)
        except ModelError as exc:
            if cancel.is_set():
                self.dispatch(self._generation_cancelled)
            else:
                self.dispatch(self._response_failed, str(exc))
        except Exception as exc:
            self.dispatch(self._response_failed, str(exc))

    def _queue_delivery(
        self,
        event: ConversationEvent,
        result: ResponseResult,
        typing_starts_at: float,
        delivery_at: float,
    ) -> None:
        now = time.monotonic()
        self._schedule_typing(typing_starts_at)
        self._delivery_payload = (event, result)
        delay = max(0, int((delivery_at - now) * 1000))
        self._delivery_after_id = self.root.after(delay, self._deliver_response)

    def _deliver_response(self) -> None:
        payload = self._delivery_payload
        self._delivery_payload = None
        self._delivery_after_id = None
        if not payload:
            return
        event, result = payload
        self._stop_typing()
        self._set_expression(result.expression)
        self._add_message("mako", result.text)
        self._last_event = event
        self._last_result = result
        self._busy = False
        self._text_cancel = None
        # A typed desktop turn may finish while a voice call is connected. It
        # still deserves to be visible; only its status remains call-connected.
        self._set_status("call connected" if self.call.active else "ready")
        self._show_feedback()
        if self._pending_messages:
            self._schedule_pending_flush()

    def _response_failed(self, error: str) -> None:
        self._stop_typing()
        self._busy = False
        self._text_cancel = None
        self._set_status("model offline")
        self._add_message("system", f"couldn't reach mako's model: {error}")
        if self._pending_messages:
            self._schedule_pending_flush()

    def _generation_cancelled(self) -> None:
        self._stop_typing()
        self._busy = False
        self._text_cancel = None
        if not self.call.active:
            self._set_status("ready")

    def _show_typing(self) -> None:
        self._typing_after_id = None
        if self.call.active or not self._busy or self._typing:
            return
        self._typing = True
        self._typing_frame = 0
        self.typing_sound.start()
        self._animate_typing()
        self._set_status("typing")

    def _schedule_typing(self, typing_starts_at: float) -> None:
        """Let generation run during reading, but reveal typing only after it feels read."""
        if self._typing or self._typing_after_id:
            return
        delay = max(0, int((typing_starts_at - time.monotonic()) * 1000))
        if delay == 0:
            self._show_typing()
        else:
            self._typing_after_id = self.root.after(delay, self._show_typing)

    def _show_thinking(self) -> None:
        if self.call.active or not self._busy:
            return
        self.typing_label.configure(text="mako is thinking...")
        self._set_status("thinking")

    def _animate_typing(self) -> None:
        if not self._typing:
            return
        dots = "." * ((self._typing_frame % 3) + 1)
        self.typing_label.configure(text=f"mako is typing{dots}")
        self._typing_frame += 1
        self._typing_animation_id = self.root.after(350, self._animate_typing)

    def _stop_typing(self) -> None:
        if self._typing_after_id:
            self.root.after_cancel(self._typing_after_id)
            self._typing_after_id = None
        if self._typing_animation_id:
            self.root.after_cancel(self._typing_animation_id)
            self._typing_animation_id = None
        self._typing = False
        self.typing_label.configure(text="")
        self.typing_sound.stop()

    def _accept_last(self) -> None:
        if not self._last_result:
            return
        self.core.accept_response(self._last_result.turn_id)
        self._hide_feedback()
        self._set_status("kept")
        self.root.after(900, lambda: self._set_status("ready"))

    def _retry_last(self) -> None:
        if self._busy or self.call.active or not self._last_event or not self._last_result:
            return
        event = self._last_event
        previous = self._last_result
        self._busy = True
        self._hide_feedback()
        cancel = threading.Event()
        self._text_cancel = cancel
        self._show_thinking()
        threading.Thread(
            target=self._retry_worker,
            args=(event, previous, cancel),
            daemon=True,
        ).start()

    def _retry_worker(
        self,
        event: ConversationEvent,
        previous: ResponseResult,
        cancel: threading.Event,
    ) -> None:
        started = time.monotonic()
        try:
            result = self.core.regenerate(event, previous, cancel=cancel)
            if cancel.is_set():
                self.dispatch(self._generation_cancelled)
                return
            ready = time.monotonic()
            schedule = self.core.clock.schedule(
                received_at=started,
                model_ready_at=ready,
                user_text="",
                response_text=result.text,
                complexity=result.complexity,
                typing_started_at=ready,
            )
            self.dispatch(self._queue_delivery, event, result, schedule.typing_starts_at, schedule.delivery_at)
        except ModelError as exc:
            self.dispatch(self._response_failed, str(exc))
        except Exception as exc:
            self.dispatch(self._response_failed, str(exc))

    def _toggle_call(self) -> None:
        if self.call.outbound_pending:
            self._decline_outbound_call()
            return
        if self.call.active:
            self.call_sounds.stop()
            self.call.hang_up()
            return
        self._stop_typing()
        if self._delivery_after_id and self._delivery_payload:
            self.root.after_cancel(self._delivery_after_id)
            self._delivery_after_id = None
            self._deliver_response()
        elif self._text_cancel:
            self._text_cancel.set()
        self.call_sounds.start_ringing()
        self.call.start()

    def _show_outbound_call(self, _plan: OutboundCallPlan) -> None:
        if self._closed or not self.call.outbound_pending:
            return
        if self._incoming_call_window and self._incoming_call_window.winfo_exists():
            self._incoming_call_window.lift()
            return

        self.call_sounds.start_ringing()
        window = tk.Toplevel(self.root)
        self._incoming_call_window = window
        window.title("Incoming call from Mako")
        window.configure(bg=COLORS["window"])
        window.attributes("-topmost", True)
        window.resizable(False, False)
        width, height = 390, 245
        # Keep the decision close to Mako rather than losing it in a screen corner.
        x = self.root.winfo_x() + (self.root.winfo_width() - width) // 2
        y = self.root.winfo_y() + (self.root.winfo_height() - height) // 2
        x = max(0, min(x, window.winfo_screenwidth() - width))
        y = max(0, min(y, window.winfo_screenheight() - height))
        window.geometry(f"{width}x{height}+{x}+{y}")
        window.protocol("WM_DELETE_WINDOW", self._decline_outbound_call)

        card = tk.Frame(
            window,
            bg=COLORS["panel"],
            highlightthickness=1,
            highlightbackground=COLORS["line"],
        )
        card.pack(fill="both", expand=True, padx=10, pady=10)

        tk.Label(
            card,
            text="INCOMING CALL",
            font=("Segoe UI", 8, "bold"),
            fg=COLORS["rose_active"],
            bg=COLORS["panel"],
        ).pack(anchor="w", padx=16, pady=(14, 0))

        caller = tk.Frame(card, bg=COLORS["panel"])
        caller.pack(fill="x", padx=16, pady=(7, 8))
        avatar = tk.Label(caller, bg=COLORS["panel_alt"], width=9, height=5)
        avatar.pack(side="left", padx=(0, 14))
        photo = self._call_notification_photo()
        if photo:
            avatar.image = photo
            avatar.configure(image=photo, width=0, height=0)
        else:
            avatar.configure(text="MAKO", fg=COLORS["cream"], font=("Georgia", 11, "bold"))

        caller_text = tk.Frame(caller, bg=COLORS["panel"])
        caller_text.pack(side="left", fill="both", expand=True)
        tk.Label(
            caller_text,
            text="Mako",
            font=("Georgia", 19, "bold"),
            fg=COLORS["cream"],
            bg=COLORS["panel"],
            anchor="w",
        ).pack(anchor="w")
        tk.Label(
            caller_text,
            text="is calling you",
            font=("Segoe UI", 10),
            fg=COLORS["muted"],
            bg=COLORS["panel"],
            anchor="w",
        ).pack(anchor="w", pady=(2, 0))
        tk.Label(
            caller_text,
            text="ringing...",
            font=("Segoe UI", 9, "italic"),
            fg=COLORS["rose_active"],
            bg=COLORS["panel"],
            anchor="w",
        ).pack(anchor="w", pady=(3, 0))

        actions = tk.Frame(card, bg=COLORS["panel"])
        actions.pack(fill="x", padx=16, pady=(4, 14))
        decline = tk.Button(
            actions,
            text="DECLINE",
            command=self._decline_outbound_call,
            font=("Segoe UI", 9, "bold"),
            fg=COLORS["cream"],
            bg=COLORS["panel_alt"],
            activeforeground=COLORS["cream"],
            activebackground=COLORS["line"],
            relief="flat",
            borderwidth=0,
            cursor="hand2",
            padx=18,
            pady=8,
        )
        decline.pack(side="left", fill="x", expand=True, padx=(0, 5))
        answer = tk.Button(
            actions,
            text="ANSWER",
            command=self._answer_outbound_call,
            font=("Segoe UI", 9, "bold"),
            fg=COLORS["window"],
            bg=COLORS["good"],
            activeforeground=COLORS["window"],
            activebackground="#b9d5a8",
            relief="flat",
            borderwidth=0,
            cursor="hand2",
            padx=18,
            pady=8,
        )
        answer.pack(side="left", fill="x", expand=True, padx=(5, 0))
        window.bind("<Return>", lambda _event: self._answer_outbound_call())
        window.bind("<Escape>", lambda _event: self._decline_outbound_call())
        window.lift()
        window.focus_force()
        answer.focus_set()

    def _call_notification_photo(self) -> ImageTk.PhotoImage | None:
        asset = self._expression_asset(Expression.HAPPY)
        if not asset:
            return None
        try:
            with Image.open(asset) as source:
                image = source.convert("RGBA")
                image.thumbnail((76, 76), Image.Resampling.LANCZOS)
            return ImageTk.PhotoImage(image)
        except OSError:
            return None

    def _answer_outbound_call(self) -> None:
        if not self.call.outbound_pending:
            self._close_outbound_call_prompt()
            return
        self._close_outbound_call_prompt()
        self.call_sounds.answered()
        self.call.accept_outbound()

    def _decline_outbound_call(self) -> None:
        self._close_outbound_call_prompt()
        self.call_sounds.stop()
        self.call.decline_outbound("declined")

    def _close_outbound_call_prompt(self) -> None:
        if self._incoming_call_window and self._incoming_call_window.winfo_exists():
            self._incoming_call_window.destroy()
        self._incoming_call_window = None

    def _open_microphone_settings(self) -> None:
        if self._microphone_window and self._microphone_window.winfo_exists():
            self._microphone_window.deiconify()
            self._microphone_window.lift()
            return

        try:
            import sounddevice as sd

            devices = sd.query_devices()
            default_index = int(sd.default.device[0])
            default_name = str(devices[default_index]["name"])
            choices: list[tuple[int | None, str]] = [
                (None, f"System default: {default_name}")
            ]
            choices.extend(
                (index, f"[{index}] {device['name']}")
                for index, device in enumerate(devices)
                if int(device["max_input_channels"]) > 0
            )
        except Exception as exc:
            self._show_error(f"couldn't list microphones: {exc}")
            return

        window = tk.Toplevel(self.root)
        self._microphone_window = window
        self._microphone_choices = choices
        window.title("Mako microphone")
        window.configure(bg=COLORS["window"])
        window.attributes("-topmost", True)
        window.transient(self.root)
        window.resizable(False, False)
        width, height = 430, 330
        x = max(0, self.root.winfo_x() - width - 12)
        y = max(0, self.root.winfo_y() + 40)
        window.geometry(f"{width}x{height}+{x}+{y}")
        window.protocol("WM_DELETE_WINDOW", self._close_microphone_settings)

        tk.Label(
            window,
            text="MICROPHONE INPUT",
            font=("Georgia", 13, "bold"),
            fg=COLORS["cream"],
            bg=COLORS["window"],
            anchor="w",
        ).pack(fill="x", padx=16, pady=(16, 2))
        tk.Label(
            window,
            text="Choose what Mako listens to during calls. This does not affect text chat.",
            font=("Segoe UI", 9),
            fg=COLORS["muted"],
            bg=COLORS["window"],
            anchor="w",
        ).pack(fill="x", padx=16, pady=(0, 10))

        list_frame = tk.Frame(window, bg=COLORS["panel"])
        list_frame.pack(fill="both", expand=True, padx=16)
        microphone_list = tk.Listbox(
            list_frame,
            bg=COLORS["panel"],
            fg=COLORS["cream"],
            selectbackground=COLORS["rose"],
            selectforeground=COLORS["window"],
            highlightbackground=COLORS["line"],
            highlightcolor=COLORS["rose"],
            relief="flat",
            borderwidth=0,
            activestyle="none",
            font=("Segoe UI", 9),
        )
        scrollbar = tk.Scrollbar(
            list_frame,
            command=microphone_list.yview,
            bg=COLORS["panel_alt"],
            troughcolor=COLORS["panel"],
            relief="flat",
            borderwidth=0,
        )
        scrollbar.pack(side="right", fill="y")
        microphone_list.pack(side="left", fill="both", expand=True, padx=8, pady=8)
        microphone_list.configure(yscrollcommand=scrollbar.set)
        for _, label in choices:
            microphone_list.insert("end", label)

        selected_device = self.core.config.voice.input_device
        selected_index = next(
            (index for index, (device, _) in enumerate(choices) if device == selected_device),
            0,
        )
        microphone_list.selection_set(selected_index)
        microphone_list.see(selected_index)

        actions = tk.Frame(window, bg=COLORS["window"])
        actions.pack(fill="x", padx=16, pady=14)
        cancel = self._header_button(actions, "cancel", self._close_microphone_settings, width=8)
        cancel.pack(side="right")
        use_selected = tk.Button(
            actions,
            text="use selected",
            command=lambda: self._save_microphone_selection(microphone_list),
            font=("Segoe UI", 9, "bold"),
            fg=COLORS["window"],
            bg=COLORS["rose"],
            activeforeground=COLORS["window"],
            activebackground=COLORS["rose_active"],
            relief="flat",
            borderwidth=0,
            cursor="hand2",
            padx=12,
            pady=5,
        )
        use_selected.pack(side="right", padx=(0, 8))
        microphone_list.bind(
            "<Double-Button-1>",
            lambda _event: self._save_microphone_selection(microphone_list),
        )
        microphone_list.focus_set()

    def _save_microphone_selection(self, microphone_list: tk.Listbox) -> None:
        selection = microphone_list.curselection()
        if not selection:
            return
        device, label = self._microphone_choices[int(selection[0])]
        self.core.config.voice.input_device = device
        self.core.save_input_device(device)
        self._set_status("mic saved")
        self._close_microphone_settings()

    def _close_microphone_settings(self) -> None:
        if self._microphone_window and self._microphone_window.winfo_exists():
            self._microphone_window.destroy()
        self._microphone_window = None
        self._microphone_choices = []

    def _set_call_state(self, state: str) -> None:
        self._set_status(state)
        if state in {"connecting voice", "offline"}:
            self._last_user_activity = time.monotonic()
        if state == "offline":
            self.call_sounds.stop()
            self._close_outbound_call_prompt()
            self.call_button.configure(text="call", bg=COLORS["panel_alt"])
            if self._pending_messages:
                self._schedule_pending_flush()
        else:
            if state == "connecting voice":
                self.call_sounds.answered()
            self.call_button.configure(text="hang up", bg=COLORS["rose"])

    def _on_call_response(self, result: ResponseResult) -> None:
        self._set_expression(result.expression)
        if result.trace.get("call_text_only"):
            self._last_result = result
            self._add_message("mako", result.text)

    def _on_vision_response(self, result: ResponseResult) -> None:
        if self._busy or self.call.active:
            return
        self._set_expression(result.expression)
        self._add_message("mako", result.text)

    def _show_error(self, error: str) -> None:
        self._set_status("error")
        self._add_message("system", error)

    def _add_message(self, speaker: str, text: str) -> None:
        self.transcript.configure(state="normal")
        if speaker == "user":
            self.transcript.insert("end", "YOU\n", "user_name")
            self.transcript.insert("end", f" {text}\n", "user_body")
        elif speaker == "mako":
            self.transcript.insert("end", "MAKO\n", "mako_name")
            self.transcript.insert("end", f" {text}\n", "mako_body")
        else:
            self.transcript.insert("end", f"{text}\n", "system")
        self.transcript.insert("end", "\n")
        self.transcript.see("end")
        self.transcript.configure(state="disabled")

    def _set_expression(self, expression: Expression) -> None:
        asset = self._expression_asset(expression)
        if not asset:
            self.avatar_label.configure(image="", text="mako", fg=COLORS["cream"])
            return
        try:
            with Image.open(asset) as source:
                # Expression PNGs use alpha; keep it so the portrait panel shows through.
                image = source.convert("RGBA")
                image.thumbnail(
                    (
                        self.core.config.ui.avatar_max_width,
                        min(290, self.core.config.ui.avatar_max_height),
                    ),
                    Image.Resampling.LANCZOS,
                )
            photo = ImageTk.PhotoImage(image)
            self.avatar_label.image = photo
            self.avatar_label.configure(image=photo, text="")
        except OSError as exc:
            self._set_status(f"expression error: {exc}")

    def _expression_asset(self, expression: Expression) -> Path | None:
        for filename in EXPRESSION_FILES.get(expression, ("Neutral.png",)):
            path = self.core.paths.assets / filename
            if path.exists():
                return path
        return None

    def _show_feedback(self) -> None:
        return

    def _hide_feedback(self) -> None:
        return

    def _set_status(self, text: str) -> None:
        self.status_label.configure(text=text[:60])

    def _start_background_services(self) -> None:
        self.vision.start()
        threading.Thread(target=self._warm_model, daemon=True).start()

    def _warm_model(self) -> None:
        status = self.core.model_status()
        if not status.get("online"):
            self.dispatch(self._set_status, "model offline")
            return
        self.dispatch(self._set_status, "loading model")
        try:
            self.core.prewarm()
        except ModelError as exc:
            self.dispatch(self._set_status, f"model error: {exc}")
            return
        self.dispatch(self._set_status, "ready")

    def _maintenance_tick(self) -> None:
        if self._closed:
            return
        idle_for = time.monotonic() - self._last_user_activity
        can_consider_call = (
            not self._busy
            and not self.call.active
            and self.proactive_calls.can_consider(idle_for)
            and not (self._proactive_thread and self._proactive_thread.is_alive())
        )
        if can_consider_call:
            self.proactive_calls.mark_considered()
            self._proactive_thread = threading.Thread(
                target=self._consider_outbound_call,
                daemon=True,
            )
            self._proactive_thread.start()
        elif (
            idle_for >= self.core.config.memory.consolidation_idle_seconds
            and not self._busy
            and not self.call.active
        ):
            threading.Thread(target=self.core.run_maintenance, daemon=True).start()
        self.root.after(30000, self._maintenance_tick)

    def _scheduled_call_tick(self) -> None:
        if self._closed:
            return
        if not self._busy and not self.call.active:
            due_calls = self.core.due_scheduled_calls()
            if due_calls:
                callback = due_calls[0]
                greeting = SCHEDULED_CALL_GREETINGS[
                    sum(ord(character) for character in callback.id)
                    % len(SCHEDULED_CALL_GREETINGS)
                ]
                plan = OutboundCallPlan(
                    greeting=greeting,
                    opener="i kept the time. what'd i miss?",
                    reason="user-requested callback",
                    memory_basis=callback.request_text,
                    expression=Expression.HAPPY,
                )
                if self.call.offer_outbound(plan):
                    self.core.complete_scheduled_call(callback.id)
        self.root.after(1000, self._scheduled_call_tick)

    def _consider_outbound_call(self) -> None:
        plan = self.core.consider_proactive_call()
        if plan:
            self.dispatch(self._offer_outbound_call, plan)

    def _offer_outbound_call(self, plan: OutboundCallPlan) -> None:
        idle_for = time.monotonic() - self._last_user_activity
        if (
            self._closed
            or self._busy
            or self.call.active
            or idle_for < self.core.config.proactive_calls.minimum_idle_seconds
        ):
            return
        if self.call.offer_outbound(plan):
            self.proactive_calls.mark_offered()

    def _drain_ui_queue(self) -> None:
        if self._closed:
            return
        while True:
            try:
                function, args = self._ui_queue.get_nowait()
            except queue.Empty:
                break
            function(*args)
        self.root.after(40, self._drain_ui_queue)

    def _start_move(self, event: tk.Event) -> None:
        self._drag_origin = (event.x_root - self.root.winfo_x(), event.y_root - self.root.winfo_y())

    def _move_window(self, event: tk.Event) -> None:
        x = event.x_root - self._drag_origin[0]
        y = event.y_root - self._drag_origin[1]
        self.root.geometry(f"+{x}+{y}")

    def _minimize(self) -> None:
        if self.core.config.ui.borderless:
            self.root.overrideredirect(False)
            self.root.bind("<Map>", self._restore_borderless, add="+")
        self.root.iconify()

    def _restore_borderless(self, _event: tk.Event) -> None:
        if self.core.config.ui.borderless and self.root.state() == "normal":
            self.root.after(10, lambda: self.root.overrideredirect(True))
