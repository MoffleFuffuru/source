from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Iterator

from .quality import token_jaccard


class ResponseLedger:
    def __init__(self, database_path: Path) -> None:
        self.database_path = database_path
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._initialize()

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.database_path, timeout=20.0)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA foreign_keys=ON")
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS turns (
                    turn_id TEXT PRIMARY KEY,
                    event_id TEXT NOT NULL,
                    source TEXT NOT NULL,
                    user_text TEXT NOT NULL,
                    response_text TEXT NOT NULL,
                    expression TEXT NOT NULL,
                    move TEXT NOT NULL,
                    quality_score REAL NOT NULL,
                    repaired INTEGER NOT NULL,
                    attempts INTEGER NOT NULL,
                    model TEXT NOT NULL,
                    generation_seconds REAL NOT NULL,
                    explicit_feedback INTEGER,
                    feedback_reason TEXT,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS attempts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    turn_id TEXT NOT NULL,
                    attempt_number INTEGER NOT NULL,
                    candidate TEXT NOT NULL,
                    accepted INTEGER NOT NULL,
                    score REAL NOT NULL,
                    failures_json TEXT NOT NULL,
                    evidence_json TEXT NOT NULL,
                    repair_direction TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS behavior_lessons (
                    signature TEXT PRIMARY KEY,
                    lesson TEXT NOT NULL,
                    confidence REAL NOT NULL,
                    evidence_count INTEGER NOT NULL,
                    last_seen TEXT NOT NULL,
                    last_used TEXT
                );

                CREATE INDEX IF NOT EXISTS idx_turns_created_at
                ON turns(created_at DESC);

                CREATE TABLE IF NOT EXISTS memory_delivery (
                    turn_id TEXT PRIMARY KEY,
                    source TEXT NOT NULL,
                    route TEXT NOT NULL,
                    retrieved_count INTEGER NOT NULL CHECK(retrieved_count >= 0),
                    included_count INTEGER NOT NULL CHECK(included_count >= 0),
                    created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_memory_delivery_created_at
                ON memory_delivery(created_at DESC);
                """
            )

    def record_memory_delivery(
        self, *, turn_id: str, source: str, route: str,
        retrieved_count: int, included_count: int,
    ) -> None:
        """Persist count-only retrieval telemetry; never store memory text or IDs."""
        with self._lock, self._connect() as connection:
            connection.execute(
                """INSERT OR REPLACE INTO memory_delivery
                   (turn_id, source, route, retrieved_count, included_count, created_at)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (turn_id, source, route, max(0, int(retrieved_count)),
                 max(0, int(included_count)), datetime.now(UTC).isoformat()),
            )

    def memory_delivery_summary(self) -> dict[str, float | int]:
        with self._lock, self._connect() as connection:
            row = connection.execute(
                """SELECT COUNT(*) AS turns,
                          COALESCE(AVG(retrieved_count), 0) AS avg_retrieved,
                          COALESCE(AVG(included_count), 0) AS avg_included,
                          COALESCE(MAX(included_count), 0) AS max_included
                   FROM memory_delivery"""
            ).fetchone()
        return {
            "turns": int(row["turns"]),
            "avg_retrieved": float(row["avg_retrieved"]),
            "avg_included": float(row["avg_included"]),
            "max_included": int(row["max_included"]),
        }

    def recent_responses(self, limit: int = 24) -> list[str]:
        with self._lock, self._connect() as connection:
            rows = connection.execute(
                "SELECT response_text FROM turns ORDER BY created_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [str(row["response_text"]) for row in rows]

    def record_attempt(
        self,
        *,
        turn_id: str,
        attempt_number: int,
        candidate: str,
        accepted: bool,
        score: float,
        failures: list[str],
        evidence: list[str],
        repair_direction: str,
    ) -> None:
        now = datetime.now(UTC).isoformat()
        with self._lock, self._connect() as connection:
            connection.execute(
                """
                INSERT INTO attempts (
                    turn_id, attempt_number, candidate, accepted, score,
                    failures_json, evidence_json, repair_direction, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    turn_id,
                    attempt_number,
                    candidate,
                    int(accepted),
                    score,
                    json.dumps(failures),
                    json.dumps(evidence),
                    repair_direction,
                    now,
                ),
            )

    def record_turn(self, values: dict[str, Any]) -> None:
        with self._lock, self._connect() as connection:
            connection.execute(
                """
                INSERT INTO turns (
                    turn_id, event_id, source, user_text, response_text,
                    expression, move, quality_score, repaired, attempts,
                    model, generation_seconds, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    values["turn_id"],
                    values["event_id"],
                    values["source"],
                    values["user_text"],
                    values["response_text"],
                    values["expression"],
                    values["move"],
                    values["quality_score"],
                    int(values["repaired"]),
                    values["attempts"],
                    values["model"],
                    values["generation_seconds"],
                    values.get("created_at", datetime.now(UTC).isoformat()),
                ),
            )

    def record_feedback(self, turn_id: str, accepted: bool, reason: str = "") -> None:
        with self._lock, self._connect() as connection:
            connection.execute(
                """
                UPDATE turns
                SET explicit_feedback = ?, feedback_reason = ?
                WHERE turn_id = ?
                """,
                (int(accepted), reason.strip(), turn_id),
            )
        if not accepted:
            direction = reason.strip() or "Use a different conversational move and emotional angle."
            self.learn_failure(
                "explicit_user_rejection",
                f"When the user rejects a response, do not defend or lightly reword it. {direction}",
            )

    def learn_failure(self, failure: str, lesson: str) -> None:
        signature = failure.strip().lower().replace(" ", "_")
        if not signature or not lesson.strip():
            return
        now = datetime.now(UTC).isoformat()
        with self._lock, self._connect() as connection:
            existing = connection.execute(
                "SELECT confidence, evidence_count FROM behavior_lessons WHERE signature = ?",
                (signature,),
            ).fetchone()
            if existing:
                evidence_count = int(existing["evidence_count"]) + 1
                confidence = min(0.95, float(existing["confidence"]) + 0.06)
                connection.execute(
                    """
                    UPDATE behavior_lessons
                    SET lesson = ?, confidence = ?, evidence_count = ?, last_seen = ?
                    WHERE signature = ?
                    """,
                    (lesson.strip(), confidence, evidence_count, now, signature),
                )
            else:
                connection.execute(
                    """
                    INSERT INTO behavior_lessons
                    (signature, lesson, confidence, evidence_count, last_seen)
                    VALUES (?, ?, ?, 1, ?)
                    """,
                    (signature, lesson.strip(), 0.35, now),
                )

    def relevant_lessons(self, user_text: str, limit: int = 4) -> list[str]:
        with self._lock, self._connect() as connection:
            rows = connection.execute(
                """
                SELECT signature, lesson, confidence
                FROM behavior_lessons
                ORDER BY confidence DESC, evidence_count DESC
                LIMIT 40
                """
            ).fetchall()

        ranked: list[tuple[float, sqlite3.Row]] = []
        for row in rows:
            relevance = token_jaccard(user_text, f"{row['signature']} {row['lesson']}")
            score = relevance + (float(row["confidence"]) * 0.25)
            ranked.append((score, row))
        selected = [row for score, row in sorted(ranked, key=lambda item: item[0], reverse=True)[:limit] if score > 0.08]

        if selected:
            now = datetime.now(UTC).isoformat()
            with self._lock, self._connect() as connection:
                connection.executemany(
                    "UPDATE behavior_lessons SET last_used = ? WHERE signature = ?",
                    [(now, row["signature"]) for row in selected],
                )
        return [str(row["lesson"]) for row in selected]

    def stats(self) -> dict[str, int]:
        with self._lock, self._connect() as connection:
            return {
                "turns": int(connection.execute("SELECT COUNT(*) FROM turns").fetchone()[0]),
                "attempts": int(connection.execute("SELECT COUNT(*) FROM attempts").fetchone()[0]),
                "lessons": int(connection.execute("SELECT COUNT(*) FROM behavior_lessons").fetchone()[0]),
            }
