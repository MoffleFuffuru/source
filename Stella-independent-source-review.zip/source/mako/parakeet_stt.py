from __future__ import annotations

import ctypes
import logging
import os
import queue
import threading
from collections.abc import Callable
from pathlib import Path


LOG = logging.getLogger(__name__)
SAMPLE_RATE = 16_000


class ParakeetSTTError(RuntimeError):
    pass


class ParakeetSTTClient:
    """Direct local bridge to parakeet.cpp's cache-aware EOU stream API."""

    def __init__(
        self,
        *,
        root_directory: Path,
        library_path: str,
        model_path: str,
        input_device: int | None,
        chunk_milliseconds: int,
        on_utterance: Callable[[str], None],
        on_partial: Callable[[str], None] | None,
        on_status: Callable[[str], None],
    ) -> None:
        self.root_directory = root_directory
        self.library_path = self._resolve_path(library_path)
        self.model_path = self._resolve_path(model_path)
        self.input_device = input_device
        self.chunk_milliseconds = max(20, min(160, int(chunk_milliseconds)))
        self.on_utterance = on_utterance
        self.on_partial = on_partial
        self.on_status = on_status
        self._library = None
        self._context = None
        self._session = None
        self._stream = None
        self._queue: queue.Queue[object | None] = queue.Queue(maxsize=256)
        self._thread: threading.Thread | None = None
        self._running = threading.Event()
        self._muted = True
        self._native_rate = SAMPLE_RATE
        self._buffer = None
        self._parts: list[str] = []
        self._lock = threading.RLock()
        self._dll_directories = []

    def start(self) -> None:
        import numpy as np
        import sounddevice as sd

        self._load_runtime()
        self._context = self._library.parakeet_capi_load(str(self.model_path).encode())
        if not self._context:
            raise ParakeetSTTError(f"Could not load Parakeet model: {self._last_error()}")
        self._begin_session()
        self._buffer = np.empty(0, dtype=np.float32)
        device_info = sd.query_devices(self.input_device, "input")
        native_rate = int(round(float(device_info["default_samplerate"])))
        self._native_rate = native_rate if native_rate > 0 else SAMPLE_RATE
        blocksize = max(160, round(self._native_rate * self.chunk_milliseconds / 1000.0))
        self._running.set()
        self._thread = threading.Thread(target=self._run, name="mako-parakeet-stt", daemon=True)
        self._thread.start()
        self._stream = sd.InputStream(
            callback=self._audio_callback,
            channels=1,
            device=self.input_device,
            samplerate=self._native_rate,
            blocksize=blocksize,
            dtype="float32",
        )
        self._stream.start()
        self._muted = False
        self.on_status("call connected")

    def stop(self) -> None:
        self._muted = True
        self._running.clear()
        if self._stream is not None:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception:
                pass
            self._stream = None
        try:
            self._queue.put_nowait(None)
        except queue.Full:
            pass
        if self._thread is not None and self._thread is not threading.current_thread():
            self._thread.join(timeout=5)
        self._thread = None
        with self._lock:
            if self._session:
                self._library.parakeet_capi_stream_free(self._session)
                self._session = None
            if self._context:
                self._library.parakeet_capi_free(self._context)
                self._context = None

    def set_muted(self, muted: bool) -> None:
        self._muted = muted
        if not muted:
            import numpy as np

            with self._lock:
                self._buffer = np.empty(0, dtype=np.float32)

    def _load_runtime(self) -> None:
        if not self.library_path.is_file():
            raise ParakeetSTTError(f"Parakeet DLL is missing: {self.library_path}")
        if not self.model_path.is_file():
            raise ParakeetSTTError(f"Parakeet model is missing: {self.model_path}")
        if os.name == "nt":
            for directory in (self.library_path.parent, self.library_path.parent / "bin"):
                if directory.is_dir():
                    self._dll_directories.append(os.add_dll_directory(str(directory)))
            cuda_root = Path("C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.2")
            for directory in (cuda_root / "bin", cuda_root / "bin" / "x64"):
                if directory.is_dir():
                    self._dll_directories.append(os.add_dll_directory(str(directory)))
        try:
            library = ctypes.CDLL(str(self.library_path))
        except OSError as exc:
            raise ParakeetSTTError(f"Could not load Parakeet DLL: {exc}") from exc
        library.parakeet_capi_load.argtypes = [ctypes.c_char_p]
        library.parakeet_capi_load.restype = ctypes.c_void_p
        library.parakeet_capi_free.argtypes = [ctypes.c_void_p]
        library.parakeet_capi_stream_begin.argtypes = [ctypes.c_void_p]
        library.parakeet_capi_stream_begin.restype = ctypes.c_void_p
        library.parakeet_capi_stream_feed.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_float), ctypes.c_int, ctypes.POINTER(ctypes.c_int)]
        library.parakeet_capi_stream_feed.restype = ctypes.c_void_p
        library.parakeet_capi_stream_finalize.argtypes = [ctypes.c_void_p]
        library.parakeet_capi_stream_finalize.restype = ctypes.c_void_p
        library.parakeet_capi_stream_free.argtypes = [ctypes.c_void_p]
        library.parakeet_capi_free_string.argtypes = [ctypes.c_void_p]
        library.parakeet_capi_last_error.argtypes = [ctypes.c_void_p]
        library.parakeet_capi_last_error.restype = ctypes.c_char_p
        self._library = library

    def _begin_session(self) -> None:
        self._session = self._library.parakeet_capi_stream_begin(self._context)
        if not self._session:
            raise ParakeetSTTError(f"Could not start Parakeet stream: {self._last_error()}")
        self._parts.clear()

    def _run(self) -> None:
        while self._running.is_set():
            samples = self._queue.get()
            if samples is None:
                return
            try:
                self._feed(samples)
            except Exception as exc:
                LOG.exception("Parakeet streaming failed")
                self.on_status(f"voice error: Parakeet STT: {exc}")
                self._running.clear()
                return

    def _feed(self, samples) -> None:
        import numpy as np

        event = ctypes.c_int(0)
        pcm = np.ascontiguousarray(samples, dtype=np.float32)
        pointer = self._library.parakeet_capi_stream_feed(
            self._session, pcm.ctypes.data_as(ctypes.POINTER(ctypes.c_float)), pcm.size, ctypes.byref(event)
        )
        text = self._consume_string(pointer)
        if text:
            self._parts.append(text)
            partial = self._transcript()
            if partial and self.on_partial:
                self.on_partial(partial)
        if event.value & 2:
            LOG.info("Parakeet EOB ignored")
            self._reset_session()
            return
        if event.value & 1:
            # Process the pending encoder tail before committing the EOU turn.
            tail = self._consume_string(self._library.parakeet_capi_stream_finalize(self._session))
            if tail:
                self._parts.append(tail)
            transcript = self._transcript()
            LOG.info("Parakeet EOU committed transcript chars=%s", len(transcript))
            self._reset_session()
            if transcript:
                self.on_utterance(transcript)

    def _reset_session(self) -> None:
        if self._session:
            self._library.parakeet_capi_stream_free(self._session)
            self._session = None
        self._begin_session()

    def _audio_callback(self, in_data, frames, timing, status) -> None:
        del frames, timing
        if status:
            LOG.debug("Parakeet microphone status: %s", status)
        if self._muted or in_data is None or not self._running.is_set():
            return
        import numpy as np

        samples = np.asarray(in_data, dtype=np.float32).reshape(-1)
        if self._native_rate != SAMPLE_RATE and samples.size:
            target_size = max(1, round(samples.size * SAMPLE_RATE / self._native_rate))
            samples = np.interp(np.linspace(0.0, samples.size - 1, num=target_size), np.arange(samples.size), samples).astype(np.float32)
        with self._lock:
            self._buffer = np.concatenate((self._buffer, samples))
            frame_size = max(160, round(SAMPLE_RATE * self.chunk_milliseconds / 1000.0))
            while self._buffer.size >= frame_size:
                frame = self._buffer[:frame_size].copy()
                self._buffer = self._buffer[frame_size:]
                try:
                    self._queue.put_nowait(frame)
                except queue.Full:
                    LOG.warning("Parakeet audio queue overflow; dropping one frame")
                    return

    def _consume_string(self, pointer: int | None) -> str:
        if not pointer:
            raise ParakeetSTTError(self._last_error())
        try:
            return ctypes.string_at(pointer).decode("utf-8", errors="replace")
        finally:
            self._library.parakeet_capi_free_string(pointer)

    def _last_error(self) -> str:
        if not self._library or not self._context:
            return "unknown Parakeet error"
        message = self._library.parakeet_capi_last_error(self._context)
        return message.decode("utf-8", errors="replace") if message else "unknown Parakeet error"

    def _transcript(self) -> str:
        return " ".join("".join(self._parts).split())

    def _resolve_path(self, configured_path: str) -> Path:
        path = Path(configured_path).expanduser()
        return path if path.is_absolute() else self.root_directory / path
