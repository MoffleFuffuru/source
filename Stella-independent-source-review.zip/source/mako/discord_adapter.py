from __future__ import annotations

from dataclasses import dataclass

from .config import DiscordConfig
from .core import MakoCore
from .models import ConversationEvent, EventSource, Visibility


@dataclass(frozen=True, slots=True)
class DiscordEnvelope:
    content: str
    user_id: str
    display_name: str
    guild_id: str
    channel_id: str
    is_direct_message: bool = False


class DiscordAdapter:
    """Disabled transport boundary for a later Discord bot iteration."""

    def __init__(self, core: MakoCore, config: DiscordConfig) -> None:
        self.core = core
        self.config = config

    def start(self) -> None:
        if not self.config.enabled:
            return
        raise RuntimeError(
            "Discord transport is intentionally scaffolded but disabled in the desktop test build."
        )

    def event_from_message(self, message: DiscordEnvelope) -> ConversationEvent:
        if self.config.allowed_guild_ids and message.guild_id not in self.config.allowed_guild_ids:
            raise PermissionError("Discord guild is not allowlisted")
        if self.config.allowed_channel_ids and message.channel_id not in self.config.allowed_channel_ids:
            raise PermissionError("Discord channel is not allowlisted")
        return ConversationEvent(
            content=message.content,
            source=EventSource.DISCORD,
            visibility=Visibility.PRIVATE if message.is_direct_message else Visibility.PUBLIC,
            user_id=message.user_id,
            display_name=message.display_name,
            channel_id=message.channel_id,
            metadata={"guild_id": message.guild_id},
        )
