from __future__ import annotations

import json
import re
import time
from dataclasses import asdict, dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path


NUMBER_WORDS = {
    "a": 1.0, "an": 1.0, "one": 1.0, "two": 2.0, "three": 3.0, "four": 4.0,
    "five": 5.0, "six": 6.0, "seven": 7.0, "eight": 8.0, "nine": 9.0,
    "ten": 10.0, "fifteen": 15.0, "twenty": 20.0, "thirty": 30.0,
    "forty": 40.0, "forty-five": 45.0, "fifty": 50.0, "sixty": 60.0,
}
RELATIVE_TIME_RE = re.compile(
    r"\b(?:in|after)\s+(?:(?:about|around|roughly|like)\s+)*(half|an?|\d+(?:\.\d+)?|[a-z-]+)\s*"
    r"(seconds?|secs?|minutes?|mins?|hours?|hrs?|days?)\b",
    flags=re.IGNORECASE,
)
CLOCK_TIME_RE = re.compile(
    r"\b(?:tomorrow\s+)?at\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\b",
    flags=re.IGNORECASE,
)


@dataclass(frozen=True, slots=True)
class ScheduledCall:
    id: str
    due_at: float
    requested_at: float
    request_text: str
    time_label: str


def parse_scheduled_call(text: str, *, now: float | None = None) -> ScheduledCall | None:
    """Parse an explicit user request for Mako to call at a later time."""
    lowered = text.lower().replace("’", "'")
    words = set(re.findall(r"[a-z]+", lowered))
    has_call = bool({"call", "ring"} & words)
    request_words = {"me", "us", "back", "wanna", "want", "would", "could", "can", "should"}
    if not has_call or not (words & request_words):
        return None

    timestamp = time.time() if now is None else now
    relative = RELATIVE_TIME_RE.search(lowered)
    if relative:
        quantity_text, unit = relative.groups()
        quantity = 0.5 if quantity_text.lower() == "half" else NUMBER_WORDS.get(quantity_text.lower())
        if quantity is None:
            try:
                quantity = float(quantity_text)
            except ValueError:
                return None
        multipliers = {
            "second": 1, "sec": 1, "minute": 60, "min": 60,
            "hour": 3600, "hr": 3600, "day": 86400,
        }
        unit_key = unit.lower().rstrip("s")
        seconds = quantity * multipliers.get(unit_key, 0)
        if seconds <= 0:
            return None
        return ScheduledCall(
            id=f"call-{int(timestamp * 1000)}",
            due_at=timestamp + seconds,
            requested_at=timestamp,
            request_text=text,
            time_label=f"in {quantity_text} {unit}",
        )

    clock = CLOCK_TIME_RE.search(lowered)
    if not clock:
        return None
    hour_text, minute_text, meridiem = clock.groups()
    hour = int(hour_text)
    minute = int(minute_text or 0)
    if minute > 59 or hour > 23 or hour == 0 and meridiem:
        return None
    if meridiem:
        hour %= 12
        if meridiem.lower() == "pm":
            hour += 12
    local_now = datetime.fromtimestamp(timestamp, UTC).astimezone()
    due = local_now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if "tomorrow" in lowered or due <= local_now:
        due += timedelta(days=1)
    clock_label = f"{due.strftime('%I').lstrip('0') or '12'}:{due.strftime('%M %p').lower()}"
    return ScheduledCall(
        id=f"call-{int(timestamp * 1000)}",
        due_at=due.timestamp(),
        requested_at=timestamp,
        request_text=text,
        time_label=f"at {clock_label}",
    )


class ScheduledCallStore:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._calls = self._load()

    def add(self, call: ScheduledCall) -> ScheduledCall:
        self._calls = [item for item in self._calls if item.id != call.id]
        self._calls.append(call)
        self._save()
        return call

    def due(self, *, now: float | None = None) -> list[ScheduledCall]:
        timestamp = time.time() if now is None else now
        return [item for item in self._calls if item.due_at <= timestamp]

    def remove(self, call_id: str) -> None:
        self._calls = [item for item in self._calls if item.id != call_id]
        self._save()

    def _load(self) -> list[ScheduledCall]:
        if not self.path.exists():
            return []
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            return [ScheduledCall(**item) for item in raw if isinstance(item, dict)]
        except (OSError, TypeError, ValueError, json.JSONDecodeError):
            return []

    def _save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(json.dumps([asdict(item) for item in self._calls], indent=2), encoding="utf-8")
        temporary.replace(self.path)
