"""Exact, per-call user contributions retained until Stella completes a reply."""
from __future__ import annotations

import threading
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from time import monotonic


@dataclass(frozen=True, slots=True)
class VoiceContribution:
    speaker_id: str
    speaker_name: str
    text: str
    timestamp: str
    social_state: dict
    voice_profile: str = ""
    order_time: float = 0.0
    committed_at: float = field(default_factory=monotonic)


class VoiceExchangeBuffer:
    """An acknowledged-prefix buffer; cancelled or failed drafts never consume input."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._revision = 0
        self._items: list[VoiceContribution] = []

    def append(self, item: VoiceContribution) -> int:
        with self._lock:
            self._revision += 1
            self._items.append(item)
            self._items.sort(key=lambda value: value.order_time)
            return self._revision

    def snapshot(self) -> tuple[int, tuple[VoiceContribution, ...]]:
        with self._lock:
            return self._revision, tuple(self._items)

    def acknowledge(self, snapshot: tuple[VoiceContribution, ...]) -> bool:
        """Remove only the exact prefix used by a successfully completed response."""
        with self._lock:
            count = len(snapshot)
            if count > len(self._items) or tuple(self._items[:count]) != snapshot:
                return False
            del self._items[:count]
            return True

    def render(self, snapshot: tuple[VoiceContribution, ...] | None = None) -> str:
        with self._lock:
            items = tuple(self._items) if snapshot is None else snapshot
        return "\n".join(
            f"[{item.timestamp}] {item.speaker_name}: {item.text}" for item in items
        )


def local_timestamp(order_time: float | None = None) -> str:
    now_mono = monotonic()
    now = datetime.now().astimezone()
    if order_time is not None:
        now -= timedelta(seconds=max(0.0, now_mono - order_time))
    return now.isoformat(timespec="milliseconds")
