from __future__ import annotations

import asyncio
import logging
import math
import os
import shutil
import socket
import subprocess
import threading
import time
from collections.abc import Callable
from pathlib import Path
from urllib.parse import urlsplit

from .audio_io import SOUNDDEVICE_START_LOCK


LOG = logging.getLogger(__name__)

SAMPLE_RATE = 24_000
FRAME_SAMPLES = 1_920
FRAME_SECONDS = FRAME_SAMPLES / SAMPLE_RATE
POST_FLUSH_QUIET_SECONDS = FRAME_SECONDS * 2


class KyutaiSTTError(RuntimeError):
    pass


class KyutaiServerProcess:
    """Own one hidden local Kyutai worker for the lifetime of Mako."""

    def __init__(
        self,
        *,
        root_directory: Path,
        server_url: str,
        startup_timeout_seconds: float,
        on_status: Callable[[str], None],
    ) -> None:
        self.root_directory = root_directory
        self.server_url = server_url
        self.startup_timeout_seconds = startup_timeout_seconds
        self.on_status = on_status
        self._process: subprocess.Popen[bytes] | None = None
        self._log_file = None
        self._lock = threading.RLock()
        self._owns_process = False

    def start(self) -> None:
        host, port = self._address()
        if host not in {"127.0.0.1", "localhost", "::1"}:
            return
        with self._lock:
            if self._process is not None and self._process.poll() is None:
                return
            if self._port_open(host, port):
                LOG.info("Using an existing Kyutai worker on %s:%s", host, port)
                self._owns_process = False
                return

            executable = self._find_executable()
            config = self.root_directory / "tools" / "kyutai-stt-batch1.toml"
            if not config.is_file():
                raise KyutaiSTTError(f"Kyutai worker config is missing: {config}")
            log_directory = self.root_directory / "data" / "logs" / "kyutai-stt"
            log_directory.mkdir(parents=True, exist_ok=True)
            log_path = log_directory / "worker.log"
            self._log_file = log_path.open("ab", buffering=0)
            self._log_file.write(
                f"\n--- Mako Kyutai worker start {time.strftime('%Y-%m-%d %H:%M:%S')} ---\n".encode()
            )
            environment = self._worker_environment()
            creationflags = 0
            startupinfo = None
            if os.name == "nt":
                creationflags = subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = subprocess.SW_HIDE
            try:
                self._process = subprocess.Popen(
                    [
                        str(executable),
                        "worker",
                        "--config",
                        str(config),
                        "--port",
                        str(port),
                    ],
                    cwd=self.root_directory,
                    stdin=subprocess.DEVNULL,
                    stdout=self._log_file,
                    stderr=subprocess.STDOUT,
                    env=environment,
                    creationflags=creationflags,
                    startupinfo=startupinfo,
                )
            except Exception:
                self._close_log()
                raise
            self._owns_process = True

        self.on_status("loading Kyutai STT")
        deadline = time.monotonic() + self.startup_timeout_seconds
        while time.monotonic() < deadline:
            process = self._process
            if process is None:
                raise KyutaiSTTError("Kyutai worker disappeared during startup")
            exit_code = process.poll()
            if exit_code is not None:
                detail = self._log_tail(log_path)
                self.stop()
                raise KyutaiSTTError(
                    f"Kyutai worker exited with code {exit_code}. {detail}"
                )
            if self._port_open(host, port):
                LOG.info("Kyutai worker ready pid=%s port=%s", process.pid, port)
                return
            time.sleep(0.25)

        self.stop()
        raise KyutaiSTTError(
            f"Kyutai worker did not open port {port} within "
            f"{self.startup_timeout_seconds:.0f}s. See {log_path}."
        )

    def stop(self) -> None:
        with self._lock:
            process = self._process
            owns_process = self._owns_process
            self._process = None
            self._owns_process = False
        if process is not None and owns_process and process.poll() is None:
            LOG.info("Stopping Kyutai worker pid=%s", process.pid)
            if os.name == "nt":
                subprocess.run(
                    ["taskkill", "/PID", str(process.pid), "/T", "/F"],
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    creationflags=subprocess.CREATE_NO_WINDOW,
                    check=False,
                )
            else:
                process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
        self._close_log()

    def _address(self) -> tuple[str, int]:
        parsed = urlsplit(self.server_url)
        return parsed.hostname or "127.0.0.1", parsed.port or 8090

    @staticmethod
    def _port_open(host: str, port: int) -> bool:
        try:
            with socket.create_connection((host, port), timeout=0.2):
                return True
        except OSError:
            return False

    @staticmethod
    def _find_executable() -> Path:
        discovered = shutil.which("moshi-server")
        candidates = [
            Path(discovered) if discovered else None,
            Path.home() / ".cargo" / "bin" / "moshi-server.exe",
            Path.home() / ".cargo" / "bin" / "moshi-server",
        ]
        for candidate in candidates:
            if candidate is not None and candidate.is_file():
                return candidate
        raise KyutaiSTTError(
            "moshi-server is not installed. Run tools/Install-KyutaiSttServer.ps1."
        )

    def _worker_environment(self) -> dict[str, str]:
        environment = os.environ.copy()
        environment["HF_HOME"] = str(self.root_directory / "data" / "hf-cache")
        environment.setdefault("RUST_LOG", "info")
        if os.name == "nt":
            cuda_root = Path("C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA")
            compatible_cuda = cuda_root / "v13.2"
            if compatible_cuda.is_dir():
                cuda_bin = compatible_cuda / "bin"
                cuda_runtime_bin = cuda_bin / "x64"
                environment["CUDA_PATH"] = str(compatible_cuda)
                environment["CUDA_HOME"] = str(compatible_cuda)
                environment["PATH"] = os.pathsep.join(
                    [
                        str(cuda_runtime_bin),
                        str(cuda_bin),
                        environment.get("PATH", ""),
                    ]
                )
            else:
                raise KyutaiSTTError(
                    "CUDA Toolkit 13.2 is required by the installed NVIDIA driver."
                )
        return environment

    @staticmethod
    def _log_tail(path: Path) -> str:
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
            return " ".join(lines[-4:])
        except OSError:
            return f"See {path}."

    def _close_log(self) -> None:
        log_file = self._log_file
        self._log_file = None
        if log_file is not None:
            try:
                log_file.close()
            except OSError:
                pass


class KyutaiSTTClient:
    """Streaming client for Kyutai's CUDA Rust ASR websocket."""

    def __init__(
        self,
        *,
        server_url: str,
        api_key: str,
        input_device: int | None,
        vad_head_index: int,
        vad_threshold: float,
        model_delay_seconds: float,
        startup_timeout_seconds: float,
        on_utterance: Callable[[str], None],
        on_partial: Callable[[str], None] | None,
        on_semantic_eot: Callable[[str], None] | None,
        on_status: Callable[[str], None],
        on_audio: Callable[[object, int], None] | None = None,
        capture_microphone: bool = True,
    ) -> None:
        self.server_url = server_url.rstrip("/")
        self.api_key = api_key
        self.input_device = input_device
        self.vad_head_index = vad_head_index
        self.vad_threshold = vad_threshold
        self.model_delay_seconds = model_delay_seconds
        self.startup_timeout_seconds = startup_timeout_seconds
        self.on_utterance = on_utterance
        self.on_partial = on_partial
        self.on_semantic_eot = on_semantic_eot
        self.on_status = on_status
        self.on_audio = on_audio
        self.capture_microphone = capture_microphone

        self._loop = asyncio.new_event_loop()
        self._ready = threading.Event()
        self._stopped = threading.Event()
        self._startup_error: BaseException | None = None
        self._thread: threading.Thread | None = None
        self._stream = None
        self._audio_queue = None
        self._stop_async = None
        self._native_rate = SAMPLE_RATE
        self._capture_buffer = None
        self._capture_lock = threading.Lock()
        self._sequence = 0
        self._muted = True

        self._parts: list[str] = []
        self._speech_started = False
        self._pause_prediction = 1.0
        self._warmup_steps = 12
        self._current_step = 0
        self._flush_target_step: int | None = None
        self._flush_started_at = 0.0
        self._flush_settle_until = 0.0
        self._last_word_at = 0.0

    def start(self) -> None:
        import numpy as np
        import sounddevice as sd

        self._capture_buffer = np.empty(0, dtype=np.float32)
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()
        if not self._ready.wait(timeout=self.startup_timeout_seconds):
            self.stop()
            raise KyutaiSTTError(
                f"Kyutai STT did not become ready within {self.startup_timeout_seconds:.1f}s"
            )
        if self._startup_error is not None:
            error = self._startup_error
            self.stop()
            raise KyutaiSTTError(f"Could not connect to Kyutai STT: {error}") from error

        if not self.capture_microphone:
            self._muted = False
            self.on_status("Kyutai ready for injected audio")
            return

        self.on_status("starting microphone")
        LOG.info("Kyutai microphone opening device=%s", self.input_device)
        with SOUNDDEVICE_START_LOCK:
            device_info = sd.query_devices(self.input_device, "input")
            native_rate = int(round(float(device_info["default_samplerate"])))
            self._native_rate = native_rate if native_rate > 0 else SAMPLE_RATE
            blocksize = max(160, round(self._native_rate * FRAME_SECONDS))
            self._stream = sd.InputStream(
                callback=self._audio_callback,
                channels=1,
                device=self.input_device,
                samplerate=self._native_rate,
                blocksize=blocksize,
                dtype="float32",
            )
            LOG.info(
                "Kyutai microphone stream created device=%s rate=%s blocksize=%s",
                self.input_device,
                self._native_rate,
                blocksize,
            )
            self._stream.start()
        self._muted = False
        LOG.info("Kyutai microphone started device=%s", self.input_device)
        self.on_status("call connected")

    def stop(self) -> None:
        self._muted = True
        if self._stream is not None:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception:
                pass
            self._stream = None
        if self._stop_async is not None and self._loop.is_running():
            self._loop.call_soon_threadsafe(self._stop_async.set)
        thread = self._thread
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=5)
        self._thread = None

    def set_muted(self, muted: bool) -> None:
        self._muted = muted
        if not muted:
            with self._capture_lock:
                if self._capture_buffer is not None:
                    self._capture_buffer = self._capture_buffer[:0]

    def push_audio(self, samples, sample_rate: int) -> None:
        """Feed mono floating-point PCM when microphone capture is disabled."""
        if self.capture_microphone:
            raise KyutaiSTTError("push_audio is only available in injected-audio mode")
        self._feed_samples(samples, sample_rate)

    def _run_loop(self) -> None:
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._run())
        except BaseException as exc:
            if not self._ready.is_set():
                self._startup_error = exc
            else:
                LOG.exception("Kyutai STT connection failed")
                self.on_status(f"voice error: Kyutai STT disconnected: {exc}")
        finally:
            self._ready.set()
            self._stopped.set()
            self._loop.close()

    async def _run(self) -> None:
        import aiohttp
        import msgpack

        # Keep microphone frames ahead of the silence used to fast-forward the
        # delayed model. Reordering those frames can split one utterance.
        self._audio_queue = asyncio.Queue(maxsize=256)
        self._stop_async = asyncio.Event()
        url = self.server_url
        if not url.endswith("/api/asr-streaming"):
            url += "/api/asr-streaming"
        headers = {"kyutai-api-key": self.api_key}
        async with aiohttp.ClientSession(headers=headers) as session:
            async with session.ws_connect(url, max_msg_size=0) as websocket:
                ready = await websocket.receive()
                if ready.type != aiohttp.WSMsgType.BINARY:
                    raise KyutaiSTTError(
                        f"Expected binary Ready message, got websocket type {ready.type!r}"
                    )
                message = msgpack.unpackb(ready.data, raw=False)
                if message.get("type") == "Error":
                    raise KyutaiSTTError(
                        str(message.get("message", "server rejected connection"))
                    )
                if message.get("type") != "Ready":
                    raise KyutaiSTTError(f"Expected Ready, got {message.get('type')!r}")
                LOG.info("Kyutai websocket ready")
                self._ready.set()
                sender = asyncio.create_task(self._send_loop(websocket))
                receiver = asyncio.create_task(self._receive_loop(websocket))
                stopper = asyncio.create_task(self._stop_async.wait())
                done, pending = await asyncio.wait(
                    {sender, receiver, stopper}, return_when=asyncio.FIRST_COMPLETED
                )
                for task in pending:
                    task.cancel()
                await asyncio.gather(*pending, return_exceptions=True)
                for task in done:
                    if task is not stopper:
                        task.result()

    async def _send_loop(self, websocket) -> None:
        import msgpack

        assert self._audio_queue is not None
        while True:
            samples = await self._audio_queue.get()
            payload = msgpack.packb(
                {"type": "Audio", "pcm": samples.tolist()},
                use_bin_type=True,
                use_single_float=True,
            )
            await websocket.send_bytes(payload)

    async def _receive_loop(self, websocket) -> None:
        import msgpack

        import aiohttp

        async for packed in websocket:
            if packed.type == aiohttp.WSMsgType.ERROR:
                raise KyutaiSTTError(str(websocket.exception()))
            if packed.type != aiohttp.WSMsgType.BINARY:
                continue
            message = msgpack.unpackb(packed.data, raw=False)
            message_type = message.get("type")
            if message_type == "Word":
                self._on_word(str(message.get("text", "")))
            elif message_type == "EndWord":
                self._on_end_word()
            elif message_type == "Step":
                await self._on_step(message)
            elif message_type == "Error":
                raise KyutaiSTTError(str(message.get("message", "unknown server error")))

    def _on_word(self, text: str) -> None:
        if not text:
            return
        self._parts.append(text)
        self._last_word_at = time.monotonic()
        self._speech_started = True
        self._pause_prediction = 0.0
        partial = self._transcript()
        if partial and self.on_partial:
            self.on_partial(partial)

    def _on_end_word(self) -> None:
        if self._parts and self._parts[-1] != " ":
            self._parts.append(" ")

    async def _on_step(self, message: dict) -> None:
        self._current_step = int(message.get("step_idx", self._current_step + 1))
        probabilities = message.get("prs") or []
        if self._warmup_steps > 0:
            self._warmup_steps -= 1
        elif self.vad_head_index < len(probabilities):
            prediction = float(probabilities[self.vad_head_index])
            alpha = 1.0 - math.exp(-FRAME_SECONDS / 0.01)
            self._pause_prediction += alpha * (prediction - self._pause_prediction)

        if self._flush_target_step is not None:
            if self._current_step >= self._flush_target_step:
                elapsed = max(0.0001, time.monotonic() - self._flush_started_at)
                LOG.info(
                    "Kyutai flush completed milliseconds=%.1f rtf=%.2f",
                    elapsed * 1000.0,
                    self.model_delay_seconds / elapsed,
                )
                self._flush_target_step = None
                self._flush_settle_until = time.monotonic() + POST_FLUSH_QUIET_SECONDS
            return

        if self._flush_settle_until:
            now = time.monotonic()
            # Fast-forward drained the delayed audio window; allow only a short
            # quiet period for an in-flight final word before committing.
            quiet_until = self._last_word_at + POST_FLUSH_QUIET_SECONDS
            if now < max(self._flush_settle_until, quiet_until):
                return
            LOG.info("Kyutai delayed word stream settled")
            self._flush_settle_until = 0.0
            self._commit_transcript()
            return

        if self._speech_started and self._pause_prediction > self.vad_threshold:
            await self._begin_fast_forward_flush()

    async def _begin_fast_forward_flush(self) -> None:
        if self._flush_target_step is not None:
            return
        frame_count = math.ceil(self.model_delay_seconds / FRAME_SECONDS) + 1
        self._flush_target_step = self._current_step + frame_count
        self._flush_started_at = time.monotonic()
        LOG.info(
            "Kyutai semantic EOT probability=%.3f flush_frames=%s",
            self._pause_prediction,
            frame_count,
        )
        provisional = self._transcript()
        if provisional and self.on_semantic_eot:
            # The final delayed words are still arriving. The caller must validate
            # this snapshot before using any model output derived from it.
            self.on_semantic_eot(provisional)
        import numpy as np

        silence = np.zeros(FRAME_SAMPLES, dtype=np.float32)
        for _ in range(frame_count):
            self._enqueue(silence.copy(), priority=0)

    def _commit_transcript(self) -> None:
        text = self._transcript()
        self._parts.clear()
        self._speech_started = False
        self._pause_prediction = 1.0
        self._last_word_at = 0.0
        if text:
            LOG.info("Kyutai committed transcript chars=%s", len(text))
            self.on_utterance(text)

    def _transcript(self) -> str:
        return " ".join("".join(self._parts).split())

    def _audio_callback(self, in_data, frames, timing, status) -> None:
        del frames, timing
        if status:
            LOG.debug("Kyutai microphone status: %s", status)
        if self._muted or in_data is None or not self._loop.is_running():
            return
        import numpy as np

        self._feed_samples(in_data, self._native_rate)

    def _feed_samples(self, input_samples, sample_rate: int) -> None:
        if self._muted or input_samples is None or not self._loop.is_running():
            return
        import numpy as np

        samples = np.asarray(input_samples, dtype=np.float32).reshape(-1)
        if self.on_audio:
            try:
                self.on_audio(samples.copy(), sample_rate)
            except Exception:
                LOG.debug("Kyutai audio observer failed", exc_info=True)
        if sample_rate != SAMPLE_RATE and samples.size:
            target_size = max(1, round(samples.size * SAMPLE_RATE / sample_rate))
            samples = np.interp(
                np.linspace(0.0, samples.size - 1, num=target_size),
                np.arange(samples.size),
                samples,
            ).astype(np.float32)
        with self._capture_lock:
            self._capture_buffer = np.concatenate((self._capture_buffer, samples))
            while self._capture_buffer.size >= FRAME_SAMPLES:
                frame = self._capture_buffer[:FRAME_SAMPLES].copy()
                self._capture_buffer = self._capture_buffer[FRAME_SAMPLES:]
                self._loop.call_soon_threadsafe(self._enqueue, frame, 1)

    def _enqueue(self, samples, priority: int = 1) -> None:
        queue = self._audio_queue
        if queue is None or queue.full():
            if priority == 1:
                LOG.warning("Kyutai audio queue overflow; dropping one frame")
            return
        self._sequence += 1
        del priority
        queue.put_nowait(samples)
