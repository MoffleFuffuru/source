from __future__ import annotations


def deep_recall_bridge(text: str) -> str | None:
    """Automatic spoken recall fillers are disabled; keep normal recall generation."""
    return None
