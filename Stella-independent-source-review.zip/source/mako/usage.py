from __future__ import annotations

import sqlite3
import threading
from contextlib import contextmanager
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any


class UsageTracker:
    """Local accounting for the daily budget Groq does not expose in headers."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = threading.RLock()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS api_usage (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    model TEXT NOT NULL,
                    prompt_tokens INTEGER NOT NULL,
                    cached_tokens INTEGER NOT NULL,
                    completion_tokens INTEGER NOT NULL,
                    status TEXT NOT NULL,
                    fallback INTEGER NOT NULL,
                    remaining_requests TEXT,
                    remaining_tokens TEXT
                )
                """
            )

    def record(
        self,
        *,
        model: str,
        prompt_tokens: int,
        cached_tokens: int,
        completion_tokens: int,
        status: str,
        fallback: bool,
        rate_limits: dict[str, str] | None = None,
    ) -> None:
        with self._lock, self._connect() as connection:
            connection.execute(
                """
                INSERT INTO api_usage (
                    created_at, model, prompt_tokens, cached_tokens, completion_tokens,
                    status, fallback, remaining_requests, remaining_tokens
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    datetime.now(UTC).isoformat(), model, max(0, prompt_tokens),
                    max(0, cached_tokens), max(0, completion_tokens), status,
                    int(fallback), (rate_limits or {}).get("remaining_requests"),
                    (rate_limits or {}).get("remaining_tokens"),
                ),
            )

    def summary(self, model: str, *, now: datetime | None = None) -> dict[str, int | float | str | None]:
        current = now or datetime.now(UTC)
        day_start = current.replace(hour=0, minute=0, second=0, microsecond=0)
        minute_start = current - timedelta(minutes=1)
        with self._lock, self._connect() as connection:
            daily = connection.execute(
                """SELECT COUNT(*), COALESCE(SUM(prompt_tokens - cached_tokens + completion_tokens), 0),
                          COALESCE(SUM(prompt_tokens), 0), COALESCE(SUM(cached_tokens), 0),
                          COALESCE(SUM(completion_tokens), 0), COALESCE(SUM(fallback), 0)
                   FROM api_usage WHERE model = ? AND created_at >= ? AND status = 'success'""",
                (model, day_start.isoformat()),
            ).fetchone()
            minute = connection.execute(
                """SELECT COALESCE(SUM(prompt_tokens - cached_tokens + completion_tokens), 0)
                   FROM api_usage WHERE model = ? AND created_at >= ? AND status = 'success'""",
                (model, minute_start.isoformat()),
            ).fetchone()
            latest = connection.execute(
                """SELECT remaining_requests, remaining_tokens, created_at
                   FROM api_usage WHERE model = ?
                     AND (remaining_requests IS NOT NULL OR remaining_tokens IS NOT NULL)
                   ORDER BY id DESC LIMIT 1""",
                (model,),
            ).fetchone()
        return {
            "requests_today": int(daily[0]), "uncached_tokens_today": int(daily[1]),
            "raw_prompt_tokens_today": int(daily[2]), "cached_prompt_tokens_today": int(daily[3]),
            "completion_tokens_today": int(daily[4]), "fallbacks_today": int(daily[5]),
            "uncached_tokens_last_minute": int(minute[0]),
            "cache_hit_percent": round((int(daily[3]) / int(daily[2]) * 100) if daily[2] else 0.0, 1),
            # Groq labels these headers RPD and TPM respectively. Daily token
            # capacity remains local accounting because Groq does not send TPD left.
            "header_rpd_remaining": latest[0] if latest else None,
            "header_tpm_remaining": latest[1] if latest else None,
            "header_observed_at": latest[2] if latest else None,
        }

    def daily_available(
        self,
        model: str,
        *,
        estimated_tokens: int,
        config: Any,
        reserve_for_direct_use: bool = False,
    ) -> bool:
        usage = self.summary(model)
        reserve = (
            int(config.daily_token_limit * config.reserve_daily_token_ratio)
            if reserve_for_direct_use
            else 0
        )
        return (
            usage["requests_today"] < config.daily_request_limit
            and usage["uncached_tokens_today"] + estimated_tokens <= config.daily_token_limit - reserve
        )

    @contextmanager
    def _connect(self):
        connection = sqlite3.connect(self.path)
        try:
            with connection:
                yield connection
        finally:
            connection.close()
