from __future__ import annotations

import math
import re
from difflib import SequenceMatcher
from typing import Iterable

from .models import QualityReport


WORD_RE = re.compile(r"[a-z0-9']+")
SENTENCE_RE = re.compile(r"(?<=[.!?])\s+|\n+")

ASSISTANT_PHRASES = (
    "as an ai",
    "i'm here to help",
    "i am here to help",
    "it sounds like you're",
    "it sounds like you are",
    "that's completely valid",
    "that is completely valid",
    "how can i assist",
    "let me know if you need",
)

STAGE_DIRECTION_RE = re.compile(r"\*[^*]{1,80}\*|\[[^\]]{1,80}\]")
PRIVATE_SYSTEM_RE = re.compile(
    r"\b(?:system prompt|hidden (?:rule|rules|filter|filters|response filter|response filters)|response filter|memory system)\b",
    flags=re.IGNORECASE,
)
PRIVATE_REASONING_RE = re.compile(
    r"\b(?:i need to respond to|i should reply|i should respond|"
    r"recent greetings were|the prompt says|state\s*:\s*(?:warmth|energy|playfulness|curiosity)|"
    r"let'?s go with\s*:|short, natural, fits the mood|i need a fresh, natural)\b",
    flags=re.IGNORECASE,
)
BLAME_SHIFT_RE = re.compile(
    r"\b(?:probably|maybe)\s+(?:something\s+)?(?:on your end|your fault)\b|"
    r"\bi(?:'m| am) not the one who has to wait\b",
    flags=re.IGNORECASE,
)
REFLECTIVE_PARAPHRASE_RE = re.compile(
    r"^\s*(?:(?:so|well),?\s+)?(?:it\s+)?sounds\s+like\s+you(?:'re|\s+are)\b|^\s*so\s+you(?:'re|\s+are)\s+(?:feeling|stuck|having|trying)\b",
    flags=re.IGNORECASE,
)

TOPIC_FAMILIES = {
    "keyboard, typing, and typo jokes": frozenset(
        {
            "autocorrect",
            "click",
            "clicking",
            "key",
            "keyboard",
            "keypress",
            "keys",
            "smash",
            "type",
            "typed",
            "typing",
            "typo",
            "typos",
        }
    ),
    "voice and hearing observations": frozenset(
        {
            "hear",
            "hearing",
            "heard",
            "listen",
            "listening",
            "silence",
            "sound",
            "voice",
        }
    ),
    "call connection and loop jokes": frozenset(
        {
            "connected",
            "connection",
            "disconnect",
            "glitch",
            "loop",
            "ringing",
            "stuck",
        }
    ),
    "computer presence and hardware jokes": frozenset(
        {
            "computer",
            "hardware",
            "laptop",
            "machine",
            "screen",
        }
    ),
}

REPETITION_BOUNDARIES = (
    "already said",
    "change the subject",
    "do not mention",
    "don't mention",
    "drop the",
    "enough with",
    "keep saying",
    "move on",
    "no more",
    "not mentioning",
    "said that too",
    "stop mentioning",
    "too many times",
)


def normalize(text: str) -> str:
    return " ".join(WORD_RE.findall(text.lower().replace("’", "'")))


def words(text: str) -> list[str]:
    return WORD_RE.findall(text.lower().replace("’", "'"))


def topic_families(text: str) -> set[str]:
    tokens = {
        token[:-2] if token.endswith("'s") else token
        for token in words(text)
    }
    return {
        label
        for label, vocabulary in TOPIC_FAMILIES.items()
        if tokens & vocabulary
    }


def fatigued_topics(
    recent_responses: Iterable[str],
    *,
    recent_limit: int = 8,
    repetition_limit: int = 2,
) -> set[str]:
    counts: dict[str, int] = {}
    for response in list(recent_responses)[:recent_limit]:
        for label in topic_families(response):
            counts[label] = counts.get(label, 0) + 1
    return {label for label, count in counts.items() if count >= repetition_limit}


def user_rejected_topics(user_text: str, recent_responses: Iterable[str]) -> set[str]:
    clean_user = normalize(user_text)
    if not any(boundary in clean_user for boundary in REPETITION_BOUNDARIES):
        return set()
    explicit = topic_families(user_text)
    if explicit:
        return explicit
    recent = list(recent_responses)
    return topic_families(recent[0]) if recent else set()


def token_jaccard(left: str, right: str) -> float:
    left_tokens = set(words(left))
    right_tokens = set(words(right))
    if not left_tokens or not right_tokens:
        return 0.0
    return len(left_tokens & right_tokens) / len(left_tokens | right_tokens)


def longest_common_run(left: list[str], right: list[str]) -> int:
    if not left or not right:
        return 0
    previous = [0] * (len(right) + 1)
    longest = 0
    for left_word in left:
        current = [0]
        for index, right_word in enumerate(right, start=1):
            run = previous[index - 1] + 1 if left_word == right_word else 0
            current.append(run)
            longest = max(longest, run)
        previous = current
    return longest


def evaluate_candidate(
    *,
    user_text: str,
    candidate: str,
    recent_responses: Iterable[str],
    exhausted_topics: set[str] | None = None,
    forbidden_topics: set[str] | None = None,
    semantic_act: str = "",
) -> QualityReport:
    blocking: list[str] = []
    warnings: list[str] = []
    evidence: list[str] = []
    score = 1.0

    recent_responses = list(recent_responses)
    clean_candidate = normalize(candidate)
    clean_user = normalize(user_text)
    candidate_words = words(candidate)
    user_words = words(user_text)
    candidate_topics = topic_families(candidate)

    # These checks are intentionally narrow. They guard only direct conflicts
    # with high-confidence local evidence; they do not grade Mako's personality.
    activity_pitch = bool(re.search(
        r"\b(?:how about|what about|we could|let's|let us|wanna|want to)\b.{0,48}\b(?:watch|movie|show|game|play|activity|plan)\b",
        clean_candidate,
    ))
    if semantic_act == "topic_boundary" and activity_pitch:
        blocking.append("ignored_semantic_boundary")
        evidence.append("offers another activity after a direct topic boundary")
        score -= 0.7
    if semantic_act == "clarification_repair" and activity_pitch:
        blocking.append("ignored_clarification_request")
        evidence.append("pivots to an activity instead of clarifying Mako's prior thought")
        score -= 0.55
    if semantic_act == "feedback_or_test" and activity_pitch:
        blocking.append("ignored_behavior_feedback")
        evidence.append("changes topic instead of receiving feedback about Mako's behavior")
        score -= 0.4
    if semantic_act == "emotional_disclosure" and activity_pitch:
        blocking.append("premature_activity_pitch")
        evidence.append("offers an activity before receiving the user's difficult state")
        score -= 0.4
    if semantic_act == "closed_acknowledgment" and (
        "?" in candidate
        or bool(re.search(r"\b(?:agenda|what(?:'s| is) next|anything else|on your mind)\b", clean_candidate))
    ):
        blocking.append("forced_followup_after_acknowledgment")
        evidence.append("turns a closed acknowledgment into an assistant-style follow-up")
        score -= 0.65

    exhausted_overlap = candidate_topics & set(exhausted_topics or ())
    if exhausted_overlap:
        blocking.append("topic_fixation")
        evidence.append(
            "returns to exhausted topic: " + ", ".join(sorted(exhausted_overlap))
        )
        score -= 0.55

    forbidden_overlap = candidate_topics & set(forbidden_topics or ())
    if forbidden_overlap:
        blocking.append("ignored_topic_boundary")
        evidence.append(
            "repeats topic the user rejected: " + ", ".join(sorted(forbidden_overlap))
        )
        score -= 0.7

    if not clean_candidate:
        return QualityReport(0.0, ["empty_response"], evidence=["no visible text"])

    if "\ufffd" in candidate:
        blocking.append("corrupted_text")
        evidence.append("contains an undecodable character")
        score -= 0.7

    if STAGE_DIRECTION_RE.search(candidate):
        blocking.append("stage_direction")
        evidence.append("contains a non-spoken stage direction")
        score -= 0.45

    if PRIVATE_SYSTEM_RE.search(candidate):
        blocking.append("private_system_leak")
        evidence.append("mentions private system behavior")
        score -= 0.65

    if PRIVATE_REASONING_RE.search(candidate):
        blocking.append("private_reasoning_leak")
        evidence.append("contains internal response-planning or emotional-state notes")
        score -= 0.8

    if BLAME_SHIFT_RE.search(candidate):
        blocking.append("blame_shift")
        evidence.append("blames the user for a response or connection failure")
        score -= 0.75

    if clean_candidate == clean_user:
        blocking.append("parroting")
        evidence.append("candidate is the normalized user message")
        score -= 0.65

    for phrase in ASSISTANT_PHRASES:
        if phrase in clean_candidate:
            blocking.append("assistant_language")
            evidence.append(phrase)
            score -= 0.4
            break

    if REFLECTIVE_PARAPHRASE_RE.search(candidate):
        blocking.append("reflective_paraphrase")
        evidence.append("reframes the user instead of adding Mako's own response")
        score -= 0.45

    if len(user_words) >= 2 and candidate_words[:2] == user_words[:2]:
        blocking.append("copied_opening")
        evidence.append("candidate begins with the user's opening words")
        score -= 0.35

    common_run = longest_common_run(user_words, candidate_words)
    required_run = max(3, math.ceil(len(user_words) * 0.6))
    if len(user_words) >= 3 and common_run >= required_run:
        response_addition = max(0, len(candidate_words) - common_run)
        if response_addition <= 7:
            blocking.append("parroting")
            evidence.append(f"copies {common_run} consecutive user words")
            score -= 0.5

    if clean_user and len(user_words) >= 3 and clean_user in clean_candidate:
        blocking.append("direct_restating")
        evidence.append("contains the normalized user message")
        score -= 0.45

    sentences = [item.strip() for item in SENTENCE_RE.split(candidate) if item.strip()]
    if len(sentences) >= 4:
        warnings.append("too_many_conversational_moves")
        evidence.append(f"contains {len(sentences)} sentence-level moves")
        score -= 0.18
    if len(sentences) >= 7:
        blocking.append("response_sprawl")
        score -= 0.25

    if len(candidate_words) > 85:
        warnings.append("overlong_for_companion_chat")
        evidence.append(f"contains {len(candidate_words)} words")
        score -= 0.12

    question_count = candidate.count("?")
    if question_count >= 2:
        warnings.append("question_chaining")
        evidence.append(f"contains {question_count} questions")
        score -= 0.15
    if question_count >= 3:
        blocking.append("question_chaining")
        score -= 0.2

    for old_response in recent_responses:
        old_clean = normalize(old_response)
        if not old_clean:
            continue
        sequence_similarity = SequenceMatcher(None, clean_candidate, old_clean).ratio()
        overlap = token_jaccard(candidate, old_response)
        if sequence_similarity >= 0.88 or overlap >= 0.78:
            blocking.append("repeated_response")
            evidence.append("too similar to a recent Mako response")
            score -= 0.5
            break
        old_words = words(old_response)
        if len(candidate_words) >= 3 and candidate_words[:3] == old_words[:3]:
            warnings.append("repeated_opening")
            evidence.append("reuses a recent three-word opening")
            score -= 0.12
            break

    return QualityReport(
        score=max(0.0, min(1.0, score)),
        blocking_issues=list(dict.fromkeys(blocking)),
        warnings=list(dict.fromkeys(warnings)),
        evidence=evidence,
    )
