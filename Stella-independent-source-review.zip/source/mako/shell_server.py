from __future__ import annotations

import json
import hmac
import os
import logging
import threading
import time
from collections import deque
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from .call import CallCallbacks, CallSession
from .core import MakoCore
from .discord_service import DiscordService
from .models import ConversationEvent, ResponseResult, EventSource, InteractionMode
from .interface_events import setting_reaction
from .voice import VoiceEngine
from .sage.host import SageHost


LOG = logging.getLogger(__name__)
HOST = "127.0.0.1"
PORT = 39541


def _sage_event_key(name: str) -> str:
    key = os.environ.get(name, "")
    if not key and os.name == "nt":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as registry:
                key = str(winreg.QueryValueEx(registry, name)[0])
        except OSError:
            pass
    return key


class ShellRuntime:
    """Small local API for the Electron shell; the companion logic stays in Python."""

    def __init__(self, root: Path) -> None:
        self.core = MakoCore(root)
        self.discord = DiscordService(self.core, self.core.config.discord)
        self.voice = VoiceEngine(
            self.core.config.voice,
            self.core.paths.temporary,
            on_playback_level=self.core.body.set_speech_level,
        )
        self.call = CallSession(
            self.core,
            self.voice,
            CallCallbacks(
                on_state=lambda state: self.emit("call_state", {"state": state}),
                on_response=self._on_call_response,
                on_error=lambda error: self.emit("error", {"message": error}),
                on_offer=lambda _plan: self.emit("call_state", {"state": "incoming call"}),
                on_transcript=self._on_call_transcript,
                on_response_prefix=self._on_call_response_prefix,
                on_activity=lambda: getattr(self, "sage_host", None) and self.sage_host.preempt(),
            ),
        )
        self._events: deque[dict[str, Any]] = deque(maxlen=256)
        self._sequence = 0
        self._lock = threading.Lock()
        self._busy = False
        self._interface_pending = None
        self._interface_worker = None
        self._closed = threading.Event()
        self.sage_host = SageHost(self)
        self.discord.start()
        self.sage_host.start()
        self.emit("status", {"text": "ready"})

    def close(self) -> None:
        self._closed.set()
        self.sage_host.close()
        try:
            if self.call.active:
                self.call.hang_up()
            self.voice.shutdown()
            self.discord.stop()
        finally:
            self.core.close()

    def emit(self, kind: str, payload: dict[str, Any]) -> None:
        with self._lock:
            self._sequence += 1
            self._events.append({"id": self._sequence, "type": kind, "data": payload})

    def events_after(self, after: int) -> dict[str, Any]:
        with self._lock:
            return {"events": [event for event in self._events if event["id"] > after], "last": self._sequence}

    def snapshot(self) -> dict[str, Any]:
        model = self.core.config.model
        voice = self.core.config.voice
        discord = self.core.config.discord
        return {
            "status": "thinking" if self._busy else ("call connected" if self.call.active else "ready"),
            "call_active": self.call.active,
            "sage": self.sage_host.status() if hasattr(self, "sage_host") else {},
            "config": {
                "memory": {"enabled": self.core.config.memory.enabled},
                "memory_model": {
                    "provider": self.core.config.memory_model.provider,
                    "endpoint": self.core.config.memory_model.endpoint,
                    "api_key_environment_variable": self.core.config.memory_model.api_key_environment_variable,
                    "model": self.core.config.memory_model.model,
                    "reasoning_effort": self.core.config.memory_model.reasoning_effort,
                    "timeout_seconds": self.core.config.memory_model.timeout_seconds,
                    "max_output_tokens": self.core.config.memory_model.max_output_tokens,
                },
                "model": {
                    "call_model": model.call_model,
                    "call_provider": model.call_provider,
                    "call_reasoning_effort": model.call_reasoning_effort,
                    "call_max_output_tokens": model.call_max_output_tokens,
                    "call_recent_turns": model.call_recent_turns,
                },
                "voice": {
                    "stt_backend": voice.stt_backend,
                    "tts_backend": voice.tts_backend,
                    "elevenlabs_tts_voice": voice.elevenlabs_tts_voice,
                    "elevenlabs_keyterms": voice.elevenlabs_keyterms,
                    "elevenlabs_vad_silence_seconds": voice.elevenlabs_vad_silence_seconds,
                    "vocal_context_provider": voice.vocal_context_provider,
                    "elevenlabs_stt_fallback": voice.elevenlabs_stt_fallback,
                    "elevenlabs_tts_fallback": voice.elevenlabs_tts_fallback,
                    "inworld_tts_voice": voice.inworld_tts_voice,
                    "input_enabled": voice.input_enabled,
                    "input_device": voice.input_device,
                    "output_device": voice.output_device,
                    "output_volume": voice.output_volume,
                    "inworld_stt_min_eot_silence_ms": voice.inworld_stt_min_eot_silence_ms,
                    "inworld_stt_max_turn_silence_ms": voice.inworld_stt_max_turn_silence_ms,
                },
                "discord": {
                    "enabled": discord.enabled,
                    "connected": bool(self.discord._thread and self.discord._thread.is_alive()),
                    "autonomy_enabled": discord.autonomy_enabled,
                },
            },
        }

    def send_chat(self, text: str) -> None:
        clean = text.strip()
        if not clean:
            return
        self.sage_host.human(clean)
        with self._lock:
            if self._busy:
                raise RuntimeError("Stella is already responding.")
            self._busy = True
        self.emit("message", {"speaker": "user", "text": clean})
        self.emit("status", {"text": "thinking"})
        threading.Thread(target=self._respond, args=(clean,), daemon=True, name="stella-shell-response").start()

    def _respond(self, text: str) -> None:
        try:
            result = self.core.respond(ConversationEvent(content=text))
            self._emit_response(result)
        except Exception as exc:
            LOG.exception("Electron shell response failed")
            self.emit("error", {"message": str(exc)})
        finally:
            with self._lock:
                self._busy = False
            self.emit("status", {"text": "call connected" if self.call.active else "ready"})

    def _emit_response(self, result: ResponseResult, *, record_sage: bool = True) -> None:
        if record_sage:
            self.sage_host.assistant(result)
        self.emit(
            "message",
            {
                "speaker": "stella",
                "text": result.text,
                "response_id": result.event_id,
                "expression": result.expression.value,
                "model": result.model,
                "generation_seconds": result.generation_seconds,
            },
        )

    def _on_call_response(self, result: ResponseResult) -> None:
        self._emit_response(result)

    def _on_call_transcript(self, text: str) -> None:
        self.sage_host.human(text, call=True)
        self.emit("message", {"speaker": "user", "text": text})

    def _on_call_response_prefix(self, event_id: str, text: str) -> None:
        self.emit("message", {"speaker": "stella", "text": text, "response_id": event_id})

    def toggle_call(self) -> dict[str, Any]:
        self.sage_host.preempt()
        if not self.core.config.voice.input_enabled:
            raise RuntimeError("Voice calls are disabled in text-only mode. Enable a microphone in Settings first.")
        if self.call.active:
            self.call.hang_up()
        else:
            self.call.start()
        return {"call_active": self.call.active}

    def end_call(self) -> dict[str, Any]:
        """Release microphone and Inworld state before the Electron shell exits."""
        self.sage_host.preempt()
        if self.call.active:
            self.call.hang_up()
        return {"call_active": False}

    def devices(self) -> dict[str, Any]:
        try:
            import sounddevice as sd

            inputs = [
                {"id": index, "name": str(device["name"]), "channels": int(device["max_input_channels"])}
                for index, device in enumerate(sd.query_devices())
                if int(device["max_input_channels"]) > 0
            ]
            outputs = [
                {"id": index, "name": str(device["name"]), "channels": int(device["max_output_channels"])}
                for index, device in enumerate(sd.query_devices())
                if int(device["max_output_channels"]) > 0
            ]
            return {"devices": inputs, "output_devices": outputs}
        except Exception as exc:
            LOG.warning("Could not enumerate audio devices: %s", exc)
            return {"devices": [], "output_devices": [], "error": str(exc)}

    def onboarding_speak(self, data: dict[str, Any]) -> None:
        text = str(data.get("text", "")).strip()
        request_id = str(data.get("request_id", ""))[:80]
        if not text or len(text) > 1200:
            raise ValueError("Onboarding speech must be between 1 and 1200 characters")
        self.voice.speak(text, on_done=lambda: self.emit(
            "onboarding_speech_done", {"request_id": request_id}
        ))

    def update_config(self, changes: dict[str, Any]) -> dict[str, Any]:
        allowed = {
            "model.call_model": str,
            "model.call_provider": str,
            "model.call_reasoning_effort": str,
            "model.call_max_output_tokens": int,
            "model.call_recent_turns": int,
            "voice.stt_backend": str,
            "voice.tts_backend": str,
            "voice.elevenlabs_tts_voice": str,
            "voice.elevenlabs_keyterms": list,
            "voice.elevenlabs_vad_silence_seconds": (int, float),
            "voice.vocal_context_provider": str,
            "voice.elevenlabs_stt_fallback": str,
            "voice.elevenlabs_tts_fallback": str,
            "voice.inworld_tts_voice": str,
            "voice.input_device": (int, type(None)),
            "voice.input_enabled": bool,
            "voice.output_device": (int, type(None)),
            "voice.output_volume": (int, float),
            "memory.enabled": bool,
            "memory_model.provider": str,
            "memory_model.endpoint": str,
            "memory_model.api_key_environment_variable": str,
            "memory_model.model": str,
            "memory_model.reasoning_effort": str,
            "memory_model.timeout_seconds": (int, float),
            "memory_model.max_output_tokens": int,
            "voice.inworld_stt_min_eot_silence_ms": int,
            "voice.inworld_stt_max_turn_silence_ms": int,
            "discord.enabled": bool,
            "discord.autonomy_enabled": bool,
        }
        # Validate the whole batch before changing anything or reacting to it.
        from .elevenlabs_voice import validate_keyterms
        if "voice.elevenlabs_keyterms" in changes:
            changes["voice.elevenlabs_keyterms"] = validate_keyterms(changes["voice.elevenlabs_keyterms"])
        choices = {"voice.vocal_context_provider": {"none", "inworld_stt"},
                   "voice.elevenlabs_stt_fallback": {"", "inworld_stt"},
                   "voice.elevenlabs_tts_fallback": {"", "inworld_tts"}}
        for name, options in choices.items():
            if name in changes and changes[name] not in options:
                raise ValueError(f"Unsupported setting: {name}")
        silence = changes.get("voice.elevenlabs_vad_silence_seconds", .45)
        if isinstance(silence, bool) or not isinstance(silence, (int, float)) or not .3 <= silence <= 3:
            raise ValueError("Scribe silence must be between 0.3 and 3 seconds")
        volume = changes.get("voice.output_volume", 1.0)
        if isinstance(volume, bool) or not isinstance(volume, (int, float)) or not 0 <= volume <= 1:
            raise ValueError("Output volume must be between 0 and 1")
        for key, value in changes.items():
            expected = allowed.get(key)
            if expected is None or not isinstance(value, expected):
                raise ValueError(f"Unsupported setting: {key}")
        actual_changes = {key: value for key, value in changes.items()
                          if getattr(getattr(self.core.config, key.split('.')[0]), key.split('.')[1]) != value}
        discord_enabled = actual_changes.get("discord.enabled")
        for key, value in changes.items():
            expected = allowed.get(key)
            if expected is None or not isinstance(value, expected):
                raise ValueError(f"Unsupported setting: {key}")
            group_name, field_name = key.split(".", 1)
            setattr(getattr(self.core.config, group_name), field_name, value)
        if "model.call_provider" in actual_changes:
            routes = {
                "lithos": ("https://api.lithosai.cloud/v1", "LITHOSAI_API_KEY"),
                "cerebras": ("https://api.cerebras.ai/v1", "CEREBRAS_API_KEY"),
            }
            route = routes.get(self.core.config.model.call_provider)
            if route:
                self.core.config.model.call_endpoint, self.core.config.model.call_api_key_environment_variable = route
        self.core.save_config()
        # Admit the visual/Qwen reaction before a Discord client shutdown can
        # block this settings request while closing its network and audio loops.
        for key, value in actual_changes.items():
            self._react_to_setting(key, value)
        if discord_enabled is False:
            self.discord.stop()
            self.emit("status", {"text": "Discord integration paused"})
        elif discord_enabled is True:
            # DiscordService owns a renderer that is intentionally shut down
            # with the client, so reconnect with a fresh transport instance.
            self.discord.stop()
            self.discord = DiscordService(self.core, self.core.config.discord)
            self.discord.start()
            self.emit("status", {"text": "Discord integration starting"})
        self.emit("status", {"text": "settings saved; voice changes apply on the next call"})
        return self.snapshot()

    def _react_to_setting(self, key: str, value: object) -> None:
        reaction = setting_reaction(key, value)
        self.emit("interface_reaction", reaction)
        if not reaction.get("comment"):
            return
        with self._lock:
            self._interface_pending = (time.monotonic(), reaction)
            if self._interface_worker and self._interface_worker.is_alive():
                return
            self._interface_worker = threading.Thread(target=self._interface_loop, daemon=True, name="stella-interface-reaction")
            self._interface_worker.start()

    def _interface_loop(self) -> None:
        while not self._closed.wait(.1):
            with self._lock:
                pending = self._interface_pending
                if pending is None:
                    self._interface_worker = None
                    return
                since, context = pending
                age = time.monotonic() - since
                if age > 20:
                    self._interface_pending = None
                    continue
                if age < .3 or self._busy:
                    continue
            if self.core._model_lock.locked():
                continue
            if self.call.active:
                if not self.call.submit_interface_event(context):
                    continue
                with self._lock:
                    if self._interface_pending is pending:
                        self._interface_pending = None
                continue
            if self.voice._speaking.is_set():
                continue
            with self._lock:
                if self._busy or self._interface_pending is not pending:
                    continue
                self._busy = True
                self._interface_pending = None
            try:
                started = time.monotonic()
                event = ConversationEvent(content=str(context["summary"]), source=EventSource.SYSTEM,
                    mode=InteractionMode.CALL, channel_id="desktop", metadata={"interface_event": context})
                result = self.core.respond(event, cancel=self._closed)
                if self._closed.is_set():
                    return
                self._emit_response(result)
                acting = result.acting or {}
                if self.core.config.voice.enabled:
                    self.voice.speak(result.text, on_done=self.core.body.speech_finished,
                                     vocal_cue=str(acting.get("vocal_cue", "none")), delivery=str(acting.get("delivery", "neutral")))
                else:
                    self.core.body.speech_finished()
                LOG.info("Interface reaction name=%s generation_seconds=%.3f", context["name"], time.monotonic() - started)
            except Exception as exc:
                LOG.exception("Interface response failed")
                self.core.body.speech_finished()
                self.emit("error", {"message": str(exc)})
            finally:
                with self._lock:
                    self._busy = False


class ShellHandler(BaseHTTPRequestHandler):
    runtime: ShellRuntime

    def log_message(self, format: str, *args: Any) -> None:
        LOG.debug("shell api " + format, *args)

    def _json(self, status: HTTPStatus, value: Any) -> None:
        payload = json.dumps(value).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(payload)

    def _body(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        if length > 64_000:
            raise ValueError("Request is too large")
        raw = self.rfile.read(length)
        data = json.loads(raw or b"{}")
        if not isinstance(data, dict):
            raise ValueError("JSON object required")
        return data

    def do_GET(self) -> None:
        try:
            if self.path == "/api/state":
                self._json(HTTPStatus.OK, self.runtime.snapshot())
            elif self.path.startswith("/api/events"):
                query = self.path.partition("?")[2]
                after = 0
                if query.startswith("after="):
                    after = int(query.removeprefix("after="))
                self._json(HTTPStatus.OK, self.runtime.events_after(after))
            elif self.path == "/api/devices":
                self._json(HTTPStatus.OK, self.runtime.devices())
            elif self.path == "/api/sage":
                self._json(HTTPStatus.OK, self.runtime.sage_host.status())
            elif self.path.startswith("/api/sage/stream?") or self.path == "/api/sage/stream":
                if not self._sage_authorized():
                    return
                from urllib.parse import parse_qs, urlsplit
                query = parse_qs(urlsplit(self.path).query)
                packet = self.runtime.events_after(int(query.get("after", ["0"])[0]))
                scope = self.runtime.sage_host.stream_scope
                self._json(HTTPStatus.OK, {"last": packet["last"], "events": [
                    event for event in packet["events"] if event["type"] == "sage_stream_reply"
                    and event["data"].get("scope") == scope]})
            else:
                self._json(HTTPStatus.NOT_FOUND, {"error": "unknown route"})
        except Exception as exc:
            self._json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})

    def _sage_authorized(self) -> bool:
        key = _sage_event_key(self.runtime.core.config.sage.stream_event_key_environment_variable)
        provided = self.headers.get("Authorization", "").removeprefix("Bearer ")
        if not key or not hmac.compare_digest(key, provided):
            self._json(HTTPStatus.UNAUTHORIZED, {"error": "Stream event key required"})
            return False
        return True

    def do_POST(self) -> None:
        try:
            data = self._body()
            origin = self.headers.get("Origin")
            if origin and origin not in {f"http://{HOST}:{PORT}", f"http://localhost:{PORT}"}:
                raise ValueError("Cross-origin control is not allowed")
            if self.path == "/api/chat":
                self.runtime.send_chat(str(data.get("text", "")))
                self._json(HTTPStatus.ACCEPTED, {"ok": True})
            elif self.path == "/api/onboarding/speak":
                self.runtime.onboarding_speak(data)
                self._json(HTTPStatus.ACCEPTED, {"ok": True})
            elif self.path == "/api/onboarding/stop-speaking":
                self.runtime.voice.stop_speaking()
                self._json(HTTPStatus.OK, {"ok": True})
            elif self.path == "/api/call/toggle":
                self._json(HTTPStatus.OK, self.runtime.toggle_call())
            elif self.path == "/api/call/end":
                self._json(HTTPStatus.OK, self.runtime.end_call())
            elif self.path == "/api/config":
                self._json(HTTPStatus.OK, self.runtime.update_config(data.get("changes", {})))
            elif self.path == "/api/sage/control":
                self._json(HTTPStatus.OK, self.runtime.sage_host.control(
                    str(data.get("action", "")), voice=data.get("voice") is True))
            elif self.path == "/api/sage/event":
                if not self._sage_authorized():
                    return
                self._json(HTTPStatus.OK, self.runtime.sage_host.ingest(data))
            else:
                self._json(HTTPStatus.NOT_FOUND, {"error": "unknown route"})
        except Exception as exc:
            self._json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})


def run_shell_server(root: Path) -> int:
    runtime = ShellRuntime(root)
    ShellHandler.runtime = runtime
    server = ThreadingHTTPServer((HOST, PORT), ShellHandler)
    LOG.info("Stella Electron shell bridge listening on http://%s:%s", HOST, PORT)
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        runtime.close()
    return 0
