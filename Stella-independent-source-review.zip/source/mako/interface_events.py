"""Small factual UI events shared by body reactions and the existing dialogue path."""
from __future__ import annotations


def setting_reaction(key: str, value: object) -> dict[str, object]:
    if key == "discord.enabled":
        return {
            "name": "discord_on" if value else "discord_off",
            "summary": "The user just enabled Discord integration." if value else "The user just disabled Discord integration. Desktop conversation remains available.",
            "body": "pleased, relaxing into a warm expression" if value else "a small playful pout, with lowered chin and slightly drawn-in shoulders",
            "comment": True,
        }
    if key == "discord.autonomy_enabled":
        return {"name": "autonomy_on" if value else "autonomy_off", "comment": False}
    name = "model_change" if key.startswith("model.") else "microphone_change" if key == "voice.input_device" else "voice_change" if key.startswith("voice.") else "settings_change"
    return {"name": name, "comment": False}


def interface_prompt(context: dict[str, object]) -> str:
    return (
        "Interface event, not user speech: " + str(context.get("summary", ""))[:300]
        + " Your avatar has already started " + str(context.get("body", "a small reaction"))[:200]
        + ". Continue that reaction naturally in one short in-character sentence, selecting compatible expression and gesture. "
        "You enjoy chatting on Discord; a playful pout when disconnected is appropriate. "
        "Accept the control choice. Do not claim the user said these words or that Discord is connected after it was disabled."
    )
