from __future__ import annotations

import json
import threading
from collections import deque
from datetime import datetime
from pathlib import Path
from time import monotonic
from typing import Any


class CallContinuity:
    """Small local call-scoped ledger; raw call journals remain the full archive."""

    def __init__(self, root: Path, scope: str) -> None:
        self.path = root / "call_continuity" / f"{scope}.json"
        self._lock = threading.RLock()
        self._previous: dict[str, Any] = {}
        self._current: deque[dict[str, Any]] = deque(maxlen=30)
        self._participants: dict[str, str] = {}
        self._branches: deque[str] = deque(maxlen=6)
        self._floor = "human"
        self._started_at = ""
        self._load()

    def _load(self) -> None:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError):
            self._bootstrap_from_recent_journal()
            return
        if isinstance(data, dict):
            previous = data.get("previous_call")
            if isinstance(previous, dict):
                self._previous = previous
            else:
                self._bootstrap_from_recent_journal()

    def _bootstrap_from_recent_journal(self) -> None:
        """Seed the first call-memory run from the latest existing Discord transcript."""
        journal_dir = self.path.parent.parent / "call_logs"
        try:
            candidates = sorted(journal_dir.glob("*.jsonl"), key=lambda item: item.stat().st_mtime, reverse=True)
        except OSError:
            return
        for candidate in candidates[:12]:
            try:
                with candidate.open("r", encoding="utf-8") as stream:
                    first = json.loads(next(stream))
            except (OSError, ValueError):
                continue
            if first.get("kind") != "session_start" or first.get("transport") != "discord_voice":
                continue
            events, participants = self._read_journal(candidate)
            if not events:
                continue
            useful = [f"{item['speaker']}: {item['text']}" for item in events if not item.get("interrupted")]
            compressed = " | ".join(useful)
            summary = (
                compressed[:420] + " ... [middle of call summarized in timestamped events] ... " + compressed[-1280:]
                if len(compressed) > 1800 else compressed
            )
            self._previous = {
                "started_at": str(first.get("time_local", "")),
                "ended_at": str(datetime.fromtimestamp(candidate.stat().st_mtime).astimezone().isoformat(timespec="seconds")),
                "summary": summary or "No intelligible turns were captured.",
                "events": events[-12:],
                "participants": participants,
            }
            return

    def start(self) -> None:
        with self._lock:
            self._current.clear()
            self._participants.clear()
            self._branches.clear()
            self._floor = "human"
            self._started_at = datetime.now().astimezone().isoformat(timespec="seconds")

    def record_user(self, *, speaker_id: str, speaker_name: str, text: str, state: dict[str, Any]) -> None:
        with self._lock:
            self._participants[str(speaker_id)] = str(speaker_name)
            self._floor = "Stella may respond after the room yields"
            branch = str(state.get("thread", "current_conversation"))
            if branch not in self._branches:
                self._branches.append(branch)
            self._current.append({
                "time": datetime.now().astimezone().strftime("%H:%M:%S"),
                "speaker": str(speaker_name),
                "text": " ".join(text.split())[:260],
                "referent": state.get("likely_referent", "unclear"),
                "addressee": state.get("likely_addressee", "room_or_unclear"),
                "branch": branch,
            })

    def record_assistant(self, *, text: str, interrupted: bool = False) -> None:
        with self._lock:
            entry: dict[str, Any] = {
                "time": datetime.now().astimezone().strftime("%H:%M:%S"),
                "speaker": "Stella",
                "branch": self._branches[-1] if self._branches else "current_conversation",
            }
            if interrupted:
                entry["text"] = "[Stella was interrupted; generated wording omitted from call memory]"
                entry["interrupted"] = True
            else:
                entry["text"] = " ".join(text.split())[:260]
            self._current.append(entry)
            self._floor = "human"

    def prompt_block(self) -> str:
        with self._lock:
            previous = self._previous
            prior_events = previous.get("events", []) if isinstance(previous, dict) else []
            current = list(self._current)
            participants = dict(self._participants)
            branches = list(self._branches)
            floor = self._floor
            started = self._started_at
        lines = ["CALL CONTINUITY - TIMESTAMPED LIVE CONTEXT"]
        if previous:
            lines.append("FROZEN RECAP OF PREVIOUS CALL: " + str(previous.get("summary", "")))
            if prior_events:
                lines.append("Selected timestamped moments from the previous call:")
                lines.extend(self._render(item) for item in prior_events[-10:] if isinstance(item, dict))
        lines.append("CURRENT CALL (chronological; newest items are most relevant):")
        lines.append(f"Started: {started or 'unknown'}; floor: {floor}.")
        if participants:
            lines.append("Participants: " + ", ".join(f"{name} (id {uid})" for uid, name in participants.items()))
        if branches:
            lines.append("Active conversation branches: " + ", ".join(branches))
        lines.extend(self._render(item) for item in current)
        lines.append(
            "Interpretation: distinguish who a line is addressed to from who it refers to. "
            "If the room likely means Stella but evidence is not decisive, ask naturally whether they mean you; "
            "do not describe yourself as a third party. Wait while sustained human speech owns the floor."
        )
        return "\n".join(lines)

    @staticmethod
    def _render(item: dict[str, Any]) -> str:
        text = str(item.get("text", "")).replace("\n", " ")
        return (
            f"[{item.get('time', '??:??:??')}] {item.get('speaker', 'Unknown')}: {text} "
            f"(branch={item.get('branch', 'unknown')}; referent={item.get('referent', 'n/a')}; "
            f"addressee={item.get('addressee', 'n/a')})"
        )

    def finish(self, journal_path: Path | None = None) -> None:
        with self._lock:
            events = list(self._current)
            participants = dict(self._participants)
            if journal_path is not None:
                archived_events, archived_participants = self._read_journal(journal_path)
                if archived_events:
                    events = archived_events
                    participants.update(archived_participants)
            useful = [
                f"{item.get('speaker', 'Unknown')}: {item.get('text', '')}"
                for item in events if not item.get("interrupted")
            ]
            compressed = " | ".join(useful)
            if len(compressed) > 1800:
                summary = compressed[:420] + " ... [middle of call summarized in timestamped events] ... " + compressed[-1280:]
            else:
                summary = compressed or "No intelligible turns were captured."
            previous = {
                "started_at": self._started_at,
                "ended_at": datetime.now().astimezone().isoformat(timespec="seconds"),
                "summary": summary,
                "events": events[-12:],
                "participants": participants,
            }
            data = {"version": 1, "previous_call": previous}
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self.path.with_suffix(".tmp")
            temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            temporary.replace(self.path)
            self._previous = previous


def interrupt_confirmation_ready(
    candidate_at: float,
    now: float,
    transcript: str,
    last_speech_at: float | None,
    *,
    minimum_seconds: float = 1.0,
    max_silence_seconds: float = 0.35,
) -> bool:
    """Require a full second of candidate speech plus contemporaneous transcript evidence."""
    return bool(
        transcript.strip()
        and now - candidate_at >= minimum_seconds
        and last_speech_at is not None
        and 0.0 <= now - last_speech_at <= max_silence_seconds
    )

    @staticmethod
    def _read_journal(path: Path) -> tuple[list[dict[str, Any]], dict[str, str]]:
        events: list[dict[str, Any]] = []
        participants: dict[str, str] = {}
        try:
            rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
        except (OSError, ValueError):
            return events, participants
        interrupted_ids = {
            str(row.get("turn_id")) for row in rows
            if row.get("kind") == "assistant_playback" and row.get("status") == "interrupted"
        }
        for row in rows:
            kind = row.get("kind")
            if kind == "user_turn":
                speaker = str(row.get("speaker_name", "Unknown"))
                speaker_id = str(row.get("speaker_id", ""))
                participants[speaker_id] = speaker
                state = row.get("social_state") if isinstance(row.get("social_state"), dict) else {}
                events.append({
                    "time": str(row.get("time_local", ""))[11:19], "speaker": speaker,
                    "text": " ".join(str(row.get("text", "")).split())[:260],
                    "addressee": state.get("likely_addressee", row.get("addressed_to", "unknown")),
                    "referent": state.get("likely_referent", "unknown"),
                    "branch": state.get("thread", "current_conversation"),
                })
            elif kind == "assistant_turn":
                interrupted = str(row.get("turn_id", "")) in interrupted_ids
                events.append({
                    "time": str(row.get("time_local", ""))[11:19], "speaker": "Stella",
                    "text": "[Stella was interrupted; generated wording omitted from call memory]" if interrupted else " ".join(str(row.get("text", "")).split())[:260],
                    "branch": "current_conversation", "interrupted": interrupted,
                })
        return events, participants


class SustainedSpeechGate:
    """Per-speaker adaptive PCM gate that rejects steady background noise."""

    def __init__(
        self, *, rms_threshold: int = 240, noise_floor_ratio: float = 2.0,
        noise_floor_alpha: float = 0.12, calibration_seconds: float = 0.5,
        attack_seconds: float = 0.35,
        hangover_seconds: float = 0.12,
    ) -> None:
        self.rms_threshold = rms_threshold
        self.noise_floor_ratio = noise_floor_ratio
        self.noise_floor_alpha = noise_floor_alpha
        self.calibration_seconds = calibration_seconds
        self.attack_seconds = attack_seconds
        self.hangover_seconds = hangover_seconds
        self._lock = threading.Lock()
        self._state: dict[str, tuple[float, float, float, float, bool, bool]] = {}

    def observe(self, speaker_id: str, pcm_rms: int, now: float) -> bool:
        """Fire once for speech sustained above both the absolute and adaptive floors."""
        key = str(speaker_id)
        with self._lock:
            state = self._state.get(key)
            if state is None:
                floor = min(float(max(0, pcm_rms)), float(self.rms_threshold))
                calibration_until = now + self.calibration_seconds
                started, last_voice, fired, candidate = now, now, False, False
            else:
                floor, calibration_until, started, last_voice, fired, candidate = state
            if now < calibration_until:
                floor += (float(max(0, pcm_rms)) - floor) * self.noise_floor_alpha
                self._state[key] = (floor, calibration_until, now, now, False, False)
                return False
            threshold = max(self.rms_threshold, floor * self.noise_floor_ratio)
            if pcm_rms >= threshold:
                if not candidate or now - last_voice > self.hangover_seconds:
                    started, fired = now, False
                candidate = True
                last_voice = now
                if not fired and now - started >= self.attack_seconds:
                    fired = True
                    self._state[key] = (floor, calibration_until, started, last_voice, fired, candidate)
                    return True
                self._state[key] = (floor, calibration_until, started, last_voice, fired, candidate)
                return False
            if now - last_voice > self.hangover_seconds:
                floor += (float(max(0, pcm_rms)) - floor) * self.noise_floor_alpha
                started, last_voice, fired = now, now, False
                candidate = False
            self._state[key] = (floor, calibration_until, started, last_voice, fired, candidate)
            return False

    def last_speech_at(self, speaker_id: str) -> float | None:
        """Return the last above-threshold frame time for a speaker, if seen."""
        with self._lock:
            state = self._state.get(str(speaker_id))
            return state[3] if state is not None and state[5] else None


class SileroSpeechOnsetGate:
    """Streaming Silero VAD gate for low-latency, per-speaker barge-in."""

    def __init__(
        self, model=None, *, model_factory=None, threshold: float = 0.72, required_frames: int = 5,
        release_frames: int = 5, frame_samples: int = 512, activity_threshold: float = 0.45,
    ) -> None:
        import numpy as np
        import torch

        self.model = model
        self.model_factory = model_factory
        self.threshold = threshold
        self.activity_threshold = activity_threshold
        self.required_frames = required_frames
        self.release_frames = release_frames
        self.frame_samples = frame_samples
        self._np = np
        self._torch = torch
        self._lock = threading.Lock()
        self._state: dict[str, tuple[Any, Any, int, int, bool]] = {}
        self._last_speech_at: dict[str, float] = {}
        self._initial_model_claimed = False

    def observe(self, speaker_id: str, samples, sample_rate: int = 16_000) -> bool:
        """Consume mono float samples at 16 kHz; fire once per speech segment."""
        key = str(speaker_id)
        incoming = self._np.asarray(samples, dtype=self._np.float32).reshape(-1)
        with self._lock:
            state = self._state.get(key)
            if state is None:
                if self.model is not None and not self._initial_model_claimed:
                    model = self.model
                    self._initial_model_claimed = True
                else:
                    model = self.model_factory() if self.model_factory is not None else self.model
                pending, positives, negatives, fired = self._np.empty(0, dtype=self._np.float32), 0, 0, False
            else:
                model, pending, positives, negatives, fired = state
            pending = self._np.concatenate((pending, incoming))
            detected = False
            while pending.size >= self.frame_samples:
                frame, pending = pending[:self.frame_samples], pending[self.frame_samples:]
                probability = float(model(self._torch.from_numpy(frame), sample_rate).reshape(-1)[0])
                if probability >= self.activity_threshold:
                    self._last_speech_at[key] = monotonic()
                if probability >= self.threshold:
                    positives += 1
                    negatives = 0
                    if not fired and positives >= self.required_frames:
                        fired = True
                        detected = True
                else:
                    positives = 0
                    negatives += 1
                    if negatives >= self.release_frames:
                        fired = False
            self._state[key] = (model, pending, positives, negatives, fired)
            return detected

    def last_speech_at(self, speaker_id: str) -> float | None:
        with self._lock:
            return self._last_speech_at.get(str(speaker_id))

    def reset(self, speaker_id: str | None = None) -> None:
        with self._lock:
            if speaker_id is None:
                for model, *_ in self._state.values():
                    reset = getattr(model, "reset_states", None)
                    if callable(reset):
                        reset()
                self._state.clear()
                self._last_speech_at.clear()
                if self.model is not None:
                    reset = getattr(self.model, "reset_states", None)
                    if callable(reset):
                        reset()
                self._initial_model_claimed = False
            else:
                state = self._state.pop(str(speaker_id), None)
                self._last_speech_at.pop(str(speaker_id), None)
                if state is not None:
                    reset = getattr(state[0], "reset_states", None)
                    if callable(reset):
                        reset()

    def reset_scope(self, prefix: str) -> None:
        """Reset all speaker streams whose keys begin with a call/guild scope."""
        with self._lock:
            keys = [key for key in self._state if key.startswith(prefix)]
            for key in keys:
                model = self._state.pop(key)[0]
                self._last_speech_at.pop(key, None)
                reset = getattr(model, "reset_states", None)
                if callable(reset):
                    reset()
                if model is self.model:
                    self._initial_model_claimed = False
