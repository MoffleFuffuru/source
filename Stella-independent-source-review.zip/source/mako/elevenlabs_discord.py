"""Speaker-isolated input and clock-safe Discord PCM for ElevenLabs."""
from __future__ import annotations

import logging
import queue
import threading
import time
from collections import deque
from dataclasses import dataclass, field

from .elevenlabs_voice import ScribeSTTClient
from .inworld_stt import InworldSTTClient

LOG = logging.getLogger(__name__)


class PcmBuffer:
    """Discord's 20ms clock must never wait on network reads or mistake a gap for EOF."""

    def __init__(self):
        self._lock = threading.Lock()
        self._data = bytearray()
        self.finished = False
        self.consumed_bytes = 0
        self.cancelled = threading.Event()

    def put(self, data):
        with self._lock:
            if not self.cancelled.is_set():
                if len(self._data) + len(data) > 48_000 * 4 * 60:
                    raise RuntimeError("Discord speech buffer exceeded one minute")
                self._data.extend(data)

    def size(self):
        with self._lock:
            return len(self._data)

    def read(self):
        with self._lock:
            if self.cancelled.is_set():
                return b""
            if not self._data:
                return b"" if self.finished else bytes(3840)
            frame = bytes(self._data[:3840])
            del self._data[:3840]
            self.consumed_bytes += len(frame)
            return frame.ljust(3840, b"\0")

    def finish(self):
        with self._lock:
            self.finished = True

    def cleanup(self):
        self.cancelled.set()
        with self._lock:
            self._data.clear()


@dataclass
class Speaker:
    member: object
    audio: queue.Queue = field(default_factory=lambda: queue.Queue(maxsize=250))
    stop: threading.Event = field(default_factory=threading.Event)
    last_audible: float = field(default_factory=time.monotonic)
    profile: str = ""
    thread: threading.Thread | None = None


class SpeakerPool:
    def __init__(self, config, on_turn, on_partial=None):
        self.config = config
        self.on_turn = on_turn
        self.on_partial = on_partial
        self.lock = threading.RLock()
        self.entries = {}
        self.retry_after = {}
        self.closed = False

    def push(self, guild_id, member, pcm):
        import numpy as np
        samples = np.frombuffer(pcm, dtype="<i2")
        if len(samples) < 2:
            return
        mono = samples[:len(samples) // 2 * 2].reshape(-1, 2).mean(axis=1).astype("float32") / 32768
        audible = float(np.sqrt(np.mean(mono * mono))) >= 200 / 32768
        key = (guild_id, int(member.id))
        with self.lock:
            if self.closed:
                return
            speaker = self.entries.get(key)
            if speaker is None:
                if not audible or len(self.entries) >= 8 or time.monotonic() < self.retry_after.get(key, 0):
                    return
                speaker = Speaker(member)
                self.entries[key] = speaker
                speaker.thread = threading.Thread(target=self._run, args=(key, speaker), daemon=True, name=f"scribe-discord-{member.id}")
                speaker.thread.start()
            if audible:
                speaker.last_audible = time.monotonic()
            try:
                speaker.audio.put_nowait(mono)
            except queue.Full:
                # Discard the entire interrupted utterance, not random internal audio.
                speaker.stop.set()
                LOG.warning("Discord Scribe input overflow speaker=%s; discarding stream", member.id)

    def _run(self, key, speaker):
        client = None
        def committed(text):
            with self.lock:
                current = not self.closed and self.entries.get(key) is speaker and not speaker.stop.is_set()
            if current:
                self.on_turn(key[0], speaker.member, text, speaker.profile, speaker.last_audible)
                speaker.profile = ""
        def partial(text):
            with self.lock:
                current = not self.closed and self.entries.get(key) is speaker and not speaker.stop.is_set()
            if current and self.on_partial is not None:
                self.on_partial(key[0], speaker.member, text)
        def status(value):
            if value.startswith("voice error:"):
                speaker.stop.set()
                LOG.warning("Discord Scribe disconnected speaker=%s", key[1])
        try:
            client = ScribeSTTClient(self.config, capture_microphone=False, on_utterance=committed,
                                     on_partial=partial,
                                     on_voice_profile=lambda value: setattr(speaker, "profile", value), on_status=status)
            try:
                client.start()
            except Exception:
                client.stop()
                if self.config.elevenlabs_stt_fallback != "inworld_stt" or speaker.stop.is_set():
                    raise
                c = self.config
                client = InworldSTTClient(
                    api_key_environment_variable=c.inworld_stt_api_key_environment_variable,
                    input_device=None, language=c.language, profile_threshold=c.inworld_stt_profile_threshold,
                    eot_confidence_threshold=c.inworld_stt_eot_confidence_threshold,
                    min_eot_silence_ms=c.inworld_stt_min_eot_silence_ms, max_turn_silence_ms=c.inworld_stt_max_turn_silence_ms,
                    on_utterance=committed, on_partial=partial,
                    on_voice_profile=lambda value: setattr(speaker, "profile", value), on_status=status, capture_microphone=False,
                )
                client.start()
                LOG.warning("Discord speaker=%s using Inworld STT fallback", key[1])
            import numpy as np
            while not speaker.stop.is_set() and time.monotonic() - speaker.last_audible < 30:
                try:
                    samples = speaker.audio.get(timeout=.1)
                except queue.Empty:
                    if isinstance(client, ScribeSTTClient):
                        continue
                    # Inworld fallback also needs silence when Discord stops packets.
                    samples = np.zeros(4800, dtype=np.float32)
                client.push_audio(samples, 48000)
        except Exception:
            LOG.exception("Discord Scribe speaker session failed speaker=%s", key[1])
            with self.lock:
                self.retry_after[key] = time.monotonic() + 10
        finally:
            speaker.stop.set()
            if client is not None:
                client.stop()
            with self.lock:
                if self.entries.get(key) is speaker:
                    del self.entries[key]

    def close(self, guild_id=None):
        with self.lock:
            if guild_id is None:
                self.closed = True
            entries = [entry for key, entry in self.entries.items() if guild_id is None or key[0] == guild_id]
            for entry in entries:
                entry.stop.set()
        deadline = time.monotonic() + 6
        for entry in entries:
            if entry.thread is not threading.current_thread():
                entry.thread.join(max(0, deadline - time.monotonic()))


class VocalProfilePool:
    """Best-effort Inworld prosody sidecars; never own turn boundaries."""

    def __init__(self, config, on_profile):
        self.config = config
        self.on_profile = on_profile
        self.lock = threading.RLock()
        self.entries = {}
        self.closed = False
        self.closed_guilds = set()
        self.incoming = queue.Queue(maxsize=1000)
        self.dispatcher = threading.Thread(target=self._dispatch, daemon=True, name="inworld-profile-dispatch")
        self.dispatcher.start()

    def push(self, guild_id, member, pcm):
        if self.closed or self.config.vocal_context_provider != "inworld_stt":
            return
        try:
            self.incoming.put_nowait((guild_id, member, pcm))
        except queue.Full:
            LOG.warning("Inworld sidecar dispatch queue full; dropping one audio frame")

    def open_guild(self, guild_id):
        with self.lock:
            self.closed_guilds.discard(guild_id)

    def _dispatch(self):
        while not self.closed:
            try:
                item = self.incoming.get(timeout=0.1)
            except queue.Empty:
                continue
            if item is None:
                return
            try:
                self._push_audio(*item)
            except Exception:
                LOG.exception("Could not enqueue audio for Inworld vocal sidecar")

    def _push_audio(self, guild_id, member, pcm):
        import numpy as np

        samples = np.frombuffer(pcm, dtype="<i2")
        if len(samples) < 2:
            return
        mono = samples[: len(samples) // 2 * 2].reshape(-1, 2).mean(axis=1).astype("float32") / 32768
        audible = float(np.sqrt(np.mean(mono * mono))) >= 200 / 32768
        key = (guild_id, int(member.id))
        with self.lock:
            if self.closed or guild_id in self.closed_guilds:
                return
            speaker = self.entries.get(key)
            if speaker is None:
                if not audible or len(self.entries) >= 8:
                    return
                speaker = Speaker(member)
                self.entries[key] = speaker
                speaker.thread = threading.Thread(target=self._run, args=(key, speaker), daemon=True,
                                                  name=f"inworld-profile-{member.id}")
                speaker.thread.start()
            if audible:
                speaker.last_audible = time.monotonic()
            try:
                speaker.audio.put_nowait(mono)
            except queue.Full:
                LOG.warning("Inworld vocal sidecar queue full speaker=%s; dropping profile audio", member.id)

    def _run(self, key, speaker):
        client = None
        try:
            client = InworldSTTClient(
                api_key_environment_variable=self.config.inworld_stt_api_key_environment_variable,
                input_device=None, language=self.config.language,
                profile_threshold=self.config.inworld_stt_profile_threshold,
                eot_confidence_threshold=self.config.inworld_stt_eot_confidence_threshold,
                min_eot_silence_ms=self.config.inworld_stt_min_eot_silence_ms,
                max_turn_silence_ms=self.config.inworld_stt_max_turn_silence_ms,
                on_utterance=lambda _text: None, on_partial=None,
                on_voice_profile=lambda value: self.on_profile(key, speaker.member, value),
                on_status=lambda _status: None, capture_microphone=False,
            )
            client.start()
            import numpy as np
            while not speaker.stop.is_set() and time.monotonic() - speaker.last_audible < 30:
                try:
                    samples = speaker.audio.get(timeout=0.1)
                except queue.Empty:
                    samples = np.zeros(4800, dtype=np.float32)
                if samples is not None:
                    client.push_audio(samples, 48_000)
        except Exception:
            LOG.exception("Inworld vocal sidecar failed speaker=%s", key[1])
        finally:
            speaker.stop.set()
            if client is not None:
                client.stop()
            with self.lock:
                if self.entries.get(key) is speaker:
                    del self.entries[key]

    def close(self, guild_id=None):
        with self.lock:
            if guild_id is None:
                self.closed = True
            else:
                self.closed_guilds.add(guild_id)
            entries = [entry for key, entry in self.entries.items() if guild_id is None or key[0] == guild_id]
            for entry in entries:
                entry.stop.set()
        if guild_id is None:
            try:
                self.incoming.put_nowait(None)
            except queue.Full:
                pass
            if self.dispatcher is not threading.current_thread():
                self.dispatcher.join(2)
        deadline = time.monotonic() + 6
        for entry in entries:
            if entry.thread is not threading.current_thread():
                entry.thread.join(max(0, deadline - time.monotonic()))
