from __future__ import annotations

import json
import re
import sqlite3
import threading
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, Iterator
from uuid import uuid4

from .config import MemoryConfig
from .model_backend import ModelBackend, ModelError
from .models import ConversationEvent, EventSource, Expression, InteractionMode, ResponseResult, Visibility
from .prompts import CONSOLIDATION_SYSTEM
from .quality import token_jaccard


_EXPLICIT_MEMORY_ACTION = re.compile(r"\b(?:remember|recall|recollect)\b", re.IGNORECASE)
_LOOKUP_ACTION = re.compile(
    r"\b(?:search(?:\s+for)?|find|locate|retrieve|look\s+(?:up|through|for)|pull\s+up|quote)\b",
    re.IGNORECASE,
)
_HISTORY_OBJECT = re.compile(
    r"\b(?:call|conversation|chat|discord|text(?:s|ing)?|message|voice|"
    r"project|plan|implementation|memory\s+(?:board|system)|core\s+memory)\b",
    re.IGNORECASE,
)
_PAST_ANCHOR = re.compile(
    r"\b(?:last|previous|earlier|before|first|old|recent|back\s+then|"
    r"the\s+other\s+day|yesterday|today)\b",
    re.IGNORECASE,
)
_SHARED_PAST_FACT = re.compile(
    r"\b(?:what|which|who|when|where|how)\b.{0,100}\b(?:did|was|were|had|"
    r"said|told|mentioned|described|explained|asked|planned|promised|decided|"
    r"wanted|talked|discussed|worked)\b",
    re.IGNORECASE,
)
_PERSONAL_HISTORY = re.compile(
    r"\b(?:what|tell\s+me|describe|quote)\b.{0,80}\b(?:you\s+know|you\s+remember|"
    r"about\s+(?:me|us|my|our|\w+)|from\s+(?:your|our)\s+(?:memory|history))\b",
    re.IGNORECASE,
)
_REQUEST_FORM = re.compile(
    r"\?|^\s*(?:what|which|who|when|where|how|tell|describe|quote|search|find|look|"
    r"can|could|do|did|are|were|is|was)\b",
    re.IGNORECASE,
)
_DIRECTED_RECALL = re.compile(
    r"\b(?:i\s+(?:need|want)|please|go\s+ahead\s+and)\b.{0,70}"
    r"\b(?:remember|recall|recollect|search|find|locate|retrieve|quote)\b",
    re.IGNORECASE,
)
_RECALL_STOPWORDS = {
    "do", "did", "can", "could", "would", "you", "remember", "anything", "about",
    "that", "this", "what", "when", "from", "the", "a", "an", "we", "i", "me",
    "mako", "yesterday", "today", "last", "time",
}
_ASSOCIATION_STOPWORDS = _RECALL_STOPWORDS | {
    "is", "are", "was", "were", "be", "been", "have", "has", "had", "for", "with",
    "and", "but", "not", "just", "then", "than", "into", "from", "your", "our", "their",
    "they", "them", "she", "her", "him", "his", "its", "about", "there", "here", "this",
    "earlier", "new", "main", "parts", "details", "points", "describe", "described",
}


def is_memory_recall_request(text: str) -> bool:
    """Route natural shared-history questions to scoped evidence retrieval.

    Recall wording is highly variable in real conversation. This deliberately
    favors a bounded lookup over a confident unsupported answer whenever a user
    asks about prior shared speech, people, plans, or personal history.
    """
    normalized = " ".join(text.lower().split())
    if not normalized:
        return False

    has_explicit_memory_action = bool(_EXPLICIT_MEMORY_ACTION.search(normalized))
    has_lookup_action = bool(_LOOKUP_ACTION.search(normalized))
    has_history_object = bool(_HISTORY_OBJECT.search(normalized))
    has_past_anchor = bool(_PAST_ANCHOR.search(normalized))
    shared_subject = bool(re.search(r"\b(?:i|me|my|we|our|you|your)\b", normalized))

    # Direct requests such as "what do you remember about Jalty?" or "search
    # your memory for toes" should always inspect evidence.
    is_request = bool(_REQUEST_FORM.search(normalized) or _DIRECTED_RECALL.search(normalized))
    if not is_request:
        return False
    if has_explicit_memory_action:
        return True
    if has_lookup_action and (shared_subject or has_history_object):
        return True
    if _PERSONAL_HISTORY.search(normalized):
        return True

    # People rarely say "remember" when asking "what did I say I would do?"
    # Treat a question about a shared, past fact as recall even without that word.
    if shared_subject and _SHARED_PAST_FACT.search(normalized):
        return True
    if has_history_object and has_past_anchor:
        return True
    return False


def _is_negative_recall_evidence(text: str) -> bool:
    """Do not let earlier failed recall answers become proof of amnesia."""
    return bool(re.search(
        r"\b(?:nothing|nope|no\s+idea)\b"
        r"|\b(?:i\s+)?(?:do\s+not|don't|cannot|can't)\s+(?:remember|know|place)\b"
        r"|\bno,?\s+i\s+(?:do\s+not|don't)\b"
        r"|\bwho(?:'s|\s+is)\s+\w+\??\s*$",
        text,
        re.IGNORECASE,
    ))


@dataclass(slots=True)
class ConsolidationResult:
    processed: int = 0
    relationship_delta: dict[str, float] = field(default_factory=dict)


def _json_object(text: str) -> dict[str, Any]:
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    return json.loads(cleaned)


def _local_timestamp(value: str) -> str:
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone().strftime("%Y-%m-%d %I:%M %p")
    except ValueError:
        return value


def _recall_time_window(query: str) -> tuple[datetime, datetime] | None:
    """Translate explicit local-time language into a hard recall window."""
    local_now = datetime.now().astimezone()
    start_of_day = local_now.replace(hour=0, minute=0, second=0, microsecond=0)
    normalized = query.lower()
    if re.search(r"\b(?:this|earlier)\s+morning\b", normalized):
        return start_of_day, min(local_now, start_of_day + timedelta(hours=12))
    if re.search(r"\b(?:this|earlier)\s+afternoon\b", normalized):
        return start_of_day + timedelta(hours=12), min(local_now, start_of_day + timedelta(hours=18))
    if re.search(r"\b(?:this|earlier)\s+evening\b", normalized):
        return start_of_day + timedelta(hours=18), local_now
    if re.search(r"\b(?:earlier\s+)?today\b", normalized):
        return start_of_day, local_now
    return None


class MemoryEngine:
    def __init__(self, database_path: Path, config: MemoryConfig) -> None:
        self.database_path = database_path
        self.config = config
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._initialize()
        self.session_id = self._start_session()

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.database_path, timeout=20.0)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA journal_mode=WAL")
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS sessions (
                    id TEXT PRIMARY KEY,
                    started_at TEXT NOT NULL,
                    ended_at TEXT,
                    turn_count INTEGER NOT NULL DEFAULT 0,
                    meaningful INTEGER NOT NULL DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS episodes (
                    id TEXT PRIMARY KEY,
                    session_id TEXT NOT NULL,
                    event_id TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    source TEXT NOT NULL,
                    mode TEXT NOT NULL,
                    visibility TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    channel_id TEXT NOT NULL DEFAULT 'desktop',
                    user_text TEXT NOT NULL,
                    mako_text TEXT NOT NULL,
                    emotional_weight REAL NOT NULL DEFAULT 0.2,
                    importance REAL NOT NULL DEFAULT 0.2,
                    consolidated INTEGER NOT NULL DEFAULT 0,
                    recalled_count INTEGER NOT NULL DEFAULT 0,
                    last_recalled TEXT
                );

                CREATE TABLE IF NOT EXISTS concepts (
                    key TEXT PRIMARY KEY,
                    label TEXT NOT NULL,
                    summary TEXT NOT NULL,
                    topics_json TEXT NOT NULL,
                    visibility TEXT NOT NULL DEFAULT 'private',
                    strength REAL NOT NULL,
                    confidence REAL NOT NULL,
                    recurrence INTEGER NOT NULL,
                    emotional_weight REAL NOT NULL,
                    relationship_relevance REAL NOT NULL,
                    core INTEGER NOT NULL DEFAULT 0,
                    protection_cycles INTEGER NOT NULL DEFAULT 0,
                    last_seen TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_episodes_created
                ON episodes(created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_episodes_pending
                ON episodes(consolidated, created_at);

                CREATE TABLE IF NOT EXISTS episode_terms (
                    episode_id TEXT NOT NULL,
                    scope TEXT NOT NULL,
                    term TEXT NOT NULL,
                    weight REAL NOT NULL DEFAULT 1.0,
                    PRIMARY KEY (episode_id, scope, term)
                );
                CREATE INDEX IF NOT EXISTS idx_episode_terms_lookup
                ON episode_terms(scope, term, episode_id);

                CREATE TABLE IF NOT EXISTS term_edges (
                    scope TEXT NOT NULL,
                    left_term TEXT NOT NULL,
                    right_term TEXT NOT NULL,
                    weight REAL NOT NULL DEFAULT 1.0,
                    last_seen TEXT NOT NULL,
                    PRIMARY KEY (scope, left_term, right_term)
                );
                CREATE INDEX IF NOT EXISTS idx_term_edges_lookup
                ON term_edges(scope, left_term, weight DESC);

                CREATE TABLE IF NOT EXISTS identity_aliases (
                    scope TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    alias TEXT NOT NULL,
                    first_seen TEXT NOT NULL,
                    last_seen TEXT NOT NULL,
                    PRIMARY KEY (scope, user_id, alias)
                );

                CREATE TABLE IF NOT EXISTS discord_memory_profiles (
                    guild_id TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    display_name TEXT NOT NULL,
                    summary TEXT NOT NULL,
                    source_digest TEXT NOT NULL,
                    source_turns INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL,
                    model TEXT NOT NULL DEFAULT 'openai/gpt-oss-120b',
                    PRIMARY KEY (guild_id, user_id)
                );

                CREATE TABLE IF NOT EXISTS discord_memory_profile_chunks (
                    guild_id TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    source_digest TEXT NOT NULL,
                    chunk_index INTEGER NOT NULL,
                    summary TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (guild_id, user_id, source_digest, chunk_index)
                );

                CREATE TABLE IF NOT EXISTS metadata (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                """
            )
            concept_columns = {
                str(row["name"])
                for row in connection.execute("PRAGMA table_info(concepts)").fetchall()
            }
            if "visibility" not in concept_columns:
                connection.execute(
                    "ALTER TABLE concepts ADD COLUMN visibility TEXT NOT NULL DEFAULT 'private'"
                )
            episode_columns = {
                str(row["name"])
                for row in connection.execute("PRAGMA table_info(episodes)").fetchall()
            }
            if "channel_id" not in episode_columns:
                connection.execute(
                    "ALTER TABLE episodes ADD COLUMN channel_id TEXT NOT NULL DEFAULT 'desktop'"
                )
            self._backfill_shared_discord_history(connection)
            self._backfill_associations(connection)
            self._backfill_identity_aliases(connection)

    def _backfill_shared_discord_history(self, connection: sqlite3.Connection) -> None:
        """Expose already-saved public bot exchanges to their original Discord channel."""
        marker = connection.execute(
            "SELECT value FROM metadata WHERE key = 'shared_discord_backfill_v2'"
        ).fetchone()
        if marker:
            return
        rows = connection.execute(
            """SELECT session_id, event_id, created_at, source, mode, visibility,
                      user_id, channel_id, user_text, mako_text, emotional_weight, importance
               FROM episodes
               WHERE source = 'discord' AND visibility = 'public'
                 AND channel_id LIKE 'discord:%:speaker:%'"""
        ).fetchall()
        for row in rows:
            match = re.match(r"^discord:([^:]+):speaker:", str(row["channel_id"]))
            if not match:
                continue
            channel_id = f"discord:{match.group(1)}:shared"
            connection.execute(
                """INSERT INTO episodes (
                    id, session_id, event_id, created_at, source, mode, visibility,
                    user_id, channel_id, user_text, mako_text, emotional_weight, importance
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    uuid4().hex, str(row["session_id"]), f"{row['event_id']}:shared-backfill",
                    str(row["created_at"]), str(row["source"]), str(row["mode"]), str(row["visibility"]),
                    str(row["user_id"]), channel_id,
                    f"Discord speaker {row['user_id']}: {row['user_text']}", str(row["mako_text"]),
                    float(row["emotional_weight"]), float(row["importance"]),
                ),
            )
        connection.execute(
            "INSERT OR REPLACE INTO metadata (key, value) VALUES ('shared_discord_backfill_v2', ?)",
            (datetime.now(UTC).isoformat(),),
        )

    def _backfill_associations(self, connection: sqlite3.Connection) -> None:
        """Index old turns once without changing or re-summarising their content."""
        marker = connection.execute(
            "SELECT value FROM metadata WHERE key = 'associative_memory_index_v3'"
        ).fetchone()
        if marker:
            return
        # Index both sides of a turn and the immediate same-session transition.
        # Adjacent turns often supply the answer without sharing literal words.
        connection.execute("DELETE FROM episode_terms")
        connection.execute("DELETE FROM term_edges")
        rows = connection.execute(
            """SELECT id, session_id, visibility, user_id, channel_id, user_text, mako_text, created_at
               FROM episodes ORDER BY created_at ASC"""
        ).fetchall()
        previous_terms: dict[tuple[str, str], list[str]] = {}
        for row in rows:
            terms = self._index_episode(
                connection, str(row["id"]), str(row["visibility"]), str(row["user_id"]),
                str(row["channel_id"]), str(row["user_text"]), str(row["mako_text"]), str(row["created_at"]),
            )
            key = (self._scope(str(row["visibility"]), str(row["user_id"]), str(row["channel_id"])), str(row["session_id"]))
            if key in previous_terms:
                self._link_adjacent_terms(connection, key[0], previous_terms[key], terms, str(row["created_at"]))
            previous_terms[key] = terms
        connection.execute(
            "INSERT OR REPLACE INTO metadata (key, value) VALUES ('associative_memory_index_v3', ?)",
            (datetime.now(UTC).isoformat(),),
        )

    def _backfill_identity_aliases(self, connection: sqlite3.Connection) -> None:
        marker = connection.execute(
            "SELECT value FROM metadata WHERE key = 'identity_alias_index_v2'"
        ).fetchone()
        if marker:
            return
        connection.execute("DELETE FROM identity_aliases")
        rows = connection.execute(
            """SELECT visibility, user_id, channel_id, user_text, created_at FROM episodes
               WHERE visibility = ? AND user_id = ? ORDER BY created_at ASC""",
            (Visibility.PRIVATE.value, "owner"),
        ).fetchall()
        for row in rows:
            self._record_identity_aliases(
                connection, str(row["visibility"]), str(row["user_id"]), str(row["channel_id"]),
                str(row["user_text"]), str(row["created_at"]),
            )
        connection.execute(
            "INSERT OR REPLACE INTO metadata (key, value) VALUES ('identity_alias_index_v2', ?)",
            (datetime.now(UTC).isoformat(),),
        )

    @staticmethod
    def _scope(visibility: str, user_id: str, channel_id: str) -> str:
        # Keep per-speaker indexes; access to a public channel unions its scopes.
        if visibility == Visibility.PRIVATE.value and user_id == "owner":
            return "private:owner"
        return f"{visibility}:{user_id}:{channel_id}"

    @staticmethod
    def _terms(text: str) -> list[str]:
        terms = [
            token for token in re.findall(r"[a-z0-9][a-z0-9']{2,}", text.lower())
            if token not in _ASSOCIATION_STOPWORDS
        ]
        return list(dict.fromkeys(terms))[:24]

    def _index_episode(
        self, connection: sqlite3.Connection, episode_id: str, visibility: str, user_id: str,
        channel_id: str, user_text: str, mako_text: str, created_at: str,
    ) -> list[str]:
        scope = self._scope(visibility, user_id, channel_id)
        terms = list(dict.fromkeys([*self._terms(user_text), *self._terms(mako_text)]))[:36]
        connection.executemany(
            "INSERT OR IGNORE INTO episode_terms (episode_id, scope, term) VALUES (?, ?, ?)",
            [(episode_id, scope, term) for term in terms],
        )
        for index, left_term in enumerate(terms):
            for right_term in terms[index + 1:index + 9]:
                first, second = sorted((left_term, right_term))
                connection.execute(
                    """INSERT INTO term_edges (scope, left_term, right_term, weight, last_seen)
                       VALUES (?, ?, ?, 1.0, ?)
                       ON CONFLICT(scope, left_term, right_term) DO UPDATE SET
                         weight = weight + 1.0, last_seen = excluded.last_seen""",
                    (scope, first, second, created_at),
                )
        return terms

    @staticmethod
    def _link_adjacent_terms(
        connection: sqlite3.Connection, scope: str, previous: list[str], current: list[str], created_at: str,
    ) -> None:
        for left_term in previous[:10]:
            for right_term in current[:10]:
                if left_term == right_term:
                    continue
                first, second = sorted((left_term, right_term))
                connection.execute(
                    """INSERT INTO term_edges (scope, left_term, right_term, weight, last_seen)
                       VALUES (?, ?, ?, 0.35, ?)
                       ON CONFLICT(scope, left_term, right_term) DO UPDATE SET
                         weight = weight + 0.35, last_seen = excluded.last_seen""",
                    (scope, first, second, created_at),
                )

    def _record_identity_aliases(
        self, connection: sqlite3.Connection, visibility: str, user_id: str,
        channel_id: str, text: str, created_at: str,
    ) -> None:
        if visibility != Visibility.PRIVATE.value or user_id != "owner":
            return
        aliases: set[str] = set()
        for match in re.finditer(r"\b([a-z][a-z0-9_-]*(?:\s+[a-z][a-z0-9_-]*){0,2})\s+(?:is|was)\s+(?:also\s+)?me\b", text, re.IGNORECASE):
            aliases.add(match.group(1).strip())
        for match in re.finditer(r"\b(?:i\s+)?go\s+by\s+([a-z][a-z0-9_-]*(?:\s+[a-z][a-z0-9_-]*){0,2})", text, re.IGNORECASE):
            aliases.add(match.group(1).strip())
        scope = self._scope(visibility, user_id, channel_id)
        for alias in aliases:
            normalized = re.sub(r"^(?:that|the)\s+", "", alias.lower()).strip()
            if len(normalized) < 3 or any(word in {"i", "you", "me", "my", "your", "tell"} for word in normalized.split()):
                continue
            connection.execute(
                """INSERT INTO identity_aliases (scope, user_id, alias, first_seen, last_seen)
                   VALUES (?, ?, ?, ?, ?)
                   ON CONFLICT(scope, user_id, alias) DO UPDATE SET last_seen = excluded.last_seen""",
                (scope, user_id, normalized, created_at, created_at),
            )

    def _start_session(self) -> str:
        session_id = uuid4().hex
        now = datetime.now(UTC).isoformat()
        with self._connect() as connection:
            connection.execute(
                """
                UPDATE sessions
                SET ended_at = ?, meaningful = CASE WHEN turn_count >= ? THEN 1 ELSE 0 END
                WHERE ended_at IS NULL
                """,
                (now, self.config.meaningful_session_turns),
            )
            connection.execute(
                "INSERT INTO sessions (id, started_at) VALUES (?, ?)",
                (session_id, now),
            )
        return session_id

    def close_session(self) -> None:
        with self._lock, self._connect() as connection:
            row = connection.execute(
                "SELECT turn_count FROM sessions WHERE id = ?",
                (self.session_id,),
            ).fetchone()
            turn_count = int(row["turn_count"]) if row else 0
            meaningful = int(turn_count >= self.config.meaningful_session_turns)
            connection.execute(
                """
                UPDATE sessions SET ended_at = ?, meaningful = ? WHERE id = ?
                """,
                (datetime.now(UTC).isoformat(), meaningful, self.session_id),
            )

    def record_turn(self, event: ConversationEvent, result: ResponseResult) -> None:
        emotional_weight = min(1.0, sum(abs(value) for value in result.mood_delta.values()))
        importance = min(1.0, 0.15 + (result.complexity * 0.1) + (emotional_weight * 0.35))
        with self._lock, self._connect() as connection:
            episode_id = uuid4().hex
            connection.execute(
                """
                INSERT INTO episodes (
                    id, session_id, event_id, created_at, source, mode, visibility,
                    user_id, channel_id, user_text, mako_text, emotional_weight, importance
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    episode_id,
                    self.session_id,
                    event.id,
                    event.created_at,
                    event.source.value,
                    event.mode.value,
                    event.visibility.value,
                    event.user_id,
                    event.channel_id,
                    event.content,
                    result.text,
                    emotional_weight,
                    importance,
                ),
            )
            self._index_episode(
                connection, episode_id, event.visibility.value, event.user_id, event.channel_id,
                event.content, result.text, event.created_at,
            )
            self._record_identity_aliases(
                connection, event.visibility.value, event.user_id, event.channel_id,
                event.content, event.created_at,
            )
            connection.execute(
                "UPDATE sessions SET turn_count = turn_count + 1 WHERE id = ?",
                (self.session_id,),
            )
            shared_channel = str(event.metadata.get("discord_channel_id", "")).strip()
            if event.visibility is Visibility.PUBLIC and event.source.value == "discord" and shared_channel:
                shared_episode_id = uuid4().hex
                connection.execute(
                    """INSERT INTO episodes (
                        id, session_id, event_id, created_at, source, mode, visibility,
                        user_id, channel_id, user_text, mako_text, emotional_weight, importance
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        shared_episode_id, self.session_id, f"{event.id}:shared", event.created_at,
                        event.source.value, event.mode.value, event.visibility.value,
                        event.user_id, f"discord:{shared_channel}:shared",
                        self._shared_discord_text(event),
                        result.text, emotional_weight, importance,
                    ),
                )
                self._index_episode(
                    connection, shared_episode_id, event.visibility.value, event.user_id,
                    f"discord:{shared_channel}:shared", self._shared_discord_text(event), result.text,
                    event.created_at,
                )
            self._prune_episodes(connection)

    def record_assistant_notice(
        self, *, event_id: str, text: str, user_id: str, display_name: str,
        channel_id: str, shared_channel_id: str,
    ) -> bool:
        """Store a delivered assistant notice as Stella speech, not user-authored text."""
        if not self.config.enabled or not text.strip():
            return False
        event = ConversationEvent(
            id=event_id,
            content="[system notice: delayed AI response]",
            source=EventSource.DISCORD,
            mode=InteractionMode.CALL,
            visibility=Visibility.PUBLIC,
            user_id=user_id,
            display_name=display_name,
            channel_id=channel_id,
            metadata={
                "discord_channel_id": shared_channel_id,
                "assistant_notice": True,
            },
        )
        result = ResponseResult(
            turn_id=event_id,
            event_id=event_id,
            text=text.strip(),
            expression=Expression.NEUTRAL,
            move="assistant delay notice",
            complexity=1,
            mood_delta={},
            relationship_delta={},
            score=1.0,
            repaired=False,
            attempts=0,
            model="local-notice",
            generation_seconds=0.0,
            trace={"assistant_notice": True},
        )
        with self._lock, self._connect() as connection:
            if connection.execute("SELECT 1 FROM episodes WHERE event_id = ? LIMIT 1", (event_id,)).fetchone():
                return False
            self.record_turn(event, result)
        return True

    def record_public_observation(self, event: ConversationEvent) -> None:
        """Store allowed public Discord text separately from personal conversation history."""
        shared_channel = str(event.metadata.get("discord_channel_id", "")).strip()
        if event.visibility is not Visibility.PUBLIC or event.source.value != "discord" or not shared_channel:
            return
        with self._lock, self._connect() as connection:
            # Discord history can be fetched again for a later recall question.
            # The original message id makes importing that observation idempotent.
            existing = connection.execute(
                "SELECT 1 FROM episodes WHERE event_id = ? LIMIT 1",
                (f"{event.id}:observation",),
            ).fetchone()
            if existing:
                return
            episode_id = uuid4().hex
            connection.execute(
                """INSERT INTO episodes (
                    id, session_id, event_id, created_at, source, mode, visibility,
                    user_id, channel_id, user_text, mako_text, emotional_weight, importance
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    episode_id, self.session_id, f"{event.id}:observation", event.created_at,
                    event.source.value, event.mode.value, event.visibility.value,
                    event.user_id, f"discord:{shared_channel}:shared", self._shared_discord_text(event),
                    "", 0.0, 0.04,
                ),
            )
            self._index_episode(
                connection, episode_id, event.visibility.value, event.user_id,
                f"discord:{shared_channel}:shared", self._shared_discord_text(event), "", event.created_at,
            )
            self._prune_episodes(connection)

    @staticmethod
    def _shared_discord_text(event: ConversationEvent) -> str:
        speaker = event.display_name.strip() or event.user_id
        return f"Discord speaker {speaker} ({event.user_id}): {event.content}"

    def _prune_episodes(self, connection: sqlite3.Connection) -> None:
        if self.config.max_episodes <= 0:
            return
        connection.execute(
            """
            DELETE FROM episodes
            WHERE id IN (
                SELECT id FROM episodes
                ORDER BY created_at DESC
                LIMIT -1 OFFSET ?
            )
            """,
            (self.config.max_episodes,),
        )

    def recent_history(
        self,
        limit: int | None = None,
        exclude_event_id: str | None = None,
        channel_id: str | None = None,
    ) -> list[tuple[str, str]]:
        turn_limit = limit or self.config.recent_turns
        exclusion = "AND event_id != ?" if exclude_event_id else ""
        filters = ["session_id = ?"]
        parameters: list[Any] = [self.session_id]
        if channel_id:
            filters.append("channel_id = ?")
            parameters.append(channel_id)
        if exclude_event_id:
            filters.append("event_id != ?")
            parameters.append(exclude_event_id)
        parameters.append(turn_limit)
        with self._lock, self._connect() as connection:
            rows = connection.execute(
                f"""
                SELECT user_text, mako_text FROM episodes
                WHERE {' AND '.join(filters)}
                ORDER BY created_at DESC, rowid DESC LIMIT ?
                """,
                parameters,
            ).fetchall()
        return [(str(row["user_text"]), str(row["mako_text"])) for row in reversed(rows)]

    def full_session_history(
        self,
        exclude_event_id: str | None = None,
        channel_id: str | None = None,
    ) -> list[tuple[str, str]]:
        """Return every turn in the active session for one conversation channel."""
        return self.recent_history(
            limit=-1,
            exclude_event_id=exclude_event_id,
            channel_id=channel_id,
        )

    def recent_history_with_times(
        self,
        limit: int | None = None,
        exclude_event_id: str | None = None,
        channel_id: str | None = None,
    ) -> list[tuple[str, str, str]]:
        turn_limit = limit or self.config.recent_turns
        exclusion = "AND event_id != ?" if exclude_event_id else ""
        filters = ["session_id = ?"]
        parameters: list[Any] = [self.session_id]
        if channel_id:
            filters.append("channel_id = ?")
            parameters.append(channel_id)
        if exclude_event_id:
            filters.append("event_id != ?")
            parameters.append(exclude_event_id)
        parameters.append(turn_limit)
        with self._lock, self._connect() as connection:
            rows = connection.execute(
                f"""
                SELECT user_text, mako_text, created_at FROM episodes
                WHERE {' AND '.join(filters)}
                ORDER BY created_at DESC, rowid DESC LIMIT ?
                """,
                parameters,
            ).fetchall()
        return [
            (str(row["user_text"]), str(row["mako_text"]), str(row["created_at"]))
            for row in reversed(rows)
        ]

    def full_session_history_with_times(
        self,
        exclude_event_id: str | None = None,
        channel_id: str | None = None,
    ) -> list[tuple[str, str, str]]:
        """Return every timestamped turn in the active session for one channel."""
        return self.recent_history_with_times(
            limit=-1,
            exclude_event_id=exclude_event_id,
            channel_id=channel_id,
        )

    def owner_session_history_with_times(self) -> list[tuple[str, str, str]]:
        """Unify the owner's app text and call turns within the active session."""
        with self._lock, self._connect() as connection:
            rows = connection.execute(
                """
                SELECT user_text, mako_text, created_at FROM episodes
                WHERE session_id = ? AND user_id = ? AND visibility = ?
                  AND mode IN (?, ?)
                ORDER BY created_at ASC, rowid ASC
                """,
                (
                    self.session_id,
                    "owner",
                    Visibility.PRIVATE.value,
                    "text",
                    "call",
                ),
            ).fetchall()
        return [
            (str(row["user_text"]), str(row["mako_text"]), str(row["created_at"]))
            for row in rows
        ]

    def relationship_history(self, limit: int = 600) -> list[tuple[str, str]]:
        """Return private owner conversation as evidence for the relationship state."""
        with self._lock, self._connect() as connection:
            rows = connection.execute(
                """
                SELECT user_text, mako_text FROM episodes
                WHERE user_id = ? AND visibility = ? AND mode IN (?, ?)
                ORDER BY created_at DESC LIMIT ?
                """,
                ("owner", Visibility.PRIVATE.value, "text", "call", limit),
            ).fetchall()
        return [(str(row["user_text"]), str(row["mako_text"])) for row in reversed(rows)]

    def discord_relationship_summary(self, user_id: str, limit: int = 240) -> str:
        """Derive cautious per-user relationship evidence from recorded public history."""
        with self._lock, self._connect() as connection:
            rows = connection.execute(
                """
                SELECT user_text, mako_text FROM episodes
                WHERE user_id = ? AND source = 'discord'
                  AND channel_id LIKE 'discord:%:shared'
                ORDER BY created_at DESC LIMIT ?
                """,
                (user_id, limit),
            ).fetchall()
        turns = len(rows)
        if turns <= 1:
            return (
                "relationship=unknown; insufficient history; familiarity=0.00; trust=0.00; "
                "affection=0.00; friction=0.00"
            )
        text = "\n".join(str(row["user_text"]).lower() for row in rows)
        replies = sum(bool(str(row["mako_text"]).strip()) for row in rows)

        def hits(phrases: tuple[str, ...]) -> int:
            return sum(len(re.findall(rf"(?<!\w){re.escape(item)}(?!\w)", text)) for item in phrases)

        affection_hits = hits(("love you", "miss you", "care about you", "you're cute", "you are cute"))
        trust_hits = hits(("i trust you", "thank you", "appreciate you", "being honest", "i'm sorry", "im sorry"))
        friction_hits = hits(("shut up", "hate you", "stupid", "idiot", "annoying", "fuck you"))
        familiarity = min(0.90, ((turns - 1) * 0.015) + (replies * 0.02))
        trust = min(0.85, (trust_hits * 0.08) + (replies * 0.008))
        affection = min(0.90, (affection_hits * 0.12) + (familiarity * 0.12))
        friction = min(0.90, friction_hits * 0.11)
        return (
            f"relationship=established; turns={turns}; familiarity={familiarity:.2f}; "
            f"trust={trust:.2f}; affection={affection:.2f}; friction={friction:.2f}"
        )

    def proactive_context(self, episode_limit: int = 10, concept_limit: int = 6) -> list[str]:
        """Return recent experiences and strong concepts suitable for a callback."""
        with self._lock, self._connect() as connection:
            episodes = connection.execute(
                """
                SELECT user_text, mako_text, created_at
                FROM episodes
                WHERE visibility = 'private'
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (episode_limit,),
            ).fetchall()
            concepts = connection.execute(
                """
                SELECT label, summary
                FROM concepts
                WHERE visibility = 'private'
                ORDER BY core DESC, relationship_relevance DESC, strength DESC, last_seen DESC
                LIMIT ?
                """,
                (concept_limit,),
            ).fetchall()

        context = [
            f"Recent exchange: User: {row['user_text']} | Mako: {row['mako_text']}"
            for row in reversed(episodes)
        ]
        context.extend(
            f"Durable memory: {row['label']}: {row['summary']}" for row in concepts
        )
        return context

    def replace_turn(self, event: ConversationEvent, result: ResponseResult) -> bool:
        emotional_weight = min(1.0, sum(abs(value) for value in result.mood_delta.values()))
        importance = min(1.0, 0.15 + (result.complexity * 0.1) + (emotional_weight * 0.35))
        with self._lock, self._connect() as connection:
            cursor = connection.execute(
                """
                UPDATE episodes
                SET mako_text = ?, emotional_weight = ?, importance = ?, consolidated = 0
                WHERE event_id = ?
                """,
                (result.text, emotional_weight, importance, event.id),
            )
            return cursor.rowcount > 0

    def _allowed_scopes(
        self, visibility: Visibility, user_id: str | None, *, include_private_owner: bool,
        shared_channel_id: str | None = None,
    ) -> list[str]:
        if shared_channel_id and visibility is Visibility.PUBLIC and user_id:
            channel = f"discord:{shared_channel_id}:shared"
            with self._lock, self._connect() as connection:
                speakers = connection.execute(
                    "SELECT DISTINCT user_id FROM episodes WHERE visibility = ? AND channel_id = ?",
                    (Visibility.PUBLIC.value, channel),
                ).fetchall()
            scopes = [self._scope(Visibility.PUBLIC.value, str(row["user_id"]), channel) for row in speakers]
            if include_private_owner and user_id == "owner":
                scopes.append("private:owner")
            return scopes
        if include_private_owner and user_id == "owner":
            scopes = ["private:owner"]
            if shared_channel_id:
                scopes.append(self._scope(visibility.value, "owner", f"discord:{shared_channel_id}:shared"))
            return scopes
        if not user_id:
            return []
        if shared_channel_id:
            return [self._scope(visibility.value, user_id, f"discord:{shared_channel_id}:shared")]
        return [self._scope(visibility.value, user_id, "desktop")]

    def _associative_memories(
        self, query: str, visibility: Visibility, *, user_id: str | None,
        include_private_owner: bool, shared_channel_id: str | None = None, limit: int | None = None,
        candidate_limit: int | None = None,
        suggestion_context: list[tuple] | None = None,
        target_user_id: str | None = None,
    ) -> list[str]:
        """Bounded two-stage recall: query terms, then one-hop co-occurrence terms."""
        packet_limit = max(1, min(10, int(limit or self.config.associative_packet_size)))
        current_terms = set(self._terms(query))
        context_terms = set()
        recent_texts = set()
        if suggestion_context is not None:
            for turn in suggestion_context[-3:]:
                # User evidence supplies context; generated replies must not seed facts.
                context_terms.update(self._terms(str(turn[0])[-600:]))
                recent_texts.add(re.sub(r"\W+", " ", str(turn[0]).lower()).strip())
        query_terms = list(dict.fromkeys([*self._terms(query), *sorted(context_terms)]))[:48]
        if target_user_id and shared_channel_id and visibility is Visibility.PUBLIC:
            channel = f"discord:{shared_channel_id}:shared"
            scopes = [self._scope(visibility.value, target_user_id, channel)]
        else:
            scopes = self._allowed_scopes(
                visibility, user_id, include_private_owner=include_private_owner,
                shared_channel_id=shared_channel_id,
            )
        if not query_terms or not scopes:
            return []
        scope_marks = ",".join("?" for _ in scopes)
        term_marks = ",".join("?" for _ in query_terms)
        with self._lock, self._connect() as connection:
            # Edges are stored canonically, so either side may continue activation.
            edge_rows = connection.execute(
                f"""SELECT left_term, right_term, weight FROM term_edges
                    WHERE scope IN ({scope_marks})
                      AND (left_term IN ({term_marks}) OR right_term IN ({term_marks}))
                    ORDER BY weight DESC LIMIT 32""",
                [*scopes, *query_terms, *query_terms],
            ).fetchall()
            associated = {
                str(row["right_term"]) if str(row["left_term"]) in query_terms else str(row["left_term"])
                for row in edge_rows
            }
            active_terms = list(dict.fromkeys([*query_terms, *associated]))[:48]
            active_marks = ",".join("?" for _ in active_terms)
            rows = connection.execute(
                f"""SELECT e.id, e.session_id, e.user_id, e.source, e.user_text, e.mako_text, e.created_at, e.importance,
                           GROUP_CONCAT(et.term) AS matched_terms,
                           SUM(CASE WHEN et.term IN ({term_marks}) THEN 1 ELSE 0 END) AS direct_count
                    FROM episodes e JOIN episode_terms et ON et.episode_id = e.id
                    WHERE et.scope IN ({scope_marks}) AND et.term IN ({active_marks})
                    GROUP BY e.id
                    ORDER BY direct_count DESC, e.created_at DESC LIMIT ?""",
                [*query_terms, *scopes, *active_terms, candidate_limit or self.config.associative_candidate_limit],
            ).fetchall()
        scored: list[tuple[float, sqlite3.Row]] = []
        direct = set(query_terms)
        time_window = _recall_time_window(query)
        normalized_query = re.sub(r"\W+", " ", query.lower()).strip()
        raw_words = re.findall(r"[a-z0-9']+", query.lower())
        query_phrases = {
            " ".join(raw_words[start:start + size])
            for size in range(3, min(6, len(raw_words) + 1))
            for start in range(0, len(raw_words) - size + 1)
            if len(set(raw_words[start:start + size]) - _ASSOCIATION_STOPWORDS) >= 2
        }
        recent_reference = bool(re.search(r"\b(?:earlier\s+today|last\s+call|previous\s+call|just\s+now)\b", query, re.IGNORECASE))
        asks_for_details = bool(re.search(r"\b(?:main\s+)?(?:parts|details|points)\b", query, re.IGNORECASE))
        for row in rows:
            if time_window:
                try:
                    created_at = datetime.fromisoformat(str(row["created_at"]).replace("Z", "+00:00")).astimezone()
                except ValueError:
                    continue
                if not time_window[0] <= created_at <= time_window[1]:
                    continue
            normalized_user_text = re.sub(r"\W+", " ", str(row["user_text"]).lower()).strip()
            if suggestion_context is not None and normalized_user_text in recent_texts:
                continue
            prior_answer = str(row["mako_text"]).lower()
            # Do not let prior copies of this question, or a prior admission of
            # failed recall, become stronger evidence than the original memory.
            if normalized_user_text == normalized_query or any(
                phrase in prior_answer
                for phrase in (
                    "i don't have", "i don�t have", "don't remember", "don�t remember", "cannot place",
                    "don't want to hallucinate", "don�t want to hallucinate", "hallucinate the parts",
                    "can't verify", "can�t verify", "available memories",
                )
            ) or ("verify" in prior_answer and ("available" in prior_answer or "have" in prior_answer)):
                continue
            matched = set(str(row["matched_terms"] or "").split(","))
            direct_hits = len(matched & direct)
            related_hits = len(matched - direct)
            information = min(0.50, len(self._terms(f"{row['user_text']} {row['mako_text']}")) / 48.0)
            try:
                age_hours = max(0.0, (datetime.now(UTC) - datetime.fromisoformat(str(row["created_at"]).replace("Z", "+00:00"))).total_seconds() / 3600)
            except ValueError:
                age_hours = 24.0 * 365.0
            recency = 0.40 / (1.0 + (age_hours / 24.0))
            temporal_match = 1.20 if recent_reference and age_hours <= 12.0 else 0.0
            substance = min(1.0, len(re.findall(r"[a-z0-9']+", f"{row['user_text']} {row['mako_text']}".lower())) / 80.0)
            detail_match = substance if asks_for_details and recent_reference and age_hours <= 12.0 else 0.0
            transcript = f"{row['user_text']} {row['mako_text']}".lower()
            phrase_match = min(2.0, 0.70 * sum(phrase in transcript for phrase in query_phrases))
            score = (direct_hits * 1.0) + (related_hits * 0.18) + (float(row["importance"]) * 0.12) + information + recency + temporal_match + detail_match + phrase_match
            if suggestion_context is not None:
                evidence_terms = set(self._terms(str(row["user_text"])))
                current_hits = len(evidence_terms & current_terms)
                context_hits = len(evidence_terms & context_terms)
                # Two grounded cues, with the latest topic leading. Short acknowledgments
                # may continue the prior topic; unrelated full turns may not.
                if not (current_hits >= 2 or (current_hits and context_hits and
                        len(evidence_terms & (current_terms | context_terms)) >= 2) or
                        (len(current_terms) < 2 and context_hits >= 2)):
                    continue
                score = current_hits * 2.0 + context_hits * 0.65 + phrase_match + information + recency * 0.25
            if direct_hits or related_hits >= 2:
                scored.append((score, row))
        if not scored:
            return []
        scored.sort(key=lambda item: item[0], reverse=True)
        top_score, top_row = scored[0]
        selected: list[sqlite3.Row] = []
        seen_fingerprints: set[str] = set()
        relevance_floor = top_score * 0.72
        for score, row in scored:
            if score < relevance_floor:
                break
            fingerprint = re.sub(r"\W+", " ", str(row["user_text"]).lower()).strip()
            if not fingerprint or fingerprint in seen_fingerprints:
                continue
            selected.append(row)
            seen_fingerprints.add(fingerprint)
            if len(selected) >= packet_limit:
                break
        if not selected:
            return []
        now = datetime.now(UTC).isoformat()
        with self._lock, self._connect() as connection:
            connection.executemany(
                "UPDATE episodes SET recalled_count = recalled_count + 1, last_recalled = ? WHERE id = ?",
                [(now, str(row["id"])) for row in selected],
            )
        # A question often matches the setup turn while the answer is in the
        # immediately following turn. Include that bounded same-session companion.
        if suggestion_context is None:
            selected = self._with_adjacent_companions(selected, scopes)
        return [
            f"[memory:{str(row['id'])[:8]} | {_local_timestamp(str(row['created_at']))}] "
            + (f"[{row['source']} | user:{row['user_id']}] " if suggestion_context is not None else "")
            + f"User: {row['user_text']}\nMako: {row['mako_text']}"
            for row in selected[:packet_limit]
        ]

    def _with_adjacent_companions(
        self, selected: list[sqlite3.Row], scopes: list[str]) -> list[sqlite3.Row]:
        if not selected or not scopes:
            return selected
        marks = ",".join("?" for _ in scopes)
        expanded: list[sqlite3.Row] = []
        seen = {str(row["id"]) for row in selected}
        with self._lock, self._connect() as connection:
            for row in selected[:5]:
                expanded.append(row)
                if len(expanded) >= self.config.associative_packet_size:
                    break
                anchor_terms = self._terms(str(row["user_text"]))
                if len(anchor_terms) < 2:
                    continue
                anchor_marks = ",".join("?" for _ in anchor_terms)
                companions = connection.execute(
                    f"""SELECT e.id, e.session_id, e.user_text, e.mako_text, e.created_at, e.importance
                        FROM episodes e JOIN episode_terms et ON et.episode_id = e.id
                        WHERE e.session_id = ? AND e.created_at > ? AND et.scope IN ({marks})
                          AND et.term IN ({anchor_marks})
                        GROUP BY e.id HAVING COUNT(DISTINCT et.term) >= 2
                        ORDER BY e.created_at ASC LIMIT 2""",
                    [str(row["session_id"]), str(row["created_at"]), *scopes, *anchor_terms],
                ).fetchall()
                for companion in companions:
                    if len(expanded) >= self.config.associative_packet_size:
                        break
                    if str(companion["id"]) not in seen:
                        expanded.append(companion)
                        seen.add(str(companion["id"]))
        return expanded or selected

    def inspect_memory(
        self, handle: str, visibility: Visibility, *, user_id: str | None,
        include_private_owner: bool, shared_channel_id: str | None = None,
        context_radius: int = 2, full_call: bool = False, call_offset: int = 0,
        page_size: int = 12,
    ) -> str:
        """Read a memory locally; owner private calls may be inspected as paged transcripts."""
        memory_id = re.sub(r"[^a-f0-9]", "", handle.lower())[:32]
        if len(memory_id) < 8:
            return "Invalid memory handle."
        scopes = self._allowed_scopes(
            visibility, user_id, include_private_owner=include_private_owner,
            shared_channel_id=shared_channel_id,
        )
        if not scopes:
            return "No memory is available in this scope."
        marks = ",".join("?" for _ in scopes)
        radius = max(0, min(4, int(context_radius)))
        with self._lock, self._connect() as connection:
            row = connection.execute(
                f"""SELECT e.rowid AS row_position, e.id, e.session_id, e.channel_id,
                           e.visibility, e.source, e.mode, e.user_id,
                           e.created_at, e.user_text, e.mako_text
                    FROM episodes e JOIN episode_terms et ON et.episode_id = e.id
                    WHERE e.id LIKE ? AND et.scope IN ({marks})
                    GROUP BY e.id LIMIT 1""",
                [f"{memory_id}%", *scopes],
            ).fetchone()
            if full_call:
                if not row:
                    return "That memory is unavailable in this conversation's scope."
                if not (
                    include_private_owner and user_id == "owner"
                    and str(row["visibility"]) == Visibility.PRIVATE.value
                    and str(row["user_id"]) == "owner"
                    and str(row["source"]) == EventSource.VOICE_CALL.value
                    and str(row["mode"]) == InteractionMode.CALL.value
                ):
                    return "Full-call inspection is available only for the owner's private personal-call memories."
                call_rows = connection.execute(
                    f"""SELECT e.id, e.created_at, e.user_text, e.mako_text
                        FROM episodes e WHERE e.session_id = ? AND e.channel_id = ?
                          AND e.visibility = ? AND e.user_id = ?
                          AND e.source = ? AND e.mode = ?
                          AND EXISTS (
                              SELECT 1 FROM episode_terms et
                              WHERE et.episode_id = e.id AND et.scope IN ({marks})
                          )
                        ORDER BY e.created_at ASC, e.rowid ASC""",
                    [
                        str(row["session_id"]), str(row["channel_id"]),
                        Visibility.PRIVATE.value, "owner", EventSource.VOICE_CALL.value,
                        InteractionMode.CALL.value, *scopes,
                    ],
                ).fetchall()
                total = len(call_rows)
                offset = max(0, min(total, int(call_offset)))
                page_size = max(1, min(12, int(page_size)))
                page = call_rows[offset:offset + page_size]
                if not page:
                    return f"This personal call has {total} turns; no transcript turns exist at offset {offset}."
                lines = [
                    f"Owner personal-call transcript, turns {offset + 1}-{offset + len(page)} of {total}. "
                    "This is the complete source conversation when read across all pages."
                ]
                for index, item in enumerate(page, start=offset + 1):
                    anchor = " | selected memory" if str(item["id"]) == str(row["id"]) else ""
                    lines.append(
                        f"[turn {index}{anchor} | memory:{str(item['id'])[:8]} | "
                        f"{_local_timestamp(str(item['created_at']))}] "
                        f"User: {item['user_text']}\nStella: {item['mako_text']}"
                    )
                return "\n\n".join(lines)
            context_rows = [row] if row else []
            if row and radius:
                scope_exists = f"""EXISTS (
                    SELECT 1 FROM episode_terms et
                    WHERE et.episode_id = e.id AND et.scope IN ({marks})
                )"""
                base = "e.session_id = ? AND e.channel_id = ? AND e.visibility = ?"
                shared = [str(row["session_id"]), str(row["channel_id"]), str(row["visibility"])]
                before = connection.execute(
                    f"""SELECT e.rowid AS row_position, e.id, e.created_at, e.user_text, e.mako_text
                        FROM episodes e WHERE {base}
                          AND (e.created_at < ? OR (e.created_at = ? AND e.rowid < ?))
                          AND {scope_exists}
                        ORDER BY e.created_at DESC, e.rowid DESC LIMIT ?""",
                    [*shared, str(row["created_at"]), str(row["created_at"]),
                     int(row["row_position"]), *scopes, radius],
                ).fetchall()
                after = connection.execute(
                    f"""SELECT e.rowid AS row_position, e.id, e.created_at, e.user_text, e.mako_text
                        FROM episodes e WHERE {base}
                          AND (e.created_at > ? OR (e.created_at = ? AND e.rowid > ?))
                          AND {scope_exists}
                        ORDER BY e.created_at ASC, e.rowid ASC LIMIT ?""",
                    [*shared, str(row["created_at"]), str(row["created_at"]),
                     int(row["row_position"]), *scopes, radius],
                ).fetchall()
                context_rows = [*reversed(before), row, *after]
        if not row:
            return "That memory is unavailable in this conversation's scope."
        return "\n\n".join(
            f"[{('selected memory' if item['id'] == row['id'] else 'surrounding turn')} | "
            f"memory:{str(item['id'])[:8]} | {_local_timestamp(str(item['created_at']))}] "
            f"User: {item['user_text']}\nMako: {item['mako_text']}"
            for item in context_rows
        )

    def related_memories(
        self, handle: str, visibility: Visibility, *, user_id: str | None,
        include_private_owner: bool, shared_channel_id: str | None = None,
    ) -> list[str]:
        scopes = self._allowed_scopes(
            visibility, user_id, include_private_owner=include_private_owner,
            shared_channel_id=shared_channel_id,
        )
        if not scopes:
            return []
        memory_id = re.sub(r"[^a-f0-9]", "", handle.lower())[:32]
        if len(memory_id) < 8:
            return []
        marks = ",".join("?" for _ in scopes)
        with self._lock, self._connect() as connection:
            terms = connection.execute(
                f"SELECT term FROM episode_terms WHERE episode_id LIKE ? AND scope IN ({marks})",
                [f"{memory_id}%", *scopes],
            ).fetchall()
        query = " ".join(str(row["term"]) for row in terms[:12])
        return self._associative_memories(
            query, visibility, user_id=user_id, include_private_owner=include_private_owner,
            shared_channel_id=shared_channel_id, limit=4,
        )

    def retrieve_rma_slots(
        self, query: str, visibility: Visibility, *, user_id: str | None,
        include_private_owner: bool, context_history: list[tuple[str, ...]] | None = None,
        shared_channel_id: str | None = None, seed_memories: list[str] | None = None,
        per_slot: int = 7,
    ) -> dict[str, list[str]]:
        """Build six synchronous evidence packets; sparse slots stay sparse."""
        count = max(5, min(10, int(per_slot)))
        labels = (
            "L0 Core Identity", "L1 Hot Memory", "L2 Topic Threads",
            "L3 Older Episodes", "L4 Current Context", "L5 Practical Lessons",
        )
        slots = {label: [] for label in labels}
        scopes = self._allowed_scopes(
            visibility, user_id, include_private_owner=include_private_owner,
            shared_channel_id=shared_channel_id,
        )
        if not scopes:
            return slots

        marks = ",".join("?" for _ in scopes)
        private_owner = include_private_owner and user_id == "owner"
        concept_filter = "" if private_owner or visibility is Visibility.PRIVATE else "WHERE visibility = ?"
        concept_params: tuple[str, ...] = () if not concept_filter else (visibility.value,)
        include_concepts = user_id in {None, "owner"} and (not shared_channel_id or private_owner)
        with self._lock, self._connect() as connection:
            concepts = (
                connection.execute(
                    f"""SELECT key, label, summary, topics_json, strength, confidence,
                               relationship_relevance, core, last_seen
                        FROM concepts {concept_filter}
                        ORDER BY core DESC, relationship_relevance DESC, strength DESC, last_seen DESC
                        LIMIT 240""",
                    concept_params,
                ).fetchall()
                if include_concepts
                else []
            )
            episodes = connection.execute(
                f"""SELECT e.id, e.session_id, e.source, e.mode, e.visibility, e.user_id,
                           e.channel_id, e.user_text, e.mako_text, e.created_at,
                           e.importance, e.emotional_weight
                    FROM episodes e
                    WHERE EXISTS (
                        SELECT 1 FROM episode_terms et
                        WHERE et.episode_id = e.id AND et.scope IN ({marks})
                    )
                    ORDER BY e.created_at DESC LIMIT 2400""",
                scopes,
            ).fetchall()

        now = datetime.now(UTC)
        normalized_query = re.sub(r"(?<=\w)'s\b", "", query.casefold())
        query_terms = set(self._terms(normalized_query))
        terms_by_episode = {
            str(row["id"]): set(self._terms(f"{row['user_text']} {row['mako_text']}"))
            for row in episodes
        }

        def episode_text(row: sqlite3.Row) -> str:
            return (
                f"[memory:{str(row['id'])[:8]} | {_local_timestamp(str(row['created_at']))}] "
                f"User: {row['user_text']}\nStella: {row['mako_text']}"
            )

        def episode_relevance(row: sqlite3.Row) -> float:
            if not query_terms:
                return 0.0
            # User-authored wording is the primary evidence for personal facts.
            # Assistant replies often contain generic acknowledgements or
            # paraphrases that can make an unrelated episode win on shared
            # boilerplate (for example, every fixture saying "favorite detail").
            def scoped_overlap(text: str) -> float:
                normalized = re.sub(r"(?<=\w)'s\b", "", text.casefold())
                candidate_terms = set(self._terms(normalized))
                union = query_terms | candidate_terms
                return len(query_terms & candidate_terms) / len(union) if union else 0.0

            user_relevance = scoped_overlap(str(row["user_text"] or ""))
            full_relevance = scoped_overlap(
                f"{row['user_text']} {row['mako_text']}"
            )
            return user_relevance * 0.8 + full_relevance * 0.2

        # Stable, explicitly consolidated core concepts are always kept separate
        # from recent episodes so identity does not get displaced by recency.
        for row in concepts:
            if not int(row["core"]):
                continue
            slots[labels[0]].append(f"{row['label']}: {row['summary']}")
            if len(slots[labels[0]]) >= count:
                break

        hot = []
        older = []
        for row in episodes:
            try:
                age = now - datetime.fromisoformat(str(row["created_at"]).replace("Z", "+00:00")).astimezone(UTC)
            except ValueError:
                continue
            if age <= timedelta(days=30):
                hot.append(row)
            elif episode_relevance(row) >= 0.04 or float(row["importance"]) >= 0.78:
                older.append(row)
        hot_limit = min(10, count + 3)
        slots[labels[1]] = [episode_text(row) for row in hot[:hot_limit]]

        # Topic packets retain their supporting episode handles so Stella can
        # expand a promising thread into original evidence on demand.
        ranked_topics: list[tuple[float, sqlite3.Row, list[str]]] = []
        for concept in concepts:
            raw_topics = str(concept["topics_json"] or "[]")
            try:
                parsed = json.loads(raw_topics)
            except json.JSONDecodeError:
                parsed = []
            topic_names = [str(item) for item in parsed if str(item).strip()] if isinstance(parsed, list) else []
            topic_text = " | ".join([str(concept["label"]), str(concept["summary"]), *topic_names])
            relevance = token_jaccard(query, topic_text) if query_terms else 0.0
            if relevance < 0.025 and not topic_names:
                continue
            topic_terms = set(self._terms(topic_text))
            linked = [
                row for row in episodes
                if topic_terms & terms_by_episode[str(row["id"])]
            ][:2]
            linked_text = "; ".join(
                f"memory:{str(row['id'])[:8]} {str(row['user_text'])[:180]}" for row in linked
            )
            detail = f"Topics: {', '.join(topic_names[:5])}" if topic_names else ""
            packet = f"{concept['label']}: {concept['summary']}"
            if detail:
                packet += f" ({detail})"
            if linked_text:
                packet += f" | linked episodes: {linked_text}"
            score = relevance + float(concept["strength"]) * 0.10 + float(concept["relationship_relevance"]) * 0.08
            ranked_topics.append((score, concept, [packet]))
        ranked_topics.sort(key=lambda item: item[0], reverse=True)
        slots[labels[2]] = [packet for _, _, packets in ranked_topics[:count] for packet in packets]

        older.sort(
            key=lambda row: (
                episode_relevance(row) + float(row["importance"]) * 0.08,
                str(row["created_at"]),
            ), reverse=True,
        )
        slots[labels[3]] = [episode_text(row) for row in older[:count]]

        seen_context: set[str] = set()
        for item in seed_memories or []:
            text = str(item).strip()
            if text and text not in seen_context:
                slots[labels[4]].append(text)
                seen_context.add(text)
                if len(slots[labels[4]]) >= count:
                    break
        for turn in reversed(context_history or []):
            if len(slots[labels[4]]) >= count:
                break
            user_text = str(turn[0]).strip() if turn else ""
            stella_text = str(turn[1]).strip() if len(turn) > 1 else ""
            timestamp = _local_timestamp(str(turn[2])) if len(turn) > 2 else "current session"
            text = f"[{timestamp}] User: {user_text}\nStella: {stella_text}"
            if user_text and text not in seen_context:
                slots[labels[4]].append(text)
                seen_context.add(text)
        return slots

    def retrieve(
        self,
        query: str,
        visibility: Visibility,
        limit: int | None = None,
        *,
        user_id: str | None = None,
        include_private_owner: bool = False,
        shared_channel_id: str | None = None,
        suggestion_context: list[tuple] | None = None,
        trace: dict[str, str] | None = None,
    ) -> list[str]:
        memory_limit = limit or self.config.retrieval_limit
        associative = self._associative_memories(
            query, visibility, user_id=user_id, include_private_owner=include_private_owner,
            shared_channel_id=shared_channel_id, limit=memory_limit,
            suggestion_context=suggestion_context,
        )
        if associative:
            if trace is not None:
                trace["route"] = "associative"
            return associative
        if shared_channel_id and visibility is Visibility.PUBLIC:
            if trace is not None:
                trace["route"] = "shared_channel_fallback"
            return self.retrieve_for_recall(
                query, visibility, user_id=user_id, shared_channel_id=shared_channel_id,
                limit=memory_limit, include_private_owner=include_private_owner,
            )
        if trace is not None:
            trace["route"] = "concept_episode_fallback"
        private_owner = include_private_owner and user_id == "owner"
        include_concepts = user_id in {None, "owner"}
        concept_filter = "" if visibility is Visibility.PRIVATE or private_owner else "WHERE visibility = ?"
        concept_parameters: tuple[str, ...] = (
            () if visibility is Visibility.PRIVATE or private_owner else (visibility.value,)
        )
        episode_filters: list[str] = []
        episode_parameters: list[str] = []
        if visibility is not Visibility.PRIVATE and not private_owner:
            episode_filters.append("visibility = ?")
            episode_parameters.append(visibility.value)
        if user_id:
            episode_filters.append("user_id = ?")
            episode_parameters.append(user_id)
        episode_filter = f"WHERE {' AND '.join(episode_filters)}" if episode_filters else ""
        with self._lock, self._connect() as connection:
            concepts = (
                connection.execute(
                    f"""
                    SELECT key, label, summary, strength, confidence, emotional_weight,
                           relationship_relevance, core
                    FROM concepts
                    {concept_filter}
                    ORDER BY core DESC, strength DESC, last_seen DESC
                    LIMIT 100
                    """,
                    concept_parameters,
                ).fetchall()
                if include_concepts
                else []
            )
            episodes = connection.execute(
                f"""
                SELECT id, user_id, source, visibility, user_text, mako_text,
                       importance, emotional_weight, created_at
                FROM episodes
                {episode_filter}
                ORDER BY created_at DESC LIMIT 120
                """,
                episode_parameters,
            ).fetchall()

        context_terms: set[str] = set()
        recent_texts: set[str] = set()
        if suggestion_context is not None:
            for turn in suggestion_context[-3:]:
                context_terms.update(self._terms(str(turn[0])[-600:]))
                recent_texts.add(re.sub(r"\W+", " ", str(turn[0]).lower()).strip())
        current_terms = set(self._terms(query))
        fallback_query = query
        if suggestion_context is not None and context_terms:
            fallback_query = " ".join([query, *sorted(context_terms)])

        ranked: list[tuple[float, str, str | None]] = []
        for row in concepts:
            text = f"{row['label']}: {row['summary']}"
            relevance = token_jaccard(fallback_query, text)
            score = relevance + (float(row["strength"]) * 0.12) + (float(row["core"]) * 0.15)
            grounded_enough = relevance > 0.08 if suggestion_context is not None else relevance > 0 or row["core"]
            if grounded_enough:
                ranked.append((score, text, None))

        for row in episodes:
            normalized_user_text = re.sub(r"\W+", " ", str(row["user_text"]).lower()).strip()
            if suggestion_context is not None:
                if normalized_user_text in recent_texts:
                    continue
                evidence_terms = set(self._terms(str(row["user_text"])))
                current_hits = len(evidence_terms & current_terms)
                context_hits = len(evidence_terms & context_terms)
                if not (
                    current_hits >= 2
                    or (current_hits and context_hits and len(evidence_terms & (current_terms | context_terms)) >= 2)
                    or (len(current_terms) < 2 and context_hits >= 2)
                ):
                    continue
            text = (
                f"Memory from {_local_timestamp(str(row['created_at']))}: "
                f"User: {row['user_text']}\nMako: {row['mako_text']}"
            )
            relevance = token_jaccard(fallback_query if suggestion_context is not None else query,
                                      str(row["user_text"]) if suggestion_context is not None else text)
            score = relevance + (float(row["importance"]) * 0.08)
            if relevance > 0.08:
                ranked.append((score, text, str(row["id"])))

        ordered = sorted(ranked, key=lambda item: item[0], reverse=True)
        selected = ordered[:1]
        if selected and selected[0][0] < 0.80 and memory_limit > 1 and len(ordered) > 1:
            if ordered[1][0] >= selected[0][0] * 0.72:
                selected.append(ordered[1])
        recalled_ids = [episode_id for _, _, episode_id in selected if episode_id]
        if recalled_ids:
            now = datetime.now(UTC).isoformat()
            with self._lock, self._connect() as connection:
                connection.executemany(
                    """
                    UPDATE episodes
                    SET recalled_count = recalled_count + 1, last_recalled = ?
                    WHERE id = ?
                    """,
                    [(now, episode_id) for episode_id in recalled_ids],
                )
        return [text for _, text, _ in selected]

    def public_discord_call_archive(
        self, guild_id: str, *, user_id: str | None = None, exclude_text: str = ""
    ) -> list[dict[str, str]]:
        """Read public Discord-call memories from one explicit test guild only."""
        guild_id = str(guild_id).strip()
        if not guild_id.isdigit():
            return []
        filters = [
            "source = 'discord'", "mode = 'call'", "visibility = 'public'",
            "channel_id LIKE ?",
        ]
        parameters: list[str] = [f"discord:{guild_id}:%"]
        if user_id:
            filters.append("user_id = ?")
            parameters.append(str(user_id))
        with self._lock, self._connect() as connection:
            rows = connection.execute(
                "SELECT created_at, session_id, user_id, user_text, mako_text FROM episodes WHERE "
                + " AND ".join(filters) + " ORDER BY created_at ASC",
                parameters,
            ).fetchall()
        excluded = " ".join(exclude_text.casefold().split())
        return [
            {
                "time": str(row["created_at"]),
                "session_id": str(row["session_id"]),
                "user_id": str(row["user_id"]),
                "user": str(row["user_text"] or ""),
                "stella": str(row["mako_text"] or ""),
            }
            for row in rows
            if not excluded or excluded not in " ".join(str(row["user_text"] or "").casefold().split())
        ]

    def public_discord_call_user_ids(self, guild_id: str) -> list[str]:
        """List identities present in public Discord-call memory for a single guild."""
        guild_id = str(guild_id).strip()
        if not guild_id.isdigit():
            return []
        with self._lock, self._connect() as connection:
            rows = connection.execute(
                """SELECT DISTINCT user_id FROM episodes
                   WHERE source = 'discord' AND mode = 'call' AND visibility = 'public'
                     AND channel_id LIKE ? ORDER BY user_id""",
                (f"discord:{guild_id}:%",),
            ).fetchall()
        return [str(row["user_id"]) for row in rows]

    def get_discord_memory_profile(self, guild_id: str, user_id: str) -> dict[str, str | int] | None:
        """Return the precomputed profile for one person in one Discord server."""
        with self._lock, self._connect() as connection:
            row = connection.execute(
                """SELECT guild_id, user_id, display_name, summary, source_digest,
                          source_turns, updated_at, model
                   FROM discord_memory_profiles WHERE guild_id = ? AND user_id = ?""",
                (str(guild_id), str(user_id)),
            ).fetchone()
        if row is None:
            return None
        return {key: row[key] for key in row.keys()}

    def get_discord_memory_profile_chunks(
        self, guild_id: str, user_id: str, source_digest: str
    ) -> dict[int, str]:
        with self._lock, self._connect() as connection:
            rows = connection.execute(
                """SELECT chunk_index, summary FROM discord_memory_profile_chunks
                   WHERE guild_id = ? AND user_id = ? AND source_digest = ? ORDER BY chunk_index""",
                (str(guild_id), str(user_id), str(source_digest)),
            ).fetchall()
        return {int(row["chunk_index"]): str(row["summary"]) for row in rows}

    def save_discord_memory_profile_chunk(
        self, *, guild_id: str, user_id: str, source_digest: str,
        chunk_index: int, summary: str,
    ) -> None:
        clean_summary = str(summary).strip()
        if not clean_summary:
            raise ValueError("cannot cache an empty Discord memory-profile chunk")
        with self._lock, self._connect() as connection:
            connection.execute(
                """INSERT INTO discord_memory_profile_chunks (
                       guild_id, user_id, source_digest, chunk_index, summary, updated_at
                   ) VALUES (?, ?, ?, ?, ?, ?)
                   ON CONFLICT(guild_id, user_id, source_digest, chunk_index) DO UPDATE SET
                       summary = excluded.summary, updated_at = excluded.updated_at""",
                (str(guild_id), str(user_id), str(source_digest), int(chunk_index), clean_summary,
                 datetime.now(UTC).isoformat()),
            )

    def save_discord_memory_profile(
        self,
        *,
        guild_id: str,
        user_id: str,
        display_name: str,
        summary: str,
        source_digest: str,
        source_turns: int,
        model: str = "openai/gpt-oss-120b",
    ) -> None:
        clean_summary = " ".join(str(summary).split())
        if not clean_summary:
            raise ValueError("cannot cache an empty Discord memory profile")
        with self._lock, self._connect() as connection:
            connection.execute(
                """INSERT INTO discord_memory_profiles (
                       guild_id, user_id, display_name, summary, source_digest,
                       source_turns, updated_at, model
                   ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                   ON CONFLICT(guild_id, user_id) DO UPDATE SET
                       display_name = excluded.display_name,
                       summary = excluded.summary,
                       source_digest = excluded.source_digest,
                       source_turns = excluded.source_turns,
                       updated_at = excluded.updated_at,
                       model = excluded.model""",
                (
                    str(guild_id), str(user_id), str(display_name), clean_summary,
                    str(source_digest), max(0, int(source_turns)),
                    datetime.now(UTC).isoformat(), str(model),
                ),
            )

    def retrieve_for_recall(
        self,
        query: str,
        visibility: Visibility,
        *,
        user_id: str | None,
        shared_channel_id: str | None = None,
        limit: int = 5,
        include_private_owner: bool = False,
        target_user_id: str | None = None,
    ) -> list[str]:
        """Return evidence for an explicit recall question, never guessed memories."""
        episode_filters: list[str] = []
        parameters: list[str] = []
        private_owner = include_private_owner and user_id == "owner"
        if visibility is not Visibility.PRIVATE and not private_owner:
            episode_filters.append("visibility = ?")
            parameters.append(visibility.value)
        if private_owner and shared_channel_id:
            episode_filters.append(
                "((visibility = ? AND channel_id = ?) OR (visibility = ? AND user_id = ?))"
            )
            parameters.extend(
                [visibility.value, f"discord:{shared_channel_id}:shared", Visibility.PRIVATE.value, "owner"]
            )
        elif private_owner:
            # The owner may explicitly recall the shared archive from the private
            # desktop app. Do not discard other speakers before chronology lookup.
            pass
        elif shared_channel_id:
            episode_filters.append("channel_id = ?")
            parameters.append(f"discord:{shared_channel_id}:shared")
            if target_user_id:
                episode_filters.append("user_id = ?")
                parameters.append(str(target_user_id))
        elif user_id:
            episode_filters.append("user_id = ?")
            parameters.append(user_id)
        clause = f"WHERE {' AND '.join(episode_filters)}" if episode_filters else ""
        row_limit = 1000 if private_owner else 240
        with self._lock, self._connect() as connection:
            rows = connection.execute(
                f"""
                SELECT id, user_id, source, mode, channel_id, visibility, user_text, mako_text,
                       importance, emotional_weight, created_at
                FROM episodes
                {clause}
                ORDER BY created_at DESC LIMIT ?
                """,
                [*parameters, row_limit],
            ).fetchall()
            concept_clause = "" if private_owner or visibility is Visibility.PRIVATE else "WHERE visibility = ?"
            concept_parameters = [] if concept_clause == "" else [visibility.value]
            concepts = connection.execute(
                f"""
                SELECT key, label, summary, strength, confidence, core
                FROM concepts
                {concept_clause}
                ORDER BY core DESC, strength DESC, last_seen DESC
                LIMIT 160
                """,
                concept_parameters,
            ).fetchall()

        # Concepts have no channel provenance; public-channel recall uses scoped
        # episode evidence unless the owner already has private-context access.
        if shared_channel_id and not private_owner:
            concepts = []

        asks_for_last_discord_call = bool(re.search(
            r"\b(?:last|latest|most\s+recent)\b.{0,60}\bdiscord\b.{0,60}\bcall\b"
            r"|\bdiscord\b.{0,30}\b(?:last|latest|most\s+recent)\b.{0,30}\bcall\b",
            query,
            re.IGNORECASE,
        ))
        if private_owner and asks_for_last_discord_call:
            # "Last Discord call" is a recency question, not a keyword search:
            # call words are often absent from the actual conversation itself.
            discord_rows = [
                row for row in rows
                if str(row["source"]) == "discord"
                or str(row["channel_id"]).startswith("discord:")
            ]
            if discord_rows:
                evidence_rows = discord_rows[:min(2, limit)]
                evidence = [
                    f"Memory from {_local_timestamp(str(row['created_at']))}: "
                    f"User: {row['user_text']}\nMako: {row['mako_text']}"
                    for row in evidence_rows
                ]
                now = datetime.now(UTC).isoformat()
                with self._lock, self._connect() as connection:
                    connection.executemany(
                        "UPDATE episodes SET recalled_count = recalled_count + 1, last_recalled = ? WHERE id = ?",
                        [(now, str(row["id"])) for row in evidence_rows],
                    )
                return evidence

        # "What was the last thing @person said?" is an exact chronology query,
        # not a semantic similarity search. Resolve it deterministically whenever
        # Discord supplied a concrete user mention.
        mentioned_discord_ids = re.findall(r"<@!?(\d+)>", query)
        asks_for_last_message = bool(
            re.search(r"\b(?:last\s+(?:thing|message|line)|most\s+recent)\b.{0,80}\b(?:say|said|tell|told)\b", query, re.IGNORECASE)
        )
        if mentioned_discord_ids and asks_for_last_message:
            targets = {f"discord:{discord_id}" for discord_id in mentioned_discord_ids}
            for row in rows:
                if str(row["user_id"]) not in targets:
                    continue
                evidence = (
                    f"Memory from {_local_timestamp(str(row['created_at']))}: "
                    f"User: {row['user_text']}\nMako: {row['mako_text']}"
                )
                with self._lock, self._connect() as connection:
                    connection.execute(
                        "UPDATE episodes SET recalled_count = recalled_count + 1, last_recalled = ? WHERE id = ?",
                        (datetime.now(UTC).isoformat(), str(row["id"])),
                    )
                return [evidence]

        identity_request = bool(re.search(r"\b(?:identity|alias|discord\s+(?:name|identity)|what\s+.*\bname)\b", query, re.IGNORECASE))
        if identity_request and user_id == "owner" and (visibility is Visibility.PRIVATE or include_private_owner):
            with self._lock, self._connect() as connection:
                aliases = connection.execute(
                    """SELECT alias FROM identity_aliases
                       WHERE scope = ? AND user_id = ? ORDER BY last_seen DESC LIMIT 12""",
                    ("private:owner", "owner"),
                ).fetchall()
            if aliases:
                values = ", ".join(str(row["alias"]) for row in aliases)
                return [f"Established identity memory: the owner's recorded aliases are {values}."]

        concept_query = " ".join(self._terms(query))
        concept_hits: list[tuple[float, str]] = []
        concept_query_terms = set(self._terms(query))
        for concept in concepts:
            text = f"{concept['label']}: {concept['summary']}"
            score = token_jaccard(concept_query, text)
            label_overlap = len(concept_query_terms & set(self._terms(str(concept["label"]))))
            score += label_overlap * 0.24
            if str(concept["label"]).lower() in query.lower():
                score += 0.80
            if score >= 0.18 and (label_overlap >= 2 or str(concept["label"]).lower() in query.lower()):
                concept_hits.append((score, f"Durable memory: {text}"))
        if concept_hits:
            concept_hits.sort(key=lambda item: item[0], reverse=True)
            strongest = concept_hits[0]

        associative = self._associative_memories(
            query,
            visibility,
            user_id=user_id,
            shared_channel_id=shared_channel_id,
            include_private_owner=include_private_owner,
            candidate_limit=self.config.explicit_recall_candidate_limit,
            limit=limit,
            target_user_id=target_user_id,
        )
        associative = [evidence for evidence in associative if not _is_negative_recall_evidence(evidence)]
        if associative:
            return associative
        if concept_hits and strongest[0] >= 0.30:
            # Durable concepts are a fallback. Exact episode evidence wins so a
            # broad summary cannot mask the conversation that answered the question.
            if strongest[0] >= 0.80 or len(concept_hits) == 1:
                return [strongest[1]]
            second = concept_hits[1]
            return [strongest[1], second[1]] if second[0] >= strongest[0] * 0.72 else [strongest[1]]

        query_tokens = {
            token for token in re.findall(r"[a-z0-9']+", query.lower())
            if token not in _RECALL_STOPWORDS
        }
        ordered_query_tokens = [
            token for token in re.findall(r"[a-z0-9']+", query.lower())
            if token not in _RECALL_STOPWORDS
        ]
        exact_query = " ".join(ordered_query_tokens)
        wants_yesterday = "yesterday" in query.lower()
        asks_for_app_memory = bool(re.search(r"\b(?:app|desktop|call|private)\b", query, re.IGNORECASE))
        yesterday = datetime.now().astimezone().date() - timedelta(days=1)
        ranked: list[tuple[float, str, str | None]] = []
        seen_transcripts: set[str] = set()
        for row in concepts:
            concept_text = f"{row['label']}: {row['summary']}"
            concept_lower = concept_text.lower()
            score = token_jaccard(" ".join(query_tokens), concept_text) if query_tokens else 0.0
            if len(exact_query) >= 8 and exact_query in concept_lower:
                score += 1.0
            if score > 0.08 or row["core"]:
                ranked.append(
                    (
                        score + (float(row["strength"]) * 0.1) + (float(row["core"]) * 0.15),
                        f"Durable memory: {concept_text}",
                        None,
                    )
                )
        for row in rows:
            if _is_negative_recall_evidence(str(row["mako_text"])):
                continue
            created_at = str(row["created_at"])
            transcript = f"{row['user_text']} {row['mako_text']}"
            dedupe_key = transcript.strip().lower()
            if dedupe_key in seen_transcripts:
                continue
            seen_transcripts.add(dedupe_key)
            transcript_lower = transcript.lower()
            score = token_jaccard(" ".join(query_tokens), transcript) if query_tokens else 0.0
            if len(exact_query) >= 8 and exact_query in transcript_lower:
                score += 1.0
            for index in range(len(ordered_query_tokens) - 1):
                phrase = " ".join(ordered_query_tokens[index:index + 2])
                if len(phrase) >= 6 and phrase in transcript_lower:
                    score += 0.25
            if asks_for_app_memory and str(row["visibility"]) == Visibility.PRIVATE.value:
                score += 1.0
            # In a channel recall, a mentioned person's display name is often the
            # only useful query token. Reward that direct speaker match without
            # making unrelated recent messages eligible.
            speaker_tokens = set(re.findall(r"[a-z0-9']+", str(row["user_text"]).lower()))
            if query_tokens & speaker_tokens:
                score += 0.16
            try:
                row_date = datetime.fromisoformat(created_at.replace("Z", "+00:00")).astimezone().date()
            except ValueError:
                row_date = None
            if wants_yesterday and row_date == yesterday:
                score += 1.0
            if score <= 0.08 and not (wants_yesterday and row_date == yesterday):
                continue
            evidence = (
                f"Memory from {_local_timestamp(created_at)}: "
                f"User: {row['user_text']}\nMako: {row['mako_text']}"
            )
            ranked.append((score + (float(row["importance"]) * 0.05), evidence, str(row["id"])))

        # A broad "do you remember anything" question should receive recent real
        # evidence rather than inviting the model to invent a detail.
        broad_recall = bool(re.search(r"\bremember\s+anything\b", query, re.IGNORECASE))
        if not ranked and (not query_tokens or broad_recall):
            for row in rows[:limit]:
                created_at = str(row["created_at"])
                evidence = (
                    f"Memory from {_local_timestamp(created_at)}: "
                    f"User: {row['user_text']}\nMako: {row['mako_text']}"
                )
                ranked.append((0.01, evidence, str(row["id"])))

        ordered = sorted(ranked, key=lambda item: item[0], reverse=True)
        selected = ordered[:1]
        if selected and selected[0][0] < 1.0 and limit > 1 and len(ordered) > 1:
            if ordered[1][0] >= selected[0][0] * 0.72:
                selected.append(ordered[1])
        if selected:
            now = datetime.now(UTC).isoformat()
            with self._lock, self._connect() as connection:
                connection.executemany(
                    "UPDATE episodes SET recalled_count = recalled_count + 1, last_recalled = ? WHERE id = ?",
                    [(now, episode_id) for _, _, episode_id in selected],
                )
        return [evidence for _, evidence, _ in selected]

    def consolidate(
        self,
        backend: ModelBackend,
        batch_size: int | None = None,
    ) -> ConsolidationResult:
        size = batch_size or self.config.consolidation_batch_size
        with self._lock, self._connect() as connection:
            first = connection.execute(
                """
                SELECT visibility FROM episodes
                WHERE consolidated = 0
                ORDER BY created_at ASC LIMIT 1
                """
            ).fetchone()
            if not first:
                return ConsolidationResult()
            visibility_value = str(first["visibility"])
            rows = connection.execute(
                """
                SELECT id, created_at, source, mode, user_text, mako_text,
                       emotional_weight, importance
                FROM episodes
                WHERE consolidated = 0 AND visibility = ?
                ORDER BY created_at ASC LIMIT ?
                """,
                (visibility_value, size),
            ).fetchall()
        if not rows:
            return ConsolidationResult()

        schema = {
            "memories": [
                {
                    "label": "short stable label",
                    "summary": "what happened or what may be true",
                    "topics": ["specific topic"],
                    "importance": 0.0,
                    "emotional_weight": 0.0,
                    "relationship_relevance": 0.0,
                    "confidence": 0.0,
                }
            ],
            "relationship_delta": {
                "familiarity": 0.0,
                "trust": 0.0,
                "affection": 0.0,
                "attraction": 0.0,
                "friction": 0.0,
            },
        }
        prompt = (
            "Consolidate these recent episodes. Return the exact JSON shape shown.\n\n"
            f"Schema:\n{json.dumps(schema, indent=2)}\n\n"
            f"Episodes:\n{json.dumps([dict(row) for row in rows], indent=2)}"
        )
        try:
            generation = backend.generate(
                system=CONSOLIDATION_SYSTEM,
                prompt=prompt,
                temperature=0.25,
                max_tokens=700,
                json_output=True,
            )
            data = _json_object(generation.text)
        except (ModelError, ValueError, TypeError, json.JSONDecodeError):
            return ConsolidationResult()

        memories = data.get("memories", [])
        now = datetime.now(UTC).isoformat()
        with self._lock, self._connect() as connection:
            for memory in memories:
                if not isinstance(memory, dict):
                    continue
                label = str(memory.get("label", "")).strip()
                summary = str(memory.get("summary", "")).strip()
                if not label or not summary:
                    continue
                slug = re.sub(r"[^a-z0-9]+", "_", label.lower()).strip("_")
                if not slug:
                    continue
                key = f"{visibility_value}:{slug}"
                existing = connection.execute(
                    "SELECT * FROM concepts WHERE key = ?",
                    (key,),
                ).fetchone()
                importance = max(0.0, min(1.0, float(memory.get("importance", 0.2))))
                confidence = max(0.0, min(1.0, float(memory.get("confidence", 0.35))))
                topics = memory.get("topics", [])
                if existing:
                    connection.execute(
                        """
                        UPDATE concepts SET summary = ?, topics_json = ?,
                            strength = ?, confidence = ?, recurrence = recurrence + 1,
                            emotional_weight = ?, relationship_relevance = ?, last_seen = ?
                        WHERE key = ?
                        """,
                        (
                            summary,
                            json.dumps(topics),
                            min(1.0, float(existing["strength"]) + (importance * 0.12)),
                            max(float(existing["confidence"]), confidence),
                            max(0.0, min(1.0, float(memory.get("emotional_weight", 0.0)))),
                            max(0.0, min(1.0, float(memory.get("relationship_relevance", 0.0)))),
                            now,
                            key,
                        ),
                    )
                else:
                    connection.execute(
                        """
                        INSERT INTO concepts (
                            key, label, summary, topics_json, visibility, strength, confidence,
                            recurrence, emotional_weight, relationship_relevance, last_seen
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)
                        """,
                        (
                            key,
                            label,
                            summary,
                            json.dumps(topics),
                            visibility_value,
                            importance,
                            confidence,
                            max(0.0, min(1.0, float(memory.get("emotional_weight", 0.0)))),
                            max(0.0, min(1.0, float(memory.get("relationship_relevance", 0.0)))),
                            now,
                        ),
                    )
            connection.executemany(
                "UPDATE episodes SET consolidated = 1 WHERE id = ?",
                [(row["id"],) for row in rows],
            )
        relationship_delta: dict[str, float] = {}
        raw_relationship = data.get("relationship_delta", {})
        if isinstance(raw_relationship, dict) and visibility_value == Visibility.PRIVATE.value:
            for name in ("familiarity", "trust", "affection", "attraction", "friction"):
                try:
                    relationship_delta[name] = max(
                        -0.03,
                        min(0.03, float(raw_relationship.get(name, 0.0))),
                    )
                except (TypeError, ValueError):
                    continue
        return ConsolidationResult(len(rows), relationship_delta)

    def pending_episode_count(self) -> int:
        with self._lock, self._connect() as connection:
            return int(
                connection.execute(
                    "SELECT COUNT(*) FROM episodes WHERE consolidated = 0"
                ).fetchone()[0]
            )

    def run_memory_cycle(self) -> dict[str, int]:
        with self._lock, self._connect() as connection:
            rows = connection.execute(
                """
                SELECT key, strength, confidence, recurrence, core, protection_cycles
                FROM concepts
                ORDER BY core DESC, strength DESC, last_seen DESC
                """
            ).fetchall()
            promoted = 0
            for row in rows:
                key = str(row["key"])
                strength = float(row["strength"])
                confidence = float(row["confidence"])
                recurrence = int(row["recurrence"])
                core = bool(row["core"])
                protection = max(0, int(row["protection_cycles"]) - 1)
                if (
                    not core
                    and recurrence >= self.config.core_min_recurrence
                    and strength >= self.config.core_min_strength
                    and confidence >= self.config.core_min_confidence
                ):
                    core = True
                    protection = 2
                    promoted += 1
                if not core and protection == 0:
                    strength *= 0.94
                    confidence *= 0.98
                connection.execute(
                    """
                    UPDATE concepts
                    SET strength = ?, confidence = ?, core = ?, protection_cycles = ?
                    WHERE key = ?
                    """,
                    (strength, confidence, int(core), protection, key),
                )

            removed_weak = connection.execute(
                """
                DELETE FROM concepts
                WHERE core = 0 AND protection_cycles = 0
                  AND strength < 0.12 AND confidence < 0.22
                """
            ).rowcount
            removed_overflow = connection.execute(
                """
                DELETE FROM concepts
                WHERE key IN (
                    SELECT key FROM concepts WHERE core = 0
                    ORDER BY strength DESC, confidence DESC, last_seen DESC
                    LIMIT -1 OFFSET ?
                )
                """,
                (self.config.max_concepts,),
            ).rowcount
            meaningful_sessions = int(
                connection.execute(
                    "SELECT COUNT(*) FROM sessions WHERE meaningful = 1"
                ).fetchone()[0]
            )
            connection.execute(
                """
                INSERT INTO metadata (key, value) VALUES ('last_memory_cycle_sessions', ?)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value
                """,
                (str(meaningful_sessions),),
            )
        return {
            "promoted": promoted,
            "removed": max(0, removed_weak) + max(0, removed_overflow),
        }

    def memory_cycle_due(self) -> bool:
        with self._lock, self._connect() as connection:
            meaningful_sessions = int(
                connection.execute(
                    "SELECT COUNT(*) FROM sessions WHERE meaningful = 1"
                ).fetchone()[0]
            )
            row = connection.execute(
                "SELECT value FROM metadata WHERE key = 'last_memory_cycle_sessions'"
            ).fetchone()
        last_cycle = int(row["value"]) if row else 0
        return meaningful_sessions - last_cycle >= self.config.major_cycle_sessions

    def stats(self) -> dict[str, int]:
        with self._lock, self._connect() as connection:
            return {
                "sessions": int(connection.execute("SELECT COUNT(*) FROM sessions").fetchone()[0]),
                "episodes": int(connection.execute("SELECT COUNT(*) FROM episodes").fetchone()[0]),
                "concepts": int(connection.execute("SELECT COUNT(*) FROM concepts").fetchone()[0]),
                "core_memories": int(
                    connection.execute("SELECT COUNT(*) FROM concepts WHERE core = 1").fetchone()[0]
                ),
                "pending": int(
                    connection.execute(
                        "SELECT COUNT(*) FROM episodes WHERE consolidated = 0"
                    ).fetchone()[0]
                ),
            }
