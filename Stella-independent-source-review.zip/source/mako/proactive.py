from __future__ import annotations

import json
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from .config import ProactiveCallConfig


@dataclass(slots=True)
class ProactiveCallState:
    last_considered_at: float = 0.0
    last_offered_at: float = 0.0


class ProactiveCallPolicy:
    def __init__(self, config: ProactiveCallConfig, state_path: Path) -> None:
        self.config = config
        self.state_path = state_path
        self.state = self._load()

    def can_consider(
        self,
        idle_seconds: float,
        *,
        now: float | None = None,
        local_hour: int | None = None,
    ) -> bool:
        if not self.config.enabled or idle_seconds < self.config.minimum_idle_seconds:
            return False
        timestamp = time.time() if now is None else now
        hour = datetime.now().hour if local_hour is None else local_hour
        if self._is_quiet_hour(hour):
            return False
        if timestamp - self.state.last_considered_at < self.config.decision_cooldown_seconds:
            return False
        if timestamp - self.state.last_offered_at < self.config.offer_cooldown_seconds:
            return False
        return True

    def mark_considered(self, *, now: float | None = None) -> None:
        self.state.last_considered_at = time.time() if now is None else now
        self._save()

    def mark_offered(self, *, now: float | None = None) -> None:
        timestamp = time.time() if now is None else now
        self.state.last_considered_at = timestamp
        self.state.last_offered_at = timestamp
        self._save()

    def _is_quiet_hour(self, hour: int) -> bool:
        start = self.config.quiet_hours_start % 24
        end = self.config.quiet_hours_end % 24
        if start == end:
            return False
        if start < end:
            return start <= hour < end
        return hour >= start or hour < end

    def _load(self) -> ProactiveCallState:
        if not self.state_path.exists():
            return ProactiveCallState()
        try:
            raw = json.loads(self.state_path.read_text(encoding="utf-8"))
            return ProactiveCallState(
                last_considered_at=float(raw.get("last_considered_at", 0.0)),
                last_offered_at=float(raw.get("last_offered_at", 0.0)),
            )
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            return ProactiveCallState()

    def _save(self) -> None:
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.state_path.with_suffix(".tmp")
        temporary.write_text(
            json.dumps(
                {
                    "last_considered_at": self.state.last_considered_at,
                    "last_offered_at": self.state.last_offered_at,
                },
                indent=2,
            ),
            encoding="utf-8",
        )
        temporary.replace(self.state_path)
