"""Cartesia Sonic streaming PCM transport. No microphone or local key storage."""
from __future__ import annotations

import asyncio
import logging
import os
import queue
import time

import aiohttp

PCM_RATE = 24000
LOG = logging.getLogger(__name__)


def cartesia_key(config):
    name = config.cartesia_api_key_environment_variable
    key = os.getenv(name, "").strip()
    if not key and os.name == "nt":
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as registry:
                key = str(winreg.QueryValueEx(registry, name)[0]).strip()
        except OSError:
            pass
    if not key:
        raise ValueError(f"Cartesia needs {name} in your Windows user environment")
    return key


def speech_payload(config, text):
    if not config.cartesia_tts_voice.strip():
        raise ValueError("Choose a Cartesia voice ID")
    return {
        "model_id": config.cartesia_tts_model,
        "transcript": text,
        "voice": config.cartesia_tts_voice.strip(),
        "language": config.cartesia_tts_language,
        "output_format": {"container": "raw", "encoding": "pcm_s16le", "sample_rate": PCM_RATE},
    }


async def stream_dialogue(config, chunks, *, cancelled=lambda: False, on_alignment=None):
    """Accept complete text or incremental clauses; preserve order and PCM boundaries."""
    if cancelled():
        return
    headers = {"Authorization": "Bearer " + cartesia_key(config), "Cartesia-Version": "2026-10-17"}
    timeout = aiohttp.ClientTimeout(total=None, sock_connect=10, sock_read=30)
    async with aiohttp.ClientSession(headers=headers, timeout=timeout) as session:
        waiting_since = time.monotonic()
        while not cancelled():
            try:
                text = chunks.get_nowait()
            except queue.Empty:
                if time.monotonic() - waiting_since > 45:
                    raise TimeoutError("Cartesia input did not finish")
                await asyncio.sleep(.01)
                continue
            if text is None:
                return
            if not text.strip():
                continue
            started = time.monotonic()
            async with session.post("https://api.cartesia.ai/tts/bytes", json=speech_payload(config, text)) as response:
                if response.status != 200:
                    # Do not log credentials, transcripts, or echoed request bodies.
                    raise RuntimeError(f"Cartesia TTS HTTP {response.status}; check voice, model, key and quota")
                tail = b""
                received = False
                iterator = response.content.iter_chunked(960).__aiter__()
                pending = asyncio.create_task(iterator.__anext__())
                try:
                    while not cancelled():
                        done, _ = await asyncio.wait((pending,), timeout=.05)
                        if not done:
                            continue
                        try:
                            block = pending.result()
                        except StopAsyncIteration:
                            break
                        pending = asyncio.create_task(iterator.__anext__())
                        pcm = tail + block
                        size = len(pcm) - len(pcm) % 2
                        tail = pcm[size:]
                        if size:
                            if not received:
                                LOG.info("Cartesia first_pcm_seconds=%.3f model=%s", time.monotonic() - started, config.cartesia_tts_model)
                            received = True
                            yield pcm[:size]
                finally:
                    pending.cancel()
                    await asyncio.gather(pending, return_exceptions=True)
                if cancelled():
                    return
                if not received or tail:
                    raise RuntimeError("Cartesia returned empty or incomplete PCM")
            waiting_since = time.monotonic()
