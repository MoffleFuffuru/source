from __future__ import annotations

import threading


# PortAudio can deadlock on Windows when stream startup and a separate playback
# warmup enter the library concurrently from different threads.
SOUNDDEVICE_START_LOCK = threading.RLock()
