from __future__ import annotations

import asyncio
import importlib.util
import json
import logging
import os
import queue
import re
import threading
import time
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Callable
from urllib.parse import urlencode

from .config import VoiceConfig


LOG = logging.getLogger(__name__)

_KOKORO_PIPELINES: dict[str, object] = {}
_KOKORO_PIPELINE_LOCK = threading.RLock()


class VoiceUnavailable(RuntimeError):
    pass


def inworld_expressive_text(
    text: str,
    *,
    vocal_cue: str = "none",
    delivery: str = "neutral",
) -> str:
    """Translate validated model acting fields into native Realtime TTS-2 tags."""
    cue_tags = {
        "laugh": "[laugh]",
        "soft_laugh": "[laugh]",
        "sigh": "[sigh]",
        "hmm": "[hmm]",
        "breath": "[breath]",
    }
    delivery_tags = {
        "soft": "[Speak softly]",
        "whisper": "[whisper]",
        "excited": "[excited]",
    }
    tags = [delivery_tags.get(delivery, ""), cue_tags.get(vocal_cue, "")]
    prefix = " ".join(tag for tag in tags if tag)
    return f"{prefix} {text}".strip()


@dataclass(frozen=True, slots=True)
class VoiceCapabilities:
    microphone: bool
    faster_whisper: bool
    moonshine: bool
    kyutai: bool
    parakeet: bool
    deepgram_flux: bool
    inworld_tts: bool
    inworld_stt: bool
    qwen_tts: bool
    kokoro: bool
    pyttsx3: bool

    @property
    def can_listen(self) -> bool:
        return self.microphone and (
            self.faster_whisper
            or self.moonshine
            or self.kyutai
            or self.parakeet
            or self.inworld_stt
        )

    @property
    def can_speak(self) -> bool:
        return self.deepgram_flux or self.inworld_tts or self.qwen_tts or self.kokoro or self.pyttsx3


@dataclass(frozen=True, slots=True)
class CompletedTurn:
    """Raw endpointed audio used for the one authoritative call transcript."""

    samples: object
    endpointed_at: float


def detect_voice_capabilities() -> VoiceCapabilities:
    available = importlib.util.find_spec
    microphone = all(available(name) is not None for name in ("sounddevice", "soundfile", "numpy"))
    return VoiceCapabilities(
        microphone=microphone,
        faster_whisper=available("faster_whisper") is not None,
        moonshine=available("moonshine_voice") is not None,
        kyutai=all(available(name) is not None for name in ("aiohttp", "msgpack")),
        parakeet=microphone,
        deepgram_flux=available("aiohttp") is not None,
        inworld_tts=available("aiohttp") is not None,
        inworld_stt=available("aiohttp") is not None,
        qwen_tts=available("qwen_tts") is not None,
        kokoro=available("kokoro") is not None,
        pyttsx3=available("pyttsx3") is not None,
    )


class SpeechEndpoint:
    """Adaptive scalar audio gate used by the real-time microphone callback."""

    def __init__(self, config: VoiceConfig, *, silence_seconds: float | None = None) -> None:
        self.config = config
        self.silence_seconds = (
            config.silence_seconds if silence_seconds is None else silence_seconds
        )
        self.noise_floor = 0.0
        self.recording = False
        self._calibration_started_at: float | None = None
        self._calibrated = False
        self._activation_started_at: float | None = None
        self._continuation_started_at: float | None = None
        self._recording_started_at = 0.0
        self._last_voice_at = 0.0

    @property
    def threshold(self) -> float:
        adaptive = self.noise_floor * self.config.noise_floor_multiplier
        return max(self.config.speech_threshold, adaptive)

    def reset(self) -> None:
        self.noise_floor = 0.0
        self.recording = False
        self._calibration_started_at = None
        self._calibrated = False
        self._activation_started_at = None
        self._continuation_started_at = None
        self._recording_started_at = 0.0
        self._last_voice_at = 0.0

    def pause(self) -> None:
        self._activation_started_at = None
        self._continuation_started_at = None

    def process(self, level: float, now: float) -> str:
        level = max(0.0, float(level))
        if self._calibration_started_at is None:
            self._calibration_started_at = now

        if not self._calibrated:
            self._update_noise_floor(level, weight=0.16)
            if now - self._calibration_started_at < self.config.noise_calibration_seconds:
                return "calibrating"
            self._calibrated = True
            return "calibrated"

        threshold = self.threshold
        if self.recording:
            release_threshold = threshold * self.config.speech_release_multiplier
            if level >= release_threshold:
                if self._continuation_started_at is None:
                    self._continuation_started_at = now
                elif (
                    now - self._continuation_started_at
                    >= self.config.speech_hold_seconds
                ):
                    self._last_voice_at = now
            else:
                self._continuation_started_at = None
            maximum_reached = (
                now - self._recording_started_at
                >= self.config.maximum_utterance_seconds
            )
            silence_reached = now - self._last_voice_at >= self.silence_seconds
            if maximum_reached or silence_reached:
                spoken_for = self._last_voice_at - self._recording_started_at
                self.recording = False
                self._activation_started_at = None
                self._continuation_started_at = None
                return "finish" if spoken_for >= self.config.minimum_speech_seconds else "discard"
            return "recording"

        if level < threshold:
            self._activation_started_at = None
            self._update_noise_floor(level, weight=0.035)
            return "idle"

        if self._activation_started_at is None:
            self._activation_started_at = now
            return "activating"
        if now - self._activation_started_at < self.config.speech_start_seconds:
            return "activating"

        self.recording = True
        self._recording_started_at = self._activation_started_at
        self._last_voice_at = now
        self._continuation_started_at = now
        return "start"

    def _update_noise_floor(self, level: float, *, weight: float) -> None:
        if self.noise_floor <= 0.0:
            self.noise_floor = level
        else:
            self.noise_floor = ((1.0 - weight) * self.noise_floor) + (weight * level)


class CallReflexes:
    _presence_pattern = re.compile(
        r"^\s*(you there|are you there|hello|hello there|mako|can you hear me|still there)[?.!\s]*$",
        flags=re.IGNORECASE,
    )

    def __init__(self) -> None:
        self._index = 0

    def is_presence_check(self, text: str) -> bool:
        return bool(self._presence_pattern.match(text))

    def presence_response(self, mood_summary: str) -> str:
        if "irritation high" in mood_summary:
            options = ("yeah. thinking.", "still here. give me a second.")
        elif "warmth high" in mood_summary or "affection high" in mood_summary:
            options = ("mhm, i'm here. just thinking.", "yeah, still with you.")
        else:
            options = ("yeah, i'm just thinking.", "mhm. still here.", "one second, i'm thinking.")
        response = options[self._index % len(options)]
        self._index += 1
        return response


class TranscriptAssembler:
    """Merges overlapping Whisper windows without repeating their shared words."""

    def __init__(self) -> None:
        self._tokens: list[str] = []

    def __bool__(self) -> bool:
        return bool(self._tokens)

    @property
    def word_count(self) -> int:
        return len(self._tokens)

    def add(self, text: str) -> bool:
        incoming = text.strip().split()
        if not incoming:
            return False
        if not self._tokens:
            self._tokens.extend(incoming)
            return True

        existing_keys = [self._token_key(token) for token in self._tokens]
        incoming_keys = [self._token_key(token) for token in incoming]
        overlap_limit = min(10, len(existing_keys), len(incoming_keys))
        overlap = 0
        for size in range(overlap_limit, 0, -1):
            if existing_keys[-size:] == incoming_keys[:size]:
                overlap = size
                break

        additions = incoming[overlap:]
        if not additions:
            return False
        self._tokens.extend(additions)
        return True

    def pop(self) -> str:
        text = " ".join(self._tokens).strip()
        self._tokens.clear()
        return re.sub(r"\s+([,.!?;:])", r"\1", text)

    @staticmethod
    def _token_key(token: str) -> str:
        return re.sub(r"[^a-z0-9']+", "", token.lower().replace("’", "'"))


class LiveKitTurnDetectorBridge:
    """Runs LiveKit's local v1-mini detector on a private asyncio loop."""

    def __init__(
        self,
        sample_rate: int,
        on_prediction: Callable[[bool, float], None],
    ) -> None:
        self.sample_rate = sample_rate
        self.on_prediction = on_prediction
        self._loop = asyncio.new_event_loop()
        self._ready = threading.Event()
        self._stream = None
        self._closed = False
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        if not self._ready.wait(timeout=10):
            raise VoiceUnavailable("LiveKit turn detector did not initialize.")

    def _run(self) -> None:
        asyncio.set_event_loop(self._loop)

        async def initialize() -> None:
            from livekit.agents.inference import TurnDetector

            detector = TurnDetector(version="v1-mini", sample_rate=self.sample_rate)
            self._stream = detector.stream()

        try:
            self._loop.run_until_complete(initialize())
        finally:
            self._ready.set()
        self._loop.run_forever()
        if self._stream is not None:
            self._loop.run_until_complete(self._stream.aclose())
        self._loop.close()

    def push_audio(self, samples: object) -> None:
        if self._closed or self._stream is None:
            return
        import numpy as np
        from livekit import rtc

        pcm = np.clip(np.asarray(samples).reshape(-1), -1.0, 1.0)
        pcm = (pcm * 32767.0).astype(np.int16, copy=False)
        frame = rtc.AudioFrame(
            pcm.tobytes(),
            sample_rate=self.sample_rate,
            num_channels=1,
            samples_per_channel=len(pcm),
        )
        self._loop.call_soon_threadsafe(self._stream.push_audio, frame)

    def predict(self) -> None:
        if self._closed or self._stream is None:
            return

        async def run_prediction() -> None:
            try:
                from livekit.agents.language import LanguageCode

                event = await self._stream.predict()
                probability = float(event.end_of_turn_probability)
                threshold = await self._stream.unlikely_threshold(LanguageCode("en"))
                if threshold is None:
                    threshold = 0.5
                self.on_prediction(probability >= threshold, probability)
            except Exception as exc:
                LOG.warning("LiveKit turn prediction failed: %s", exc)

        asyncio.run_coroutine_threadsafe(run_prediction(), self._loop)

    def cancel_prediction(self) -> None:
        if not self._closed and self._stream is not None:
            self._loop.call_soon_threadsafe(self._stream.cancel_inference)

    def flush(self) -> None:
        if not self._closed and self._stream is not None:
            self._loop.call_soon_threadsafe(self._stream.flush, "turn committed")

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._loop.call_soon_threadsafe(self._loop.stop)
        self._thread.join(timeout=5)


class VoiceEngine:
    def __init__(
        self,
        config: VoiceConfig,
        temporary_directory: Path,
        on_playback_level: Callable[[float], None] | None = None,
    ) -> None:
        self.config = config
        self.temporary_directory = temporary_directory
        self.capabilities = detect_voice_capabilities()
        self._running = threading.Event()
        self._speaking = threading.Event()
        self._audio_queue: queue.Queue[object | None] = queue.Queue()
        self._stream = None
        self._transcriber = None
        self._moonshine_mic = None
        self._kyutai_client = None
        self._kyutai_server = None
        self._inworld_stt_client = None
        self._elevenlabs_stt_client = None
        self._speech_generation = 0
        self._parakeet_client = None
        self._tts_engine = None
        self._kokoro_pipeline = None
        self._qwen_tts_model = None
        self._qwen_warm_thread: threading.Thread | None = None
        self._deepgram_flux_loop: asyncio.AbstractEventLoop | None = None
        self._deepgram_flux_thread: threading.Thread | None = None
        self._deepgram_flux_ready = threading.Event()
        self._deepgram_flux_session = None
        self._deepgram_flux_websocket = None
        self._deepgram_flux_lock = threading.RLock()
        self._utterance_callback: Callable[[str], None] | None = None
        self._partial_callback: Callable[[str], None] | None = None
        self._semantic_eot_callback: Callable[[str], None] | None = None
        self._voice_profile_callback: Callable[[str], None] | None = None
        self._status_callback: Callable[[str], None] | None = None
        self._playback_level_callback = on_playback_level
        self._tts_lock = threading.RLock()
        self._speech_prepare_lock = threading.Lock()
        self._speech_prepared = False
        self._speech_serial = threading.Lock()
        self._microphone_resume_at = 0.0
        self._capture_sample_rate = config.sample_rate
        self._endpoint = SpeechEndpoint(config)
        self._capture_lock = threading.Lock()
        self._pre_roll_chunks = deque()
        self._turn_chunks: list[object] = []
        self._capturing_turn = False
        self._authoritative_turn_active = threading.Event()
        self._livekit_turn_detector: LiveKitTurnDetectorBridge | None = None
        self._livekit_endpoint = SpeechEndpoint(
            config,
            silence_seconds=config.livekit_probe_silence_seconds,
        )
        self._moonshine_partial = ""
        self._moonshine_final = ""
        self._moonshine_turn_committed = False
        self._moonshine_text_lock = threading.Lock()
        self._livekit_failsafe_timer: threading.Timer | None = None
        self._livekit_transcript_timer: threading.Timer | None = None
        self._livekit_commit_pending = False
        self._affect_monitor = None

    def start_affect_monitor(self) -> None:
        if self._affect_monitor is not None:
            self._affect_monitor.start()
            return
        from .affect import LiveAffectAnalyzer
        self._affect_monitor = LiveAffectAnalyzer(
            self.temporary_directory.parent / "hf-cache",
            enabled=self.config.live_affect_enabled,
            experimental=self.config.live_affect_experimental_enabled,
            window_seconds=self.config.live_affect_window_seconds,
        )
        self._affect_monitor.start()

    def affect_audio(self, samples: object, sample_rate: int, speaker_id: str = "owner") -> None:
        if self._affect_monitor is not None:
            self._affect_monitor.push_audio(speaker_id, samples, sample_rate)

    def set_affect_partial_text(self, speaker_id: str, text: str) -> None:
        if self._affect_monitor is not None:
            self._affect_monitor.set_partial_text(speaker_id, text)

    def affect_snapshot(self, speaker_id: str = "owner"):
        if self._affect_monitor is None:
            from .affect import AffectState
            return AffectState()
        return self._affect_monitor.snapshot(speaker_id)

    def start(
        self,
        on_utterance: Callable[[str], None],
        on_status: Callable[[str], None],
    ) -> None:
        if not self.config.input_enabled:
            raise VoiceUnavailable("Microphone listening is disabled in text-only mode.")
        if self._running.is_set():
            return
        backend = self.config.stt_backend.lower()
        if backend == "elevenlabs_stt":
            self._start_elevenlabs_stt(on_utterance, on_status)
            return
        if backend == "inworld_stt":
            if not self.capabilities.microphone or not self.capabilities.inworld_stt:
                raise VoiceUnavailable("Inworld STT calls need sounddevice, numpy, and aiohttp.")
            self._start_inworld_stt(on_utterance, on_status)
            return
        if backend == "kyutai":
            if not self.capabilities.microphone or not self.capabilities.kyutai:
                raise VoiceUnavailable(
                    "Kyutai calls need sounddevice, numpy, aiohttp, and msgpack."
                )
            self._start_kyutai(on_utterance, on_status)
            return
        if backend == "parakeet":
            if not self.capabilities.microphone:
                raise VoiceUnavailable("Parakeet calls need sounddevice and numpy.")
            self._start_parakeet(on_utterance, on_status)
            return
        if backend == "moonshine":
            if not self.capabilities.microphone or not self.capabilities.moonshine:
                raise VoiceUnavailable("Moonshine calls need sounddevice, numpy, and moonshine-voice.")
            self._start_moonshine(on_utterance, on_status)
            return
        if not self.capabilities.microphone or not self.capabilities.faster_whisper:
            raise VoiceUnavailable(
                "Live calls need sounddevice, soundfile, numpy, and faster-whisper."
            )

        import sounddevice as sd
        from faster_whisper import WhisperModel

        self._utterance_callback = on_utterance
        self._status_callback = on_status
        self._endpoint.reset()
        with self._capture_lock:
            self._pre_roll_chunks.clear()
            self._turn_chunks.clear()
            self._capturing_turn = False
        self._authoritative_turn_active.clear()
        self._emit_status("loading voice")
        if self._transcriber is None:
            self._transcriber = WhisperModel(
                self.config.whisper_model,
                device="cpu",
                compute_type="int8",
            )
        queue_capacity = max(
            32,
            round(6000 / max(10, self.config.block_milliseconds)),
        )
        self._audio_queue = queue.Queue(maxsize=queue_capacity)
        self._running.set()
        threading.Thread(target=self._transcription_loop, daemon=True).start()
        # Load Kokoro while the call connects, not after Mako has an answer to say.
        threading.Thread(target=self._prewarm_speech, daemon=True).start()
        device_info = sd.query_devices(self.config.input_device, "input")
        native_rate = int(round(float(device_info["default_samplerate"])))
        self._capture_sample_rate = native_rate if native_rate > 0 else self.config.sample_rate
        blocksize = max(
            160,
            int(self._capture_sample_rate * (self.config.block_milliseconds / 1000.0)),
        )
        self._stream = sd.InputStream(
            callback=self._audio_callback,
            channels=1,
            device=self.config.input_device,
            samplerate=self._capture_sample_rate,
            blocksize=blocksize,
            dtype="float32",
        )
        self._stream.start()
        self._emit_status("call connected")

    def set_partial_transcript_callback(
        self, callback: Callable[[str], None] | None
    ) -> None:
        """Receive Moonshine's continuously revised in-progress line."""
        self._partial_callback = callback

    def set_semantic_eot_callback(
        self, callback: Callable[[str], None] | None
    ) -> None:
        """Receive Kyutai's provisional text exactly when semantic EOT fires."""
        self._semantic_eot_callback = callback

    def set_voice_profile_callback(
        self, callback: Callable[[str], None] | None
    ) -> None:
        """Receive confidence-filtered paralinguistic evidence for the current turn."""
        self._voice_profile_callback = callback

    def _start_elevenlabs_stt(self, on_utterance, on_status) -> None:
        from .elevenlabs_voice import ScribeSTTClient

        self._utterance_callback = on_utterance
        self._status_callback = on_status
        def status(value):
            self._emit_status(value)
            if value.startswith("voice error:"):
                self._running.clear()
        client = ScribeSTTClient(
            self.config,
            on_utterance=lambda text: on_utterance(text) if self._running.is_set() else None,
            on_partial=lambda text: self._partial_callback(text)
            if self._partial_callback and self._running.is_set() else None,
            on_voice_profile=lambda text: self._voice_profile_callback(text)
            if self._voice_profile_callback and self._running.is_set() else None,
            on_status=status,
        )
        self._running.set()
        self._elevenlabs_stt_client = client
        try:
            client.start()
        except Exception as exc:
            client.stop()
            self._elevenlabs_stt_client = None
            self._running.clear()
            if self.config.elevenlabs_stt_fallback == "inworld_stt":
                self._emit_status("Scribe unavailable; using configured Inworld STT fallback")
                self._start_inworld_stt(on_utterance, on_status)
                return
            raise VoiceUnavailable(str(exc)) from exc
        threading.Thread(target=self._prewarm_speech, daemon=True).start()

    def _start_inworld_stt(
        self,
        on_utterance: Callable[[str], None],
        on_status: Callable[[str], None],
    ) -> None:
        from .inworld_stt import InworldSTTClient, InworldSTTError

        self._utterance_callback = on_utterance
        self._status_callback = on_status
        self._emit_status("connecting Inworld STT")
        def on_inworld_status(status: str) -> None:
            self._emit_status(status)
            # Inworld closes idle streams server-side. Do not leave the engine
            # marked running after that, or the next call becomes a no-op.
            if status.startswith("voice error: Inworld STT disconnected:"):
                self._running.clear()
                self._inworld_stt_client = None

        client = InworldSTTClient(
            api_key_environment_variable=self.config.inworld_stt_api_key_environment_variable,
            input_device=self.config.input_device,
            language=self.config.language,
            profile_threshold=self.config.inworld_stt_profile_threshold,
            eot_confidence_threshold=self.config.inworld_stt_eot_confidence_threshold,
            min_eot_silence_ms=self.config.inworld_stt_min_eot_silence_ms,
            max_turn_silence_ms=self.config.inworld_stt_max_turn_silence_ms,
            on_utterance=lambda text: self._utterance_callback(self._normalize_name(text))
            if self._utterance_callback and self._running.is_set()
            else None,
            on_partial=lambda text: self._partial_callback(self._normalize_name(text))
            if self._partial_callback and self._running.is_set()
            else None,
            on_voice_profile=lambda summary: self._voice_profile_callback(summary)
            if self._voice_profile_callback and self._running.is_set()
            else None,
            on_audio=lambda samples, rate: self.affect_audio(samples, rate),
            on_status=on_inworld_status,
        )
        self._running.set()
        try:
            client.start()
        except InworldSTTError as exc:
            self._running.clear()
            raise VoiceUnavailable(str(exc)) from exc
        self._inworld_stt_client = client
        threading.Thread(target=self._prewarm_speech, daemon=True).start()

    def _start_kyutai(
        self,
        on_utterance: Callable[[str], None],
        on_status: Callable[[str], None],
    ) -> None:
        from .kyutai_stt import KyutaiServerProcess, KyutaiSTTClient, KyutaiSTTError

        self._utterance_callback = on_utterance
        self._status_callback = on_status
        self._emit_status("connecting Kyutai STT")
        if self._kyutai_server is None:
            root_directory = self.temporary_directory.parent.parent
            self._kyutai_server = KyutaiServerProcess(
                root_directory=root_directory,
                server_url=self.config.kyutai_server_url,
                startup_timeout_seconds=self.config.kyutai_worker_startup_timeout_seconds,
                on_status=self._emit_status,
            )
        try:
            self._kyutai_server.start()
        except KyutaiSTTError as exc:
            raise VoiceUnavailable(str(exc)) from exc
        client = KyutaiSTTClient(
            server_url=self.config.kyutai_server_url,
            api_key=self.config.kyutai_api_key,
            input_device=self.config.input_device,
            vad_head_index=self.config.kyutai_vad_head_index,
            vad_threshold=self.config.kyutai_vad_threshold,
            model_delay_seconds=self.config.kyutai_model_delay_seconds,
            startup_timeout_seconds=self.config.kyutai_startup_timeout_seconds,
            on_utterance=lambda text: self._utterance_callback(self._normalize_name(text))
            if self._utterance_callback and self._running.is_set()
            else None,
            on_partial=lambda text: self._partial_callback(self._normalize_name(text))
            if self._partial_callback and self._running.is_set()
            else None,
            on_semantic_eot=lambda text: self._semantic_eot_callback(
                self._normalize_name(text)
            )
            if self._semantic_eot_callback and self._running.is_set()
            else None,
            on_status=self._emit_status,
            on_audio=lambda samples, rate: self.affect_audio(samples, rate),
        )
        self._running.set()
        try:
            client.start()
        except KyutaiSTTError as exc:
            self._running.clear()
            raise VoiceUnavailable(str(exc)) from exc
        self._kyutai_client = client
        threading.Thread(target=self._prewarm_speech, daemon=True).start()
        self._emit_status("call connected")

    def _start_parakeet(
        self,
        on_utterance: Callable[[str], None],
        on_status: Callable[[str], None],
    ) -> None:
        from .parakeet_stt import ParakeetSTTClient, ParakeetSTTError

        self._utterance_callback = on_utterance
        self._status_callback = on_status
        self._emit_status("loading Parakeet STT")
        root_directory = self.temporary_directory.parent.parent
        client = ParakeetSTTClient(
            root_directory=root_directory,
            library_path=self.config.parakeet_library_path,
            model_path=self.config.parakeet_model_path,
            input_device=self.config.input_device,
            chunk_milliseconds=self.config.parakeet_chunk_milliseconds,
            on_utterance=lambda text: self._utterance_callback(self._normalize_name(text))
            if self._utterance_callback and self._running.is_set()
            else None,
            on_partial=lambda text: self._partial_callback(self._normalize_name(text))
            if self._partial_callback and self._running.is_set()
            else None,
            on_status=self._emit_status,
        )
        self._running.set()
        try:
            client.start()
        except ParakeetSTTError as exc:
            self._running.clear()
            raise VoiceUnavailable(str(exc)) from exc
        self._parakeet_client = client
        threading.Thread(target=self._prewarm_speech, daemon=True).start()

    def _start_moonshine(
        self,
        on_utterance: Callable[[str], None],
        on_status: Callable[[str], None],
    ) -> None:
        """Use Moonshine's streaming end-of-turn model instead of amplitude gating."""
        from moonshine_voice import MicTranscriber

        self._utterance_callback = on_utterance
        self._status_callback = on_status
        self._emit_status("loading voice")

        def on_line(line) -> None:
            text = self._normalize_name(str(getattr(line, "text", "")))
            if text and self._running.is_set() and not self._speaking.is_set():
                LOG.info("Moonshine final transcript chars=%s", len(text))
                if self.config.livekit_turn_detection_enabled:
                    commit_now = False
                    with self._moonshine_text_lock:
                        if self._moonshine_turn_committed:
                            return
                        self._moonshine_final = text
                        self._moonshine_partial = text
                        commit_now = self._livekit_commit_pending
                    if commit_now:
                        self._commit_livekit_transcript()
                    return
                callback = self._utterance_callback
                if callback:
                    callback(text)

        def on_text(text: str) -> None:
            partial = self._normalize_name(text)
            if partial and self.config.livekit_turn_detection_enabled:
                with self._moonshine_text_lock:
                    if self._moonshine_turn_committed:
                        return
                    self._moonshine_partial = partial
            callback = self._partial_callback
            if partial and callback and self._running.is_set() and not self._speaking.is_set():
                callback(partial)

        def on_error(error: BaseException) -> None:
            LOG.warning("Moonshine STT error: %s", error)
            self._emit_status(f"voice error: {error}")

        mic = (
            MicTranscriber()
            .language("en" if self.config.language.lower().startswith("en") else self.config.language)
            .device(self.config.input_device)
            .update_interval(0.25)
            .on_text(on_text)
            .on_line(on_line)
            .on_error(on_error)
        )
        try:
            mic.load()
            # Bias Moonshine toward Mako's name before live transcription begins.
            mic.set_keyterms(["Mako"])
            self._moonshine_mic = mic
            self._running.set()
            if self.config.livekit_turn_detection_enabled:
                self._start_moonshine_livekit_capture(mic)
            else:
                mic.start()
        except Exception as exc:
            self._moonshine_mic = None
            self._running.clear()
            raise VoiceUnavailable(f"Moonshine could not start: {exc}") from exc
        threading.Thread(target=self._prewarm_speech, daemon=True).start()
        self._emit_status("call connected")

    def _start_moonshine_livekit_capture(self, mic: object) -> None:
        """Share one microphone stream between Moonshine and LiveKit."""
        import numpy as np
        import sounddevice as sd

        assert getattr(mic, "mic_stream", None) is not None
        device_info = sd.query_devices(self.config.input_device, "input")
        native_rate = int(round(float(device_info["default_samplerate"])))
        self._capture_sample_rate = native_rate if native_rate > 0 else self.config.sample_rate
        blocksize = max(
            160,
            int(self._capture_sample_rate * (self.config.block_milliseconds / 1000.0)),
        )
        self._livekit_endpoint.reset()
        self._livekit_turn_detector = LiveKitTurnDetectorBridge(
            self.config.sample_rate,
            self._on_livekit_prediction,
        )
        mic.mic_stream.start()
        self._audio_queue = queue.Queue(maxsize=256)

        def feed_moonshine() -> None:
            while self._running.is_set():
                item = self._audio_queue.get()
                if item is None:
                    break
                samples, sample_rate = item
                mic.mic_stream.add_audio(samples, sample_rate)

        threading.Thread(target=feed_moonshine, daemon=True).start()

        def audio_callback(in_data, frames, timing, status) -> None:
            del frames, timing
            if status:
                LOG.debug("Microphone status: %s", status)
            if not self._running.is_set() or self._speaking.is_set() or in_data is None:
                return
            samples = np.asarray(in_data, dtype=np.float32).reshape(-1).copy()
            try:
                self._audio_queue.put_nowait((samples, self._capture_sample_rate))
            except queue.Full:
                LOG.warning("Moonshine audio queue overflow; dropping one block")

            detector_samples = self._resample_for_whisper(samples)
            detector = self._livekit_turn_detector
            if detector is not None:
                detector.push_audio(detector_samples)
            level = float(np.sqrt(np.mean(np.square(samples)))) if samples.size else 0.0
            endpoint_state = self._livekit_endpoint.process(level, time.monotonic())
            if endpoint_state == "start":
                self._cancel_livekit_failsafe()
                self._cancel_livekit_transcript_timer()
                with self._moonshine_text_lock:
                    self._moonshine_turn_committed = False
                    self._livekit_commit_pending = False
                    self._moonshine_partial = ""
                    self._moonshine_final = ""
                if detector is not None:
                    detector.cancel_prediction()
            elif endpoint_state == "finish":
                if detector is not None:
                    detector.predict()
                self._schedule_livekit_failsafe()

        self._stream = sd.InputStream(
            callback=audio_callback,
            channels=1,
            device=self.config.input_device,
            samplerate=self._capture_sample_rate,
            blocksize=blocksize,
            dtype="float32",
        )
        self._stream.start()

    def _on_livekit_prediction(self, end_of_turn: bool, probability: float) -> None:
        LOG.debug("LiveKit EOT probability=%.3f end=%s", probability, end_of_turn)
        if end_of_turn:
            self._request_livekit_commit()

    def _schedule_livekit_failsafe(self) -> None:
        self._cancel_livekit_failsafe()
        timer = threading.Timer(
            self.config.livekit_max_endpoint_seconds,
            self._request_livekit_commit,
        )
        timer.daemon = True
        self._livekit_failsafe_timer = timer
        timer.start()

    def _cancel_livekit_failsafe(self) -> None:
        timer = self._livekit_failsafe_timer
        self._livekit_failsafe_timer = None
        if timer is not None:
            timer.cancel()

    def _request_livekit_commit(self) -> None:
        self._cancel_livekit_failsafe()
        with self._moonshine_text_lock:
            if self._moonshine_turn_committed:
                return
            self._livekit_commit_pending = True
            final_ready = bool(self._moonshine_final)
        if final_ready:
            self._commit_livekit_transcript()
            return
        self._cancel_livekit_transcript_timer()
        timer = threading.Timer(
            self.config.livekit_transcript_grace_seconds,
            self._commit_livekit_transcript,
        )
        timer.daemon = True
        self._livekit_transcript_timer = timer
        timer.start()

    def _cancel_livekit_transcript_timer(self) -> None:
        timer = self._livekit_transcript_timer
        self._livekit_transcript_timer = None
        if timer is not None and timer is not threading.current_thread():
            timer.cancel()

    def _commit_livekit_transcript(self) -> None:
        self._cancel_livekit_failsafe()
        self._cancel_livekit_transcript_timer()
        if not self._running.is_set() or self._speaking.is_set():
            return
        with self._moonshine_text_lock:
            text = self._moonshine_final or self._moonshine_partial
            if text:
                self._moonshine_turn_committed = True
                self._livekit_commit_pending = False
                self._moonshine_final = ""
                self._moonshine_partial = ""
        if text:
            LOG.info("LiveKit committed Moonshine transcript chars=%s", len(text))
            detector = self._livekit_turn_detector
            if detector is not None:
                detector.flush()
            callback = self._utterance_callback
            if callback:
                callback(text)

    def stop(self) -> None:
        self._running.clear()
        self._cancel_livekit_failsafe()
        self._cancel_livekit_transcript_timer()
        detector = self._livekit_turn_detector
        self._livekit_turn_detector = None
        if detector is not None:
            detector.close()
        self.stop_speaking()
        self._close_deepgram_flux()
        self._authoritative_turn_active.clear()
        if self._elevenlabs_stt_client is not None:
            self._elevenlabs_stt_client.stop()
            self._elevenlabs_stt_client = None
        if self._kyutai_client is not None:
            self._kyutai_client.stop()
            self._kyutai_client = None
        if self._inworld_stt_client is not None:
            self._inworld_stt_client.stop()
            self._inworld_stt_client = None
        if self._parakeet_client is not None:
            self._parakeet_client.stop()
            self._parakeet_client = None
        if self._moonshine_mic is not None:
            try:
                self._moonshine_mic.stop()
                self._moonshine_mic.close()
            except Exception:
                pass
            self._moonshine_mic = None
        if self._stream is not None:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception:
                pass
            self._stream = None
        try:
            self._audio_queue.put_nowait(None)
        except queue.Full:
            try:
                self._audio_queue.get_nowait()
            except queue.Empty:
                pass
            self._audio_queue.put_nowait(None)

    def shutdown(self) -> None:
        """End call resources and aggressively stop owned background workers."""
        self.stop()
        if self._affect_monitor is not None:
            self._affect_monitor.stop()
            self._affect_monitor = None
        server = self._kyutai_server
        self._kyutai_server = None
        if server is not None:
            server.stop()

    def speak(
        self,
        text: str,
        on_done: Callable[[], None] | None = None,
        *,
        vocal_cue: str = "none",
        delivery: str = "neutral",
        mood: str = "neutral",
        on_result: Callable[[bool], None] | None = None,
        on_started: Callable[[], None] | None = None,
    ) -> None:
        if not text.strip():
            if on_result:
                on_result(False)
            if on_done:
                on_done()
            return
        if not self.capabilities.can_speak and self.config.tts_backend != "cartesia_tts":
            raise VoiceUnavailable("Live speech needs Inworld, Deepgram Flux, Qwen, Kokoro, or pyttsx3.")
        if self._uses_inworld_tts():
            text = inworld_expressive_text(text, vocal_cue=vocal_cue, delivery=delivery)
        if self.config.tts_backend == "cartesia_tts":
            chunks = queue.Queue()
            chunks.put(text.strip())
            chunks.put(None)
            self._schedule_elevenlabs(chunks, on_done, on_result, on_started)
            return
        if self.config.tts_backend == "elevenlabs_tts":
            from .elevenlabs_voice import expressive_text
            chunks = queue.Queue()
            chunks.put(expressive_text(text, vocal_cue=vocal_cue, delivery=delivery, mood=mood))
            chunks.put(None)
            self._schedule_elevenlabs(chunks, on_done, on_result, on_started)
            return
        threading.Thread(
            target=self._speak_worker,
            args=(text.strip(), on_done, on_result, self._speech_generation),
            daemon=True,
        ).start()

    def speak_stream(
        self,
        chunks: queue.Queue[str | None],
        on_done: Callable[[], None] | None = None,
        on_started: Callable[[], None] | None = None,
    ) -> None:
        if self.config.tts_backend in {"elevenlabs_tts", "cartesia_tts"}:
            self._schedule_elevenlabs(chunks, on_done, on_started=on_started)
            return
        if not self.capabilities.can_speak:
            raise VoiceUnavailable("Live speech needs Deepgram Flux, Qwen, Kokoro, or pyttsx3.")
        threading.Thread(
            target=self._speak_stream_worker,
            args=(chunks, on_done),
            daemon=True,
        ).start()

    def prepare_speech(self) -> None:
        """Warm voice synthesis and the output stream before the audible greeting."""
        if self.config.tts_backend == "cartesia_tts":
            from .cartesia_voice import cartesia_key, speech_payload
            cartesia_key(self.config)
            speech_payload(self.config, "")
            self._speech_prepared = True
            return
        if self.config.tts_backend == "elevenlabs_tts":
            from .elevenlabs_voice import elevenlabs_key
            elevenlabs_key(self.config)
            if not self.config.elevenlabs_tts_voice.strip():
                raise VoiceUnavailable("Choose an ElevenLabs voice ID")
            self._speech_prepared = True
            return
        if self._uses_deepgram_flux_tts() or self._uses_inworld_tts():
            (self._deepgram_api_key if self._uses_deepgram_flux_tts() else self._inworld_api_key)()
            self._speech_prepared = True
            return
        if self._uses_qwen_tts():
            with self._speech_prepare_lock:
                if self._qwen_tts_model is not None:
                    self._speech_prepared = True
                    return
                if self._qwen_warm_thread is None or not self._qwen_warm_thread.is_alive():
                    self._qwen_warm_thread = threading.Thread(
                        target=self._warm_qwen_tts,
                        name="mako-qwen-tts-warmup",
                        daemon=True,
                    )
                    self._qwen_warm_thread.start()
            return
        if not (self.capabilities.kokoro and self.config.tts_backend in {"auto", "kokoro"}):
            return
        with self._speech_prepare_lock:
            if self._speech_prepared:
                return
            pipeline = self._get_kokoro_pipeline()
            voice = self.config.voice if self.config.voice.startswith("af_") else "af_heart"
            # Warm synthesis only. Opening PortAudio output before the M-Audio
            # WASAPI input can deadlock the subsequent microphone start.
            with _KOKORO_PIPELINE_LOCK:
                next(pipeline("ready", voice=voice, speed=max(0.75, min(1.35, self.config.kokoro_speed))))
            self._speech_prepared = True

    def stop_speaking(self) -> None:
        self._speech_generation += 1
        if self.capabilities.kokoro:
            try:
                import sounddevice as sd

                sd.stop()
            except Exception:
                pass
        with self._tts_lock:
            if self._tts_engine is not None:
                try:
                    self._tts_engine.stop()
                except Exception:
                    pass
        self._speaking.clear()
        self._microphone_resume_at = time.monotonic() + 0.25
        self._resume_stt_after_speech()

    def _audio_callback(self, indata, frames, time_info, status) -> None:
        del frames, time_info
        if status:
            self._emit_status(str(status))
        if not self._running.is_set():
            return

        import numpy as np

        now = time.monotonic()
        if self._speaking.is_set() or now < self._microphone_resume_at:
            return

        capture_chunk = np.asarray(indata).reshape(-1).astype("float32", copy=True)
        level = float(np.sqrt(np.mean(capture_chunk * capture_chunk))) if capture_chunk.size else 0.0
        endpoint_state = self._endpoint.process(level, now)
        chunk = self._resample_for_whisper(capture_chunk)
        completed_turn = self._capture_endpoint_audio(chunk, endpoint_state, now)
        if self.config.rolling_transcription_enabled:
            try:
                self._audio_queue.put_nowait(chunk)
            except queue.Full:
                # Preserve the newest speech if transcription briefly falls behind real time.
                try:
                    self._audio_queue.get_nowait()
                except queue.Empty:
                    pass
                try:
                    self._audio_queue.put_nowait(chunk)
                except queue.Full:
                    pass
        if completed_turn is not None:
            try:
                self._audio_queue.put_nowait(completed_turn)
            except queue.Full:
                # Preserve the complete turn over stale provisional audio.
                try:
                    self._audio_queue.get_nowait()
                    self._audio_queue.put_nowait(completed_turn)
                except queue.Empty:
                    pass

    def _resample_for_whisper(self, samples):
        """Capture at the interface's native rate, then feed Whisper its 16 kHz audio."""
        import numpy as np

        source_rate = self._capture_sample_rate
        target_rate = self.config.sample_rate
        if source_rate == target_rate or samples.size == 0:
            return samples
        target_size = max(1, round(samples.size * target_rate / source_rate))
        source_positions = np.linspace(0.0, samples.size - 1, num=samples.size)
        target_positions = np.linspace(0.0, samples.size - 1, num=target_size)
        return np.interp(target_positions, source_positions, samples).astype("float32")

    def _capture_endpoint_audio(
        self, chunk, endpoint_state: str, now: float
    ) -> CompletedTurn | None:
        """Keep a single raw utterance so final STT never stitches rolling windows."""
        import numpy as np

        with self._capture_lock:
            if self._capturing_turn:
                self._turn_chunks.append(chunk)
            else:
                self._pre_roll_chunks.append(chunk)
                pre_roll_limit = max(2, round(0.35 / max(0.01, self.config.block_milliseconds / 1000.0)))
                while len(self._pre_roll_chunks) > pre_roll_limit:
                    self._pre_roll_chunks.popleft()

            if endpoint_state == "start":
                self._capturing_turn = True
                self._authoritative_turn_active.set()
                self._turn_chunks = list(self._pre_roll_chunks)
                self._pre_roll_chunks.clear()
                return None
            if endpoint_state != "finish" or not self._capturing_turn:
                return None

            samples = np.concatenate(self._turn_chunks).astype("float32", copy=False)
            self._turn_chunks.clear()
            self._capturing_turn = False
            return CompletedTurn(samples=samples, endpointed_at=now)

    def _transcription_loop(self) -> None:
        import numpy as np

        self.temporary_directory.mkdir(parents=True, exist_ok=True)
        window_seconds = max(0.7, self.config.transcription_window_seconds)
        overlap_seconds = min(
            window_seconds * 0.4,
            max(0.0, self.config.transcription_overlap_seconds),
        )
        window_samples = max(1, round(self.config.sample_rate * window_seconds))
        step_samples = max(
            1,
            round(self.config.sample_rate * (window_seconds - overlap_seconds)),
        )
        idle_limit = max(1, self.config.transcript_idle_windows)
        fallback_idle_limit = max(3, idle_limit)
        buffer = np.empty(0, dtype="float32")
        transcript = TranscriptAssembler()
        idle_windows = 0
        active_windows = 0

        while True:
            try:
                audio = self._audio_queue.get(timeout=0.25)
            except queue.Empty:
                if not self._running.is_set():
                    return
                continue
            if audio is None:
                return
            if isinstance(audio, CompletedTurn):
                self._flush_final_turn(audio)
                self._authoritative_turn_active.clear()
                buffer = np.empty(0, dtype="float32")
                transcript = TranscriptAssembler()
                idle_windows = 0
                active_windows = 0
                continue

            samples = np.asarray(audio).reshape(-1).astype("float32", copy=False)
            buffer = np.concatenate((buffer, samples))
            while buffer.size >= window_samples:
                window = buffer[:window_samples]
                buffer = buffer[step_samples:]
                try:
                    text = self._transcribe_window(window)
                except Exception as exc:
                    self._emit_status(f"voice error: {exc}")
                    continue

                added = transcript.add(text)
                if added:
                    idle_windows = 0
                    active_windows += 1
                elif transcript:
                    idle_windows += 1
                    active_windows += 1

                maximum_reached = (
                    active_windows * (window_seconds - overlap_seconds)
                    >= self.config.maximum_utterance_seconds
                )
                if (
                    transcript
                    and not self._authoritative_turn_active.is_set()
                    and (idle_windows >= fallback_idle_limit or maximum_reached)
                ):
                    # Some microphones never cross the amplitude endpoint threshold.
                    # Keep a deliberately slower provisional fallback so a call cannot hang.
                    utterance = transcript.pop()
                    idle_windows = 0
                    active_windows = 0
                    if utterance and self._utterance_callback:
                        self._utterance_callback(utterance)

    def _flush_final_turn(self, turn: CompletedTurn) -> None:
        """Use one complete utterance as the model-facing transcript."""
        started_at = time.monotonic()
        try:
            utterance = self._transcribe_final_utterance(turn.samples)
        except Exception as exc:
            self._emit_status(f"voice error: {exc}")
            return
        finished_at = time.monotonic()
        LOG.info(
            "Call STT timing audio=%.2fs decode=%.3fs endpoint_to_text=%.3fs chars=%s",
            len(turn.samples) / self.config.sample_rate,
            finished_at - started_at,
            finished_at - turn.endpointed_at,
            len(utterance),
        )
        self._deliver_completed_utterance(utterance)

    def _deliver_completed_utterance(self, utterance: str) -> None:
        """Deliver the final transcript immediately after acoustic endpointing."""
        if utterance and self._utterance_callback:
            self._utterance_callback(utterance)

    def _transcribe_window(self, samples) -> str:
        path = self.temporary_directory / "call_input.wav"
        transcription_input = samples
        if self.config.raw_audio_retained:
            import soundfile as sf

            sf.write(path, samples, self.config.sample_rate)
            transcription_input = str(path)

        language = "en" if self.config.language.lower().startswith("en") else None
        segments, _ = self._transcriber.transcribe(
            transcription_input,
            beam_size=1,
            best_of=1,
            temperature=0.0,
            condition_on_previous_text=False,
            language=language,
            vad_filter=True,
            vad_parameters={
                "min_silence_duration_ms": 160,
                "speech_pad_ms": 100,
            },
            max_new_tokens=48,
            hotwords="Mako",
        )
        text = " ".join(segment.text.strip() for segment in segments).strip()
        return self._normalize_name(text)

    def _transcribe_final_utterance(self, samples) -> str:
        """Transcribe the endpointed audio once; acoustic gating already removed silence."""
        language = "en" if self.config.language.lower().startswith("en") else None
        segments, _ = self._transcriber.transcribe(
            samples,
            beam_size=1,
            best_of=1,
            temperature=0.0,
            condition_on_previous_text=False,
            language=language,
            vad_filter=False,
            max_new_tokens=64,
            hotwords="Mako",
        )
        text = " ".join(segment.text.strip() for segment in segments).strip()
        return self._normalize_name(text)

    def _schedule_elevenlabs(self, chunks, on_done, on_result=None, on_started=None):
        generation = self._speech_generation
        threading.Thread(target=self._elevenlabs_worker, args=(chunks, on_done, generation, on_result, on_started),
                         name="stella-elevenlabs-playback", daemon=True).start()

    def _elevenlabs_worker(self, chunks, on_done, generation, on_result=None, on_started=None):
        from contextlib import aclosing
        from .elevenlabs_voice import PCM_RATE, stream_dialogue
        if self.config.tts_backend == "cartesia_tts":
            from .cartesia_voice import PCM_RATE, stream_dialogue
        import numpy as np
        import sounddevice as sd

        cancelled = lambda: generation != self._speech_generation
        acquired = False
        played = False
        succeeded = False
        text_parts = []
        finished_text = False
        class RecordedQueue:
            def get_nowait(inner):
                nonlocal finished_text
                value = chunks.get_nowait()
                if value is None:
                    finished_text = True
                else:
                    text_parts.append(value)
                return value

        async def play():
            nonlocal played
            stream = None
            first_frame_written = False
            try:
                async with aclosing(stream_dialogue(self.config, RecordedQueue(), cancelled=cancelled)) as audio:
                    async for pcm in audio:
                        if cancelled():
                            break
                        if stream is None:
                            stream = sd.RawOutputStream(samplerate=PCM_RATE, channels=1, dtype="int16", blocksize=480,
                                                        device=self.config.output_device)
                            stream.start()
                            self._emit_status("speaking")
                            LOG.info("Cloud TTS desktop playback started backend=%s monotonic=%.6f", self.config.tts_backend, time.monotonic())
                        for offset in range(0, len(pcm), 960):
                            if cancelled():
                                break
                            frame = pcm[offset:offset + 960]
                            if self.config.output_volume < .999:
                                frame = (np.frombuffer(frame, dtype="<i2").astype(np.float32)
                                         * self.config.output_volume).astype("<i2").tobytes()
                            # PortAudio writes block at playback speed; keep the
                            # websocket event loop free to receive and heartbeat.
                            await asyncio.to_thread(stream.write, frame)
                            played = True
                            if not first_frame_written:
                                first_frame_written = True
                                if on_started:
                                    try:
                                        on_started()
                                    except Exception:
                                        LOG.exception("Speech start callback failed")
                            if self._playback_level_callback:
                                values = np.frombuffer(frame, dtype="<i2").astype(np.float32) / 32768
                                self._playback_level_callback(float(np.sqrt(np.mean(values * values))))
                            await asyncio.sleep(0)
            finally:
                if stream is not None:
                    stream.abort() if cancelled() else stream.stop()
                    stream.close()

        try:
            deadline = time.monotonic() + 15
            while not cancelled() and time.monotonic() < deadline:
                if self._speech_serial.acquire(timeout=.05):
                    acquired = True
                    break
            if not acquired or cancelled():
                return
            self._speaking.set()
            self._set_stt_muted(True)
            try:
                asyncio.run(play())
                succeeded = played and not cancelled()
            except Exception:
                if cancelled():
                    return
                LOG.exception("Cloud TTS speech delivery failed backend=%s played=%s", self.config.tts_backend, played)
                # Never replay a partially heard reply on another voice.
                if not played and self.config.tts_backend == "elevenlabs_tts" and self.config.elevenlabs_tts_fallback == "inworld_tts":
                    deadline = time.monotonic() + 10
                    while not finished_text and not cancelled() and time.monotonic() < deadline:
                        try:
                            RecordedQueue().get_nowait()
                        except queue.Empty:
                            time.sleep(.02)
                    if finished_text and text_parts and not cancelled():
                        self._emit_status("ElevenLabs unavailable; using Inworld TTS fallback")
                        self._speak_inworld("".join(text_parts))
                        succeeded = not cancelled()
                        return
                self._emit_status(f"voice error: {self.config.tts_backend} speech failed; see runtime log")
        finally:
            if acquired:
                self._speaking.clear()
                if self._playback_level_callback:
                    self._playback_level_callback(0.0)
                self._resume_stt_after_speech()
                self._speech_serial.release()
                if self._running.is_set():
                    self._emit_status("call connected")
            if on_result:
                on_result(succeeded and not cancelled())
            if on_done:
                on_done()

    def _speak_worker(self, text: str, on_done: Callable[[], None] | None, on_result=None, generation=None) -> None:
        # A stalled provider request must not leave every later response silently
        # waiting behind this one worker for the rest of the call.
        LOG.info("Voice playback queued chars=%s backend=%s", len(text), self.config.tts_backend)
        generation = self._speech_generation if generation is None else generation
        if generation != self._speech_generation:
            if on_result:
                on_result(False)
            if on_done:
                on_done()
            return
        if not self._speech_serial.acquire(timeout=15.0):
            message = "voice playback queue was busy for 15 seconds; skipped stale reply"
            LOG.error(message)
            self._emit_status(f"voice error: {message}")
            if on_result:
                on_result(False)
            if on_done:
                on_done()
            return
        succeeded = False
        try:
            if generation != self._speech_generation:
                if on_result:
                    on_result(False)
                if on_done:
                    on_done()
                return
            self._set_stt_muted(True)
            self._speaking.set()
            self._emit_status("preparing voice")
            try:
                if self._uses_qwen_tts():
                    self._speak_qwen(text)
                elif self._uses_inworld_tts():
                    self._speak_inworld(text)
                elif self._uses_deepgram_flux_tts():
                    self._speak_deepgram_flux(text)
                elif self.capabilities.kokoro and self.config.tts_backend in {"auto", "kokoro"}:
                    self._speak_kokoro(text)
                else:
                    self._speak_pyttsx3(text)
                succeeded = generation == self._speech_generation
            except Exception as exc:
                # Surface delivery failures in the durable runtime log as well
                # as the transient UI state; otherwise a silent call has no
                # diagnosable evidence after the shell exits.
                LOG.exception("Live voice playback failed")
                self._emit_status(f"voice error: {exc}")
            finally:
                self._speaking.clear()
                self._resume_stt_after_speech()
                if self._running.is_set():
                    self._emit_status("call connected")
                if on_result:
                    on_result(succeeded)
                if on_done:
                    on_done()
        finally:
            self._speech_serial.release()

    def _speak_stream_worker(
        self,
        chunks: queue.Queue[str | None],
        on_done: Callable[[], None] | None,
    ) -> None:
        with self._speech_serial:
            self._set_stt_muted(True)
            self._speaking.set()
            try:
                if self._uses_inworld_tts():
                    self._speak_inworld_stream(chunks)
                elif self._uses_deepgram_flux_tts():
                    self._speak_deepgram_flux_stream(chunks)
                else:
                    while True:
                        text = chunks.get()
                        if text is None:
                            break
                        text = text.strip()
                        if not text:
                            continue
                        if self._uses_qwen_tts():
                            self._speak_qwen(text)
                        elif self.capabilities.kokoro and self.config.tts_backend in {"auto", "kokoro"}:
                            self._speak_kokoro(text)
                        else:
                            self._speak_pyttsx3(text)
            except Exception as exc:
                LOG.exception("Live streaming voice playback failed")
                self._emit_status(f"voice error: {exc}")
            finally:
                self._speaking.clear()
                self._resume_stt_after_speech()
                if self._running.is_set():
                    self._emit_status("call connected")
                if on_done:
                    on_done()

    def _prewarm_speech(self) -> None:
        try:
            self.prepare_speech()
        except Exception as exc:
            self._emit_status(f"voice setup error: {exc}")

    def _uses_qwen_tts(self) -> bool:
        return self.config.tts_backend.lower() == "qwen3"

    def _uses_deepgram_flux_tts(self) -> bool:
        return self.config.tts_backend.lower() == "deepgram_flux"

    def _uses_inworld_tts(self) -> bool:
        return self.config.tts_backend.lower() == "inworld_tts"

    def _inworld_api_key(self) -> str:
        key = os.getenv(self.config.inworld_tts_api_key_environment_variable, "").strip()
        if not key and os.name == "nt":
            try:
                import winreg

                with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as registry_key:
                    value, _ = winreg.QueryValueEx(
                        registry_key,
                        self.config.inworld_tts_api_key_environment_variable,
                    )
                key = str(value).strip()
            except OSError:
                pass
        if not key:
            raise VoiceUnavailable("Inworld TTS needs INWORLD_API_KEY.")
        return key

    def _speak_inworld(self, text: str) -> None:
        # The streaming endpoint can open an output device yet stall before its
        # first audio event on this Windows audio stack. The regular endpoint
        # returns a verified waveform reliably; retain the same RMS callback so
        # lip sync remains driven by real speech energy.
        import sounddevice as sd

        audio, sample_rate = self._generate_inworld_audio(text)
        if audio.size == 0:
            raise VoiceUnavailable("Inworld TTS returned an empty audio response.")
        if float(abs(audio).max()) < 0.0005:
            raise VoiceUnavailable("Inworld TTS returned silent audio.")
        LOG.info(
            "Inworld complete audio ready seconds=%s chars=%s",
            round(float(audio.size) / sample_rate, 3),
            len(text),
        )
        self._emit_status("speaking")
        self._play_audio_with_levels(sd, audio, sample_rate)

    def _generate_inworld_audio(self, text: str):
        import base64
        import io
        import numpy as np
        import soundfile as sf

        audio_bytes = asyncio.run(self._request_inworld_audio(text))
        if audio_bytes.lstrip().startswith(b"{"):
            # REST returns one top-level audioContent value; the streaming endpoint
            # returns NDJSON with audioContent nested under result.
            chunks = [
                base64.b64decode(
                    payload.get("audioContent")
                    or payload.get("result", {}).get("audioContent", "")
                )
                for line in audio_bytes.splitlines()
                if line.strip()
                for payload in (json.loads(line),)
                if payload.get("audioContent")
                or payload.get("result", {}).get("audioContent")
            ]
            decoded_chunks = [sf.read(io.BytesIO(chunk), dtype="float32") for chunk in chunks]
            if not decoded_chunks:
                raise VoiceUnavailable("Inworld TTS returned no audio chunks.")
            audio = np.concatenate([chunk_audio for chunk_audio, _ in decoded_chunks])
            sample_rate = decoded_chunks[0][1]
        elif audio_bytes.startswith(b"RIFF"):
            audio, sample_rate = sf.read(io.BytesIO(audio_bytes), dtype="float32")
        else:
            audio = np.frombuffer(audio_bytes, dtype="<i2").astype("float32") / 32768.0
            sample_rate = self.config.inworld_tts_sample_rate
        return audio, int(sample_rate)

    def _speak_inworld_stream(self, chunks: queue.Queue[str | None]) -> None:
        while True:
            text = chunks.get()
            if text is None:
                break
            clean = text.strip()
            if clean:
                asyncio.run(self._stream_inworld_audio(clean))

    async def _stream_inworld_audio(self, text: str) -> None:
        """Play each HTTP streaming TTS chunk as it arrives from Inworld."""
        import base64
        import io

        import aiohttp
        import numpy as np
        import sounddevice as sd
        import soundfile as sf

        payload = {
            "text": text,
            "voiceId": self.config.inworld_tts_voice,
            "modelId": self.config.inworld_tts_model,
            "audioConfig": {
                "audioEncoding": "LINEAR16",
                "sampleRateHertz": self.config.inworld_tts_sample_rate,
            },
            "deliveryMode": self.config.inworld_tts_delivery_mode,
            "instruction": self.config.inworld_tts_instruction,
            # Audio can arrive before optional alignment metadata is calculated.
            "timestampTransportStrategy": "ASYNC",
        }
        started = time.monotonic()
        output = None
        sample_rate = 0
        first_audio = True
        # Playback may last longer than a short reply, so only bound connection
        # and silent-read stalls. A dead stream must release the speech queue.
        timeout = aiohttp.ClientTimeout(total=None, connect=10, sock_read=10)
        try:
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(
                    "https://api.inworld.ai/tts/v1/voice:stream",
                    headers={"Authorization": f"Basic {self._inworld_api_key()}"},
                    json=payload,
                ) as response:
                    if response.status >= 400:
                        raise VoiceUnavailable(
                            f"Inworld TTS request failed ({response.status}): {await response.text()}"
                        )
                    async for raw_line in response.content:
                        line = raw_line.decode("utf-8", errors="replace").strip()
                        if not line:
                            continue
                        if line.startswith("data:"):
                            line = line[5:].strip()
                        try:
                            item = json.loads(line)
                        except json.JSONDecodeError as exc:
                            raise VoiceUnavailable("Inworld TTS returned an invalid stream chunk.") from exc
                        if item.get("error"):
                            raise VoiceUnavailable(f"Inworld TTS stream error: {item['error']}")
                        encoded = str(item.get("result", {}).get("audioContent", ""))
                        if not encoded:
                            continue
                        audio, chunk_rate = sf.read(
                            io.BytesIO(base64.b64decode(encoded)), dtype="float32"
                        )
                        samples = np.asarray(audio, dtype="float32").reshape(-1, 1)
                        if self.config.output_volume < .999:
                            samples *= self.config.output_volume
                        if not samples.size:
                            continue
                        if output is None:
                            sample_rate = int(chunk_rate)
                            output = sd.OutputStream(
                                samplerate=sample_rate,
                                channels=1,
                                dtype="float32",
                                device=self.config.output_device,
                            )
                            output.start()
                        elif int(chunk_rate) != sample_rate:
                            raise VoiceUnavailable("Inworld TTS changed sample rate mid-stream.")
                        if first_audio:
                            first_audio = False
                            LOG.info(
                                "Inworld streaming first audio seconds=%.3f chars=%s",
                                time.monotonic() - started,
                                len(text),
                            )
                            self._emit_status("speaking")
                        # The avatar consumes an RMS envelope, not merely a
                        # speaking flag. Feed the same short windows we are
                        # sending to PortAudio so its mouth follows phonetic
                        # energy instead of holding one open pose per reply.
                        callback = self._playback_level_callback
                        frame_samples = max(1, round(sample_rate / 20))
                        # OutputStream.write blocks until this audio reaches
                        # the device queue. Writing one 50 ms frame at a time
                        # keeps lip motion synchronized with audible speech.
                        for offset in range(0, samples.shape[0], frame_samples):
                            frame = samples[offset:offset + frame_samples]
                            if callback:
                                flat = frame.reshape(-1)
                                callback(
                                    float(np.sqrt(np.mean(flat * flat)))
                                    if flat.size else 0.0
                                )
                            output.write(frame)
        finally:
            if output is not None:
                output.stop()
                output.close()
            callback = self._playback_level_callback
            if callback:
                callback(0.0)

    async def _request_inworld_audio(self, text: str) -> bytes:
        import aiohttp

        payload = {
            "text": text,
            "voiceId": self.config.inworld_tts_voice,
            "modelId": self.config.inworld_tts_model,
            "audioConfig": {
                "audioEncoding": "LINEAR16",
                "sampleRateHertz": self.config.inworld_tts_sample_rate,
            },
            "deliveryMode": self.config.inworld_tts_delivery_mode,
            "instruction": self.config.inworld_tts_instruction,
        }
        timeout = aiohttp.ClientTimeout(total=60, sock_read=45)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(
                "https://api.inworld.ai/tts/v1/voice",
                headers={"Authorization": f"Basic {self._inworld_api_key()}"},
                json=payload,
            ) as response:
                if response.status >= 400:
                    raise VoiceUnavailable(
                        f"Inworld TTS request failed ({response.status}): {await response.text()}"
                    )
                return await response.read()

    def _deepgram_api_key(self) -> str:
        key = os.getenv(self.config.deepgram_tts_api_key_environment_variable, "").strip()
        if key or os.name != "nt":
            if key:
                return key
            raise VoiceUnavailable("Deepgram Flux needs DEEPGRAM_API_KEY.")
        try:
            import winreg

            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as registry_key:
                value, _ = winreg.QueryValueEx(
                    registry_key,
                    self.config.deepgram_tts_api_key_environment_variable,
                )
            key = str(value).strip()
        except OSError:
            key = ""
        if not key:
            raise VoiceUnavailable("Deepgram Flux needs DEEPGRAM_API_KEY.")
        return key

    def _speak_deepgram_flux(self, text: str) -> None:
        chunks: queue.Queue[str | None] = queue.Queue()
        chunks.put(text)
        chunks.put(None)
        self._speak_deepgram_flux_stream(chunks)

    def _speak_deepgram_flux_stream(self, chunks: queue.Queue[str | None]) -> None:
        loop = self._ensure_deepgram_flux_loop()
        future = asyncio.run_coroutine_threadsafe(self._stream_deepgram_flux(chunks), loop)
        future.result()

    def _ensure_deepgram_flux_loop(self) -> asyncio.AbstractEventLoop:
        with self._deepgram_flux_lock:
            loop = self._deepgram_flux_loop
            if loop is not None and loop.is_running():
                return loop
            self._deepgram_flux_ready.clear()
            loop = asyncio.new_event_loop()
            self._deepgram_flux_loop = loop
            thread = threading.Thread(
                target=self._run_deepgram_flux_loop,
                args=(loop,),
                name="mako-deepgram-flux",
                daemon=True,
            )
            self._deepgram_flux_thread = thread
            thread.start()
        if not self._deepgram_flux_ready.wait(timeout=5):
            raise VoiceUnavailable("Deepgram Flux event loop did not start.")
        return loop

    def _run_deepgram_flux_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        asyncio.set_event_loop(loop)
        self._deepgram_flux_ready.set()
        loop.run_forever()
        loop.close()

    async def _get_deepgram_flux_websocket(self):
        import aiohttp

        websocket = self._deepgram_flux_websocket
        if websocket is not None and not websocket.closed:
            return websocket
        session = self._deepgram_flux_session
        if session is None or session.closed:
            session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=60, sock_read=45))
            self._deepgram_flux_session = session
        query = urlencode(
            {
                "model": self.config.deepgram_flux_model,
                "encoding": "linear16",
                "sample_rate": str(self.config.deepgram_flux_sample_rate),
            }
        )
        self._deepgram_flux_websocket = await session.ws_connect(
            f"wss://api.deepgram.com/v2/speak?{query}",
            headers={"Authorization": f"Token {self._deepgram_api_key()}"},
            heartbeat=20,
        )
        LOG.info("Deepgram Flux session connected")
        return self._deepgram_flux_websocket

    async def _close_deepgram_flux_connection(self) -> None:
        websocket = self._deepgram_flux_websocket
        self._deepgram_flux_websocket = None
        if websocket is not None and not websocket.closed:
            await websocket.close()
        session = self._deepgram_flux_session
        self._deepgram_flux_session = None
        if session is not None and not session.closed:
            await session.close()

    def _close_deepgram_flux(self) -> None:
        with self._deepgram_flux_lock:
            loop = self._deepgram_flux_loop
            thread = self._deepgram_flux_thread
        if loop is None or not loop.is_running():
            return
        try:
            asyncio.run_coroutine_threadsafe(
                self._close_deepgram_flux_connection(), loop
            ).result(timeout=5)
        except Exception as exc:
            LOG.warning("Deepgram Flux shutdown failed: %s", exc)
        loop.call_soon_threadsafe(loop.stop)
        if thread is not None:
            thread.join(timeout=5)
        with self._deepgram_flux_lock:
            self._deepgram_flux_loop = None
            self._deepgram_flux_thread = None

    async def _stream_deepgram_flux(self, chunks: queue.Queue[str | None]) -> None:
        """Send one Mako reply to Flux and play its PCM frames as they arrive."""
        import aiohttp
        import numpy as np
        import sounddevice as sd

        audio_chunks: list[object] = []
        audio_received = False
        first_audio = True
        next_chunk = None
        receive_task = None
        try:
            websocket = await self._get_deepgram_flux_websocket()
            next_chunk = asyncio.create_task(asyncio.to_thread(chunks.get))
            receive_task = asyncio.create_task(websocket.receive())
            flushed = False
            while receive_task is not None:
                waiting = {receive_task}
                if next_chunk is not None:
                    waiting.add(next_chunk)
                done, _ = await asyncio.wait(waiting, return_when=asyncio.FIRST_COMPLETED)

                if next_chunk is not None and next_chunk in done:
                    text = next_chunk.result()
                    if text is None:
                        await websocket.send_json({"type": "Flush"})
                        flushed = True
                        next_chunk = None
                    elif text.strip():
                        await websocket.send_json({"type": "Speak", "text": text})
                        next_chunk = asyncio.create_task(asyncio.to_thread(chunks.get))
                    else:
                        next_chunk = asyncio.create_task(asyncio.to_thread(chunks.get))

                if receive_task in done:
                    message = receive_task.result()
                    if message.type is aiohttp.WSMsgType.BINARY:
                        if not self._speaking.is_set():
                            await websocket.send_json({"type": "Interrupt"})
                            break
                        samples = np.frombuffer(message.data, dtype="<i2").astype("float32") / 32768.0
                        if samples.size:
                            if first_audio:
                                first_audio = False
                                LOG.info("Deepgram Flux first audio received")
                            audio_chunks.append(samples)
                            audio_received = True
                    elif message.type is aiohttp.WSMsgType.TEXT:
                        payload = json.loads(message.data)
                        event_type = str(payload.get("type", ""))
                        if event_type in {"Error", "error"}:
                            raise VoiceUnavailable(str(payload.get("description") or payload))
                        if flushed and event_type == "SpeechMetadata":
                            break
                    elif message.type in {aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR}:
                        raise VoiceUnavailable(f"Deepgram Flux connection closed: {message.data}")
                    receive_task = asyncio.create_task(websocket.receive())
            if not audio_received:
                raise VoiceUnavailable("Deepgram Flux returned no audio.")
            audio = np.concatenate(audio_chunks)
            peak = float(np.max(np.abs(audio)))
            if peak > 0.001:
                # Normalize quiet raw Flux PCM to the playback level Mako already uses.
                audio = np.clip(audio * min(8.0, 0.82 / peak), -1.0, 1.0)

            if self._speaking.is_set():
                self._emit_status("speaking")
                self._play_audio_with_levels(
                    sd,
                    audio,
                    self.config.deepgram_flux_sample_rate,
                )
        except Exception:
            await self._close_deepgram_flux_connection()
            raise
        finally:
            if next_chunk is not None:
                next_chunk.cancel()
            if receive_task is not None:
                receive_task.cancel()
            callback = self._playback_level_callback
            if callback:
                callback(0.0)

    def _warm_qwen_tts(self) -> None:
        """Load Qwen off the call-control thread so a call can connect immediately."""
        try:
            self._get_qwen_tts_model()
            self._speech_prepared = True
            LOG.info("Qwen TTS is ready")
        except Exception as exc:
            LOG.warning("Qwen TTS warmup failed: %s", exc)

    def _speak_qwen(self, text: str) -> None:
        import sounddevice as sd

        audio, sample_rate = self._generate_qwen_audio(text)
        if self._speaking.is_set():
            self._play_audio_with_levels(sd, audio, sample_rate)

    def _speak_kokoro(self, text: str) -> None:
        import sounddevice as sd

        started = time.monotonic()
        pipeline = self._get_kokoro_pipeline()
        voice = self.config.voice if self.config.voice.startswith("af_") else "af_heart"
        first_chunk = True
        with _KOKORO_PIPELINE_LOCK:
            for _, _, audio in pipeline(
                text,
                voice=voice,
                speed=max(0.75, min(1.35, self.config.kokoro_speed)),
            ):
                if not self._speaking.is_set():
                    break
                if first_chunk:
                    first_chunk = False
                    LOG.info(
                        "Kokoro first audio seconds=%.3f chars=%s",
                        time.monotonic() - started,
                        len(text),
                    )
                    self._emit_status("speaking")
                self._play_audio_with_levels(sd, audio, 24000)

    def _play_audio_with_levels(self, sounddevice, audio, sample_rate: int) -> None:
        """Play synthesized audio while publishing a small RMS envelope for lip sync."""
        import numpy as np

        samples = np.asarray(audio, dtype="float32").reshape(-1)
        if not samples.size:
            return
        sounddevice.play(samples * self.config.output_volume, sample_rate, device=self.config.output_device)
        callback = self._playback_level_callback
        frame_samples = max(1, round(sample_rate / 20))
        started_at = time.monotonic()
        while self._speaking.is_set():
            position = min(samples.size, int((time.monotonic() - started_at) * sample_rate))
            if position >= samples.size:
                break
            frame = samples[position:min(samples.size, position + frame_samples)]
            if callback:
                callback(float(np.sqrt(np.mean(frame * frame))) if frame.size else 0.0)
            time.sleep(.05)
        if callback:
            callback(0.0)
        sounddevice.wait()

    def render_kokoro_wav(self, text: str, destination: Path) -> None:
        """Render the same Kokoro voice used in calls for another transport."""
        import numpy as np
        import soundfile as sf

        pipeline = self._get_kokoro_pipeline()
        voice = self.config.voice if self.config.voice.startswith("af_") else "af_heart"
        with _KOKORO_PIPELINE_LOCK:
            chunks = [
                audio
                for _, _, audio in pipeline(
                    text,
                    voice=voice,
                    speed=max(0.75, min(1.35, self.config.kokoro_speed)),
                )
            ]
        if not chunks:
            raise VoiceUnavailable("Kokoro returned no audio")
        destination.parent.mkdir(parents=True, exist_ok=True)
        sf.write(destination, np.concatenate(chunks), 24000)

    def render_speech_wav(
        self,
        text: str,
        destination: Path,
        *,
        vocal_cue: str = "none",
        delivery: str = "neutral",
    ) -> None:
        """Render the configured speech backend for a non-desktop transport."""
        if self.config.tts_backend in {"elevenlabs_tts", "cartesia_tts"}:
            from .elevenlabs_voice import stream_dialogue, expressive_text, PCM_RATE
            if self.config.tts_backend == "cartesia_tts":
                from .cartesia_voice import stream_dialogue, PCM_RATE
                expressive_text = lambda text, **kwargs: text
            import wave
            chunks = queue.Queue()
            chunks.put(expressive_text(text, vocal_cue=vocal_cue, delivery=delivery))
            chunks.put(None)
            async def collect():
                return b"".join([pcm async for pcm in stream_dialogue(self.config, chunks)])
            pcm = asyncio.run(collect())
            destination.parent.mkdir(parents=True, exist_ok=True)
            with wave.open(str(destination), "wb") as wav:
                wav.setparams((1, 2, PCM_RATE, 0, "NONE", "not compressed"))
                wav.writeframes(pcm)
            return
        if self._uses_inworld_tts():
            import soundfile as sf

            text = inworld_expressive_text(text, vocal_cue=vocal_cue, delivery=delivery)
            audio, sample_rate = self._generate_inworld_audio(text)
            destination.parent.mkdir(parents=True, exist_ok=True)
            sf.write(destination, audio, sample_rate)
            return
        if not self._uses_qwen_tts():
            self.render_kokoro_wav(text, destination)
            return
        import soundfile as sf

        audio, sample_rate = self._generate_qwen_audio(text)
        destination.parent.mkdir(parents=True, exist_ok=True)
        sf.write(destination, audio, sample_rate)

    def _generate_qwen_audio(self, text: str):
        import numpy as np

        model = self._get_qwen_tts_model()
        wavs, sample_rate = model.generate_custom_voice(
            text=text,
            language="English",
            speaker=self.config.qwen_tts_speaker,
        )
        if not wavs:
            raise VoiceUnavailable("Qwen TTS returned no audio")
        return np.asarray(wavs[0], dtype="float32").reshape(-1), int(sample_rate)

    def _get_qwen_tts_model(self):
        if self._qwen_tts_model is None:
            with self._tts_lock:
                if self._qwen_tts_model is None:
                    import torch
                    from qwen_tts import Qwen3TTSModel

                    device = self.config.qwen_tts_device.lower()
                    if device.startswith("cuda") and not torch.cuda.is_available():
                        raise VoiceUnavailable("Qwen TTS is configured for CUDA, but CUDA is unavailable.")
                    self._qwen_tts_model = Qwen3TTSModel.from_pretrained(
                        self.config.qwen_tts_model,
                        device_map="cuda:0" if device.startswith("cuda") else "cpu",
                        dtype=torch.float16 if device.startswith("cuda") else torch.float32,
                    )
        return self._qwen_tts_model

    def _get_kokoro_pipeline(self):
        from kokoro import KPipeline

        if self._kokoro_pipeline is None:
            with _KOKORO_PIPELINE_LOCK:
                if self._kokoro_pipeline is None:
                    import torch

                    torch.set_num_threads(
                        max(1, min(16, int(self.config.kokoro_cpu_threads)))
                    )
                    requested_device = self.config.kokoro_device.lower().strip() or "cuda"
                    device = requested_device if requested_device != "cuda" or torch.cuda.is_available() else "cpu"
                    shared = _KOKORO_PIPELINES.get(device)
                    if shared is not None:
                        self._kokoro_pipeline = shared
                        return self._kokoro_pipeline
                    try:
                        self._kokoro_pipeline = KPipeline(
                            lang_code="a",
                            repo_id="hexgrad/Kokoro-82M",
                            device=device,
                        )
                        LOG.info("Kokoro initialized on %s", device)
                    except RuntimeError:
                        if device != "cuda":
                            raise
                        LOG.warning("Kokoro CUDA initialization failed; falling back to CPU", exc_info=True)
                        self._kokoro_pipeline = KPipeline(
                            lang_code="a",
                            repo_id="hexgrad/Kokoro-82M",
                            device="cpu",
                        )
                        device = "cpu"
                    _KOKORO_PIPELINES[device] = self._kokoro_pipeline
        return self._kokoro_pipeline

    def _speak_pyttsx3(self, text: str) -> None:
        import pyttsx3

        engine = pyttsx3.init()
        with self._tts_lock:
            self._tts_engine = engine
        try:
            for voice in engine.getProperty("voices"):
                name = f"{getattr(voice, 'name', '')} {getattr(voice, 'id', '')}".lower()
                if "zira" in name or "aria" in name or "female" in name:
                    engine.setProperty("voice", voice.id)
                    break
            engine.setProperty("rate", 188)
            engine.say(text)
            engine.runAndWait()
        finally:
            with self._tts_lock:
                if self._tts_engine is engine:
                    self._tts_engine = None

    def _emit_status(self, status: str) -> None:
        if self._status_callback:
            self._status_callback(status)

    def _set_moonshine_muted(self, muted: bool) -> None:
        if self._moonshine_mic is not None:
            try:
                self._moonshine_mic.mute(muted)
            except Exception:
                pass

    def _set_stt_muted(self, muted: bool) -> None:
        self._set_moonshine_muted(muted)
        if self._elevenlabs_stt_client is not None:
            self._elevenlabs_stt_client.set_muted(muted)
        if self._kyutai_client is not None:
            self._kyutai_client.set_muted(muted)
        if self._inworld_stt_client is not None:
            self._inworld_stt_client.set_muted(muted)
        if self._parakeet_client is not None:
            self._parakeet_client.set_muted(muted)

    def set_stt_muted(self, muted: bool) -> None:
        """Temporarily suppress live STT without stopping the call engine."""
        self._set_stt_muted(muted)

    def _resume_stt_after_speech(self) -> None:
        """Avoid transcribing the tail of Mako's own local playback."""
        if (
            self._moonshine_mic is None
            and self._kyutai_client is None
            and self._inworld_stt_client is None
            and self._elevenlabs_stt_client is None
            and self._parakeet_client is None
        ):
            return

        def resume() -> None:
            if self._running.is_set() and not self._speaking.is_set():
                self._set_stt_muted(False)

        timer = threading.Timer(0.25, resume)
        timer.daemon = True
        timer.start()

    @staticmethod
    def _normalize_name(text: str) -> str:
        replacements = (
            "Marco",
            "Maco",
            "Macko",
            "Mayco",
            "Maeko",
            "Maiko",
            "Meko",
            "Meiko",
            "Mego",
            "Miko",
            "Myko",
            "Monco",
            "Marko",
            "Makko",
            "Mocko",
            "Mocco",
            "Mikkel",
            "Mikel",
            "Mikell",
            "Mickel",
        )
        for wrong in replacements:
            text = re.sub(rf"\b{wrong}\b", "Mako", text, flags=re.IGNORECASE)
        text = re.sub(r"\bmake(?:\s+|-)o\b", "Mako", text, flags=re.IGNORECASE)
        text = re.sub(r"\bmakeo\b", "Mako", text, flags=re.IGNORECASE)
        text = re.sub(r"\bmike\s+(?:mego|mako)\b", "Mako", text, flags=re.IGNORECASE)
        return text.strip()
