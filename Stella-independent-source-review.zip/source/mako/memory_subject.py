from __future__ import annotations

import re
from typing import Any


_SELF_ABOUT_RE = re.compile(r"\b(?:about|of)\s+(?:me|myself)\b", re.IGNORECASE)
_PROFILE_PROMPT_RE = re.compile(
    r"\b(?:what\s+(?:do|can)\s+you\s+(?:remember|know)|"
    r"tell\s+me\s+what\s+you\s+(?:remember|know)|"
    r"summari[sz]e\s+(?:what\s+)?you\s+(?:remember|know))\s+about\s+([^?!.\n]+)",
    re.IGNORECASE,
)


def is_personal_memory_summary_request(
    text: str, participants: list[dict[str, Any]] | None = None
) -> bool:
    """Recognize broad person-history questions, not a lookup about an event/topic."""
    match = _PROFILE_PROMPT_RE.search(text)
    if not match:
        return False
    subject = " ".join(match.group(1).casefold().split()).strip(" ,:;'“”\"")
    if subject in {"me", "myself", "us", "you", "yourself", "him", "her", "them"}:
        return True
    if re.fullmatch(r"<@!?\d+>", subject):
        return True
    if re.match(r"(?:the\s+)?(?:last|latest|previous|most\s+recent)\s+(?:call|conversation|chat|topic)", subject):
        return False
    if participants:
        return any(
            isinstance(row, dict)
            and str(row.get("name", "")).strip()
            and re.search(rf"\b{re.escape(str(row['name']).strip())}\b", subject, re.IGNORECASE)
            for row in participants
        )
    return len(subject.split()) <= 4 and subject not in {"the call", "our call", "this", "that"}


def resolve_memory_subject(
    text: str,
    *,
    current_user_id: str,
    current_display_name: str,
    participants: list[dict[str, Any]],
) -> dict[str, str] | None:
    """Resolve a recall question's person from conversational role and participants."""
    if _SELF_ABOUT_RE.search(text):
        return {"user_id": str(current_user_id), "name": str(current_display_name)}

    mention = re.search(r"<@!?(\d+)>", text)
    if mention:
        user_id = f"discord:{mention.group(1)}"
        match = next((row for row in participants if str(row.get("user_id")) == user_id), None)
        return {"user_id": user_id, "name": str(match.get("name", "")) if match else user_id}

    # Only treat a participant name as the recall target when it follows a
    # subject relation. A name elsewhere may be a vocative, not the person asked about.
    for participant in sorted(
        (row for row in participants if isinstance(row, dict)),
        key=lambda row: len(str(row.get("name", ""))),
        reverse=True,
    ):
        name = str(participant.get("name", "")).strip()
        user_id = str(participant.get("user_id", "")).strip()
        if not name or not user_id:
            continue
        relation = rf"\b(?:about|of|regarding|profile\s+of)\s+{re.escape(name)}\b"
        if re.search(relation, text, re.IGNORECASE):
            return {"user_id": user_id, "name": name}

    return None
