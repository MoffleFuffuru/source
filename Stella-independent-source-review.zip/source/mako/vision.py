from __future__ import annotations

import base64
import ctypes
import io
import threading
import time
from dataclasses import dataclass
from typing import Callable

from PIL import Image, ImageGrab

from .core import MakoCore
from .models import ConversationEvent, EventSource, InteractionMode, ResponseResult


@dataclass(frozen=True, slots=True)
class ScreenSnapshot:
    active_window: str
    jpeg_base64: str
    signature: bytes


class VisionObserver:
    """View-only screen observer. It has no input, shell, or window-control methods."""

    def __init__(
        self,
        core: MakoCore,
        on_response: Callable[[ResponseResult], None],
        on_status: Callable[[str], None],
        can_comment: Callable[[], bool] | None = None,
    ) -> None:
        self.core = core
        self.on_response = on_response
        self.on_status = on_status
        self.can_comment = can_comment or (lambda: True)
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._last_signature: bytes | None = None
        self._last_comment = 0.0

    def start(self) -> None:
        if not self.core.config.vision.enabled or not self.core.config.vision.passive_enabled:
            return
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def _loop(self) -> None:
        while not self._stop.wait(self.core.config.vision.poll_seconds):
            try:
                if not self.can_comment():
                    continue
                snapshot = self._capture()
                if snapshot is None:
                    continue
                if self._last_signature is None:
                    self._last_signature = snapshot.signature
                    continue
                novelty = self._novelty(snapshot.signature)
                self._last_signature = snapshot.signature
                if novelty < self.core.config.vision.novelty_threshold:
                    continue
                if (
                    time.monotonic() - self._last_comment
                    < self.core.config.vision.minimum_comment_interval_seconds
                ):
                    continue
                analysis = self.core.analyze_screen(
                    snapshot.jpeg_base64,
                    snapshot.active_window,
                )
                if not analysis:
                    continue
                confidence = float(analysis.get("confidence", 0.0))
                if not analysis.get("worth_commenting") or confidence < self.core.config.vision.minimum_confidence:
                    continue
                fact = {
                    "active_app": str(analysis.get("active_app", "")),
                    "activity": str(analysis.get("activity", "")),
                    "notable_change": str(analysis.get("notable_change", "")),
                    "comment_focus": str(analysis.get("comment_focus", "")),
                    "confidence": confidence,
                }
                event = ConversationEvent(
                    content=f"Private view-only screen observation: {fact}",
                    source=EventSource.VISION,
                    mode=InteractionMode.PASSIVE,
                    metadata={"active_window": snapshot.active_window, "analysis": fact},
                )
                result = self.core.respond(event)
                if result.text:
                    self._last_comment = time.monotonic()
                    self.on_response(result)
            except Exception as exc:
                self.on_status(f"vision paused: {exc}")
                if self._stop.wait(30.0):
                    return

    def _capture(self) -> ScreenSnapshot | None:
        title = self._active_window_title()
        lowered = title.lower()
        if any(term.lower() in lowered for term in self.core.config.vision.denied_window_terms):
            self.on_status("vision paused for a private window")
            return None
        image = ImageGrab.grab(all_screens=True)
        signature_image = image.convert("L").resize((32, 18), Image.Resampling.BILINEAR)
        signature = signature_image.tobytes()
        buffer = io.BytesIO()
        image.thumbnail((1280, 720), Image.Resampling.LANCZOS)
        image.convert("RGB").save(buffer, format="JPEG", quality=78, optimize=True)
        return ScreenSnapshot(
            active_window=title,
            jpeg_base64=base64.b64encode(buffer.getvalue()).decode("ascii"),
            signature=signature,
        )

    def _novelty(self, signature: bytes) -> float:
        if self._last_signature is None or len(self._last_signature) != len(signature):
            return 1.0
        difference = sum(abs(left - right) for left, right in zip(self._last_signature, signature))
        return difference / (len(signature) * 255.0)

    @staticmethod
    def _active_window_title() -> str:
        user32 = ctypes.windll.user32
        handle = user32.GetForegroundWindow()
        length = user32.GetWindowTextLengthW(handle)
        buffer = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(handle, buffer, length + 1)
        return buffer.value.strip()
