from __future__ import annotations

import logging
import queue
import threading
import time
from collections import deque
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

LOG = logging.getLogger(__name__)


@dataclass(slots=True)
class AffectState:
    emotion2vec: dict[str, Any] | None = None
    experimental: dict[str, Any] | None = None
    prosody: dict[str, float] | None = None
    updated_at: float = 0.0

    def compact(self, *, max_age_seconds: float = 10.0) -> str:
        parts: list[str] = []
        # Do not let a prior utterance's affect bias a much later reply.
        # updated_at is the audio-capture timestamp, not inference completion.
        if self.updated_at > 0 and time.time() - self.updated_at > max_age_seconds:
            return ""
        # The auxiliary Wav2Vec2 head scored poorly in a balanced CREMA-D
        # probe; retain its output for diagnostics but never let it steer a
        # live reply unless a future evaluation validates it.
        result = self.emotion2vec
        if result and result.get("label") and result.get("confidence", 0) >= 0.38:
            parts.append(f"emotion2vec+ base: {result['label']} ({result['confidence']:.2f})")
        if self.prosody:
            if self.prosody.get("energy", 0) >= 0.72:
                parts.append("prosody: high vocal energy")
            elif self.prosody.get("energy", 0) <= 0.22:
                parts.append("prosody: soft/low vocal energy")
            if self.prosody.get("pace", 0) >= 0.72:
                parts.append("prosody: fast pace")
            elif self.prosody.get("pace", 0) <= 0.22:
                parts.append("prosody: slow pace")
        return "; ".join(parts)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class LiveAffectAnalyzer:
    """Background audio sidecar; bounded queue means it never backpressures STT."""

    BASE_MODEL = "iic/emotion2vec_plus_base"
    EXPERIMENTAL_MODEL = "superb/wav2vec2-base-superb-er"

    def __init__(
        self,
        cache_dir: Path,
        *,
        enabled: bool = True,
        experimental: bool = True,
        window_seconds: float = 3.0,
    ) -> None:
        self.cache_dir = cache_dir
        self.enabled = enabled
        self.experimental_enabled = experimental
        self.window_samples = max(24_000, int(max(1.5, window_seconds) * 16_000))
        self._queue: queue.Queue[tuple[str, Any, float] | None] = queue.Queue(maxsize=1)
        self._lock = threading.RLock()
        self._samples: dict[str, deque[Any]] = {}
        self._states: dict[str, AffectState] = {}
        self._last_submit: dict[str, float] = {}
        self._partial_text: dict[str, str] = {}
        self._partial_progress: dict[str, tuple[int, float]] = {}
        self._pace_scores: dict[str, float] = {}
        self._thread: threading.Thread | None = None
        self._stopping = threading.Event()
        self._base_model = None
        self._experimental_model = None
        self._experimental_extractor = None
        self._load_errors: list[str] = []

    def start(self) -> None:
        if not self.enabled or (self._thread and self._thread.is_alive()):
            return
        self._stopping.clear()
        self._thread = threading.Thread(target=self._run, name="stella-live-affect", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stopping.set()
        try:
            self._queue.put_nowait(None)
        except queue.Full:
            pass
        if self._thread and self._thread is not threading.current_thread():
            self._thread.join(timeout=2.0)
        self._thread = None

    def set_partial_text(self, speaker_id: str, text: str) -> None:
        key = str(speaker_id)
        clean = text.strip()
        now = time.monotonic()
        with self._lock:
            self._partial_text[key] = clean
            words = len(clean.split())
            previous = self._partial_progress.get(key)
            if previous is not None and words > previous[0]:
                word_delta = words - previous[0]
                elapsed = max(0.15, now - previous[1])
                words_per_minute = word_delta * 60.0 / elapsed
                # Map conversational speech rates (roughly 80–220 wpm) onto
                # the same 0..1 scale used by the compact prosody summary.
                observed = max(0.0, min(1.0, (words_per_minute - 80.0) / 140.0))
                old = self._pace_scores.get(key, 0.5)
                self._pace_scores[key] = old * 0.35 + observed * 0.65
            self._partial_progress[key] = (words, now)

    def push_audio(self, speaker_id: str, samples: Any, sample_rate: int) -> None:
        if not self.enabled or self._stopping.is_set():
            return
        try:
            import numpy as np
            audio = np.asarray(samples, dtype=np.float32).reshape(-1)
            if audio.size == 0:
                return
            if sample_rate != 16000:
                size = max(1, round(audio.size * 16000 / sample_rate))
                audio = np.interp(np.linspace(0, audio.size - 1, size), np.arange(audio.size), audio).astype(np.float32)
            key = str(speaker_id)
            with self._lock:
                chunks = self._samples.setdefault(key, deque(maxlen=80))
                chunks.append(audio.copy())
                now = time.monotonic()
                if sum(chunk.size for chunk in chunks) < 24000 or now - self._last_submit.get(key, 0) < 0.9:
                    return
                self._last_submit[key] = now
                window = np.concatenate(list(chunks))[-self.window_samples :].copy()
                prosody = self._prosody(window)
                prosody["pace"] = self._pace_scores.get(key, 0.5)
                captured_at = time.time()
                self._states[key] = AffectState(prosody=prosody, updated_at=captured_at)
            try:
                self._queue.put_nowait((key, window, captured_at))
            except queue.Full:
                try:
                    self._queue.get_nowait()
                except queue.Empty:
                    pass
                try:
                    self._queue.put_nowait((key, window, captured_at))
                except queue.Full:
                    pass
        except Exception:
            LOG.debug("Live affect audio enqueue failed", exc_info=True)

    def snapshot(self, speaker_id: str = "owner") -> AffectState:
        with self._lock:
            state = self._states.get(str(speaker_id))
            return AffectState(**state.to_dict()) if state else AffectState()

    def status(self) -> dict[str, Any]:
        return {"enabled": self.enabled, "base_loaded": self._base_model is not None,
                "experimental_loaded": self._experimental_model is not None,
                "errors": list(self._load_errors)}

    def _load_models(self) -> None:
        if self._base_model is None:
            try:
                from funasr import AutoModel
                self._base_model = AutoModel(
                    model=self.BASE_MODEL, hub="hf", device="cpu",
                    cache_dir=str(self.cache_dir / "emotion2vec")
                )
                LOG.info("Loaded emotion2vec+ base affect classifier")
            except Exception as exc:
                self._load_errors.append(f"emotion2vec+ base unavailable: {exc}")
                LOG.warning("emotion2vec+ base unavailable; install funasr to enable it: %s", exc)
        if self.experimental_enabled and self._experimental_model is None:
            try:
                import torch
                from transformers import AutoFeatureExtractor, AutoModelForAudioClassification
                name = self.EXPERIMENTAL_MODEL
                self._experimental_extractor = AutoFeatureExtractor.from_pretrained(name, cache_dir=str(self.cache_dir / "hf"))
                self._experimental_model = AutoModelForAudioClassification.from_pretrained(name, cache_dir=str(self.cache_dir / "hf")).eval()
                if torch.cuda.is_available():
                    self._experimental_model.to("cuda")
                LOG.info("Loaded experimental Wav2Vec2 emotion classifier")
            except Exception as exc:
                self._load_errors.append(f"experimental Wav2Vec2 classifier unavailable: {exc}")
                LOG.warning("Experimental emotion classifier unavailable: %s", exc)

    def _run(self) -> None:
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._load_models()
        while not self._stopping.is_set():
            try:
                item = self._queue.get(timeout=0.25)
            except queue.Empty:
                continue
            if item is None:
                break
            speaker_id, audio, captured_at = item
            prosody = self._prosody(audio)
            with self._lock:
                prosody["pace"] = self._pace_scores.get(speaker_id, 0.5)
            state = AffectState(prosody=prosody, updated_at=captured_at)
            if self._base_model is not None:
                try:
                    state.emotion2vec = self._classify_emotion2vec(audio)
                except Exception as exc:
                    LOG.warning("emotion2vec inference failed: %s", exc)
            if self._experimental_model is not None:
                try:
                    state.experimental = self._classify_experimental(audio)
                except Exception as exc:
                    LOG.warning("experimental emotion inference failed: %s", exc)
            with self._lock:
                self._states[speaker_id] = state

    @staticmethod
    def _prosody(audio: Any) -> dict[str, float]:
        import numpy as np
        rms = float(np.sqrt(np.mean(np.square(audio)))) if len(audio) else 0.0
        peak = float(np.max(np.abs(audio))) if len(audio) else 0.0
        return {"energy": max(0.0, min(1.0, rms / 0.16)), "peak": max(0.0, min(1.0, peak)), "pace": 0.5}

    def _classify_emotion2vec(self, audio: Any) -> dict[str, Any] | None:
        import soundfile as sf
        import tempfile
        with tempfile.NamedTemporaryFile(suffix=".wav", dir=self.cache_dir, delete=False) as file:
            path = Path(file.name)
        try:
            sf.write(path, audio, 16000)
            output = self._base_model.generate(
                input=str(path), output_dir=str(self.cache_dir / "output"),
                granularity="utterance", extract_embedding=False,
            )
            return self._top_result(output)
        finally:
            path.unlink(missing_ok=True)

    def _classify_experimental(self, audio: Any) -> dict[str, Any] | None:
        import torch
        inputs = self._experimental_extractor(audio, sampling_rate=16000, return_tensors="pt", padding=True)
        device = next(self._experimental_model.parameters()).device
        inputs = {key: value.to(device) for key, value in inputs.items()}
        with torch.inference_mode():
            scores = self._experimental_model(**inputs).logits.softmax(-1)[0]
        index = int(scores.argmax().item())
        labels = self._experimental_model.config.id2label
        return {"label": _normalize_emotion_label(labels.get(index, index)), "confidence": float(scores[index].item())}

    @staticmethod
    def _top_result(output: Any) -> dict[str, Any] | None:
        if not output:
            return None
        result = output[0] if isinstance(output, list) else output
        labels, scores = result.get("labels"), result.get("scores")
        if hasattr(labels, "tolist"):
            labels = labels.tolist()
        if hasattr(scores, "tolist"):
            scores = scores.tolist()
        if isinstance(scores, list) and scores and isinstance(scores[0], list):
            scores = scores[0]
        if isinstance(labels, list) and labels:
            if isinstance(scores, list) and scores:
                index = max(range(min(len(labels), len(scores))), key=lambda item: float(scores[item]))
                return {"label": _normalize_emotion_label(labels[index]), "confidence": float(scores[index])}
            return {"label": _normalize_emotion_label(labels[0]), "confidence": 0.0}
        return None


def _normalize_emotion_label(value: Any) -> str:
    """Normalize the two local speech models' label formats for prompting."""
    import re

    label = str(value).strip().casefold()
    # emotion2vec uses bilingual labels (Chinese/English); Wav2Vec2 SUPERB
    # uses short tags such as hap, neu, and ang.
    label = label.rsplit("/", 1)[-1].strip()
    label = re.sub(r"[^a-z]+", " ", label).strip()
    aliases = {
        "ang": "angry", "anger": "angry", "angry": "angry",
        "dis": "disgusted", "disgust": "disgusted", "disgusted": "disgusted",
        "fea": "fearful", "fear": "fearful", "fearful": "fearful",
        "hap": "happy", "happiness": "happy", "happy": "happy",
        "neu": "neutral", "neutral": "neutral",
        "sad": "sad", "sadness": "sad",
        "sur": "surprised", "surprise": "surprised", "surprised": "surprised",
        "other": "uncertain", "unk": "uncertain", "unknown": "uncertain",
    }
    return aliases.get(label, "uncertain")
