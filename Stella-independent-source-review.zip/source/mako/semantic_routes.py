"""Small, deliberately separated conversational acts for local semantic routing."""

ROUTES = {
    "accept_compliment": ["thanks, i try", "glad you think so", "that was the point"],
    "correction": ["we are already talking", "you got that backwards", "that is not what i said"],
    "praise_response": ["excellent response, good job", "i am proud of you", "that was really good"],
    "playful_threat": ["i am deleting you", "stay out of my files", "i will uninstall you"],
    "technical_discussion": ["i am fixing your code", "this bug will not die", "spaghetti code everywhere"],
    "teasing": ["you little brat", "you are being dumb", "how dare you"],
    "affection_reassurance": ["i love you", "i missed you", "you are safe here", "you are adorable"],
    "agreement_acknowledgment": ["yeah that is fair", "that is true", "i agree with you", "sounds good"],
    "direct_question": ["how do you feel about me", "what are you doing", "do you trust me", "can you explain that"],
    "leave_return": ["i am back", "i will be right back", "goodnight mako", "bye for now"],
    "relationship_reflection": ["are we close", "do you remember that", "do you think about me", "do you feel familiar with me"],
    "playful_boundary": ["stop calling me that", "leave my keyboard alone", "do not call me code", "quit being evasive"],
    "emotional_disclosure": ["i had a rough day", "i am exhausted from work", "today was awful", "i feel overwhelmed"],
    "call_invitation": ["wanna call", "can we call", "call me when you can", "want to talk on a call"],
    "feedback_or_test": ["i am testing you", "that answer was good", "you are repeating yourself", "i am checking if this works"],
    "topic_boundary": ["i do not want to do that", "stop suggesting things", "not right now", "leave that topic alone"],
    "clarification_repair": ["what do you mean", "say that again", "i did not hear you", "can you explain that"],
    "shared_work_update": ["i am working on you", "i am fixing your call model", "i changed your architecture", "i am improving your code"],
    "availability_check": ["are you still there", "are you there mako", "stay with me", "are you here with me"],
}
