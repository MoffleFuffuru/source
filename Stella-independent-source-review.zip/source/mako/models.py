from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any
from uuid import uuid4


class EventSource(StrEnum):
    DESKTOP = "desktop"
    VOICE_CALL = "voice_call"
    DISCORD = "discord"
    VISION = "vision"
    SYSTEM = "system"


class Visibility(StrEnum):
    PRIVATE = "private"
    PUBLIC = "public"


class InteractionMode(StrEnum):
    TEXT = "text"
    CALL = "call"
    PASSIVE = "passive"


class Expression(StrEnum):
    NEUTRAL = "neutral"
    HAPPY = "happy"
    SMUG = "smug"
    SLEEPY = "sleepy"
    ANNOYED = "annoyed"
    EMBARRASSED = "embarrassed"
    CONCERNED = "concerned"
    EXCITED = "excited"


@dataclass(slots=True)
class ConversationEvent:
    content: str
    source: EventSource = EventSource.DESKTOP
    mode: InteractionMode = InteractionMode.TEXT
    visibility: Visibility = Visibility.PRIVATE
    user_id: str = "owner"
    display_name: str = "user"
    channel_id: str = "desktop"
    reply_to: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: uuid4().hex)
    created_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class ResponseCandidate:
    text: str
    respond: bool = True
    floor_action: str = "yield"
    addressee: str = "unclear"
    addressee_name: str = ""
    social_act: str = "unclear"
    address_confidence: float = 0.0
    expression: Expression = Expression.NEUTRAL
    move: str = "respond"
    complexity: int = 2
    confidence: float = 0.7
    mood_delta: dict[str, float] = field(default_factory=dict)
    relationship_delta: dict[str, float] = field(default_factory=dict)
    # Renderer-neutral directions selected by the dialogue model. The body
    # controller validates every value before a renderer ever sees it.
    acting: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class QualityReport:
    score: float
    blocking_issues: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    evidence: list[str] = field(default_factory=list)

    @property
    def accepted(self) -> bool:
        return not self.blocking_issues


@dataclass(slots=True)
class Critique:
    accepted: bool
    score: float
    failures: list[str] = field(default_factory=list)
    evidence: list[str] = field(default_factory=list)
    repair_direction: str = ""


@dataclass(slots=True)
class ResponseResult:
    turn_id: str
    event_id: str
    text: str
    expression: Expression
    move: str
    complexity: int
    mood_delta: dict[str, float]
    relationship_delta: dict[str, float]
    score: float
    repaired: bool
    attempts: int
    model: str
    generation_seconds: float
    acting: dict[str, Any] = field(default_factory=dict)
    trace: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class OutboundCallPlan:
    greeting: str
    opener: str
    reason: str
    memory_basis: str
    expression: Expression = Expression.NEUTRAL


@dataclass(frozen=True, slots=True)
class DiscordAutonomyDecision:
    action: str
    message_id: str = ""
    text: str = ""
    expression: Expression = Expression.NEUTRAL
    model: str = ""
    generation_seconds: float = 0.0
