from __future__ import annotations

import asyncio
import base64
import json
import logging
import os
import queue
import threading
import time
import wave
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from .config import VoiceConfig
from .voice import VoiceUnavailable


LOG = logging.getLogger(__name__)
SAMPLE_RATE = 24000


@dataclass(frozen=True, slots=True)
class XaiVoiceCallbacks:
    on_state: Callable[[str], None]
    on_turn: Callable[[str, str, float, float], None]
    on_error: Callable[[str], None]


class XaiRealtimeVoiceSession:
    """Own a single xAI speech-to-speech call without touching the local pipeline."""

    def __init__(
        self, config: VoiceConfig, callbacks: XaiVoiceCallbacks, *, capture_microphone: bool = True
    ) -> None:
        self.config = config
        self.callbacks = callbacks
        self.capture_microphone = capture_microphone
        self._stop = threading.Event()
        self._ready = threading.Event()
        self._thread: threading.Thread | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._websocket = None
        self._input: asyncio.Queue[bytes | None] | None = None
        self._output: queue.Queue[bytes] = queue.Queue(maxsize=256)
        self._output_buffer = bytearray()
        self._output_lock = threading.Lock()
        self._output_frames = 0
        self._output_played = False
        self._response_audio = bytearray()
        self._speaking_until = 0.0
        self._latest_user_text = ""
        self._response_text = ""
        self._response_started_at = 0.0
        self._input_frames = 0
        self._input_peak = 0.0
        self._input_stream = None
        self._output_stream = None
        self._output_thread: threading.Thread | None = None

    def start(self, instructions: str, opening_text: str) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(
            target=self._thread_main,
            args=(instructions, opening_text),
            daemon=True,
            name="mako-xai-realtime-voice",
        )
        self._thread.start()

    def submit_text(self, text: str) -> bool:
        clean = text.strip()
        if not clean or not self._ready.is_set() or not self._loop:
            return False
        asyncio.run_coroutine_threadsafe(self._send_text(clean), self._loop)
        return True

    def stop(self) -> None:
        self._stop.set()
        if self._loop:
            self._loop.call_soon_threadsafe(self._queue_stop)
        if self._thread and self._thread is not threading.current_thread():
            self._thread.join(timeout=2.0)

    def _thread_main(self, instructions: str, opening_text: str) -> None:
        try:
            asyncio.run(self._run(instructions, opening_text))
        except Exception as exc:
            if not self._stop.is_set():
                LOG.exception("xAI realtime voice failed")
                self.callbacks.on_error(f"xAI realtime voice failed: {exc}")
        finally:
            self._ready.clear()
            self._close_audio()

    async def _run(self, instructions: str, opening_text: str) -> None:
        try:
            import aiohttp
            import numpy as np
            import sounddevice as sd
        except ImportError as exc:
            raise VoiceUnavailable("xAI realtime calls need aiohttp, numpy, and sounddevice.") from exc

        api_key = os.getenv(self.config.xai_voice_api_key_environment_variable, "").strip()
        if not api_key:
            raise VoiceUnavailable(
                f"Set {self.config.xai_voice_api_key_environment_variable} before using xAI realtime calls."
            )

        self._loop = asyncio.get_running_loop()
        self._input = asyncio.Queue(maxsize=96)
        headers = {"Authorization": f"Bearer {api_key}"}
        url = f"wss://api.x.ai/v1/realtime?model={self.config.xai_voice_model}"
        timeout = aiohttp.ClientTimeout(total=None, sock_connect=20, sock_read=None)
        turn_detection = (
            {
                "type": "server_vad",
                # xAI defaults to 0.85, which misses this microphone's
                # normal conversational level. 0.1 is its documented floor.
                "threshold": 0.1,
                "silence_duration_ms": self.config.xai_voice_silence_duration_ms,
                "prefix_padding_ms": 250,
                "create_response": True,
            }
            if self.capture_microphone
            else None
        )
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.ws_connect(url, headers=headers, max_msg_size=0) as websocket:
                self._websocket = websocket
                await websocket.send_json(
                    {
                        "type": "session.update",
                        "session": {
                            "voice": self.config.xai_voice_name,
                            "instructions": instructions,
                            "reasoning": {"effort": "none"},
                            "turn_detection": turn_detection,
                            "audio": {
                                "input": {
                                    "format": {"type": "audio/pcm", "rate": SAMPLE_RATE},
                                    "transcription": {
                                        "model": "grok-transcribe",
                                        "language_hint": "en",
                                        "keyterms": ["Stella", "Moffle", "Kyutai", "Grok", "Discord"],
                                    },
                                },
                                "output": {
                                    "format": {"type": "audio/pcm", "rate": SAMPLE_RATE},
                                },
                            },
                        },
                    }
                )
                # xAI applies audio transport settings asynchronously. Sending PCM before
                # this acknowledgement can silently leave the server on its JSON path.
                while True:
                    configured = await asyncio.wait_for(websocket.receive(), timeout=12.0)
                    if configured.type is aiohttp.WSMsgType.TEXT:
                        event = json.loads(configured.data)
                        self._handle_event(event)
                        if event.get("type") == "session.updated":
                            break
                    elif configured.type in {aiohttp.WSMsgType.ERROR, aiohttp.WSMsgType.CLOSED}:
                        raise VoiceUnavailable("xAI realtime session closed during setup.")
                self._open_audio(sd, np)
                self._ready.set()
                self.callbacks.on_state("xAI voice connected")
                sender = asyncio.create_task(self._send_audio(websocket)) if self.capture_microphone else None
                await self._send_text(opening_text, websocket)
                try:
                    async for message in websocket:
                        if self._stop.is_set():
                            break
                        if message.type is aiohttp.WSMsgType.BINARY:
                            self._queue_output(bytes(message.data))
                        elif message.type is aiohttp.WSMsgType.TEXT:
                            self._handle_event(json.loads(message.data))
                        elif message.type in {aiohttp.WSMsgType.ERROR, aiohttp.WSMsgType.CLOSED}:
                            break
                finally:
                    if sender is not None:
                        await self._stop_sender(sender)

    async def _send_text(self, text: str, websocket=None) -> None:
        websocket = websocket or self._websocket
        if websocket is None:
            return
        self._latest_user_text = text
        await websocket.send_json(
            {
                "type": "conversation.item.create",
                "item": {
                    "type": "message",
                    "role": "user",
                    "content": [{"type": "input_text", "text": text}],
                },
            }
        )
        await websocket.send_json({"type": "response.create"})

    async def _send_audio(self, websocket) -> None:
        assert self._input is not None
        while not self._stop.is_set():
            payload = await self._input.get()
            if payload is None:
                return
            # Realtime audio input is a JSON append event, not a raw WebSocket
            # binary frame. The latter opens successfully but is ignored by VAD.
            await websocket.send_json(
                {
                    "type": "input_audio_buffer.append",
                    "audio": base64.b64encode(payload).decode("ascii"),
                }
            )
            if self._input_frames == 1:
                LOG.info("xAI realtime first microphone frame sent to server")

    async def _stop_sender(self, sender: asyncio.Task[None]) -> None:
        self._queue_stop()
        try:
            await asyncio.wait_for(sender, timeout=1.0)
        except (asyncio.TimeoutError, asyncio.CancelledError):
            sender.cancel()

    def _queue_stop(self) -> None:
        if self._input and not self._input.full():
            self._input.put_nowait(None)

    def _open_audio(self, sounddevice, numpy) -> None:
        def input_callback(indata, _frames, _time_info, _status) -> None:
            if self._stop.is_set() or time.monotonic() < self._speaking_until:
                return
            pcm = numpy.clip(indata[:, 0], -1.0, 1.0)
            peak = float(numpy.max(numpy.abs(pcm))) if len(pcm) else 0.0
            self._input_peak = max(self._input_peak, peak)
            payload = (pcm * 32767).astype("<i2").tobytes()
            loop = self._loop
            if loop:
                loop.call_soon_threadsafe(self._queue_input, payload)

        def play_output() -> None:
            # Match Mako's established TTS path: write PCM directly instead of
            # relying on a callback buffer that can underrun under WebSocket load.
            with sounddevice.OutputStream(
                samplerate=SAMPLE_RATE,
                channels=1,
                dtype="float32",
                blocksize=960,
            ) as stream:
                self._output_stream = stream
                while not self._stop.is_set():
                    try:
                        chunk = self._output.get(timeout=0.2)
                    except queue.Empty:
                        continue
                    samples = numpy.frombuffer(chunk, dtype="<i2").astype("float32") / 32768.0
                    if samples.size:
                        stream.write(samples.reshape(-1, 1))
                        if not self._output_played:
                            self._output_played = True
                            LOG.info("xAI realtime audio reached local speaker bytes=%s", len(chunk))

        self._input_stream = sounddevice.InputStream(
            samplerate=SAMPLE_RATE,
            channels=1,
            dtype="float32",
            blocksize=960,
            device=self.config.input_device,
            callback=input_callback,
        )
        LOG.info("xAI realtime microphone opened device=%s rate=%s", self.config.input_device, SAMPLE_RATE)
        if self.capture_microphone:
            self._input_stream.start()
        self._output_thread = threading.Thread(target=play_output, daemon=True, name="mako-xai-speaker")
        self._output_thread.start()

    def _close_audio(self) -> None:
        for stream in (self._input_stream, self._output_stream):
            if stream is not None:
                try:
                    stream.stop()
                    stream.close()
                except Exception:
                    pass
        self._input_stream = None
        self._output_stream = None
        thread = self._output_thread
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=0.5)
        self._output_thread = None
        self._websocket = None
        self._loop = None

    def _queue_input(self, payload: bytes) -> None:
        if self._input and not self._input.full():
            self._input.put_nowait(payload)
            self._input_frames += 1
            if self._input_frames == 1:
                LOG.info("xAI realtime microphone frames are sending")
            elif self._input_frames % 100 == 0:
                LOG.info("xAI realtime microphone peak=%.3f", self._input_peak)
                self._input_peak = 0.0

    def _queue_output(self, payload: bytes) -> None:
        # Keep the mic muted through the actual queued PCM, not a fixed grace
        # period, so Mako never treats her own voice as caller audio.
        duration = len(payload) / (SAMPLE_RATE * 2)
        self._speaking_until = max(self._speaking_until, time.monotonic()) + duration
        self._response_audio.extend(payload)
        self._output_frames += 1
        if self._output_frames == 1:
            LOG.info(
                "xAI realtime first audio seconds=%.3f bytes=%s",
                max(0.0, time.monotonic() - self._response_started_at),
                len(payload),
            )
        try:
            self._output.put_nowait(payload)
        except queue.Full:
            LOG.warning("xAI realtime audio queue overflow")

    def _handle_event(self, event: dict) -> None:
        event_type = str(event.get("type", ""))
        if event_type.startswith("input_audio_buffer.") or event_type == "error":
            LOG.info("xAI realtime event=%s", event_type)
        if event_type == "conversation.item.input_audio_transcription.updated":
            self._latest_user_text = str(event.get("transcript", "")).strip() or self._latest_user_text
            LOG.info("xAI realtime transcript updated chars=%s", len(self._latest_user_text))
        elif event_type == "conversation.item.input_audio_transcription.completed":
            self._latest_user_text = str(event.get("transcript", "")).strip() or self._latest_user_text
            LOG.info("xAI realtime transcript completed chars=%s", len(self._latest_user_text))
        elif event_type == "response.output_audio.delta":
            encoded = str(event.get("delta", ""))
            if encoded:
                try:
                    self._queue_output(base64.b64decode(encoded))
                except ValueError:
                    LOG.warning("xAI realtime received invalid audio delta")
        elif event_type in {"response.output_audio_transcript.delta", "response.audio_transcript.delta"}:
            self._response_text += str(event.get("delta", ""))
        elif event_type in {"response.output_audio_transcript.done", "response.audio_transcript.done"}:
            self._response_text = str(event.get("transcript", "")).strip() or self._response_text
        elif event_type == "response.created":
            self._response_text = ""
            self._response_audio.clear()
            self._output_frames = 0
            self._response_started_at = time.monotonic()
            self.callbacks.on_state("thinking")
        elif event_type == "response.done":
            self._save_response_audio()
            text = self._response_text.strip()
            user_text = self._latest_user_text.strip()
            if text and user_text:
                elapsed = max(0.0, time.monotonic() - self._response_started_at)
                remaining_audio = max(0.0, self._speaking_until - time.monotonic())
                self.callbacks.on_turn(user_text, text, elapsed, remaining_audio)
                LOG.info("xAI realtime turn completed seconds=%.3f", elapsed)
            self._response_text = ""
            self.callbacks.on_state("call connected")

    def _save_response_audio(self) -> None:
        if not self._response_audio:
            LOG.warning("xAI realtime response completed without captured audio")
            return
        path = Path("data/logs/xai-last-response.wav")
        path.parent.mkdir(parents=True, exist_ok=True)
        with wave.open(str(path), "wb") as output:
            output.setnchannels(1)
            output.setsampwidth(2)
            output.setframerate(SAMPLE_RATE)
            output.writeframes(self._response_audio)
        LOG.info("xAI realtime saved response audio bytes=%s path=%s", len(self._response_audio), path)


async def render_xai_voice_wav(config: VoiceConfig, text: str, destination: Path) -> None:
    """Render an already-written Discord reply with xAI Voice into a WAV file.

    Discord owns its own STT and conversation pipeline.  A force message makes
    xAI act only as a speech renderer, so it cannot change the reply text.
    """
    clean = text.strip()
    if not clean:
        raise VoiceUnavailable("Cannot synthesize an empty Discord voice reply.")
    try:
        import aiohttp
    except ImportError as exc:
        raise VoiceUnavailable("xAI Discord voice needs aiohttp.") from exc

    api_key = os.getenv(config.xai_voice_api_key_environment_variable, "").strip()
    if not api_key:
        raise VoiceUnavailable(
            f"Set {config.xai_voice_api_key_environment_variable} before using xAI voice."
        )

    timeout = aiohttp.ClientTimeout(total=45, sock_connect=20, sock_read=30)
    url = f"wss://api.x.ai/v1/realtime?model={config.xai_voice_model}"
    audio = bytearray()
    started = time.monotonic()
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.ws_connect(
            url,
            headers={"Authorization": f"Bearer {api_key}"},
            max_msg_size=0,
        ) as websocket:
            await websocket.send_json(
                {
                    "type": "session.update",
                    "session": {
                        "voice": config.xai_voice_name,
                        "instructions": "Speak the supplied text naturally. Do not add, remove, or change words.",
                        "reasoning": {"effort": "none"},
                        "audio": {
                            "output": {
                                "format": {"type": "audio/pcm", "rate": SAMPLE_RATE},
                                "transport": "json",
                            }
                        },
                    },
                }
            )
            while True:
                message = await asyncio.wait_for(websocket.receive(), timeout=12.0)
                if message.type is aiohttp.WSMsgType.TEXT:
                    event = json.loads(message.data)
                    if event.get("type") == "session.updated":
                        break
                    if event.get("type") == "error":
                        raise VoiceUnavailable(str(event.get("error", event)))
                elif message.type in {aiohttp.WSMsgType.ERROR, aiohttp.WSMsgType.CLOSED}:
                    raise VoiceUnavailable("xAI voice session closed during setup.")

            await websocket.send_json(
                {
                    "type": "conversation.item.create",
                    "item": {
                        "type": "force_message",
                        "content": [{"type": "input_text", "text": clean}],
                        "interruptible": False,
                    },
                }
            )
            async for message in websocket:
                if message.type is aiohttp.WSMsgType.TEXT:
                    event = json.loads(message.data)
                    event_type = event.get("type")
                    if event_type == "response.output_audio.delta":
                        encoded = str(event.get("delta", ""))
                        if encoded:
                            audio.extend(base64.b64decode(encoded))
                    elif event_type == "error":
                        raise VoiceUnavailable(str(event.get("error", event)))
                    elif event_type == "response.done":
                        break
                elif message.type in {aiohttp.WSMsgType.ERROR, aiohttp.WSMsgType.CLOSED}:
                    break

    if not audio:
        raise VoiceUnavailable("xAI voice completed without audio.")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(destination), "wb") as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(SAMPLE_RATE)
        output.writeframes(audio)
    LOG.info("xAI Discord voice rendered seconds=%.3f bytes=%s", time.monotonic() - started, len(audio))
