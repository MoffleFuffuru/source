"""One authority for admission of spontaneous conversation turns."""
from __future__ import annotations
from .initiative import InitiativePolicy
from .intentions import IntentionBoard
from .living_state import LivingState
from .models import Intent

class SocialDirector:
    def __init__(self,policy:InitiativePolicy,board:IntentionBoard):self.policy=policy;self.board=board
    def select(self,state:LivingState,now:float,*,floor_available:bool=False)->Intent|None:
        if not self.policy.allowed(state,now,floor_available=floor_available):return None
        if any(item.status.value=='claimed' for item in self.board.items.values()):return None
        intent=self.board.best(now,visibility=state.session_visibility,active_people=state.active_people)
        if intent and self.board.claim(intent.id):return intent
        return None
    def mark_started(self,state:LivingState,now:float):self.policy.record(state,now)
    def mark_finished(self,intent_id:str,success:bool):self.board.finish(intent_id,success)
