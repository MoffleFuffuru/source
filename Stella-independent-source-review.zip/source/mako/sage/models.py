"""Shared SAGE contracts. All timestamps are UTC epoch seconds unless noted."""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any
import time, uuid

class EventKind(str, Enum):
    USER_SPEECH='user_speech'; USER_CHAT='user_chat'; USER_JOIN='user_join'
    USER_LEAVE='user_leave'; STELLA_SPEECH_START='stella_speech_start'
    STELLA_SPEECH_END='stella_speech_end'; USER_INTERRUPTION='user_interruption'
    TOPIC='topic'; MEMORY='memory'; TICK='tick'; AVATAR='avatar'

class IntentStatus(str, Enum):
    CANDIDATE='candidate'; READY='ready'; CLAIMED='claimed'
    COMPLETED='completed'; CANCELLED='cancelled'; EXPIRED='expired'

class CommitmentStatus(str, Enum):
    SUGGESTED='suggested'; INVITED='invited'; ACCEPTED='accepted'
    CONFIRMED='confirmed'; COMPLETED='completed'; CANCELLED='cancelled'; EXPIRED='expired'

@dataclass(slots=True)
class Event:
    kind: EventKind
    actor_id: str = ''
    text: str = ''
    data: dict[str, Any] = field(default_factory=dict)
    source_id: str = ''
    visibility: str = 'public'  # public/private
    occurred_at: float = field(default_factory=time.time)
    event_id: str = field(default_factory=lambda: uuid.uuid4().hex)

@dataclass(slots=True)
class Intent:
    summary: str
    kind: str = 'conversation'
    target_id: str = ''
    priority: float = 0.5
    evidence_ids: list[str] = field(default_factory=list)
    visibility: str = 'public'
    expires_at: float = 0.0
    status: IntentStatus = IntentStatus.CANDIDATE
    created_at: float = field(default_factory=time.time)
    id: str = field(default_factory=lambda: uuid.uuid4().hex)
    attempts: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass(slots=True)
class MemoryEvidence:
    id: str
    summary: str
    visibility: str = 'private'
    confidence: float = 1.0
    actor_id: str = ''
    occurred_at: float = 0.0

@dataclass(slots=True)
class MotionIntent:
    attention: str = 'ambient'
    affect: str = 'neutral'
    posture: str = 'relaxed_standing'
    gesture: str = ''
    engagement: float = 0.3
    duration_ms: int = 3000
    priority: int = 0

@dataclass(slots=True)
class Commitment:
    title: str
    participants: list[str]
    status: CommitmentStatus = CommitmentStatus.SUGGESTED
    due_at: float | None = None
    timezone: str = 'UTC'
    evidence_ids: list[str] = field(default_factory=list)
    visibility: str = 'private'
    id: str = field(default_factory=lambda: uuid.uuid4().hex)
    updated_at: float = field(default_factory=time.time)
    expires_at: float | None = None
    recurrence: str = ''
    last_reminded_at: float | None = None
