"""Explicit adapter for current RMA; no assumptions about the RMA API."""
from __future__ import annotations
from collections.abc import Callable
from .models import MemoryEvidence

class MemoryAdapter:
    def __init__(self,search:Callable[[str,int],list[MemoryEvidence]]|None=None):
        self._search=search
    def retrieve(self,query:str,limit:int=5,*,public_only:bool=True)->list[MemoryEvidence]:
        if not self._search:return []
        try:
            result=self._search(query,limit)
            return [x for x in result if isinstance(x,MemoryEvidence) and x.id and x.confidence>=0.5
                    and (not public_only or x.visibility=='public')][:limit]
        except Exception: return [] # fail closed: no unverified memories
