"""Bounded transport buffer, not a classifier of social value."""
from collections import deque


class StreamChatQueue:
    def __init__(self, capacity=128, per_actor=8):
        self.capacity = capacity
        self.per_actor = per_actor
        self.items = deque()
        self.dropped = 0

    def add(self, event_id, actor, name, text):
        key = text.strip().casefold()
        if any(item['actor'] == actor and item['text'].strip().casefold() == key for item in self.items):
            return
        own = [item for item in self.items if item['actor'] == actor]
        if len(own) >= self.per_actor:
            self.items.remove(own[0])
            self.dropped += 1
        if len(self.items) >= self.capacity:
            self.items.popleft()
            self.dropped += 1
        self.items.append({'id': event_id, 'actor': actor, 'name': name, 'text': text[:500]})

    def take(self, limit=24):
        # Round-robin sampling prevents one account consuming the whole model packet.
        groups = {}
        for item in self.items:
            groups.setdefault(item['actor'], deque()).append(item)
        selected = []
        while groups and len(selected) < limit:
            for actor in list(groups):
                selected.append(groups[actor].popleft())
                if not groups[actor]:
                    del groups[actor]
                if len(selected) == limit:
                    break
        self.items.clear()
        return selected
