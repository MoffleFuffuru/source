"""Fast deterministic session state, independent of LLM prompts."""
from __future__ import annotations
from dataclasses import dataclass, field
from .models import Event, EventKind

@dataclass
class LivingState:
    active_people: set[str] = field(default_factory=set)
    current_speaker: str = ''
    current_topic: str = ''
    last_human_at: float = 0.0
    last_stella_at: float = 0.0
    stella_speaking: bool = False
    human_speaking: bool = False
    session_visibility: str = 'public'
    recent_sage_speech: list[float] = field(default_factory=list)
    def apply(self, event: Event):
        k=event.kind
        if k == EventKind.USER_JOIN and event.actor_id: self.active_people.add(event.actor_id)
        elif k == EventKind.USER_LEAVE: self.active_people.discard(event.actor_id)
        elif k in (EventKind.USER_CHAT,EventKind.USER_SPEECH,EventKind.USER_INTERRUPTION):
            self.last_human_at=event.occurred_at
            self.current_speaker=event.actor_id
            self.human_speaking=(k!=EventKind.USER_CHAT)
        elif k==EventKind.STELLA_SPEECH_START:
            self.stella_speaking=True; self.last_stella_at=event.occurred_at
        elif k==EventKind.STELLA_SPEECH_END: self.stella_speaking=False
        elif k==EventKind.TOPIC: self.current_topic=event.text[:250]
        if k in (EventKind.USER_CHAT,EventKind.USER_SPEECH) and event.data.get('turn_finished'):
            self.human_speaking=False
    def quiet_for(self, now: float) -> float:
        return max(0.,now-max(self.last_human_at,self.last_stella_at))
