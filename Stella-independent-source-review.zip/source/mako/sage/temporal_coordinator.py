"""Commitment ledger. Confirmation requires evidence; no auto external actions."""
from __future__ import annotations
import time
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from .models import Commitment,CommitmentStatus

_ALLOWED={
 CommitmentStatus.SUGGESTED:{CommitmentStatus.INVITED,CommitmentStatus.CANCELLED},
 CommitmentStatus.INVITED:{CommitmentStatus.ACCEPTED,CommitmentStatus.CANCELLED},
 CommitmentStatus.ACCEPTED:{CommitmentStatus.CONFIRMED,CommitmentStatus.CANCELLED},
 CommitmentStatus.CONFIRMED:{CommitmentStatus.COMPLETED,CommitmentStatus.CANCELLED},
 CommitmentStatus.COMPLETED:set(),CommitmentStatus.CANCELLED:set(),CommitmentStatus.EXPIRED:set(),
}
class TemporalCoordinator:
    def __init__(self):self.items:dict[str,Commitment]={}
    def add(self,item:Commitment):
        ZoneInfo(item.timezone)
        if not item.evidence_ids:raise ValueError('source evidence required')
        if item.recurrence not in ('', 'daily', 'weekly'):raise ValueError('unsupported recurrence')
        if item.status==CommitmentStatus.CONFIRMED and item.due_at is None:raise ValueError('confirmed event needs a date')
        self.items[item.id]=item
    def transition(self,item_id:str,new_status:CommitmentStatus,*,evidence_id:str):
        if not evidence_id:raise ValueError('new evidence required')
        item=self.items[item_id]
        if new_status not in _ALLOWED[item.status]:raise ValueError(f'invalid transition: {item.status} -> {new_status}')
        if new_status==CommitmentStatus.CONFIRMED and item.due_at is None:raise ValueError('confirmed event needs a date')
        item.status=new_status;item.evidence_ids.append(evidence_id);item.updated_at=time.time()
    def due(self,now:float|None=None)->list[Commitment]:
        now=time.time() if now is None else now
        self.reconcile(now)
        return [x for x in self.items.values() if x.status==CommitmentStatus.CONFIRMED
                and x.due_at is not None and x.due_at<=now
                and (x.last_reminded_at is None or x.last_reminded_at<x.due_at)]
    def reconcile(self,now:float|None=None):
        now=time.time() if now is None else now
        for item in self.items.values():
            if item.expires_at and item.expires_at<=now and item.status not in {
                CommitmentStatus.COMPLETED,CommitmentStatus.CANCELLED,CommitmentStatus.EXPIRED}:
                item.status=CommitmentStatus.EXPIRED;item.updated_at=now
    def mark_reminded(self,item_id:str,now:float|None=None):
        now=time.time() if now is None else now
        item=self.items[item_id]
        item.last_reminded_at=now
        if item.recurrence and item.due_at is not None:
            local=datetime.fromtimestamp(item.due_at,ZoneInfo(item.timezone))
            step=timedelta(days=1 if item.recurrence=='daily' else 7)
            while local.timestamp()<=now:local+=step
            item.due_at=local.timestamp()
        item.updated_at=now
    def conflicts(self,item_id:str,window_seconds:float=1800)->list[str]:
        item=self.items[item_id]
        if item.status!=CommitmentStatus.CONFIRMED or item.due_at is None:return []
        return [x.id for x in self.items.values() if x.id!=item_id
                and x.status==CommitmentStatus.CONFIRMED and x.due_at is not None
                and abs(x.due_at-item.due_at)<window_seconds
                and set(x.participants)&set(item.participants)]
    @staticmethod
    def to_epoch(local_iso:str,timezone:str)->float:
        dt=datetime.fromisoformat(local_iso)
        if dt.tzinfo is not None:raise ValueError('supply naive local time with explicit timezone')
        tz=ZoneInfo(timezone)
        aware=dt.replace(tzinfo=tz)
        if aware.astimezone(ZoneInfo('UTC')).astimezone(tz).replace(tzinfo=None)!=dt:
            raise ValueError('nonexistent local time')
        if aware.utcoffset()!=dt.replace(tzinfo=tz,fold=1).utcoffset():
            raise ValueError('ambiguous local time; explicit clarification required')
        return aware.timestamp()
