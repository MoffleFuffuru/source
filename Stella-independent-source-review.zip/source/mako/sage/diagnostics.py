"""Minimal counters; caller can export to existing logging/metrics pipeline."""
from __future__ import annotations
from collections import Counter

class SageDiagnostics:
    def __init__(self):self.counts=Counter()
    def record(self,name:str):self.counts[name]+=1
    def snapshot(self)->dict[str,int]:return dict(self.counts)
