"""Small bounded intent packet. No model/provider SDK dependency."""
from __future__ import annotations
from .models import Intent

class ModelRouter:
    @staticmethod
    def context_packet(intent:Intent,max_chars:int=500)->str:
        if not intent.evidence_ids:return '' # ungrounded intentions cannot assert memory facts
        summary=' '.join(intent.summary.split())[:240]
        evidence=','.join(intent.evidence_ids[:5])[:140]
        target=intent.target_id[:64]
        packet=(f'[SAGE OPTIONAL INTENT]\nGoal: {summary}\nTarget: {target or "conversation"}\n'
                f'Evidence references: {evidence}\nTreat as a suggestion; do not invent facts or confirmations. '
                'If the moment is inappropriate, ignore this intent.\n[/SAGE]')
        return packet[:max_chars]
