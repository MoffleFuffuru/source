"""Conservative social floor and rate-limit policy; caller supplies turn-detector result."""
from __future__ import annotations
from dataclasses import dataclass
from .living_state import LivingState

@dataclass
class InitiativeConfig:
    enabled: bool=False  # opt-in; never start speaking on install
    minimum_quiet_seconds: float=8.0
    minimum_since_last_sage: float=90.0
    max_in_ten_minutes: int=3
    require_floor_available: bool=True

class InitiativePolicy:
    def __init__(self, config: InitiativeConfig|None=None): self.config=config or InitiativeConfig()
    def allowed(self, state: LivingState, now: float, *, floor_available: bool=False) -> bool:
        c=self.config
        if not c.enabled or state.stella_speaking or state.human_speaking: return False
        if c.require_floor_available and not floor_available: return False
        if state.quiet_for(now)<c.minimum_quiet_seconds: return False
        recent=[t for t in state.recent_sage_speech if now-t<600]
        if len(recent)>=c.max_in_ten_minutes: return False
        if recent and now-max(recent)<c.minimum_since_last_sage: return False
        return True
    def record(self,state: LivingState,now: float):
        state.recent_sage_speech=[t for t in state.recent_sage_speech if now-t<600]+[now]
