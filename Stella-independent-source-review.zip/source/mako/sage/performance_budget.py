"""Hard admission caps for background work; no LLM calls inside this module."""
from __future__ import annotations
import time
from collections import deque

class PerformanceBudget:
    def __init__(self,max_jobs_per_minute:int=2,max_parallel:int=1):
        self.max_jobs_per_minute=max_jobs_per_minute;self.max_parallel=max_parallel
        self._history:deque[float]=deque();self._running=0
    def acquire(self,now:float|None=None)->bool:
        now=time.monotonic() if now is None else now
        while self._history and now-self._history[0]>=60:self._history.popleft()
        if self._running>=self.max_parallel or len(self._history)>=self.max_jobs_per_minute:return False
        self._history.append(now);self._running+=1;return True
    def release(self):self._running=max(0,self._running-1)
