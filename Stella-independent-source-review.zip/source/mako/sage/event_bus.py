"""Synchronous in-process fanout; subscribe only bounded, non-inference handlers."""
from __future__ import annotations
import logging
from collections import defaultdict
from collections.abc import Callable
from .models import Event, EventKind
log=logging.getLogger(__name__)

class EventBus:
    def __init__(self):
        self._handlers: dict[EventKind | None, list[Callable[[Event],None]]] = defaultdict(list)
    def subscribe(self, kind: EventKind | None, callback: Callable[[Event],None]):
        self._handlers[kind].append(callback)
        return lambda: self._handlers[kind].remove(callback)
    def publish(self, event: Event):
        for callback in tuple(self._handlers[event.kind])+tuple(self._handlers[None]):
            try: callback(event)
            except Exception: log.exception('SAGE event subscriber failed: %s', event.kind)
