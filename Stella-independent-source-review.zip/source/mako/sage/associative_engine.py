"""Memory-grounded associations, never fabricated events."""
from __future__ import annotations
from .memory_adapter import MemoryAdapter
from .models import Intent

class AssociativeEngine:
    def __init__(self,memory:MemoryAdapter):self.memory=memory
    def propose_callback(self,topic:str,target_id:str='',*,public_only:bool=True)->Intent|None:
        evidence=self.memory.retrieve(' '.join(x for x in [topic,target_id] if x),limit=4,public_only=public_only)
        if not evidence:return None
        return Intent(summary=f'Consider a natural callback about {topic[:120]}; verify the evidence before stating facts.',
                      target_id=target_id,evidence_ids=[e.id for e in evidence],
                      visibility='public' if public_only else 'private',priority=.45,
                      metadata={'evidence_summaries':[e.summary[:220] for e in evidence]})
