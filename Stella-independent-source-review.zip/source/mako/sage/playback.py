"""Conservative Discord-output progress, optionally aligned to provider words."""
import threading


class PlaybackTrace:
    def __init__(self):
        self.lock = threading.Lock()
        self.seconds = 0.0
        self.characters = []

    def alignment(self, value):
        # Accept explicit seconds-based alignment only. Never estimate words
        # from text length or assume queued TTS text has already been heard.
        chars = value.get("characters", [])
        starts = value.get("character_start_times_seconds", [])
        ends = value.get("character_end_times_seconds", [])
        if not chars or not len(chars) == len(starts) == len(ends):
            return
        with self.lock:
            if self.characters and float(starts[0]) < self.characters[-1][2]:
                return
            self.characters.extend((str(c), float(a), float(b)) for c, a, b in zip(chars, starts, ends)
                                   if 0 <= float(a) <= float(b))

    def consumed(self, audio_bytes):
        with self.lock:
            self.seconds = max(self.seconds, audio_bytes / 192000.0)  # stereo 48kHz s16

    def snapshot(self):
        with self.lock:
            cutoff = max(0.0, self.seconds - .04)
            heard = "".join(c for c, _, end in self.characters if end <= cutoff)
            following = next((c for c, _, end in self.characters if end > cutoff), "")
            # A word crossing the cutoff is uncertain, so omit it from the quote.
            if heard and following and heard[-1].isalnum() and following.isalnum():
                boundary = max(heard.rfind(" "), heard.rfind("\n"))
                heard = heard[:boundary + 1] if boundary >= 0 else ""
            return {"text": heard.rstrip(), "audio_seconds": self.seconds,
                    "alignment_available": bool(self.characters),
                    "playback_note": ("aligned prefix; boundary word uncertain" if self.characters
                                      else "audio submitted to Discord; exact words unavailable")}
