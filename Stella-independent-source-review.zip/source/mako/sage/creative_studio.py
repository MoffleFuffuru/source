"""Optional background generator interface; never called on the speech critical path."""
from __future__ import annotations
from collections.abc import Callable
from .models import Intent

class CreativeStudio:
    def __init__(self,generator:Callable[[str],list[str]]|None=None,max_candidates:int=3):
        self.generator=generator;self.max_candidates=max_candidates
    def brainstorm(self,topic:str,evidence_ids:list[str],*,visibility:str='public')->list[Intent]:
        if not self.generator or not evidence_ids:return []
        try: raw=self.generator(topic[:300])
        except Exception:return []
        if not isinstance(raw,list):return []
        seen=set(); output=[]
        for value in raw:
            if not isinstance(value,str):continue
            summary=' '.join(value.split())[:240]
            if not summary or summary.lower() in seen:continue
            seen.add(summary.lower())
            output.append(Intent(summary=summary,evidence_ids=evidence_ids[:8],visibility=visibility,priority=.35))
            if len(output)>=self.max_candidates:break
        return output
