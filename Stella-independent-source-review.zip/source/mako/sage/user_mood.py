"""Conservative, per-person emotional continuity with bounded decay."""
from __future__ import annotations

import re


_WORD = re.compile(r"[a-z0-9']+")
_APOLOGY = re.compile(r"\b(i'?m sorry|i am sorry|i apologize|my bad|i was wrong|please forgive me)\b", re.I)
_POSITIVE = re.compile(
    r"\b(thank you|thanks|i appreciate you|love you|proud of you|great job|you're great|you are great|amazing|awesome)\b",
    re.I,
)
_DIRECT_HOSTILITY = re.compile(
    r"\b(?:you(?:'re| are)?|stella[, ]+)\s*(?:a[n]?\s+)?"
    r"(?:being\s+)?(?:fucking\s+|really\s+|damn\s+)?"
    r"(?:stupid|dumb|idiot|useless|pathetic|worthless|shut up|suck)\b"
    r"|\bi hate you\b",
    re.I,
)
_DIRECT_DISMISSAL = re.compile(
    r"\byou\s+(?:never|keep|always)\s+(?:listen|ignor(?:e|ing) me|forget|miss what i say|"
    r"mess this up|break this|fail me)\b|\byou ignored me again\b",
    re.I,
)


def _topic_tokens(text: str) -> set[str]:
    return {word for word in _WORD.findall(text.casefold()) if len(word) > 3}


def _label(warmth: float, irritation: float) -> str:
    if irritation >= 0.68:
        return "angry"
    if irritation >= 0.28:
        return "annoyed"
    if warmth >= 0.82:
        return "love"
    if warmth >= 0.55:
        return "joy"
    if warmth >= 0.24:
        return "happy"
    return "neutral"


def advance_mood(previous: dict | None, text: str, now: float) -> dict:
    """Update a user-specific mood; ambiguous profanity is deliberately ignored."""
    state = dict(previous or {})
    if (not state or now >= float(state.get("expires_at", 0))
            or now >= float(state.get("hard_expires_at", 0))):
        state = {
            "warmth": 0.0, "irritation": 0.0, "started_at": now,
            "expires_at": now, "hard_expires_at": now,
            "last_text": "", "label": "neutral",
        }
    elapsed = max(0.0, now - float(state.get("last_update", state.get("started_at", now))))
    state["warmth"] = max(0.0, float(state.get("warmth", 0.0)) - elapsed / 600.0)
    state["irritation"] = max(0.0, float(state.get("irritation", 0.0)) - elapsed / 600.0)

    previous_tokens = _topic_tokens(str(state.get("last_text", "")))
    current_tokens = _topic_tokens(text)
    topic_change = bool(previous_tokens and current_tokens and
                        len(previous_tokens & current_tokens) / len(previous_tokens | current_tokens) < 0.12)
    if topic_change:
        # A topic shift can soften the tone, but should not erase a recent
        # interpersonal mood after a single unrelated message.
        state["warmth"] *= 0.92
        state["irritation"] *= 0.90

    apology = bool(_APOLOGY.search(text))
    positive = bool(_POSITIVE.search(text))
    hostile = bool(_DIRECT_HOSTILITY.search(text) or _DIRECT_DISMISSAL.search(text))
    if apology:
        state["irritation"] *= 0.35
    if positive:
        state["irritation"] *= 0.65
        state["warmth"] = min(1.0, float(state["warmth"]) + 0.28)
    if hostile:
        state["warmth"] *= 0.5
        state["irritation"] = min(1.0, float(state["irritation"]) + 0.32)

    irritation = float(state["irritation"])
    warmth = float(state["warmth"])
    label = _label(warmth, irritation)

    if label != "neutral":
        if state.get("label") == "neutral" or not state.get("started_at"):
            state["started_at"] = now
        max_duration = 780.0 if label in {"angry", "love"} else 600.0
        hard_expiry = min(float(state.get("started_at", now)) + max_duration,
                          now + max_duration)
        soft_expiry = min(now + 300.0, hard_expiry)
        state["expires_at"] = soft_expiry
        state["hard_expires_at"] = hard_expiry
    elif warmth <= 0.02 and irritation <= 0.02:
        state.update(started_at=now, expires_at=now, hard_expires_at=now)

    state.update(label=label, last_update=now, last_text=text[:500])
    return state


def apply_model_delta(previous: dict | None, delta: dict, now: float) -> dict:
    """Fold a small, structured response-affect signal into this user's state."""
    state = advance_mood(previous, "", now)
    try:
        warmth_delta = max(-0.12, min(0.12, float(delta.get("warmth", 0.0))))
        irritation_delta = max(-0.12, min(0.12, float(delta.get("irritation", 0.0))))
    except (AttributeError, TypeError, ValueError):
        return state
    if max(abs(warmth_delta), abs(irritation_delta)) < 0.02:
        return state
    was_neutral = state.get("label") == "neutral"
    state["warmth"] = max(0.0, min(1.0, float(state["warmth"]) + warmth_delta * 2.0))
    state["irritation"] = max(0.0, min(1.0, float(state["irritation"]) + irritation_delta * 2.0))
    label = _label(state["warmth"], state["irritation"])
    if label != "neutral":
        if was_neutral:
            state["started_at"] = now
        duration = 780.0 if label in {"angry", "love"} else 600.0
        state["hard_expires_at"] = min(float(state["started_at"]) + duration, now + duration)
        state["expires_at"] = min(now + 300.0, state["hard_expires_at"])
    state.update(label=label, last_update=now)
    return state


def active_mood(state: dict | None, now: float) -> dict:
    if not state or now >= float(state.get("expires_at", 0)) or now >= float(state.get("hard_expires_at", 0)):
        return {"label": "neutral", "intensity": 0.0}
    label = str(state.get("label", "neutral"))
    if label == "neutral":
        return {"label": label, "intensity": 0.0}
    metric = "irritation" if label in {"annoyed", "angry"} else "warmth"
    return {"label": label, "intensity": round(max(0.0, min(1.0, float(state.get(metric, 0.0)))), 2)}


def mood_prompt(mood: dict) -> str:
    label = str(mood.get("label", "neutral"))
    if label == "neutral":
        return ""
    return (
        f"Per-person social tone for this addressee: {label} (subtle intensity {mood.get('intensity', 0.0)}). "
        "Use this only as a soft continuity cue for wording and delivery, not as a script or a claim about their intent. "
        "A sincere apology, constructive topic shift, or positive exchange may ease it quickly. Never announce internal mood tracking."
    )
