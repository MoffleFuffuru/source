"""Atomic JSON persistence for SAGE metadata. Avoid writing secret transcripts."""
from __future__ import annotations
import json,os,tempfile
from pathlib import Path
from dataclasses import asdict
from .models import Intent,IntentStatus,Commitment,CommitmentStatus

class SageStore:
    def __init__(self,path:str|Path):self.path=Path(path)
    def save(self,intents:list[Intent],commitments:list[Commitment]):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        data={'schema_version':1,'intents':[asdict(x) for x in intents],
              'commitments':[asdict(x) for x in commitments]}
        fd,name=tempfile.mkstemp(prefix='.sage-',suffix='.tmp',dir=self.path.parent)
        try:
            with os.fdopen(fd,'w',encoding='utf-8') as f:
                json.dump(data,f,ensure_ascii=False,indent=2);f.flush();os.fsync(f.fileno())
            os.replace(name,self.path)
        finally:
            if os.path.exists(name):os.unlink(name)
    def load(self)->tuple[list[Intent],list[Commitment]]:
        if not self.path.exists():return [],[]
        data=json.loads(self.path.read_text(encoding='utf-8'))
        if data.get('schema_version')!=1:raise ValueError('unsupported SAGE state schema')
        intents=[];commitments=[]
        for x in data.get('intents',[]):
            x['status']=IntentStatus(x['status']);intents.append(Intent(**x))
        for x in data.get('commitments',[]):
            x['status']=CommitmentStatus(x['status']);commitments.append(Commitment(**x))
        return intents,commitments
