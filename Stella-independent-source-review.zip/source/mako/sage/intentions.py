"""Bounded intent queue; explicit claim/complete prevents duplicate spontaneous turns."""
from __future__ import annotations
import time
from .models import Intent, IntentStatus

class IntentionBoard:
    def __init__(self, max_items: int=64):
        self.items: dict[str,Intent]={}; self.max_items=max_items
    def add(self, intent: Intent):
        if intent.id in self.items: return
        self.prune()
        if len(self.items)>=self.max_items:
            replaceable=[x for x in self.items.values() if x.status!=IntentStatus.CLAIMED]
            if not replaceable:return
            drop=min(replaceable,key=lambda x:(x.priority,x.created_at))
            self.items.pop(drop.id,None)
        self.items[intent.id]=intent
    def prune(self, now: float|None=None):
        now=time.time() if now is None else now
        for item in self.items.values():
            if item.expires_at and now>=item.expires_at and item.status in (IntentStatus.CANDIDATE,IntentStatus.READY):
                item.status=IntentStatus.EXPIRED
        self.items={k:v for k,v in self.items.items() if v.status not in (IntentStatus.EXPIRED,IntentStatus.CANCELLED,IntentStatus.COMPLETED)}
    def best(self, now: float|None=None, visibility: str='public', active_people: set[str]|None=None) -> Intent|None:
        self.prune(now)
        candidates=[x for x in self.items.values() if x.status in (IntentStatus.CANDIDATE,IntentStatus.READY)
                    and (visibility=='private' or x.visibility=='public')
                    and (not x.target_id or active_people is None or x.target_id in active_people)]
        return max(candidates,key=lambda x:(x.priority,-x.created_at),default=None)
    def claim(self, intent_id: str) -> bool:
        item=self.items.get(intent_id)
        if not item or item.status not in (IntentStatus.CANDIDATE,IntentStatus.READY): return False
        item.status=IntentStatus.CLAIMED; item.attempts+=1; return True
    def finish(self,intent_id: str, success: bool):
        item=self.items.get(intent_id)
        if item and item.status==IntentStatus.CLAIMED:
            item.status=IntentStatus.COMPLETED if success else IntentStatus.CANCELLED
