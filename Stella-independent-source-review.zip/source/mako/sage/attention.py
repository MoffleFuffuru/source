"""Lightweight attention scores. These are cues, not inferred emotional states."""
from __future__ import annotations
import math
from .models import Event, EventKind

class AttentionTracker:
    def __init__(self,half_life_seconds:float=120.):
        self.half_life_seconds=half_life_seconds
        self._scores:dict[str,tuple[float,float]]={}
    def observe(self,event:Event):
        if not event.actor_id:return
        score=self.score(event.actor_id,event.occurred_at)
        bonus=3. if event.kind==EventKind.USER_INTERRUPTION else 2. if event.kind==EventKind.USER_SPEECH else 1.
        self._scores[event.actor_id]=(min(10.,score+bonus),event.occurred_at)
    def score(self,actor_id:str,now:float)->float:
        score,t=self._scores.get(actor_id,(0.,now))
        return score*math.pow(.5,max(0.,now-t)/self.half_life_seconds)
    def focus(self,now:float)->str:
        return max(self._scores,key=lambda k:self.score(k,now),default='')
