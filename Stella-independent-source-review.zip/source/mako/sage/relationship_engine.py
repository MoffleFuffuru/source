"""Relationship observations with evidence and privacy; no invented affinity scores."""
from __future__ import annotations
from dataclasses import dataclass,field

@dataclass
class RelationshipFact:
    actor_id:str
    fact:str
    evidence_id:str
    visibility:str='private'
    confidence:float=1.

class RelationshipEngine:
    def __init__(self):self.facts:dict[str,list[RelationshipFact]]={}
    def add(self,fact:RelationshipFact):
        if not fact.actor_id or not fact.evidence_id or not fact.fact.strip():raise ValueError('evidence required')
        bucket=self.facts.setdefault(fact.actor_id,[])
        if not any(f.evidence_id==fact.evidence_id and f.fact==fact.fact for f in bucket):bucket.append(fact)
    def context(self,actor_id:str,*,public_only:bool=True,limit:int=5)->list[RelationshipFact]:
        return [f for f in self.facts.get(actor_id,[]) if f.confidence>=.5 and (not public_only or f.visibility=='public')][-limit:]
