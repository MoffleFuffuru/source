"""Semantic motion instructions; existing JS renderer remains bone-transform owner."""
from __future__ import annotations
from dataclasses import asdict
from .models import MotionIntent

class EmbodimentDirector:
    ALLOWED_AFFECT={'neutral','amused','happy','curious','concerned','sad','playful','focused'}
    ALLOWED_POSTURE={'relaxed_standing','attentive_standing','sitting','neutral'}
    def __init__(self):self.current=MotionIntent()
    def set_intent(self,intent:MotionIntent)->dict:
        if intent.affect not in self.ALLOWED_AFFECT:raise ValueError('unsupported affect')
        if intent.posture not in self.ALLOWED_POSTURE:raise ValueError('unsupported posture')
        intent.engagement=max(0.,min(1.,intent.engagement))
        intent.duration_ms=max(100,min(30000,intent.duration_ms))
        self.current=intent
        return {'type':'sage.motion_intent','version':1,'payload':asdict(intent)}
