"""SAGE orchestrator. Host application must explicitly call try_autonomous_turn."""
from __future__ import annotations
import time
from .event_bus import EventBus
from .living_state import LivingState
from .attention import AttentionTracker
from .intentions import IntentionBoard
from .initiative import InitiativePolicy,InitiativeConfig
from .social_director import SocialDirector
from .relationship_engine import RelationshipEngine
from .temporal_coordinator import TemporalCoordinator
from .memory_adapter import MemoryAdapter
from .associative_engine import AssociativeEngine
from .creative_studio import CreativeStudio
from .embodiment import EmbodimentDirector
from .model_router import ModelRouter
from .performance_budget import PerformanceBudget
from .diagnostics import SageDiagnostics
from .models import Event,EventKind,Intent

class SageExecutive:
    def __init__(self,*,config:InitiativeConfig|None=None,memory:MemoryAdapter|None=None):
        self.bus=EventBus();self.state=LivingState();self.attention=AttentionTracker()
        self.board=IntentionBoard();self.policy=InitiativePolicy(config)
        self.social=SocialDirector(self.policy,self.board)
        self.relationships=RelationshipEngine();self.temporal=TemporalCoordinator()
        self.memory=memory or MemoryAdapter();self.associations=AssociativeEngine(self.memory)
        self.creative=CreativeStudio();self.embodiment=EmbodimentDirector()
        self.router=ModelRouter();self.budget=PerformanceBudget();self.metrics=SageDiagnostics()
        self.bus.subscribe(None,self._observe)
    def _observe(self,event:Event):
        self.state.apply(event)
        if event.kind in (EventKind.USER_SPEECH,EventKind.USER_CHAT,EventKind.USER_INTERRUPTION):
            self.attention.observe(event)
        self.metrics.record(f'event.{event.kind.value}')
    def publish(self,event:Event):self.bus.publish(event)
    def queue(self,intent:Intent):self.board.add(intent)
    def try_autonomous_turn(self,*,floor_available:bool,now:float|None=None)->tuple[str,str]|None:
        """Returns (intent_id, bounded prompt packet). Does not call LLM/TTS or speak."""
        now=time.time() if now is None else now
        intent=self.social.select(self.state,now,floor_available=floor_available)
        if not intent:return None
        packet=self.router.context_packet(intent)
        if not packet:
            self.social.mark_finished(intent.id,False);return None
        self.metrics.record('intent.claimed')
        return intent.id,packet
    def confirm_speech_started(self,intent_id:str,*,now:float|None=None):
        """Call only after the existing dialogue/TTS pipeline accepts this turn."""
        if intent_id not in self.board.items or self.board.items[intent_id].status.value!='claimed':return
        self.social.mark_started(self.state,time.time() if now is None else now)
    def complete_turn(self,intent_id:str,success:bool):
        self.social.mark_finished(intent_id,success)
        self.metrics.record('intent.completed' if success else 'intent.cancelled')
