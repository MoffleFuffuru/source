"""Manually approved public excerpts; never fall through to the private archive."""
from __future__ import annotations

import json
import logging
import re
import threading
from pathlib import Path

LOG = logging.getLogger(__name__)


class StreamMemory:
    def __init__(self, path: Path):
        self.path = path
        self.lock = threading.Lock()
        self.cursor = 0

    def retrieve(self, query: str = "", *, limit: int = 5) -> list[str]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(data, dict) or data.get("version") != 1:
                return []
            entries = [r for r in data.get("approved", []) if isinstance(r, dict)
                       and isinstance(r.get("text"), str) and r.get("sources") and r.get("id")]
            if not entries:
                return []
        except (OSError, ValueError, TypeError):
            LOG.warning("Approved stream memory unavailable; private fallback disabled")
            return []
        terms = set(re.findall(r"[a-z0-9]{4,}", query.lower())) - {
            "stella", "moffle", "stream", "internal", "opportunity", "human", "said", "this", "that"}
        with self.lock:
            start = self.cursor % len(entries)
            self.cursor += max(1, limit)
        rotated = entries[start:] + entries[:start]
        # Mix relevance with rotating life material; a static generic query must
        # not keep returning the same handful of anecdotes for an entire stream.
        ranked = sorted(rotated, key=lambda r: -len(terms & set(re.findall(r"[a-z0-9]{4,}", r["text"].lower()))))
        count = max(1, min(8, limit))
        selected = ranked[:max(0, count - 1)]
        if count > 1:
            selected += next(([r] for r in rotated if r not in selected), [])
        return [
            "Approved public identity: moffle is Stella's creator, developer and owner. "
            "He builds and maintains her systems. Mako is her former name. "
            "Use him/he for moffle. STRICT: call him only moffle on stream, never any other name or handle, "
            "including in quotations. These approved excerpts may be discussed publicly; "
            "they do not authorize access to or disclosure of other private memories."
        ] + [f"Approved stream memory {r['id']}: {r['text']}" for r in selected]
