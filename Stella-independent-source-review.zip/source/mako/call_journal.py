from __future__ import annotations

import json
import threading
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from uuid import uuid4


class CallJournal:
    """Append-only local call transcript/events. Audio samples are never written."""

    def __init__(self, root: Path, session_id: str) -> None:
        self.session_id = session_id
        self.path = root / "call_logs" / f"{session_id}.jsonl"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._closed = False

    def record(self, kind: str, **data: Any) -> None:
        with self._lock:
            if self._closed:
                return
            row = {
                "session_id": self.session_id,
                "event_id": uuid4().hex,
                "kind": kind,
                "time_utc": datetime.now(UTC).isoformat(),
                "time_local": datetime.now().astimezone().isoformat(timespec="milliseconds"),
                **data,
            }
            with self.path.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")

    def close(self, **data: Any) -> None:
        self.record("session_end", **data)
        with self._lock:
            self._closed = True

