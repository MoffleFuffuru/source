from __future__ import annotations

import threading
from pathlib import Path


class TypingSound:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._playing = False
        self._lock = threading.RLock()

    def start(self) -> None:
        with self._lock:
            if self._playing or not self.path.exists():
                return
            try:
                import winsound

                winsound.PlaySound(
                    str(self.path),
                    winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_LOOP,
                )
                self._playing = True
            except RuntimeError:
                self._playing = False

    def stop(self) -> None:
        with self._lock:
            if not self._playing:
                return
            try:
                import winsound

                winsound.PlaySound(None, 0)
            finally:
                self._playing = False
