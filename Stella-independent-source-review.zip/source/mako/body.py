"""Local, renderer-agnostic body state for Mako.

The dialogue model supplies language; this module turns existing Mako state into
small semantic animation intents. Adapters must never raise into cognition.
"""

from __future__ import annotations

import random
import math
import base64
import json
import os
import socket
import struct
import threading
import time
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Protocol

from .models import ConversationEvent, Expression, InteractionMode, ResponseResult


class BodyState(StrEnum):
    IDLE = "idle"
    LISTENING = "listening"
    PROCESSING = "processing"
    SPEAKING = "speaking"
    DEGRADED = "degraded"


class GazeTarget(StrEnum):
    SPEAKER = "speaker"
    CAMERA = "camera"
    THINKING_AWAY = "thinking_away"
    IDLE_RANDOM = "idle_random"


_EXPRESSIONS = {"neutral", "warm", "amused", "playful", "smug", "curious", "confused", "surprised", "concerned", "annoyed", "embarrassed", "sad", "excited", "focused"}
_GESTURES = {"none", "wave", "small_head_tilt", "head_turn", "small_nod", "small_shake", "lean_in", "lean_back", "shrug", "think", "laugh", "celebrate", "stretch", "explain", "disappointed", "annoyed", "pout", "curious", "pleased", "startle"}


@dataclass(frozen=True, slots=True)
class ActingIntent:
    expression: str = "neutral"
    intensity: float = 0.25
    gesture: str = "none"
    gaze: GazeTarget = GazeTarget.CAMERA
    energy: float = 0.35

    @classmethod
    def normalized(cls, *, expression: str = "neutral", intensity: float = 0.25, gesture: str = "none", gaze: str = "camera", energy: float = 0.35) -> "ActingIntent":
        expression = expression.lower().strip()
        gesture = gesture.lower().strip()
        try:
            gaze_target = GazeTarget(gaze)
        except ValueError:
            gaze_target = GazeTarget.CAMERA
        return cls(
            expression=expression if expression in _EXPRESSIONS else "neutral",
            intensity=max(0.0, min(1.0, float(intensity))),
            gesture=gesture if gesture in _GESTURES else "none",
            gaze=gaze_target,
            energy=max(0.0, min(1.0, float(energy))),
        )


@dataclass(frozen=True, slots=True)
class BodySnapshot:
    state: BodyState
    intent: ActingIntent
    speaking: bool
    blink: float
    health: str
    last_error: str = ""
    recovery_attempts: int = 0
    speech_level: float = 0.0
    audio_sequence: int = 0
    audio_age_ms: float = 0.0
    audio_stopped: bool = True


class AvatarAdapter(Protocol):
    def apply(self, snapshot: BodySnapshot) -> None: ...
    def health_check(self) -> bool: ...
    def reconnect(self) -> bool: ...
    def close(self) -> None: ...


@dataclass(slots=True)
class DebugAvatarAdapter:
    """Deterministic local adapter used until a renderer is connected."""

    latest: BodySnapshot | None = None
    fail: bool = False

    def apply(self, snapshot: BodySnapshot) -> None:
        if self.fail:
            raise ConnectionError("debug avatar intentionally unavailable")
        self.latest = snapshot

    def health_check(self) -> bool:
        return not self.fail

    def reconnect(self) -> bool:
        return not self.fail

    def close(self) -> None:
        pass


class VmcAvatarAdapter:
    """Minimal local VMC/OSC sender for Warudo's VMC Receiver."""

    def __init__(self, host: str = "127.0.0.1", port: int = 39539) -> None:
        self.destination = (host, int(port))
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.setblocking(False)

    def apply(self, snapshot: BodySnapshot) -> None:
        weights = self._blendshapes(snapshot)
        for name, value in weights.items():
            self._send("/VMC/Ext/Blend/Val", name, value)
        self._send("/VMC/Ext/Blend/Apply")
        # Do not send sparse pose bones. Warudo treats a VMC pose receiver as an
        # authority for the rig, and a head-only packet can leave an unsupported
        # model in a permanent T-pose. Body gesture control comes after we have a
        # complete mapped skeleton for the selected avatar.

    def health_check(self) -> bool:
        return self.socket.fileno() >= 0

    def reconnect(self) -> bool:
        if self.health_check():
            return True
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.setblocking(False)
        return True

    def close(self) -> None:
        self.socket.close()

    def _send(self, address: str, *args: object) -> None:
        self.socket.sendto(_osc_message(address, *args), self.destination)

    @staticmethod
    def _blendshapes(snapshot: BodySnapshot) -> dict[str, float]:
        expression = snapshot.intent.expression
        intensity = snapshot.intent.intensity
        # VMC's core VRM0 expression names are case-sensitive.  Keep the
        # ARKit aliases as well because some Warudo character mappings expose
        # PerfectSync names instead of the VRM0 presets.
        weights = {
            "Blink_L": snapshot.blink,
            "Blink_R": snapshot.blink,
            "blinkLeft": snapshot.blink,
            "blinkRight": snapshot.blink,
            "eyeBlinkLeft": snapshot.blink,
            "eyeBlinkRight": snapshot.blink,
        }
        if snapshot.speaking:
            # The voice engine supplies a short-window RMS level while audio is
            # actually playing.  A small gate prevents idle noise from making
            # the mouth twitch between phonemes.
            mouth_open = max(0.0, min(.55, (snapshot.speech_level - .012) * 4.0))
            weights.update({"A": mouth_open, "aa": mouth_open, "jawOpen": mouth_open})
        if expression in {"warm", "amused", "playful", "smug", "excited"}:
            # A held smile competes with visemes and makes every spoken line
            # look pasted on. Keep only a faint trace of the mood while audio
            # is active; the mouth animation should own the face during speech.
            smile_strength = .45 * intensity * (.16 if snapshot.speaking else 1.0)
            weights.update({
                "Joy": smile_strength,
                "happy": smile_strength,
                "mouthSmileLeft": smile_strength,
                "mouthSmileRight": smile_strength,
            })
        if expression == "smug":
            weights["mouthSmileLeft"] = .7 * intensity
            weights["browDownRight"] = .2 * intensity
        elif expression == "concerned":
            weights.update({"browInnerUp": .5 * intensity, "mouthFrownLeft": .18 * intensity, "mouthFrownRight": .18 * intensity})
        elif expression == "annoyed":
            weights.update({"browDownLeft": .45 * intensity, "browDownRight": .45 * intensity})
        elif expression == "embarrassed":
            weights.update({"cheekSquintLeft": .25 * intensity, "cheekSquintRight": .25 * intensity})
        elif expression == "surprised":
            weights.update({"eyeWideLeft": .5 * intensity, "eyeWideRight": .5 * intensity, "jawOpen": .25 * intensity})
        return weights


class WarudoAvatarAdapter(VmcAvatarAdapter):
    """VMC face stream plus a non-blocking event channel for Warudo Playground.

    VMC owns only blendshapes, keeping Warudo's idle animation and full skeleton
    intact. The optional WebSocket channel carries discrete intent changes for
    native expressions and one-shot gestures.
    """

    def __init__(self, host: str = "127.0.0.1", port: int = 39539, bridge_file: str = "data/warudo-bridge.json") -> None:
        super().__init__(host, port)
        self._bridge_file = bridge_file
        self._event_socket: socket.socket | None = None
        self._event_channel = ""
        self._last_event: tuple[object, ...] | None = None
        self._event_lock = threading.Lock()

    def apply(self, snapshot: BodySnapshot) -> None:
        super().apply(snapshot)
        event = (
            snapshot.intent.expression,
            round(snapshot.intent.intensity, 2),
            snapshot.intent.gesture,
            snapshot.intent.gaze.value == GazeTarget.SPEAKER.value,
        )
        if event != self._last_event:
            self._last_event = event
            threading.Thread(target=self._publish_event, args=(event,), daemon=True).start()

    def close(self) -> None:
        super().close()
        with self._event_lock:
            if self._event_socket:
                self._event_socket.close()
                self._event_socket = None

    def _publish_event(self, event: tuple[object, ...]) -> None:
        channel = self._load_channel()
        if not channel:
            return
        payload = json.dumps({
            "emotion": event[0], "intensity": event[1], "gesture": event[2],
            "look_at_user": event[3], "sent_at": time.time(),
        }, separators=(",", ":")).encode("utf-8")
        with self._event_lock:
            try:
                if not self._event_socket or channel != self._event_channel:
                    if self._event_socket:
                        self._event_socket.close()
                    self._event_socket = self._connect(channel)
                    self._event_channel = channel
                self._event_socket.sendall(_websocket_frame(payload))
            except OSError:
                if self._event_socket:
                    self._event_socket.close()
                self._event_socket = None

    def _load_channel(self) -> str:
        try:
            with open(self._bridge_file, "r", encoding="utf-8") as handle:
                value = json.load(handle)
            return str(value.get("channel", "")).strip()
        except (OSError, ValueError, AttributeError):
            return ""

    @staticmethod
    def _connect(channel: str) -> socket.socket:
        sock = socket.create_connection(("127.0.0.1", 19190), timeout=.25)
        sock.settimeout(.5)
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        request = (
            "GET / HTTP/1.1\r\nHost: 127.0.0.1:19190\r\nUpgrade: websocket\r\n"
            "Connection: Upgrade\r\nSec-WebSocket-Version: 13\r\n"
            f"Sec-WebSocket-Key: {key}\r\nChannel: {channel}\r\n\r\n"
        ).encode("ascii")
        sock.sendall(request)
        if b" 101 " not in sock.recv(2048):
            sock.close()
            raise ConnectionError("Warudo event channel refused the handshake")
        sock.settimeout(None)
        return sock


def _osc_message(address: str, *args: object) -> bytes:
    """Encode the tiny OSC subset VMC uses without a runtime dependency."""
    def padded(value: bytes) -> bytes:
        return value + (b"\0" * ((4 - len(value) % 4) % 4))

    tags = ","
    encoded: list[bytes] = []
    for value in args:
        if isinstance(value, str):
            tags += "s"
            encoded.append(padded(value.encode("utf-8") + b"\0"))
        elif isinstance(value, int):
            tags += "i"
            encoded.append(struct.pack(">i", value))
        else:
            tags += "f"
            encoded.append(struct.pack(">f", float(value)))
    return padded(address.encode("utf-8") + b"\0") + padded(tags.encode("ascii") + b"\0") + b"".join(encoded)


def _websocket_frame(payload: bytes) -> bytes:
    """Build a masked, unfragmented WebSocket text frame without a dependency."""
    mask = os.urandom(4)
    size = len(payload)
    header = bytearray((0x81, 0x80))
    if size < 126:
        header[1] |= size
    elif size < 65536:
        header[1] |= 126
        header.extend(struct.pack(">H", size))
    else:
        header[1] |= 127
        header.extend(struct.pack(">Q", size))
    masked = bytes(value ^ mask[index % 4] for index, value in enumerate(payload))
    return bytes(header) + mask + masked


class DesktopAvatarAdapter:
    """Best-effort loopback telemetry; no renderer wait and no conversation text."""

    def __init__(self) -> None:
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.setblocking(False)
        self._intent: ActingIntent | None = None
        self._sequence = 0
        self._lock = threading.Lock()

    def apply(self, snapshot: BodySnapshot) -> None:
        with self._lock:
            if snapshot.intent is not self._intent:
                self._intent = snapshot.intent
                self._sequence += 1
            intent = snapshot.intent
            packet = {
                "version": 1, "sequence": self._sequence, "state": snapshot.state.value,
                "speaking": snapshot.speaking, "speech_level": snapshot.speech_level,
                "audio_sequence": snapshot.audio_sequence,
                "audio_age_ms": snapshot.audio_age_ms,
                "audio_stopped": snapshot.audio_stopped,
                "intent": {"expression": intent.expression, "intensity": intent.intensity,
                           "gesture": intent.gesture, "gaze": intent.gaze.value, "energy": intent.energy},
            }
            try:
                self.socket.sendto(json.dumps(packet).encode("utf-8"), ("127.0.0.1", 39540))
            except (BlockingIOError, ConnectionResetError, ConnectionRefusedError):
                # Closing the visual client must not impair calls or cognition.
                pass

    def health_check(self) -> bool:
        return self.socket.fileno() >= 0

    def reconnect(self) -> bool:
        return self.health_check()

    def close(self) -> None:
        self.socket.close()


def create_avatar_adapter(kind: str, *, host: str = "127.0.0.1", port: int = 39539, bridge_file: str = "data/warudo-bridge.json") -> AvatarAdapter:
    if kind.strip().lower() == "desktop":
        return DesktopAvatarAdapter()
    if kind.strip().lower() == "warudo":
        return WarudoAvatarAdapter(host, port, bridge_file)
    if kind.strip().lower() == "vmc":
        return VmcAvatarAdapter(host, port)
    return DebugAvatarAdapter()


class BodyController:
    """Non-blocking semantic body controller with bounded local recovery."""

    def __init__(self, adapter: AvatarAdapter | None = None, *, enabled: bool = True, seed: int = 4, auto_update: bool = False, update_hz: float = 20.0) -> None:
        self.adapter = adapter or DebugAvatarAdapter()
        self.enabled = enabled
        self._lock = threading.RLock()
        self._rng = random.Random(seed)
        self._state = BodyState.IDLE
        self._intent = ActingIntent.normalized(gaze="idle_random")
        self._persistent_intent = ActingIntent.normalized(gaze="idle_random")
        self._transient_expression_until = 0.0
        self._speaking = False
        self._speech_level = 0.0
        self._audio_sequence = 0
        self._audio_at: float | None = None
        self._audio_stopped = True
        self._blink = 0.0
        self._last_blink = time.monotonic()
        self._next_stream_motion = time.monotonic() + 5.0
        self._ambient_intent = None
        self._ambient_until = 0.0
        self._health = "healthy"
        self._last_error = ""
        self._recoveries = 0
        self._stop = threading.Event()
        self._worker: threading.Thread | None = None
        if enabled and auto_update:
            self._worker = threading.Thread(target=self._update_worker, args=(max(1.0, update_hz),), daemon=True)
            self._worker.start()

    def snapshot(self) -> BodySnapshot:
        with self._lock:
            age = max(0.0, time.monotonic() - self._audio_at) if self._audio_at is not None else 0.0
            return BodySnapshot(
                self._state, self._intent, self._speaking, self._blink,
                self._health, self._last_error, self._recoveries,
                self._speech_level if age < .150 else 0.0,
                self._audio_sequence, age * 1000.0, self._audio_stopped,
            )

    def observe_event(self, event: ConversationEvent, *, semantic_act: str, confidence: float) -> None:
        immediate = self._immediate_intent(semantic_act, confidence)
        with self._lock:
            self._state = BodyState.LISTENING
            self._speaking = False
            self._intent = immediate or ActingIntent.normalized(expression="focused", intensity=.22, gaze="speaker", energy=.28)
        self._push()

    def apply_listener_profile(self, profile: str) -> None:
        """Turn existing Inworld voice-profile evidence into a quiet listener cue."""
        value = profile.lower()
        expression, intensity, gesture, energy = "focused", .22, "none", .28
        if any(word in value for word in ("excited", "energetic", "happy")):
            expression, intensity, gesture, energy = "warm", .36, "small_nod", .52
        elif any(word in value for word in ("amused", "laugh", "playful")):
            expression, intensity, gesture, energy = "amused", .38, "small_head_tilt", .46
        elif any(word in value for word in ("sad", "soft", "quiet")):
            expression, intensity, gesture, energy = "concerned", .32, "none", .20
        elif any(word in value for word in ("angry", "frustrated", "tense")):
            expression, intensity, gesture, energy = "focused", .36, "none", .14
        elif any(word in value for word in ("confused", "uncertain", "questioning")):
            expression, intensity, gesture, energy = "confused", .38, "small_head_tilt", .30
        with self._lock:
            if self._speaking:
                return
            self._state = BodyState.LISTENING
            self._intent = ActingIntent.normalized(
                expression=expression, intensity=intensity, gesture=gesture,
                gaze="speaker", energy=energy,
            )
        self._push()

    def set_persistent_mood(self, expression: str, intensity: float = .25, energy: float = .35) -> None:
        """Set Stella's low-key baseline; per-turn expressions may briefly overlay it."""
        mood = ActingIntent.normalized(expression=expression, intensity=intensity,
                                       gesture="none", gaze="idle_random", energy=energy)
        with self._lock:
            self._persistent_intent = mood
            if time.monotonic() >= self._transient_expression_until and not self._speaking:
                self._intent = mood
        self._push()

    def processing(self) -> None:
        with self._lock:
            self._state = BodyState.PROCESSING
            self._intent = ActingIntent.normalized(expression="focused", intensity=.25, gesture="small_head_tilt", gaze="thinking_away", energy=.25)
        self._push()

    def apply_response(self, result: ResponseResult) -> None:
        expression = {
            Expression.HAPPY: "warm", Expression.SMUG: "smug", Expression.SLEEPY: "neutral",
            Expression.ANNOYED: "annoyed", Expression.EMBARRASSED: "embarrassed",
            Expression.CONCERNED: "concerned", Expression.EXCITED: "excited",
        }.get(result.expression, "neutral")
        gesture = "small_head_tilt" if expression in {"smug", "curious", "embarrassed"} else "small_nod" if expression in {"warm", "excited"} else "none"
        with self._lock:
            self._state = BodyState.SPEAKING
            self._speaking = True
            self._transient_expression_until = time.monotonic() + 7.0
            self._intent = ActingIntent.normalized(expression=expression, intensity=.58, gesture=gesture, gaze="speaker", energy=.55)
            # Use existing per-turn directions when supplied; never add an LLM call.
            acting = getattr(result, "acting", None)
            if isinstance(acting, dict) and acting:
                try:
                    self._intent = ActingIntent.normalized(
                        expression=str(acting.get("expression", expression)),
                        intensity=acting.get("intensity", .58),
                        gesture=str(acting.get("gesture", gesture)),
                        gaze=str(acting.get("gaze", "speaker")),
                        energy=acting.get("energy", .55),
                    )
                except (TypeError, ValueError):
                    pass
        self._push()

    def stream_idle(self) -> bool:
        """Occasional silent upper-body cues, never speech or a new model request."""
        with self._lock:
            now = time.monotonic()
            if not self.enabled or self._speaking or self._state != BodyState.IDLE:
                return False
            if now < self._next_stream_motion:
                return False
            self._next_stream_motion = now + self._rng.uniform(8.0, 14.0)
            self._ambient_until = now + 3.5
            self._ambient_intent = ActingIntent.normalized(
                expression=self._rng.choice(["neutral", "warm", "curious"]),
                intensity=.3, energy=.4,
                gesture=self._rng.choice(["head_turn", "small_head_tilt", "lean_back"]),
                gaze=self._rng.choice(["camera", "idle_random"]),
            )
            self._intent = self._ambient_intent
        self._push()
        return True

    def speech_finished(self) -> None:
        with self._lock:
            self._state = BodyState.IDLE
            self._speaking = False
            self._speech_level = 0.0
            self._audio_sequence += 1
            self._audio_at = time.monotonic()
            self._audio_stopped = True
            # Keep the brief response affect until its bounded overlay expires.
            if time.monotonic() >= self._transient_expression_until:
                self._intent = self._persistent_intent
            else:
                self._intent = ActingIntent.normalized(
                    expression=self._intent.expression, intensity=self._intent.intensity,
                    energy=self._intent.energy, gaze="idle_random",
                )
        self._push()

    def set_speech_level(self, level: float) -> None:
        """Publish raw playback RMS; the renderer owns the single envelope stage."""
        with self._lock:
            # Streamed playback can start before apply_response receives the
            # completed model result. Audio levels, not that result, own lip sync.
            try:
                value = float(level)
            except (TypeError, ValueError, OverflowError):
                value = 0.0
            self._speech_level = max(0.0, min(1.0, value)) if math.isfinite(value) else 0.0
            self._audio_sequence += 1
            self._audio_at = time.monotonic()
            self._audio_stopped = False
        self._push()

    def tick(self) -> None:
        """Advance autonomous motion. Call from a renderer/update loop when available."""
        with self._lock:
            now = time.monotonic()
            if (self._transient_expression_until and now >= self._transient_expression_until
                    and not self._speaking):
                self._intent = self._persistent_intent
                self._transient_expression_until = 0.0
            if self._ambient_intent is self._intent and now >= self._ambient_until:
                self._intent = self._persistent_intent
                self._ambient_intent = None
            elapsed = now - self._last_blink
            if self._blink and elapsed > .14:
                self._blink = 0.0
                self._last_blink = now
            elif not self._blink and elapsed > self._rng.uniform(3.0, 6.5):
                self._blink = 1.0
                self._last_blink = now
        self._push()

    def close(self) -> None:
        self._stop.set()
        if self._worker:
            self._worker.join(timeout=.5)
        try:
            self.adapter.close()
        except Exception:
            pass

    def _push(self) -> None:
        if not self.enabled:
            return
        snapshot = self.snapshot()
        try:
            self.adapter.apply(snapshot)
            with self._lock:
                self._health = "healthy"
                self._last_error = ""
        except Exception as exc:
            self._recover(str(exc))

    def _recover(self, detail: str) -> None:
        with self._lock:
            self._last_error = detail
            self._recoveries += 1
            attempts = self._recoveries
            self._health = "recovering" if attempts <= 3 else "disabled_temporarily"
            if attempts > 3:
                self._state = BodyState.DEGRADED
                return
        try:
            restored = self.adapter.health_check() or self.adapter.reconnect()
        except Exception:
            restored = False
        with self._lock:
            if restored:
                self._health = "healthy"
                self._recoveries = 0
            else:
                self._health = "degraded"

    def _update_worker(self, update_hz: float) -> None:
        interval = 1.0 / update_hz
        while not self._stop.wait(interval):
            self.tick()

    @staticmethod
    def _immediate_intent(act: str, confidence: float) -> ActingIntent | None:
        if confidence < .88:
            return None
        mapping = {
            "emotional_disclosure": ("concerned", "lean_in"),
            "affection_reassurance": ("warm", "small_nod"),
            "correction": ("focused", "small_nod"),
            "shared_work_update": ("excited", "small_nod"),
            "clarification_repair": ("confused", "small_head_tilt"),
        }
        selected = mapping.get(act)
        if not selected:
            return None
        return ActingIntent.normalized(expression=selected[0], intensity=.45, gesture=selected[1], gaze="speaker", energy=.42)
