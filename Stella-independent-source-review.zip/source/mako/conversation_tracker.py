from __future__ import annotations

import re
import threading
from collections import deque
from dataclasses import asdict, dataclass
from time import monotonic
from typing import Any


@dataclass(slots=True)
class TrackedTurn:
    speaker_id: str
    speaker_name: str
    previous_speaker: str
    text: str
    likely_addressee: str
    addressee_basis: str
    likely_referent: str
    referent_basis: str
    referent_confidence: float
    self_reference_likely: bool
    dialogue_act: str
    thread: str
    active_threads: tuple[str, ...]
    utterance_complete: bool
    human_to_human: bool
    response_expected: bool
    response_pressure: float
    floor_state: str
    continuation_of_direct_address: bool
    timestamp: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class ConversationTracker:
    """Low-cost, explainable estimates of addressee and conversational referent."""

    _PERSON = re.compile(r"\b(?:hey|yo|hi|hello|thanks|thank you),?\s+([\w'-]+)", re.I)
    _SELF_PRONOUN = re.compile(r"\b(?:she|her|hers|he|him|they|them|that girl|the girl)\b", re.I)
    _NAMED_SELF = re.compile(r"\b(?:stella|mako)\b", re.I)
    _SECOND_PERSON = re.compile(r"\b(?:you|your|yourself)\b", re.I)

    def _assistant_vocative(self, text: str) -> bool:
        """Recognize the assistant's name used as an address, not a mere mention."""
        folded = " ".join(text.casefold().split())
        for name in self.assistant_names:
            if re.fullmatch(rf"(?:hey|yo|hi|hello|okay|ok|so|wait|but|and)?\s*{re.escape(name)}[,.!?]*", folded):
                return True
            if re.match(rf"^(?:hey|yo|hi|hello|okay|ok|so|wait|but|and)?\s*{re.escape(name)}\b\s*[,!:?-]", folded):
                return True
            # An opening greeting followed by the name is a common vocative even
            # when ASR omits the comma: "hey Stella can you hear me?".
            if re.match(rf"^(?:hey|yo|hi|hello)\s+{re.escape(name)}\b(?:\s|[,!:?-])", folded):
                return True
            # STT frequently drops commas after the assistant's name. Accept a
            # narrow set of clear address frames, but not arbitrary name+text
            # strings (e.g. "Stella said she might know").
            if re.match(
                rf"^{re.escape(name)}\s+(?:can you|could you|would you|are you|do you|"
                rf"what do you|how do you|tell me|please|i need|i have|i wanted|"
                rf"thanks|thank you|sorry|wait|look)\b",
                folded,
            ):
                return True
            # A comma directly before the assistant's name is strong vocative
            # evidence, including acknowledgements and apologies. Do not infer
            # address merely because a question contains "you" before a name:
            # "did you ask Stella?" refers to Stella as an object.
            if re.search(rf",\s*{re.escape(name)}\s*[,!?\.]*$", folded):
                return True
            if re.search(
                rf"\b(?:what do you think|how do you feel|what do you mean|are you ready|"
                rf"can you hear me|do you agree|thank you|thanks|sorry|love you)\s+{re.escape(name)}[!?\.]*$",
                folded,
            ):
                return True
            if re.search(rf",\s*{re.escape(name)}\s*,", folded):
                return True
        return False

    @staticmethod
    def _participant_vocative(text: str, participant_names: tuple[str, ...]) -> str | None:
        """Return a participant named in the opening vocative, not any name mention."""
        for name in sorted((name.strip() for name in participant_names if name.strip()),
                           key=len, reverse=True):
            if re.match(rf"^\s*{re.escape(name)}\s*[,!:—-]", text, re.IGNORECASE):
                return name
        return None

    def __init__(self, assistant_names: tuple[str, ...] = ("mako", "stella")) -> None:
        self.assistant_names = tuple(name.casefold() for name in assistant_names)
        self._lock = threading.RLock()
        self._recent: deque[TrackedTurn] = deque(maxlen=16)
        self._pending_direct_address: dict[str, float] = {}

    def observe(
        self,
        *,
        speaker_id: str,
        speaker_name: str,
        text: str,
        timestamp: str,
        direct_mention: bool = False,
        reply_to_assistant: bool = False,
        single_user_call: bool = False,
        participant_names: tuple[str, ...] = (),
        utterance_complete: bool = True,
        commit: bool = True,
    ) -> TrackedTurn:
        clean = " ".join(text.split())
        folded = clean.casefold()
        explicit = direct_mention or reply_to_assistant or self._assistant_vocative(clean)
        other_names = {name.casefold() for name in participant_names if name}
        participant_vocative = self._participant_vocative(clean, participant_names)
        named = self._PERSON.search(clean)
        addressed_name = participant_vocative or (
            named.group(1) if named and named.group(1).casefold() in other_names else None
        )
        addressed_to_other = addressed_name is not None
        question = "?" in clean or bool(re.match(r"^(who|what|when|where|why|how|can|could|would|do|did|is|are|will)\b", folded))
        command = bool(re.match(r"^(please\s+)?(stop|wait|look|tell|show|remember|explain|come|go|listen|mute|unmute)\b", folded))
        acknowledgement = folded in {"yeah", "yep", "no", "right", "okay", "ok", "got it", "mhm", "thanks"}
        if acknowledgement:
            act = "acknowledgement"
        elif command:
            act = "command"
        elif question:
            act = "question"
        elif re.search(r"\b(lol|lmao|haha|hehe|😂|🤣)\b", folded):
            act = "joke_or_laughter"
        elif len(clean.split()) < 3:
            act = "fragment_or_reaction"
        else:
            act = "statement"

        if explicit:
            addressee, basis = "Stella", "explicit_name_or_discord_reference"
        elif single_user_call:
            addressee, basis = "Stella", "one_to_one_call"
        elif addressed_to_other:
            addressee, basis = addressed_name or "uncertain", "vocative_name"
        elif question and self._NAMED_SELF.search(folded):
            addressee, basis = "uncertain", "assistant_name_in_third_person_question"
        elif named:
            addressee, basis = "uncertain", "possible_vocative"
        elif question and re.search(r"\b(you|your)\b", folded):
            addressee, basis = "uncertain", "second_person_question"
        else:
            addressee, basis = "room_or_unclear", "no_direct_address_evidence"

        human_to_human = addressed_to_other
        with self._lock:
            now = monotonic()
            self._pending_direct_address = {
                key: expiry for key, expiry in self._pending_direct_address.items() if expiry > now
            }
            continuing_directed_setup = (
                self._pending_direct_address.get(str(speaker_id), 0.0) > now
                and not explicit and not addressed_to_other
            )
            if explicit or single_user_call:
                self._pending_direct_address[str(speaker_id)] = now + 60.0
            elif continuing_directed_setup:
                self._pending_direct_address[str(speaker_id)] = now + 60.0

        if continuing_directed_setup:
            addressee, basis = "Stella", "continuation_of_direct_address"
        pressure = 0.95 if explicit else (
            0.72 if single_user_call or continuing_directed_setup else 0.15 if human_to_human else 0.42 if question else 0.2
        )
        expected = pressure >= 0.55
        if not clean.endswith((".", "?", "!")) and len(clean.split()) <= 2:
            floor = "continuing_or_uncertain"
        elif expected:
            floor = "yielding_to_stella"
        else:
            floor = "human_holds_floor_or_unclear"

        with self._lock:
            previous = self._recent[-1].speaker_name if self._recent else ""
            recent_turns = tuple(self._recent)
            recent_threads = tuple(dict.fromkeys(item.thread for item in self._recent))
        referent, referent_basis, referent_confidence = self._infer_referent(
            clean, recent_turns, participant_names, addressee, single_user_call
        )
        thread = self._thread_for(folded, recent_threads)
        active_threads = tuple(dict.fromkeys((thread, *recent_threads)))[:4]
        turn = TrackedTurn(
            speaker_id=str(speaker_id), speaker_name=str(speaker_name),
            previous_speaker=previous, text=clean,
            likely_addressee=addressee, addressee_basis=basis, dialogue_act=act,
            likely_referent=referent, referent_basis=referent_basis,
            referent_confidence=referent_confidence,
            self_reference_likely=referent == "Stella" and referent_confidence >= 0.62,
            thread=thread, active_threads=active_threads,
            utterance_complete=utterance_complete,
            human_to_human=human_to_human, response_expected=expected,
            response_pressure=pressure,
            floor_state="continuing_directed_setup" if continuing_directed_setup else floor,
            continuation_of_direct_address=continuing_directed_setup,
            timestamp=timestamp,
        )
        if commit:
            with self._lock:
                self._recent.append(turn)
        return turn

    def _infer_referent(
        self, text: str, recent: tuple[TrackedTurn, ...], participant_names: tuple[str, ...],
        addressee: str, single_user_call: bool,
    ) -> tuple[str, str, float]:
        folded = text.casefold()
        if self._NAMED_SELF.search(folded):
            return "Stella", "explicit_name", 0.99
        if self._SECOND_PERSON.search(folded):
            if addressee == "Stella" or single_user_call:
                return "Stella", "second_person_addressed_to_stella", 0.94
            return "unclear", "second_person_target_ambiguous_in_group", 0.45
        pronoun = self._SELF_PRONOUN.search(folded)
        if not pronoun:
            return "unclear", "no_referent_marker", 0.0
        names = [name.casefold() for name in participant_names if name]
        mentioned = [
            (match.start(), name)
            for name in names
            if (match := re.search(rf"\b{re.escape(name)}\b", folded))
        ]
        if mentioned:
            return max(mentioned)[1], "explicit_participant_name", 0.93

        # In a live group conversation, an unanchored third-person pronoun often
        # points to the assistant when the immediately preceding branch concerned her.
        for turn in reversed(recent[-5:]):
            prior = turn.text.casefold()
            if self._NAMED_SELF.search(prior) or turn.likely_addressee == "Stella":
                return "Stella", "recent_stella_topic_or_address", 0.72
            prior_names = [
                (match.start(), name)
                for name in names
                if (match := re.search(rf"\b{re.escape(name)}\b", prior))
            ]
            if prior_names:
                return max(prior_names)[1], "recent_participant_antecedent", 0.68
        return "unclear", "ambiguous_pronoun", 0.35

    @staticmethod
    def _thread_for(text: str, recent: tuple[str, ...]) -> str:
        topics = {
            "memory": {"remember", "memory", "recall", "forget", "last time"},
            "voice_and_audio": {"voice", "audio", "hear", "sound", "mic", "speech"},
            "discord": {"discord", "server", "channel", "vc", "call"},
            "AI_and_Stella": {"mako", "stella", "model", "prompt", "ai"},
            "work_and_life": {"work", "job", "shift", "today", "home"},
            "games": {"game", "robot", "war robots", "build"},
        }
        for label, terms in topics.items():
            if any(term in text for term in terms):
                return label
        return recent[0] if recent else "current_conversation"

    def snapshot(self) -> list[dict[str, Any]]:
        with self._lock:
            return [turn.to_dict() for turn in self._recent]

    def observe_assistant(self, *, text: str, timestamp: str) -> None:
        clean = " ".join(text.split())
        with self._lock:
            # A delivered assistant turn consumes any open directed setup.
            # Keeping it alive after Stella has answered can misroute the same
            # speaker's next unrelated sentence for the remainder of 60 sec.
            self._pending_direct_address.clear()
            recent_threads = tuple(dict.fromkeys(item.thread for item in self._recent))
            previous = self._recent[-1].speaker_name if self._recent else ""
            thread = self._thread_for(clean.casefold(), recent_threads)
            self._recent.append(TrackedTurn(
                speaker_id="stella", speaker_name="Stella", previous_speaker=previous,
                text=clean, likely_addressee="none", addressee_basis="assistant_turn",
                likely_referent="Stella", referent_basis="self", referent_confidence=1.0,
                self_reference_likely=True, dialogue_act="assistant_response", thread=thread,
                active_threads=tuple(dict.fromkeys((thread, *recent_threads)))[:4],
                utterance_complete=True, human_to_human=False, response_expected=False,
                response_pressure=0.0, floor_state="human_holds_floor",
                continuation_of_direct_address=False, timestamp=timestamp,
            ))

