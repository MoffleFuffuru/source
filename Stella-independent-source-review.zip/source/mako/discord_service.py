from __future__ import annotations

import asyncio
import audioop
import json
import logging
import os
import queue
import re
import threading
import wave
from collections import Counter, defaultdict, deque
from concurrent.futures import Future
from dataclasses import dataclass, replace
from datetime import UTC, datetime, timedelta
from pathlib import Path
from time import monotonic, time, sleep
from typing import Any
from uuid import uuid4

from .config import DiscordConfig
from .core import MakoCore
from .affect import LiveAffectAnalyzer
from .call_journal import CallJournal
from .conversation_tracker import ConversationTracker
from .call_continuity import (
    CallContinuity,
    SileroSpeechOnsetGate,
    SustainedSpeechGate,
    interrupt_confirmation_ready,
)
from .memory import is_memory_recall_request
from .memory_subject import is_personal_memory_summary_request, resolve_memory_subject
from .recall_bridge import deep_recall_bridge
from .elevenlabs_discord import SpeakerPool
from .voice_exchange import VoiceContribution, VoiceExchangeBuffer, local_timestamp
from .discord_delay_notice import DiscordDelayNotice
from .sage.playback import PlaybackTrace
from .models import ConversationEvent, EventSource, InteractionMode, Visibility
from .voice import VoiceEngine, inworld_expressive_text
from .xai_realtime_voice import render_xai_voice_wav


LOG = logging.getLogger(__name__)
POST_INTERRUPT_QUIET_SECONDS = 1.5
VAD_END_CUSHION_SECONDS = 0.05


def _post_interrupt_resume_deadline(
    now: float, endpointed_at: float | None, last_speech_at: float | None,
) -> float:
    transcript_end = endpointed_at if endpointed_at is not None else now
    deadlines = [transcript_end + POST_INTERRUPT_QUIET_SECONDS]
    if last_speech_at is not None:
        deadlines.append(last_speech_at + POST_INTERRUPT_QUIET_SECONDS + VAD_END_CUSHION_SECONDS)
    return max(deadlines)


def _stop_voice_playback(voice_client) -> None:
    """Stop only output; VoiceRecvClient.stop() also tears down the input listener."""
    stop_playing = getattr(voice_client, "stop_playing", None)
    if callable(stop_playing):
        stop_playing()
        return
    if callable(getattr(voice_client, "stop_listening", None)):
        LOG.error("Voice client exposes receive control but no playback-only stop; preserving listener")
        return
    voice_client.stop()


def _is_voice_hush_command(text: str) -> bool:
    normalized = re.sub(r"[^a-z0-9']+", " ", text.casefold()).strip()
    named = re.search(r"\b(?:stella|mako)\b.*\b(?:shut up|be quiet|hush|stop talking|stop speaking|quiet)\b", normalized)
    short = re.fullmatch(r"(?:please )?(?:shut up|be quiet|hush|stop talking|stop speaking|quiet)(?: now)?", normalized)
    directed = re.fullmatch(r"(?:(?:could|can|would) you |please )+(?:please )?(?:shut up|be quiet|hush|stop talking|stop speaking|quiet)(?: now)?", normalized)
    return bool(named or short or directed)


def _is_direct_voice_address(text: str) -> bool:
    normalized = re.sub(r"[^a-z0-9']+", " ", text.casefold()).strip()
    return bool(
        re.match(r"^(?:hey |hi |okay |alright )?(?:stella|mako)\b", normalized)
        or re.match(r"^(?:hey )?(?:can|could|would) you\b", normalized)
        or re.match(r"^(?:what|how|why|where|when) do you\b", normalized)
    )


def _partial_is_interrupt_worthy(text: str) -> bool:
    """Require a real phrase, explicit address, or clear floor-taking command."""
    normalized = " ".join(text.casefold().split())
    if not normalized:
        return False
    if _is_direct_voice_address(normalized) or re.match(
        r"^(?:wait|stop|hold on|hang on|one second|one sec|listen)\b", normalized
    ):
        return True
    words = re.sub(r"[^a-z0-9']+", " ", normalized).split()
    content = [word for word in words if word not in {
        "yeah", "yep", "yes", "no", "okay", "ok", "uh", "um", "so", "well",
        "mm", "mhm", "uh-huh", "oh", "ah", "hmm", "hm", "right", "got", "it",
        "i", "was", "is", "the", "a", "and", "but", "or",
    }]
    if len(words) == 1 and len(words[0]) <= 1:
        return False
    if len(words) >= 3 and len(content) <= 1:
        return False
    return len(content) >= 1


def _is_valid_short_voice_turn(text: str) -> bool:
    """Filter sub-three-word STT fragments except complete social acts/sentences."""
    clean = " ".join(text.split())
    normalized = re.sub(r"[^a-z0-9']+", " ", clean.casefold()).strip()
    words = normalized.split()
    if len(words) >= 3:
        return True
    if not words:
        return False
    if _is_voice_hush_command(clean):
        return True
    if re.fullmatch(
        r"(?:hey|hi|hello|yo|good morning|good afternoon|good evening)"
        r"[, ]*(?:[a-z][a-z'-]*)?[!.?,]*", clean.casefold().strip()
    ):
        return True
    if len(words) == 1 and (
        clean.rstrip().endswith("?") or words[0] in {"who", "what", "when", "where", "why", "how", "which"}
    ):
        return True
    if len(words) <= 2 and re.match(r"^(?:wait|stop|listen|hold on|hang on)\b", normalized) and clean.rstrip().endswith((".", "!")):
        return True
    if len(words) <= 2 and re.match(r"^(?:wait|stop|listen|hold on|hang on)\b", normalized) and clean.rstrip().endswith((".", "!")):
        return True
    if _is_direct_voice_address(clean) and clean.rstrip().endswith((".", "!", "?")):
        return True
    if not clean.rstrip().endswith((".", "!")):
        return False

    # Short acknowledgments and vocal reactions are not standalone turns even
    # when ASR decorates them with punctuation.
    if words[0] in {
        "yeah", "yep", "yes", "no", "okay", "ok", "uh", "um", "so", "well",
        "mm", "mhm", "uh-huh", "oh", "ah", "hmm", "hm", "right", "got", "it",
        "clears", "throat", "laughs", "laughing",
    }:
        return False
    if len(words) != 2:
        return False
    # Keep common two-word clauses with an overt subject/copula or finite verb.
    first, second = words
    complete_clause = (
        first in {"i'm", "im", "you're", "youre", "he's", "hes", "she's", "shes", "it's", "its", "that's", "thats", "we're", "were", "they're", "theyre"}
        or (first in {"i", "you", "we", "they", "he", "she", "it", "that", "this"}
            and second in {"am", "is", "are", "was", "were", "do", "does", "did", "can", "could", "will", "would", "have", "has", "had", "know", "think", "agree", "understand", "remember", "work", "help"})
        or first in {"sounds", "looks", "seems", "works", "helps", "makes", "wait", "stop", "listen", "hold", "hang"}
    )
    return complete_clause

class _DiscordReplyStream:
    """Turn streamed model JSON tokens into complete clauses for Discord TTS."""

    def __init__(
        self, *, require_response_decision: bool = False, expressive_tts: bool = False, user_text: str = ""
    ) -> None:
        self.raw = ""
        self.sent = ""
        self.chunks: queue.Queue[str | None] = queue.Queue()
        self.started = False
        self.require_response_decision = require_response_decision
        self.response_decision: bool | None = None
        self.suppressed = False
        self.prefix = ""
        self.floor_action: str | None = None
        self.expressive_tts = expressive_tts
        self.user_text = user_text
        self.expression: str | None = None

    def _with_prefix(self, text: str) -> str:
        prefix, self.prefix = self.prefix, ""
        return f"{prefix} {text}" if prefix else text

    def on_token(self, token: str) -> None:
        from .call import _streamed_json_text

        self.raw += token
        floor = re.search(r'"floor_action"\s*:\s*"(yield|claim)"', self.raw, re.I)
        if floor is not None:
            self.floor_action = floor.group(1).casefold()
        if self.expressive_tts and self.expression is None:
            expression = re.search(
                r'"expression"\s*:\s*"(neutral|happy|smug|sleepy|annoyed|embarrassed|concerned|excited)"',
                self.raw, re.I,
            )
            if expression is not None:
                from .dialogue import _normalize_targeted_expression
                from .models import ConversationEvent, Expression, ResponseCandidate

                candidate = ResponseCandidate(text="", expression=Expression(expression.group(1).casefold()))
                _normalize_targeted_expression(ConversationEvent(content=self.user_text), candidate)
                self.expression = candidate.expression.value
                from .elevenlabs_voice import mood_tag
                self.prefix = mood_tag(self.expression)
        if self.require_response_decision and self.response_decision is None:
            decision = re.search(r'"respond"\s*:\s*(true|false)\b', self.raw, re.I)
            if decision is None:
                return
            self.response_decision = decision.group(1).casefold() == "true"
            self.suppressed = not self.response_decision
        if self.suppressed:
            return
        if self.require_response_decision and self.floor_action is None:
            return
        if self.expressive_tts and self.expression is None:
            return
        pending = _streamed_json_text(self.raw)[len(self.sent):]
        boundary = re.search(r"[.!?;,]\s+", pending)
        if boundary is None:
            return
        phrase = pending[:boundary.end()]
        if not phrase.strip():
            return
        self.sent += phrase
        if not self.started:
            LOG.info("Discord VC model first speakable clause chars=%s", len(phrase))
        self.started = True
        self.chunks.put(self._with_prefix(phrase))

    def finish(self, text: str) -> bool:
        if self.suppressed or (self.require_response_decision and self.response_decision is False):
            self.chunks.put(None)
            return False
        if self.require_response_decision and self.response_decision is None:
            self.response_decision = bool(text.strip())
        if self.require_response_decision and self.floor_action is None:
            self.floor_action = "yield"
        if not self.started:
            if text.strip() and self.response_decision is not False:
                self.chunks.put(self._with_prefix(text))
            self.chunks.put(None)
            return bool(text.strip())
        if not text.startswith(self.sent.rstrip()):
            LOG.warning("Discord streamed reply diverged from final text; ending stream without replay")
            self.chunks.put(None)
            return True
        remainder = text[len(self.sent):]
        if remainder.strip():
            self.chunks.put(self._with_prefix(remainder))
        self.chunks.put(None)
        return True

    def abort(self) -> None:
        self.chunks.put(None)


def _discord_pcm_from_wav(path: Path) -> bytes:
    """Convert a rendered WAV into Discord's 20 ms 48 kHz stereo PCM format."""
    with wave.open(str(path), "rb") as wav:
        channels = wav.getnchannels()
        sample_width = wav.getsampwidth()
        sample_rate = wav.getframerate()
        pcm = wav.readframes(wav.getnframes())
    if sample_width != 2:
        pcm = audioop.lin2lin(pcm, sample_width, 2)
    if channels == 1:
        pcm = audioop.tostereo(pcm, 2, 1, 1)
    elif channels != 2:
        raise ValueError(f"Unsupported WAV channel count: {channels}")
    if sample_rate != 48_000:
        pcm, _ = audioop.ratecv(pcm, 2, 2, sample_rate, 48_000, None)
    return pcm


@dataclass(frozen=True, slots=True)
class DiscordObservation:
    message_id: str
    channel_id: str
    user_id: str
    discord_user_id: str
    display_name: str
    content: str
    created_at: str
    mentioned: bool = False
    replied_to_mako: bool = False


class DiscordService:
    """Official Discord bot transport for the shared Mako core.

    Discord is deliberately an I/O boundary: it creates normal ConversationEvents,
    delegates all reasoning/memory to MakoCore, and sends the resulting text back as a
    reply to the originating message.
    """

    def __init__(self, core: MakoCore, config: DiscordConfig) -> None:
        self.core = core
        self.config = config
        self._thread: threading.Thread | None = None
        self._client: Any = None
        self._discord: Any = None
        renderer_voice_config = core.config.voice
        if renderer_voice_config.tts_backend.lower() == "qwen3":
            # The desktop call engine owns Qwen's GPU model. Discord keeps a
            # lightweight independent renderer so both transports cannot load
            # the same model onto CUDA at once.
            renderer_voice_config = replace(
                renderer_voice_config,
                tts_backend="kokoro",
                kokoro_device="cpu",
            )
        self._voice_renderer = VoiceEngine(renderer_voice_config, core.paths.temporary)
        from .elevenlabs_discord import VocalProfilePool
        self._vocal_profiles = VocalProfilePool(core.config.voice, self._on_discord_vocal_profile)
        self._started = threading.Event()
        self._proactive_at: dict[str, float] = defaultdict(float)
        self._voice_lock = threading.RLock()
        self._voice_generation_active: set[int] = set()
        self._voice_generation_cancel: dict[int, threading.Event] = {}
        self._voice_delay_notice_revision: dict[int, int] = {}
        self._voice_streams: dict[int, _DiscordReplyStream] = {}
        self._voice_sage_intents: dict[int, tuple[str, str]] = {}
        self._voice_playback_trace: dict[int, PlaybackTrace] = {}
        self._sage_text_channels: dict[str, Any] = {}
        self._sage_busy_text: set[str] = set()
        self._pending_voice_turns: dict[int, deque[tuple[Any, str, str, dict[str, Any]]]] = defaultdict(deque)
        # Retain the PCM energy candidate as a Scribe fallback; Silero now owns
        # the fast, local speech-onset stop signal.
        self._voice_interrupt_gate = SustainedSpeechGate(
            attack_seconds=0.18, calibration_seconds=0.0, hangover_seconds=0.45
        )
        self._silero_interrupt_gate: SileroSpeechOnsetGate | None = None
        self._silero_interrupt_loading = False
        self._initialize_silero_interrupt_gate()
        self._voice_interrupt_candidates: dict[tuple[int, str], float] = {}
        self._voice_interrupt_partial_text: dict[tuple[int, str], str] = {}
        self._voice_exchanges: dict[int, VoiceExchangeBuffer] = defaultdict(VoiceExchangeBuffer)
        self._voice_generation_revision: dict[int, int] = {}
        self._voice_active_reply_text: dict[int, str] = {}
        self._voice_floor_claim_until: dict[int, tuple[threading.Event, float]] = {}
        self._voice_interrupted_text: dict[int, list[str]] = defaultdict(list)
        self._voice_quiet_until: dict[int, float] = {}
        self._voice_endpointed_at: dict[int, float] = {}
        self._voice_last_speech_at: dict[int, float] = {}
        self._voice_response_timers: dict[int, threading.Timer] = {}
        self._voice_interruption_pending: set[int] = set()
        self._voice_response_required: set[int] = set()
        self._voice_playback_locks: dict[int, Any] = {}
        self._voice_join_locks: dict[int, Any] = {}
        self._handled_message_ids: deque[int] = deque(maxlen=512)
        self._handled_message_id_set: set[int] = set()
        self._voice_timeline: dict[int, deque[tuple[str, str]]] = defaultdict(
            lambda: deque(maxlen=12)
        )
        self._voice_journals: dict[int, CallJournal] = {}
        self._voice_trackers: dict[int, ConversationTracker] = {}
        self._voice_continuity: dict[int, CallContinuity] = {}
        self._affect_monitor = LiveAffectAnalyzer(
            core.paths.data / "hf-cache",
            enabled=core.config.voice.live_affect_enabled,
            experimental=core.config.voice.live_affect_experimental_enabled,
            window_seconds=core.config.voice.live_affect_window_seconds,
        )
        self._discord_transcriber: SpeakerPool | None = None
        self._observation_windows: dict[str, deque[DiscordObservation]] = defaultdict(
            lambda: deque(maxlen=max(12, self.config.autonomy_context_messages))
        )
        self._pending_observations: dict[str, set[str]] = defaultdict(set)
        self._review_due_at: dict[str, float] = {}
        self._review_active: set[str] = set()
        self._followup_remaining: dict[str, int] = {}
        self._mention_review_at: dict[tuple[str, str], float] = defaultdict(float)
        # Direct replies and autonomy are separate generation paths. Keep their
        # public, channel-local output in one short-lived continuity buffer.
        self._recent_channel_replies: dict[str, deque[str]] = defaultdict(
            lambda: deque(maxlen=6)
        )
        self._autonomy_reply_registry = self.core.paths.data / "discord_autonomy_replies.json"
        self._autonomy_replied_ids = self._load_autonomy_replied_ids()
        self._autonomy_task = None

    def start(self) -> None:
        if not self.config.enabled:
            LOG.info("Discord integration disabled")
            return
        token = self._token_from_environment()
        if not token:
            LOG.error("Discord enabled but %s is not set", self.config.token_environment_variable)
            return
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(
            target=self._run,
            args=(token,),
            name="mako-discord",
            daemon=True,
        )
        self._thread.start()

    def _warm_voice_renderer(self) -> None:
        try:
            self._voice_renderer.prepare_speech()
            LOG.info("Discord voice renderer is ready")
        except Exception as exc:
            LOG.warning("Discord voice warmup failed: %s", exc)

    def _token_from_environment(self) -> str:
        """Read the bot token without ever logging it, including a persisted Windows user value."""
        token = os.getenv(self.config.token_environment_variable, "").strip()
        if token or os.name != "nt":
            return token
        try:
            import winreg

            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as key:
                value, _ = winreg.QueryValueEx(key, self.config.token_environment_variable)
            return str(value).strip()
        except OSError:
            return ""

    def stop(self) -> None:
        self._vocal_profiles.close()
        self._affect_monitor.stop()
        with self._voice_lock:
            for cancel in self._voice_generation_cancel.values():
                cancel.set()
            for stream in self._voice_streams.values():
                stream.abort()
            for timer in self._voice_response_timers.values():
                timer.cancel()
            self._voice_response_timers.clear()
            self._voice_interruption_pending.clear()
            self._voice_response_required.clear()
            self._pending_voice_turns.clear()
        if self._client is not None:
            for guild_id in tuple(self._voice_generation_active):
                guild = self._client.get_guild(guild_id)
                if guild and guild.voice_client and guild.voice_client.is_playing():
                    guild.voice_client.stop()
        for guild_id, journal in list(self._voice_journals.items()):
            continuity = self._voice_continuity.get(guild_id)
            if continuity is not None:
                continuity.finish(journal.path)
            journal.close(transport="discord_voice", end_reason="application_shutdown")
        self._voice_journals.clear()
        self._voice_continuity.clear()
        client = self._client
        if client is not None and not client.loop.is_closed():
            future = asyncio.run_coroutine_threadsafe(client.close(), client.loop)
            try:
                future.result(timeout=8)
            except Exception as exc:
                LOG.warning("Discord shutdown did not complete cleanly: %s", exc)
        self._voice_renderer.shutdown()
        if self._discord_transcriber is not None:
            self._discord_transcriber.close()

    def send_dm(self, user_id: str, content: str) -> Future[None]:
        return self._submit(self._send_dm(user_id, content))

    def send_channel(self, channel_id: str, content: str) -> Future[None]:
        return self._submit(self._send_channel(channel_id, content))

    def trigger_autonomy_review(self) -> Future[None]:
        """Run one manual autonomy review for the first configured channel."""
        channel_ids = list(self.config.allowed_channel_ids)
        if not channel_ids:
            future: Future[None] = Future()
            future.set_exception(RuntimeError("No Discord channel is configured for autonomy testing"))
            return future
        return self._submit(self._trigger_autonomy_review(channel_ids[0]))

    async def _trigger_autonomy_review(self, channel_id: str) -> None:
        if self._client is None or self._client.is_closed():
            raise RuntimeError("Discord is not connected")
        channel = self._client.get_channel(int(channel_id))
        if channel is None:
            channel = await self._client.fetch_channel(int(channel_id))
        await self._backfill_manual_autonomy_window(channel)
        if not self._pending_observations.get(channel_id):
            raise RuntimeError("No new Discord activity is buffered for autonomy testing")
        await self._review_discord_activity(channel, trigger="manual")

    async def _backfill_manual_autonomy_window(self, channel) -> None:
        """Capture the last 30 minutes so a manual test is not startup-relative."""
        cutoff = datetime.now(UTC) - timedelta(minutes=30)
        bot_user = self._client.user if self._client else None
        async for message in channel.history(
            limit=max(12, self.config.autonomy_history_messages),
            after=cutoff,
            oldest_first=True,
        ):
            author = getattr(message, "author", None)
            if not author or getattr(author, "bot", False):
                continue
            content = str(getattr(message, "content", "") or "").strip()
            if not content:
                continue
            user_id = self._mako_user_id(author.id)
            event = ConversationEvent(
                id=f"discord:{message.id}",
                content=content,
                source=EventSource.DISCORD,
                visibility=Visibility.PRIVATE if getattr(message, "guild", None) is None else Visibility.PUBLIC,
                user_id=user_id,
                display_name=str(getattr(author, "display_name", getattr(author, "name", "unknown"))),
                channel_id=self._speaker_channel_id(channel.id, user_id),
                metadata={
                    "discord_user_id": str(author.id),
                    "discord_channel_id": str(channel.id),
                    "discord_message_id": str(message.id),
                    "discord_mentioned": bool(bot_user and bot_user in getattr(message, "mentions", [])),
                },
            )
            created_at = getattr(message, "created_at", None)
            if created_at:
                event.created_at = created_at.isoformat()
            self._observe_message(
                event,
                replied_to_mako=bool(bot_user and self._replies_to_mako(message, int(bot_user.id))),
            )

    def _submit(self, coroutine) -> Future[None]:
        if self._client is None or self._client.loop.is_closed():
            future: Future[None] = Future()
            future.set_exception(RuntimeError("Discord is not connected"))
            return future
        return asyncio.run_coroutine_threadsafe(coroutine, self._client.loop)

    def _run(self, token: str) -> None:
        try:
            import discord
        except ImportError:
            LOG.error("Discord integration needs discord.py; install requirements.txt")
            return

        intents = discord.Intents.none()
        intents.guilds = True
        intents.guild_messages = True
        intents.dm_messages = True
        intents.message_content = True
        intents.voice_states = True
        client = discord.Client(intents=intents)
        self._client = client
        self._discord = discord

        @client.event
        async def on_ready() -> None:
            self._started.set()
            LOG.info("Discord connected as %s (%s)", client.user, client.user.id if client.user else "unknown")
            if self._autonomy_task is None or self._autonomy_task.done():
                self._autonomy_task = asyncio.create_task(self._autonomy_loop())

        @client.event
        async def on_disconnect() -> None:
            LOG.warning("Discord gateway disconnected; discord.py will attempt recovery")

        @client.event
        async def on_message(message) -> None:
            await self._handle_message(message)

        @client.event
        async def on_voice_state_update(member, before, after) -> None:
            if getattr(member, "bot", False) or getattr(member, "guild", None) is None:
                return
            guild = member.guild
            voice = getattr(guild, "voice_client", None)
            channel = getattr(voice, "channel", None)
            if channel is None or (before.channel != channel and after.channel != channel):
                return
            self._sync_sage_voice_people(guild, channel)

        try:
            client.run(token, log_handler=None)
        except Exception as exc:
            LOG.exception("Discord service stopped: %s", exc)
        finally:
            self._client = None
            self._discord = None
            self._started.clear()

    async def _handle_message(self, message) -> None:
        client = self._client
        if client is None or client.user is None or message.author.bot:
            return
        message_id = int(message.id)
        if message_id in self._handled_message_id_set:
            LOG.warning("Discord duplicate message ignored id=%s", message_id)
            return
        if len(self._handled_message_ids) == self._handled_message_ids.maxlen:
            self._handled_message_id_set.discard(self._handled_message_ids[0])
        self._handled_message_ids.append(message_id)
        self._handled_message_id_set.add(message_id)
        guild_id = str(message.guild.id) if message.guild else "dm"
        channel_id = str(message.channel.id)
        LOG.info("Discord message event guild=%s channel=%s author=%s", guild_id, channel_id, message.author.id)
        content = str(message.content or "").strip()
        if not content:
            LOG.info("Discord message ignored: empty content (Message Content Intent likely disabled)")
            return
        if not self._is_permitted(message):
            if message.guild is None:
                reason = "direct messages are disabled"
            elif str(message.guild.id) not in self.config.allowed_guild_ids:
                reason = f"guild {message.guild.id} is not permitted"
            elif str(message.channel.id) in self.config.ignored_channel_ids:
                reason = f"channel {message.channel.id} is explicitly ignored"
            else:
                reason = f"channel {message.channel.id} is not permitted"
            LOG.info("Discord message ignored: %s", reason)
            return
        if await self._handle_sage_command(message, content):
            return
        if await self._handle_owner_voice_command(message, content):
            return

        direct = message.guild is None
        mentioned = client.user in message.mentions
        replied_to_mako = self._replies_to_mako(message, int(client.user.id))
        user_id = self._mako_user_id(message.author.id)
        event = ConversationEvent(
            id=f"discord:{message.id}",
            content=content,
            source=EventSource.DISCORD,
            visibility=Visibility.PRIVATE if direct else Visibility.PUBLIC,
            user_id=user_id,
            display_name=str(getattr(message.author, "display_name", message.author.name)),
            channel_id=self._speaker_channel_id(message.channel.id, user_id),
            reply_to=str(message.id),
            metadata={
                "discord_user_id": str(message.author.id),
                "discord_guild_id": str(message.guild.id) if message.guild else "",
                "discord_channel_id": str(message.channel.id),
                "discord_message_id": str(message.id),
                "discord_is_dm": direct,
                "discord_mentioned": mentioned,
            },
        )
        created_at = getattr(message, "created_at", None)
        if created_at:
            event.created_at = created_at.isoformat()

        if not direct:
            scope = f"discord:text:{message.guild.id}:{channel_id}"
            self._sage_text_channels[scope] = message.channel
            if getattr(self.core, "sage", None):
                self.core.sage.observe(scope, str(message.id), user_id, event.display_name, content)
            self.core.memory.record_public_observation(
                event
            )
            self._observe_message(event, replied_to_mako=replied_to_mako)
            direct_response_channel = channel_id in self.config.direct_response_channel_ids
            if mentioned or replied_to_mako:
                # Directly addressed messages always use the normal responder;
                # autonomy only evaluates unaddressed channel activity.
                self._pending_observations[str(message.channel.id)].discard(str(message.id))
            elif self.config.autonomy_enabled and not direct_response_channel:
                return
        else:
            scope = f"discord:text:dm:{channel_id}"
        sage = getattr(self.core, "sage", None)
        if sage is not None and sage.enabled:
            if direct:
                sage.observe(scope, str(message.id), user_id, event.display_name, content)
            mood = sage.user_mood(scope, user_id)
            event.metadata["discord_user_mood_state"] = mood
            event.metadata["discord_user_mood"] = sage.user_mood_prompt(scope, user_id)

        should_reply = direct or mentioned or replied_to_mako or channel_id in self.config.direct_response_channel_ids
        if not should_reply and self._proactive_enabled(message):
            should_reply = self._may_proactively_reply(str(message.channel.id))
        if not should_reply:
            return
        # A bot cannot index messages it missed while offline. For explicit recall
        # requests, fetch a small factual slice from this allowed public channel.
        if not direct and is_memory_recall_request(content):
            event.metadata["discord_live_recall"] = await self._recent_channel_recall_evidence(
                message, client.user
            )
        LOG.info("Discord incoming message user=%s channel=%s", message.author.id, message.channel.id)
        try:
            self._sage_busy_text.add(channel_id)
            received_at = monotonic()
            event.metadata["discord_recent_mako_replies"] = self._recent_reply_context(channel_id)
            generation = asyncio.create_task(
                asyncio.to_thread(
                    self._respond_discord_text,
                    event,
                    avoid_responses=list(self._recent_channel_replies[channel_id]),
                )
            )
            # Match desktop chat: generation overlaps reading, then Discord shows
            # typing only once Mako has plausibly read the incoming message.
            typing_starts_at = received_at + self.core.clock.reading_seconds(content)
            await asyncio.sleep(max(0.0, typing_starts_at - monotonic()))
            async with message.channel.typing():
                result = await generation
                schedule = self.core.clock.schedule(
                    received_at=received_at,
                    model_ready_at=monotonic(),
                    user_text=content,
                    response_text=result.text,
                    complexity=result.complexity,
                    typing_started_at=typing_starts_at,
                )
                # Direct mentions are active requests, not social-pacing demos.
                # Never leave an addressed user watching a permanent typing state
                # because a long delivery schedule is waiting out an old turn.
                delivery_wait = (
                    max(0.0, schedule.delivery_at - monotonic())
                    if not (mentioned or replied_to_mako or direct)
                    else 0.0
                )
                await asyncio.sleep(delivery_wait + max(0.0, self.config.post_read_delay_seconds))
            if result.text.strip():
                # Replying keeps Mako addressed to the actual speaker in busy channels.
                await message.reply(
                    result.text,
                    mention_author=False,
                    allowed_mentions=self._discord.AllowedMentions.none(),
                )
                self.core.commit_deferred_call_response(event, result)
                self._apply_delivered_user_mood(scope, user_id, result)
                self._remember_channel_reply(channel_id, result.text)
                if not direct and getattr(self.core, "sage", None):
                    self.core.sage.observe(scope, f"stella:{result.turn_id}", "stella", "Stella", result.text, kind="assistant")
                LOG.info("Discord reply sent message=%s", message.id)
                # Discord text replies stay text. Spoken VC turns use the separate
                # voice-response pipeline below and must not echo chat messages.
        except Exception as exc:
            LOG.exception("Discord message handling failed message=%s: %s", message.id, exc)
            try:
                await message.reply("My AI service couldn't complete that reply. Please try again in a moment.",
                                    mention_author=False, allowed_mentions=self._discord.AllowedMentions.none())
            except Exception:
                LOG.exception("Discord could not deliver the failure notice message=%s", message.id)
        finally:
            self._sage_busy_text.discard(channel_id)
            self.core.discard_deferred_call_response(event.id)

    def _apply_delivered_user_mood(self, scope, actor, result):
        """Persist model affect only after the addressed user actually received the turn."""
        sage = getattr(self.core, "sage", None)
        delta = getattr(result, "mood_delta", None)
        if (sage is None or not getattr(sage, "enabled", False) or not actor
                or not isinstance(delta, dict) or not delta):
            return
        sage.apply_user_mood_delta(scope, actor, delta)

    def _respond_discord_text(self, event, **kwargs):
        """Retry a transient provider failure once; never silently abandon it."""
        for attempt in range(2):
            try:
                return self.core.respond(event, defer_commit=True, **kwargs)
            except Exception as exc:
                transient = any(term in str(exc).lower() for term in (
                    "429", "503", "502", "504", "timed out", "timeout", "overloaded", "request failed"))
                if attempt or not transient:
                    raise
                LOG.warning("Discord text retry event=%s", event.id)
                sleep(1.0)

    async def _handle_sage_command(self, message, content):
        if not content.lower().startswith("!sage"):
            return False
        if str(message.author.id) not in self.config.owner_user_ids:
            return False
        sage = getattr(self.core, "sage", None)
        if sage is None:
            return False
        action = content.lower().strip().split(maxsplit=1)
        command = action[1] if len(action) > 1 else "status"
        if command in {"on", "off"}:
            self.config.sage_enabled = command == "on"
            if command == "off":
                self.config.autonomy_enabled = False
            self.core.save_config()
            if command == "off":
                with self._voice_lock:
                    for guild_id in self._voice_sage_intents:
                        cancel = self._voice_generation_cancel.get(guild_id)
                        if cancel:
                            cancel.set()
                for guild in self._client.guilds:
                    voice = getattr(guild, "voice_client", None)
                    if voice is not None and guild.id in self._voice_sage_intents and voice.is_playing():
                        _stop_voice_playback(voice)
            text = f"Great Sage autonomy is {command}."
        elif command == "review":
            scope = f"discord:text:{message.guild.id}:{message.channel.id}" if message.guild else ""
            if scope:
                sage.observe(scope, str(message.id), "owner", str(message.author.display_name),
                             "Great Sage: reconsider the current conversation and unfinished intentions.")
                sage.request_review(scope)
                self._sage_text_channels[scope] = message.channel
            text = "Great Sage will review at the next quiet opportunity."
        else:
            state = sage.diagnostics()
            text = f"Great Sage: {'enabled' if state['enabled'] else 'disabled'}; {len(state['scopes'])} tracked conversations. Commands: !sage on, !sage off, !sage review."
        await message.reply(text, mention_author=False, allowed_mentions=self._discord.AllowedMentions.none())
        return True

    def _observe_message(self, event: ConversationEvent, *, replied_to_mako: bool) -> None:
        channel_id = str(event.metadata.get("discord_channel_id", ""))
        observation = DiscordObservation(
            message_id=str(event.metadata.get("discord_message_id", "")),
            channel_id=channel_id,
            user_id=event.user_id,
            discord_user_id=str(event.metadata.get("discord_user_id", "")),
            display_name=event.display_name,
            content=event.content,
            created_at=event.created_at,
            mentioned=bool(event.metadata.get("discord_mentioned")),
            replied_to_mako=replied_to_mako,
        )
        self._observation_windows[channel_id].append(observation)
        self._pending_observations[channel_id].add(observation.message_id)
        if self._followup_remaining.get(channel_id, 0) > 0:
            self._review_due_at[channel_id] = min(
                self._review_due_at.get(channel_id, float("inf")),
                monotonic() + 15.0,
            )
        self._review_due_at.setdefault(
            channel_id,
            monotonic() + max(60.0, self.config.autonomy_review_seconds),
        )

    def _recent_reply_context(self, channel_id: str) -> str:
        replies = self._recent_channel_replies.get(channel_id)
        if not replies:
            return ""
        return "\n".join(f"- {reply}" for reply in replies)

    def _remember_channel_reply(self, channel_id: str, text: str) -> None:
        clean = text.strip()
        if clean:
            self._recent_channel_replies[channel_id].append(clean)

    def _mention_review_ready(self, channel_id: str, user_id: str) -> bool:
        key = (channel_id, user_id)
        now = monotonic()
        if now - self._mention_review_at[key] < self.config.autonomy_mention_cooldown_seconds:
            return False
        self._mention_review_at[key] = now
        return True

    def pause_sage(self) -> None:
        """Stop autonomous Discord drafts/playback without dropping human transcripts."""
        with self._voice_lock:
            guild_ids = list(self._voice_sage_intents)
            for guild_id in guild_ids:
                cancel = self._voice_generation_cancel.get(guild_id)
                if cancel:
                    cancel.set()
        for guild_id in guild_ids:
            guild = self._client.get_guild(guild_id) if self._client else None
            voice = getattr(guild, "voice_client", None)
            if voice is not None and voice.is_playing():
                _stop_voice_playback(voice)

    async def _autonomy_loop(self) -> None:
        while self._client is not None and not self._client.is_closed():
            await asyncio.sleep(1.0 if self.config.sage_enabled else 15.0)
            if not (self.config.sage_enabled or self.config.autonomy_enabled):
                continue
            if self.config.sage_enabled:
                try:
                    await self._sage_autonomy_tick()
                except Exception:
                    LOG.exception("Great Sage admission tick failed")
                continue
            now = monotonic()
            for channel_id, due_at in list(self._review_due_at.items()):
                if due_at > now or not self._pending_observations.get(channel_id):
                    continue
                try:
                    channel = self._client.get_channel(int(channel_id))
                except (TypeError, ValueError):
                    channel = None
                if channel is not None:
                    await self._review_discord_activity(channel, trigger="periodic")

    async def _sage_autonomy_tick(self):
        sage = getattr(self.core, "sage", None)
        if sage is None or not sage.enabled:
            return
        if self._voice_generation_active or self._sage_busy_text or self.core._model_lock.locked():
            return
        for guild in self._client.guilds:
            voice = getattr(guild, "voice_client", None)
            channel = getattr(voice, "channel", None)
            if voice is None or channel is None or guild.id not in self._voice_journals:
                continue
            scope = f"discord:voice:{guild.id}:{channel.id}"
            humans = [p for p in channel.members if not p.bot]
            self._sync_sage_voice_people(guild, channel)
            with self._voice_lock:
                floor = (guild.id not in self._voice_generation_active
                         and not voice.is_playing()
                         and monotonic() - self._voice_last_speech_at.get(guild.id, 0) > 1.55
                         and self._voice_quiet_until.get(guild.id, 0) <= monotonic()
                         and not self._voice_exchanges[guild.id].snapshot()[1])
            choice = await asyncio.to_thread(sage.prepare, scope, floor_available=floor, voice=True)
            if not choice:
                continue
            intent_id, packet, revision = choice
            with self._voice_lock:
                if (not humans or guild.id in self._voice_generation_active
                        or monotonic() - self._voice_last_speech_at.get(guild.id, 0) <= 1.55
                        or self._voice_exchanges[guild.id].snapshot()[1]):
                    sage.finish(scope, intent_id, False)
                    continue
                cancel = threading.Event()
                self._voice_generation_active.add(guild.id)
                self._voice_generation_cancel[guild.id] = cancel
                self._voice_sage_intents[guild.id] = (scope, intent_id)
            threading.Thread(target=self._voice_generation_worker,
                             args=(guild.id, humans[0], "Internal Great Sage initiative; no human said this.", "", cancel, {}, (scope, intent_id)),
                             daemon=True).start()
        for scope, channel in list(self._sage_text_channels.items()):
            if str(channel.id) in self._sage_busy_text:
                continue
            if (str(channel.id) in self.config.require_mention_channel_ids
                    or str(channel.id) in self.config.ignored_channel_ids):
                continue
            # Channel membership is not proof that someone is actively reading.
            # Text attention follows actual participants observed in the timeline.
            choice = await asyncio.to_thread(sage.prepare, scope, floor_available=True, voice=False)
            if not choice:
                continue
            intent_id, packet, revision = choice
            event = ConversationEvent(content="Internal Great Sage initiative; no human said this.",
                source=EventSource.DISCORD, visibility=Visibility.PUBLIC,
                user_id="sage", display_name="Stella", channel_id=str(channel.id),
                metadata={"sage_initiated": True, "sage_packet": packet,
                          "discord_guild_id": str(channel.guild.id), "discord_channel_id": str(channel.id)})
            success = False
            try:
                result = await asyncio.to_thread(self.core.respond, event, defer_commit=True)
                with sage.lock:
                    stale = revision != sage._revision.get(scope, 0)
                if (sage.enabled and self.config.sage_enabled and result.text.strip() and not stale
                        and str(channel.id) not in self._sage_busy_text):
                    await channel.send(result.text, allowed_mentions=self._discord.AllowedMentions.none())
                    sage.started(scope, intent_id)
                    self.core.commit_deferred_call_response(event, result)
                    sage.observe(scope, f"stella:{result.turn_id}", "stella", "Stella", result.text, kind="assistant")
                    success = True
            except Exception:
                LOG.exception("Great Sage text initiative failed scope=%s", scope)
            finally:
                self.core.discard_deferred_call_response(event.id)
                sage.finish(scope, intent_id, success)

    def _activity_digest(
        self,
        channel_id: str,
        *,
        trigger: str,
        focus_message_id: str,
        excluded_message_ids: set[str],
    ) -> tuple[str, set[str]]:
        observations = list(self._observation_windows[channel_id])
        pending_ids = set(self._pending_observations[channel_id])
        eligible_ids = pending_ids - excluded_message_ids
        counts = Counter(item.display_name for item in observations if item.message_id in eligible_ids)
        relationship_lines = []
        seen_users: set[str] = set()
        for item in observations:
            if item.user_id in seen_users:
                continue
            seen_users.add(item.user_id)
            relationship_lines.append(
                f"- {item.display_name} ({item.user_id}): "
                f"{self.core.discord_relationship_summary(item.user_id)}"
            )
        representative = [item for item in observations if item.message_id in eligible_ids]
        if len(representative) > 12:
            representative = representative[:4] + representative[-8:]
        background = [item for item in observations if item.message_id not in pending_ids][-6:]
        message_lines = [
            f"- id={item.message_id} speaker={item.display_name}"
            f"{' [MENTIONED MAKO]' if item.mentioned or item.replied_to_mako else ''}: {item.content}"
            for item in representative
        ]
        background_lines = [
            f"- id={item.message_id} speaker={item.display_name}: {item.content}"
            for item in background
        ]
        digest = (
            f"Discord autonomy trigger: {trigger}\n"
            f"Channel ID: {channel_id}\n"
            f"Focused message ID: {focus_message_id or 'none'}\n"
            f"Eligible new activity: {len(eligible_ids)} messages; speakers: "
            + ", ".join(f"{name}={count}" for name, count in counts.items())
            + "\nPreviously answered messages are omitted and are never valid reply targets.\n"
            + "\nRelationship evidence:\n"
            + ("\n".join(relationship_lines) or "- none")
            + "\nRepresentative exact excerpts:\n"
            + ("\n".join(message_lines) or "- none")
            + "\nRecent background Mako previously observed silently:\n"
            + ("\n".join(background_lines) or "- none")
        )
        return digest, pending_ids

    async def _exact_channel_context(self, channel) -> tuple[str, set[str]]:
        lines: list[str] = []
        valid_ids: set[str] = set()
        async for item in channel.history(
            limit=max(12, self.config.autonomy_history_messages),
            oldest_first=True,
        ):
            text = str(getattr(item, "content", "") or "").strip()
            if not text:
                continue
            message_id = str(item.id)
            author = getattr(item, "author", None)
            name = str(getattr(author, "display_name", getattr(author, "name", "unknown")))
            is_mako = bool(self._client and author and author.id == self._client.user.id)
            if not getattr(author, "bot", False):
                valid_ids.add(message_id)
            lines.append(f"- id={message_id} speaker={name}{' [MAKO]' if is_mako else ''}: {text}")
        return "Exact recent channel messages:\n" + "\n".join(lines), valid_ids

    async def _review_discord_activity(
        self,
        channel,
        *,
        trigger: str,
        focus_message_id: str = "",
    ) -> None:
        channel_id = str(channel.id)
        if channel_id in self._review_active or not self._pending_observations.get(channel_id):
            return
        self._review_active.add(channel_id)
        try:
            await self._sync_autonomy_replied_ids(channel)
            digest, reviewed_ids = self._activity_digest(
                channel_id,
                trigger=trigger,
                focus_message_id=focus_message_id,
                excluded_message_ids=self._autonomy_replied_ids,
            )
            continuity = self._recent_reply_context(channel_id)
            if continuity:
                digest += "\nRecent Mako replies in this channel:\n" + continuity
            decision = await asyncio.to_thread(self.core.consider_discord_activity, digest)
            valid_ids = {item.message_id for item in self._observation_windows[channel_id]} - self._autonomy_replied_ids
            if decision is not None and decision.action == "inspect":
                exact_context, exact_ids = await self._exact_channel_context(channel)
                valid_ids |= exact_ids - self._autonomy_replied_ids
                decision = await asyncio.to_thread(
                    self.core.consider_discord_activity,
                    digest + "\n\n" + exact_context,
                    exact_messages=True,
                )
            if decision is None:
                self._review_due_at[channel_id] = monotonic() + 60.0
                return
            LOG.info(
                "Discord autonomy decision channel=%s trigger=%s action=%s",
                channel_id,
                trigger,
                decision.action,
            )
            if decision.action == "reply" and decision.message_id in valid_ids:
                if decision.message_id in self._autonomy_replied_ids:
                    LOG.info("Discord autonomy reply rejected: already replied message=%s", decision.message_id)
                    return
                target = await channel.fetch_message(int(decision.message_id))
                if not getattr(target.author, "bot", False):
                    user_id = self._mako_user_id(target.author.id)
                    event = ConversationEvent(
                        id=f"discord-autonomy:{uuid4().hex}",
                        content=str(target.content or "").strip(),
                        source=EventSource.DISCORD,
                        visibility=Visibility.PUBLIC,
                        user_id=user_id,
                        display_name=str(getattr(target.author, "display_name", target.author.name)),
                        channel_id=self._speaker_channel_id(target.channel.id, user_id),
                        reply_to=str(target.id),
                        metadata={
                            "discord_user_id": str(target.author.id),
                            "discord_guild_id": str(target.guild.id) if target.guild else "",
                            "discord_channel_id": str(target.channel.id),
                            "discord_message_id": str(target.id),
                            "discord_autonomous": True,
                        },
                    )
                    # Make this reply visible to direct generation immediately;
                    # the actual send still respects the configured reading delay.
                    self._remember_channel_reply(channel_id, decision.text)
                    await asyncio.sleep(max(0.0, self.config.post_read_delay_seconds))
                    await target.reply(
                        decision.text,
                        mention_author=False,
                        allowed_mentions=self._discord.AllowedMentions.none(),
                    )
                    self._autonomy_replied_ids.add(str(target.id))
                    self._save_autonomy_replied_ids()
                    self.core.record_discord_autonomy(event, decision)
                    LOG.info("Discord autonomous reply sent message=%s", target.id)
                    if trigger != "followup":
                        self._followup_remaining[channel_id] = 1
            if trigger == "followup":
                self._followup_remaining.pop(channel_id, None)
            self._pending_observations[channel_id].difference_update(reviewed_ids)
            if self._pending_observations[channel_id]:
                self._review_due_at[channel_id] = monotonic() + self.config.autonomy_review_seconds
            else:
                self._review_due_at.pop(channel_id, None)
        except Exception as exc:
            self._review_due_at[channel_id] = monotonic() + 60.0
            LOG.exception("Discord autonomy review failed channel=%s: %s", channel_id, exc)
        finally:
            self._review_active.discard(channel_id)

    def _load_autonomy_replied_ids(self) -> set[str]:
        try:
            data = json.loads(self._autonomy_reply_registry.read_text(encoding="utf-8"))
        except (OSError, ValueError, json.JSONDecodeError):
            return set()
        return {str(value) for value in data if str(value).isdigit()}

    def _save_autonomy_replied_ids(self) -> None:
        # Keep a bounded, restart-safe record of Discord messages Mako has answered.
        values = sorted(self._autonomy_replied_ids)[-2000:]
        self._autonomy_replied_ids = set(values)
        self._autonomy_reply_registry.write_text(json.dumps(values), encoding="utf-8")

    async def _sync_autonomy_replied_ids(self, channel) -> None:
        """Recover existing Mako reply targets after a restart before sending."""
        bot_id = getattr(getattr(self._client, "user", None), "id", None)
        if bot_id is None:
            return
        discovered: set[str] = set()
        async for item in channel.history(limit=max(12, self.config.autonomy_history_messages)):
            author = getattr(item, "author", None)
            if getattr(author, "id", None) != bot_id:
                continue
            reference = getattr(item, "reference", None)
            target_id = getattr(reference, "message_id", None)
            if target_id is not None:
                discovered.add(str(target_id))
        if discovered - self._autonomy_replied_ids:
            self._autonomy_replied_ids.update(discovered)
            self._save_autonomy_replied_ids()

    async def _recent_channel_recall_evidence(self, message, bot_user) -> list[str]:
        """Return recent public Discord facts for an explicit in-channel recall request."""
        target_ids = {
            str(member.id)
            for member in getattr(message, "mentions", [])
            if getattr(member, "id", None) != getattr(bot_user, "id", None)
        }
        evidence: list[str] = []
        try:
            async for item in message.channel.history(limit=50, oldest_first=False):
                if item.id == message.id or getattr(item.author, "bot", False):
                    continue
                if target_ids and str(item.author.id) not in target_ids:
                    continue
                text = str(item.content or "").strip()
                if not text:
                    continue
                name = str(getattr(item.author, "display_name", item.author.name))
                evidence.append(
                    f"Recent Discord channel message from {name} ({item.author.id}): {text}"
                )
                # Keep recovered public messages so future recall can use local
                # memory even after the live Discord history window moves on.
                recovered_event = ConversationEvent(
                        id=f"discord-history:{item.id}",
                        content=text,
                        source=EventSource.DISCORD,
                        visibility=Visibility.PUBLIC,
                        user_id=self._mako_user_id(item.author.id),
                        display_name=name,
                        channel_id=self._speaker_channel_id(message.channel.id, self._mako_user_id(item.author.id)),
                        reply_to=str(item.id),
                        metadata={
                            "discord_user_id": str(item.author.id),
                            "discord_channel_id": str(message.channel.id),
                            "discord_message_id": str(item.id),
                        },
                )
                created_at = getattr(item, "created_at", None)
                if created_at:
                    recovered_event.created_at = created_at.isoformat()
                self.core.memory.record_public_observation(recovered_event)
                if len(evidence) >= 4:
                    break
        except Exception as exc:
            LOG.warning("Could not fetch recent Discord recall history: %s", exc)
        return list(reversed(evidence))

    def _is_permitted(self, message) -> bool:
        if message.guild is None:
            return self.config.allow_direct_messages
        guild_id = str(message.guild.id)
        channel_id = str(message.channel.id)
        if guild_id not in self.config.allowed_guild_ids:
            return False
        if channel_id not in self.config.allowed_channel_ids:
            return False
        return channel_id not in self.config.ignored_channel_ids

    def _mako_user_id(self, discord_user_id: int) -> str:
        """Map the configured Discord owner onto Mako's existing desktop identity."""
        return "owner" if str(discord_user_id) in self.config.owner_user_ids else f"discord:{discord_user_id}"

    def _sync_sage_voice_people(self, guild, channel=None) -> None:
        sage = getattr(self.core, "sage", None)
        channel = channel or getattr(getattr(guild, "voice_client", None), "channel", None)
        if sage is None or channel is None:
            return
        people = {
            self._mako_user_id(person.id): str(person.display_name)
            for person in channel.members if not getattr(person, "bot", False)
        }
        sage.set_people(f"discord:voice:{guild.id}:{channel.id}", people)

    @staticmethod
    def _speaker_channel_id(channel_id: int, user_id: str) -> str:
        """Keep group-channel recency from being mistaken for the current speaker's history."""
        return f"discord:{channel_id}:speaker:{user_id}"

    def _proactive_enabled(self, message) -> bool:
        channel_id = str(message.channel.id)
        return (
            channel_id in self.config.proactive_channel_ids
            and channel_id not in self.config.require_mention_channel_ids
        )

    def _may_proactively_reply(self, channel_id: str) -> bool:
        now = monotonic()
        if now - self._proactive_at[channel_id] < self.config.proactive_reply_cooldown_seconds:
            return False
        self._proactive_at[channel_id] = now
        return True

    @staticmethod
    def _replies_to_mako(message, bot_id: int) -> bool:
        reference = message.reference
        resolved = getattr(reference, "resolved", None) if reference else None
        return bool(resolved and getattr(getattr(resolved, "author", None), "id", None) == bot_id)

    async def _handle_owner_voice_command(self, message, content: str) -> bool:
        if str(message.author.id) not in self.config.owner_user_ids:
            return False
        command = content.strip().lower()
        if command not in {"!mako join", "!mako leave"}:
            return False
        guild_id = int(message.guild.id) if message.guild else 0
        lock = self._voice_join_locks.get(guild_id)
        if lock is None:
            lock = asyncio.Lock()
            self._voice_join_locks[guild_id] = lock
        async with lock:
            return await self._handle_owner_voice_command_locked(message, command)

    async def _handle_owner_voice_command_locked(self, message, command: str) -> bool:
        if not self.config.voice_enabled or message.guild is None:
            return True
        if command.endswith("leave"):
            voice = message.guild.voice_client
            if voice:
                await voice.disconnect(force=True)
            await message.reply("left the voice channel.", mention_author=False)
            LOG.info("Discord voice left guild=%s", message.guild.id)
            return True
        channel = getattr(getattr(message.author, "voice", None), "channel", None)
        if channel is None:
            await message.reply("join a voice channel first.", mention_author=False)
            return True
        voice = message.guild.voice_client
        if voice:
            await voice.move_to(channel)
        else:
            receive_client = self._voice_receive_client()
            voice = await channel.connect(cls=receive_client, reconnect=True) if receive_client else await channel.connect(reconnect=True)
        if self.config.voice_receive_enabled:
            self._start_voice_receive(message.guild)
        await message.reply("joining you.", mention_author=False)
        LOG.info("Discord voice joined guild=%s channel=%s", message.guild.id, channel.id)
        return True

    def _voice_receive_client(self):
        try:
            from discord.ext import voice_recv
            return voice_recv.VoiceRecvClient
        except ImportError:
            LOG.warning("Discord VC receive unavailable: install the pinned discord-ext-voice-recv dependency")
            return None

    def _start_voice_receive(self, guild) -> None:
        voice = guild.voice_client
        if voice is None or not hasattr(voice, "listen"):
            return
        self._vocal_profiles.open_guild(guild.id)
        self._initialize_silero_interrupt_gate()
        if self._discord_transcriber is None:
            self._discord_transcriber = SpeakerPool(
                self.core.config.voice, self._on_discord_scribe_turn, self._on_discord_scribe_partial
            )
        with self._voice_lock:
            if guild.id not in self._voice_journals:
                journal = CallJournal(self.core.paths.data, uuid4().hex)
                journal.record("session_start", transport="discord_voice", guild_id=str(guild.id))
                self._voice_journals[guild.id] = journal
                self._voice_trackers[guild.id] = ConversationTracker()
                continuity = CallContinuity(self.core.paths.data, str(guild.id))
                continuity.start()
                self._voice_continuity[guild.id] = continuity
        self._affect_monitor.start()
        try:
            voice.listen(self._make_voice_sink(guild.id))
            LOG.info("Discord VC receive started with Scribe STT guild=%s", guild.id)
        except Exception as exc:
            LOG.warning("Discord VC receive failed to start: %s", exc)

    def _on_discord_scribe_turn(self, guild_id: int, member, text: str, profile: str, endpointed_at: float) -> None:
        if not text.strip():
            return
        key = (guild_id, str(member.id))
        with self._voice_lock:
            candidate_at = self._voice_interrupt_candidates.get(key)
            self._voice_interrupt_candidates.pop(key, None)
            self._voice_interrupt_partial_text.pop(key, None)
            active = guild_id in self._voice_generation_active
        if (active and candidate_at is not None and monotonic() - candidate_at >= 1.0
                and _partial_is_interrupt_worthy(text)):
            self._interrupt_voice_turn(
                guild_id, member, recognized_text=text,
                pcm_to_partial_seconds=max(0.0, monotonic() - candidate_at),
                detector="scribe_final_after_confirmed_speech",
            )
        self._voice_endpointed_at[guild_id] = endpointed_at
        LOG.info(
            "Discord VC Scribe final chars=%s last_audio_to_commit=%.3fs",
            len(text), max(0.0, monotonic() - endpointed_at),
        )
        self._handle_voice_turn(guild_id, member, text, profile, occurred_at=endpointed_at)

    def _on_discord_scribe_partial(self, guild_id: int, member, text: str) -> None:
        """Require actual non-echo recognized speech before interrupting playback."""
        normalized = " ".join(text.casefold().split())
        if not normalized:
            return
        # Feed every incremental transcript to the affect sidecar, even when
        # no reply is currently playing. The interrupt gate below is a
        # separate concern and must not suppress ordinary pace estimation.
        self._affect_monitor.set_partial_text(str(member.id), text)
        key = (guild_id, str(member.id))
        with self._voice_lock:
            candidate_at = self._voice_interrupt_candidates.get(key)
            if candidate_at is None:
                return
            spoken = self._voice_active_reply_text.get(guild_id, "")
        spoken_words = set(re.sub(r"[^a-z0-9']+", " ", spoken.casefold()).split())
        words = set(re.sub(r"[^a-z0-9']+", " ", normalized).split())
        informative = words - {
            "yeah", "yep", "yes", "no", "okay", "ok", "uh", "um", "so", "well",
            "mm", "mhm", "uh-huh", "oh", "ah", "hmm", "hm", "right", "got", "it",
        }
        if not _partial_is_interrupt_worthy(text):
            with self._voice_lock:
                self._voice_interrupt_partial_text.pop(key, None)
                journal = self._voice_journals.get(guild_id)
            if journal is not None:
                journal.record(
                    "interrupt_partial_ignored", speaker_id=str(member.id),
                    speaker_name=str(member.display_name), recognized_text=text,
                    pcm_to_partial_seconds=round(max(0.0, monotonic() - candidate_at), 3),
                    reason="backchannel_or_single_fragment",
                )
            return
        overlap = len(informative & spoken_words) / max(1, len(informative))
        if overlap >= 0.72:
            with self._voice_lock:
                self._voice_interrupt_partial_text.pop(key, None)
            LOG.info("Discord VC ignored likely acoustic echo guild=%s speaker=%s overlap=%.2f", guild_id, member.id, overlap)
            return
        with self._voice_lock:
            self._voice_interrupt_partial_text[key] = text
        now = monotonic()
        gate = self._silero_interrupt_gate
        last_speech_at = (
            gate.last_speech_at(f"{guild_id}:{member.id}")
            if gate is not None else self._voice_interrupt_gate.last_speech_at(str(member.id))
        )
        if interrupt_confirmation_ready(candidate_at, now, text, last_speech_at):
            self._interrupt_voice_turn(
                guild_id, member, recognized_text=text,
                pcm_to_partial_seconds=max(0.0, now - candidate_at),
            )

    def _on_discord_vocal_profile(self, key, member, value: str) -> None:
        return

    def _handle_voice_turn(
        self, guild_id: int, member, text: str, voice_profile: str = "", *, occurred_at: float | None = None
    ) -> None:
        with self._voice_lock:
            tracker = self._voice_trackers.setdefault(guild_id, ConversationTracker())
            journal = self._voice_journals.get(guild_id)
        channel = getattr(getattr(member, "voice", None), "channel", None)
        participants = tuple(
            str(person.display_name) for person in getattr(channel, "members", [])
            if getattr(person, "bot", False) is False
        )
        social = tracker.observe(
            speaker_id=str(member.id), speaker_name=str(member.display_name), text=text,
            timestamp=datetime.now().astimezone().isoformat(timespec="milliseconds"),
            participant_names=participants,
            single_user_call=sum(1 for person in getattr(channel, "members", []) if not getattr(person, "bot", False)) <= 1,
        ).to_dict()
        affect = self._affect_monitor.snapshot(str(member.id))
        voice_profile = "; ".join(
            item for item in (voice_profile, affect.compact()) if item
        )
        self._record_voice_observation(guild_id, member, text)
        if journal is not None:
            journal.record(
                "user_turn", speaker_id=str(member.id), speaker_name=str(member.display_name),
                text=text, addressed_to=social["likely_addressee"], social_state=social,
                affect=affect.to_dict(), voice_profile=voice_profile,
            )
        with self._voice_lock:
            continuity = self._voice_continuity.get(guild_id)
        if continuity is not None:
            continuity.record_user(
                speaker_id=str(member.id), speaker_name=str(member.display_name), text=text, state=social
            )
        self._voice_exchanges[guild_id].append(VoiceContribution(
            speaker_id=str(member.id), speaker_name=str(member.display_name),
            text=" ".join(text.split()), timestamp=local_timestamp(occurred_at),
            social_state=dict(social), voice_profile=voice_profile,
            order_time=occurred_at if occurred_at is not None else monotonic(),
        ))
        self._record_voice_speech(guild_id, member, text)
        sage = getattr(self.core, "sage", None)
        if sage is not None:
            sage.observe(self._sage_voice_scope(guild_id), uuid4().hex,
                         self._mako_user_id(member.id), str(member.display_name), text)
        if _is_voice_hush_command(text):
            self._enter_voice_quiet_mode(guild_id, member)
            return
        # A later human contribution reaches DeepSeek, which decides whether
        # it is an invitation to rejoin. Only ambient initiatives stay hushed.
        self._voice_quiet_until.pop(guild_id, None)
        with self._voice_lock:
            interrupted = guild_id in self._voice_interruption_pending
            reply_active = guild_id in self._voice_generation_active
            if reply_active:
                self._voice_response_required.add(guild_id)
        if interrupted or reply_active:
            self._schedule_voice_response(
                guild_id, member, text, voice_profile=voice_profile,
                social_state=social, occurred_at=occurred_at,
            )
        else:
            self._respond_to_voice(
                guild_id, member, text, voice_profile=voice_profile, social_state=social
            )

    def _schedule_voice_response(
        self, guild_id: int, member, text: str, *, voice_profile: str,
        social_state: dict[str, Any], occurred_at: float | None = None,
    ) -> None:
        now = monotonic()
        with self._voice_lock:
            last_speech = self._voice_last_speech_at.get(guild_id, 0.0)
            resume_at = _post_interrupt_resume_deadline(
                now, occurred_at, last_speech if last_speech else None
            )
            previous = self._voice_response_timers.pop(guild_id, None)
            if previous is not None:
                previous.cancel()
            timer = threading.Timer(
                max(0.0, resume_at - now), self._flush_voice_response_after_quiet,
                args=(guild_id, member, text, voice_profile, social_state, resume_at),
            )
            timer.daemon = True
            self._voice_response_timers[guild_id] = timer
            timer.start()
            journal = self._voice_journals.get(guild_id)
        if journal is not None:
            journal.record(
                "post_interrupt_wait_scheduled", speaker_id=str(member.id),
                speaker_name=str(member.display_name), requested_quiet_seconds=POST_INTERRUPT_QUIET_SECONDS,
                scheduled_delay_seconds=round(max(0.0, resume_at - now), 3),
            )

    def _flush_voice_response_after_quiet(
        self, guild_id: int, member, text: str, voice_profile: str,
        social_state: dict[str, Any], resume_at: float,
    ) -> None:
        now = monotonic()
        current_timer = threading.current_thread()
        with self._voice_lock:
            if self._voice_response_timers.get(guild_id) is not current_timer:
                return
            if self._voice_quiet_until.get(guild_id, 0) > now:
                self._voice_response_timers.pop(guild_id, None)
                return
            last_speech = self._voice_last_speech_at.get(guild_id, 0.0)
            if last_speech:
                resume_at = max(
                    resume_at,
                    last_speech + POST_INTERRUPT_QUIET_SECONDS + VAD_END_CUSHION_SECONDS,
                )
            quiet_remaining = resume_at - now
            # Keep recovery registered while the cancelled worker unwinds.
            if guild_id in self._voice_generation_active:
                quiet_remaining = max(quiet_remaining, 0.05)
            if quiet_remaining > 0:
                timer = threading.Timer(
                    quiet_remaining, self._flush_voice_response_after_quiet,
                    args=(guild_id, member, text, voice_profile, social_state, resume_at),
                )
                timer.daemon = True
                self._voice_response_timers[guild_id] = timer
                timer.start()
                return
            self._voice_response_timers.pop(guild_id, None)
            if guild_id not in self._voice_response_required:
                return
            self._voice_response_required.discard(guild_id)
            journal = self._voice_journals.get(guild_id)
        if journal is not None:
            journal.record(
                "post_interrupt_wait_completed", speaker_id=str(member.id),
                speaker_name=str(member.display_name), quiet_target_seconds=POST_INTERRUPT_QUIET_SECONDS,
            )
        with self._voice_lock:
            if guild_id in self._voice_response_timers:
                return
        LOG.info("Discord VC quiet window elapsed; generating response guild=%s", guild_id)
        self._respond_to_voice(
            guild_id, member, text, voice_profile=voice_profile, social_state=social_state
        )

    def _enter_voice_quiet_mode(self, guild_id: int, member) -> None:
        until = monotonic() + 180.0
        with self._voice_lock:
            self._voice_quiet_until[guild_id] = until
            self._voice_interruption_pending.discard(guild_id)
            self._voice_response_required.discard(guild_id)
            timer = self._voice_response_timers.pop(guild_id, None)
            if timer is not None:
                timer.cancel()
            cancel = self._voice_generation_cancel.get(guild_id)
            if cancel is not None:
                cancel.set()
        guild = self._client.get_guild(guild_id) if self._client else None
        if guild and guild.voice_client and guild.voice_client.is_playing():
            _stop_voice_playback(guild.voice_client)
        LOG.info("Discord VC hush activated guild=%s duration_seconds=180", guild_id)
        # Explicit stop is immediate output control; listening and logging continue.

    def _record_voice_observation(self, guild_id: int, member, text: str) -> None:
        try:
            voice_state = getattr(member, "voice", None)
            channel = getattr(voice_state, "channel", None)
            user_id = self._mako_user_id(member.id)
            event = ConversationEvent(
                content=text,
                source=EventSource.DISCORD,
                mode=InteractionMode.CALL,
                visibility=Visibility.PUBLIC,
                user_id=user_id,
                display_name=str(member.display_name),
                channel_id=self._speaker_channel_id(guild_id, user_id),
                metadata={"discord_channel_id": str(getattr(channel, "id", guild_id)), "discord_voice": True},
            )
            self.core.memory.record_public_observation(event)
        except Exception:
            LOG.exception("Could not store Discord voice observation for memory")

    def _make_voice_sink(self, guild_id: int):
        from discord.ext import voice_recv
        service = self

        class MakoVoiceSink(voice_recv.AudioSink):
            def wants_opus(self) -> bool:
                return False

            def write(self, user, data) -> None:
                if user is not None and not getattr(user, "bot", False) and getattr(data, "pcm", None):
                    service._stream_voice_pcm(guild_id, user, bytes(data.pcm))

            def cleanup(self) -> None:
                service._vocal_profiles.close(guild_id)
                if service._silero_interrupt_gate is not None:
                    service._silero_interrupt_gate.reset_scope(f"{guild_id}:")
                if service._discord_transcriber is not None:
                    service._discord_transcriber.close(guild_id)
                with service._voice_lock:
                    cancel = service._voice_generation_cancel.get(guild_id)
                    if cancel is not None:
                        cancel.set()
                    stream = service._voice_streams.get(guild_id)
                    if stream is not None:
                        stream.abort()
                    service._pending_voice_turns.pop(guild_id, None)
                    service._voice_interrupt_candidates = {
                        key: value for key, value in service._voice_interrupt_candidates.items()
                        if key[0] != guild_id
                    }
                    service._voice_interrupt_partial_text = {
                        key: value for key, value in service._voice_interrupt_partial_text.items()
                        if key[0] != guild_id
                    }
                    service._voice_active_reply_text.pop(guild_id, None)
                    service._voice_interrupted_text.pop(guild_id, None)
                    service._voice_interruption_pending.discard(guild_id)
                    service._voice_response_required.discard(guild_id)
                    timer = service._voice_response_timers.pop(guild_id, None)
                    if timer is not None:
                        timer.cancel()
                    service._voice_last_speech_at.pop(guild_id, None)
                    service._voice_exchanges.pop(guild_id, None)
                    journal = service._voice_journals.pop(guild_id, None)
                    service._voice_trackers.pop(guild_id, None)
                    continuity = service._voice_continuity.pop(guild_id, None)
                if continuity is not None:
                    continuity.finish(journal.path if journal is not None else None)
                if journal is not None:
                    journal.close(transport="discord_voice", end_reason="voice_receive_stopped")

        return MakoVoiceSink()

    def _stream_voice_pcm(self, guild_id: int, member, pcm: bytes) -> None:
        import numpy as np

        samples = np.frombuffer(pcm, dtype=np.int16)
        if not getattr(member, "bot", False):
            try:
                rms = audioop.rms(pcm, 2)
                if self._voice_interrupt_gate.observe(str(member.id), rms, monotonic()):
                    with self._voice_lock:
                        if guild_id in self._voice_generation_active:
                            key = (guild_id, str(member.id))
                            self._voice_interrupt_candidates.setdefault(key, monotonic())
                            journal = self._voice_journals.get(guild_id)
                        else:
                            journal = None
                    if journal is not None:
                        journal.record(
                            "interrupt_audio_candidate", speaker_id=str(member.id),
                            speaker_name=str(member.display_name), detector="sustained_pcm",
                            rms=rms,
                        )
            except (audioop.error, ValueError):
                pass
        if samples.size >= 2:
            samples = samples[: samples.size - (samples.size % 2)]
            mono_48k = samples.reshape(-1, 2).mean(axis=1).astype(np.float32) / 32768.0
            gate = self._silero_interrupt_gate
            try:
                speaker_key = f"{guild_id}:{member.id}"
                detected = gate is not None and gate.observe(speaker_key, mono_48k[::3])
                last_voice = (
                    gate.last_speech_at(speaker_key) if gate is not None
                    else self._voice_interrupt_gate.last_speech_at(str(member.id))
                )
                if last_voice is not None:
                    with self._voice_lock:
                        self._voice_last_speech_at[guild_id] = max(
                            self._voice_last_speech_at.get(guild_id, 0.0), last_voice
                        )
            except Exception:
                LOG.exception("Discord VC Silero VAD inference failed; keeping Scribe interruption path")
                with self._voice_lock:
                    self._silero_interrupt_gate = None
                detected = False
                last_voice = self._voice_interrupt_gate.last_speech_at(str(member.id))
            if detected:
                key = (guild_id, str(member.id))
                with self._voice_lock:
                    active = guild_id in self._voice_generation_active
                    candidate_at = self._voice_interrupt_candidates.setdefault(key, monotonic()) if active else monotonic()
                    journal = self._voice_journals.get(guild_id)
                if active:
                    if journal is not None:
                        journal.record(
                            "interrupt_audio_candidate", speaker_id=str(member.id),
                            speaker_name=str(member.display_name), detector="silero_vad",
                        )
                    # VAD starts a candidate only; transcript plus the one-second
                    # confirmation gate below is required before cancellation.
            if not getattr(member, "bot", False):
                key = (guild_id, str(member.id))
                with self._voice_lock:
                    candidate_at = self._voice_interrupt_candidates.get(key)
                    partial_text = self._voice_interrupt_partial_text.get(key, "")
                    active = guild_id in self._voice_generation_active
                now = monotonic()
                if (
                    active and candidate_at is not None and partial_text and last_voice is not None
                    and _partial_is_interrupt_worthy(partial_text)
                    and interrupt_confirmation_ready(candidate_at, now, partial_text, last_voice)
                ):
                    self._interrupt_voice_turn(
                        guild_id, member, recognized_text=partial_text,
                        pcm_to_partial_seconds=max(0.0, now - candidate_at),
                        detector="confirmed_vad_plus_scribe_partial",
                    )
            self._affect_monitor.push_audio(str(member.id), mono_48k, 48_000)
        self._vocal_profiles.push(guild_id, member, pcm)
        transcriber = self._discord_transcriber
        if transcriber is not None:
            transcriber.push(guild_id, member, pcm)

    def _activate_voice_floor_claim(self, guild_id: int, cancel, duration: float = 3.0) -> bool:
        until = monotonic() + min(3.0, max(0.0, duration))
        if until <= monotonic():
            return False
        with self._voice_lock:
            if self._voice_generation_cancel.get(guild_id) is not cancel or cancel.is_set():
                return False
            current = self._voice_floor_claim_until.get(guild_id)
            if current is not None and current[0] is cancel and current[1] > monotonic():
                return True
            self._voice_floor_claim_until[guild_id] = (cancel, until)
            journal = self._voice_journals.get(guild_id)
        if journal is not None:
            journal.record("floor_claim_started", duration_seconds=round(until - monotonic(), 3))
        return True

    def _interrupt_voice_turn(
        self, guild_id: int, member, *, recognized_text: str,
        pcm_to_partial_seconds: float, detector: str = "sustained_pcm_plus_scribe_partial",
    ) -> None:
        claim_active = False
        with self._voice_lock:
            cancel = self._voice_generation_cancel.get(guild_id)
            if cancel is None or cancel.is_set():
                return
            journal = self._voice_journals.get(guild_id)
            claim = self._voice_floor_claim_until.get(guild_id)
            claim_active = bool(claim and claim[0] is cancel and monotonic() < claim[1])
            if not claim_active:
                self._voice_interruption_pending.add(guild_id)
                self._voice_response_required.add(guild_id)
                cancel.set()
                stream = self._voice_streams.get(guild_id)
                progress = self._voice_playback_trace.get(guild_id)
                heard = progress.snapshot() if progress is not None else {}
                already_emitted = heard.get("text", "")
                if already_emitted:
                    self._voice_interrupted_text[guild_id].append(already_emitted)
                if stream is not None:
                    stream.abort()
                if guild_id in self._voice_sage_intents:
                    # Free a speculative autonomous slot immediately for human input.
                    self._voice_sage_intents.pop(guild_id, None)
                    self._voice_generation_active.discard(guild_id)
                    self._voice_generation_cancel.pop(guild_id, None)
                    self._voice_generation_revision.pop(guild_id, None)
                    self._voice_streams.pop(guild_id, None)
                sage = getattr(self.core, "sage", None)
                if sage is not None:
                    sage.interrupt(self._sage_voice_scope(guild_id))
        if claim_active:
            if journal is not None:
                journal.record(
                    "barge_in", speaker_id=str(member.id), speaker_name=str(member.display_name),
                    detector=detector, recognized_text=recognized_text,
                    pcm_to_partial_seconds=round(pcm_to_partial_seconds, 3),
                    action="claim_floor_briefly; transcript_retained",
                )
            return
        if journal is not None:
            journal.record(
                "barge_in", speaker_id=str(member.id), speaker_name=str(member.display_name),
                detector=detector, recognized_text=recognized_text,
                pcm_to_partial_seconds=round(pcm_to_partial_seconds, 3),
                already_emitted_text=already_emitted,
                action="cancel_generation_and_playback_preserve_exchange",
            )
        if heard.get("audio_seconds", 0) > 0 and getattr(self.core, "sage", None):
            self.core.sage.observe(self._sage_voice_scope(guild_id), f"interrupted:{uuid4().hex}",
                "stella", "Stella", already_emitted or "[Speech interrupted; exact words are unavailable.]",
                kind="assistant", data={"status": "interrupted", **heard})
        guild = self._client.get_guild(guild_id) if self._client else None
        if guild is not None and guild.voice_client is not None and guild.voice_client.is_playing():
            _stop_voice_playback(guild.voice_client)
        LOG.info("Discord VC speech-onset barge-in guild=%s speaker=%s detector=%s", guild_id, member.id, detector)
        # VAD may interrupt without producing another committed transcript.
        with self._voice_lock:
            _, pending = self._voice_exchanges[guild_id].snapshot()
        if pending:
            self._schedule_voice_response(
                guild_id, member, "", voice_profile="", social_state={},
                occurred_at=monotonic(),
            )

    def _initialize_silero_interrupt_gate(self) -> None:
        with self._voice_lock:
            if self._silero_interrupt_gate is not None or self._silero_interrupt_loading:
                return
            self._silero_interrupt_loading = True

        threading.Thread(
            target=self._load_silero_interrupt_gate,
            name="stella-discord-silero-vad-init",
            daemon=True,
        ).start()

    def _load_silero_interrupt_gate(self) -> None:
        try:
            from silero_vad import load_silero_vad

            model = load_silero_vad(onnx=True, opset_version=16)
            gate = SileroSpeechOnsetGate(
                model, model_factory=lambda: load_silero_vad(onnx=True, opset_version=16),
                threshold=0.72, required_frames=5, release_frames=5,
            )
            with self._voice_lock:
                self._silero_interrupt_gate = gate
            LOG.info("Discord VC local Silero VAD interruption gate ready")
        except Exception:
            LOG.exception("Discord VC Silero VAD unavailable; retaining transcript-confirmed interruption")
        finally:
            with self._voice_lock:
                self._silero_interrupt_loading = False

    async def _speak_elevenlabs_in_voice(
        self, guild, text, *, chunks_override=None, fallback_text=None, fallback_ready=None, cancel=None
    ):
        from contextlib import aclosing
        from .elevenlabs_discord import PcmBuffer
        from .elevenlabs_voice import stream_dialogue
        if self.core.config.voice.tts_backend == "cartesia_tts":
            from .cartesia_voice import stream_dialogue

        voice = guild.voice_client
        if voice is None or not voice.is_connected():
            return
        while voice.is_playing():
            if cancel is not None and cancel.is_set():
                return
            await asyncio.sleep(.05)
        buffer = PcmBuffer()
        playback_trace = PlaybackTrace()
        body = self.core.body
        loop = asyncio.get_running_loop()
        completed = loop.create_future()
        class Source(self._discord.AudioSource):
            def read(inner):
                frame = buffer.read()
                playback_trace.consumed(buffer.consumed_bytes)
                body.set_speech_level(audioop.rms(frame, 2) / 32768 if frame else 0)
                return frame
            def cleanup(inner):
                buffer.cleanup()
        def finished(error):
            def settle():
                if not completed.done():
                    if error:
                        completed.set_exception(error)
                    else:
                        completed.set_result(None)
            loop.call_soon_threadsafe(settle)
        started = False
        rate_state = None
        chunks = chunks_override or queue.Queue()
        if chunks_override is None:
            chunks.put(text)
            chunks.put(None)
        cancelled = lambda: (
            buffer.cancelled.is_set() or not voice.is_connected()
            or (cancel is not None and cancel.is_set())
        )
        def begin():
            nonlocal started
            if not started:
                voice.play(Source(), after=finished)
                self._voice_playback_trace[guild.id] = playback_trace
                sage_job = self._voice_sage_intents.get(guild.id)
                if sage_job and getattr(self.core, "sage", None):
                    self.core.sage.started(*sage_job)
                started = True
                endpoint = self._voice_endpointed_at.get(guild.id)
                LOG.info("ElevenLabs Discord playback start eot_seconds=%.3f", monotonic() - endpoint if endpoint else -1)
        try:
            async with aclosing(stream_dialogue(self.core.config.voice, chunks, cancelled=cancelled,
                                                on_alignment=playback_trace.alignment)) as audio:
                async for pcm in audio:
                    if cancelled():
                        break
                    converted, rate_state = audioop.ratecv(pcm, 2, 1, 24000, 48000, rate_state)
                    buffer.put(audioop.tostereo(converted, 2, 1, 1))
                    if buffer.size() >= 15360:
                        begin()
            buffer.finish()
            if buffer.size() and not cancelled():
                begin()
            if started:
                await asyncio.wait_for(completed, timeout=75)
        except Exception:
            if not started and not cancelled() and self.core.config.voice.tts_backend == "elevenlabs_tts" and self.core.config.voice.elevenlabs_tts_fallback == "inworld_tts":
                LOG.warning("ElevenLabs failed before playback; using Inworld Discord TTS fallback")
                if fallback_ready is not None:
                    await asyncio.to_thread(fallback_ready.wait, 25.0)
                resolved_text = fallback_text() if fallback_text else text
                if resolved_text:
                    await self._speak_inworld_stream_in_voice(guild, resolved_text, cancel=cancel)
            else:
                raise
        finally:
            buffer.cleanup()
            if started and not completed.done():
                _stop_voice_playback(voice)
            body.set_speech_level(0.0)

    def _respond_to_voice(
        self, guild_id: int, member, text: str, *, voice_profile: str = "",
        social_state: dict[str, Any] | None = None,
    ) -> None:
        interrupted = False
        already_emitted = ""
        journal = None
        with self._voice_lock:
            if guild_id in self._voice_generation_active:
                current_revision = self._voice_exchanges[guild_id].snapshot()[0]
                active_revision = self._voice_generation_revision.get(guild_id)
                if active_revision is not None and active_revision < current_revision:
                    cancel = self._voice_generation_cancel.get(guild_id)
                    if cancel is not None and not cancel.is_set():
                        cancel.set()
                        interrupted = True
                        stream = self._voice_streams.get(guild_id)
                        progress = self._voice_playback_trace.get(guild_id)
                        heard = progress.snapshot() if progress is not None else {}
                        already_emitted = heard.get("text", "")
                        if already_emitted:
                            self._voice_interrupted_text[guild_id].append(already_emitted)
                        if stream is not None:
                            stream.abort()
                        journal = self._voice_journals.get(guild_id)
                        if guild_id in self._voice_sage_intents:
                            self._voice_sage_intents.pop(guild_id, None)
                            self._voice_generation_active.discard(guild_id)
                            self._voice_generation_cancel.pop(guild_id, None)
                            self._voice_generation_revision.pop(guild_id, None)
                            self._voice_streams.pop(guild_id, None)
                    LOG.info("Discord VC preserved new contribution and cancelled stale draft guild=%s speaker=%s", guild_id, member.id)
                else:
                    return
                if not interrupted:
                    return
            else:
                self._voice_generation_active.add(guild_id)
                cancel = threading.Event()
                self._voice_generation_cancel[guild_id] = cancel
                LOG.info("Discord VC accepted turn guild=%s speaker=%s", guild_id, member.id)
        if interrupted:
            sage = getattr(self.core, "sage", None)
            if sage is not None:
                scope = self._sage_voice_scope(guild_id)
                sage.interrupt(scope)
                if heard.get("audio_seconds", 0) > 0:
                    sage.observe(scope, f"interrupted:{uuid4().hex}", "stella", "Stella",
                        already_emitted or "[Speech interrupted; exact words are unavailable.]",
                        kind="assistant", data={"status": "interrupted", **heard})
            if journal is not None:
                journal.record(
                    "barge_in", speaker_id=str(member.id), speaker_name=str(member.display_name),
                    detector="scribe_committed_turn", recognized_text=text,
                    already_emitted_text=already_emitted,
                    action="cancel_generation_and_playback_preserve_exchange",
                )
            guild = self._client.get_guild(guild_id) if self._client else None
            voice = getattr(guild, "voice_client", None)
            if voice is not None and voice.is_playing():
                _stop_voice_playback(voice)
            self._schedule_voice_response(guild_id, member, text, voice_profile=voice_profile,
                social_state=social_state or {}, occurred_at=monotonic())
            return
        threading.Thread(
            target=self._voice_generation_worker,
            args=(guild_id, member, text, voice_profile, cancel, social_state),
            daemon=True,
        ).start()

    def _record_voice_speech(self, guild_id: int, member, text: str) -> None:
        with self._voice_lock:
            self._voice_timeline[guild_id].append((str(member.id), f"{member.display_name}: {text}"))

    def _voice_context_snapshot(self, guild_id: int) -> str:
        with self._voice_lock:
            return "\n".join(line for _, line in self._voice_timeline[guild_id])

    def _voice_delay_notice_was_spoken(self, guild_id: int, revision: int) -> bool:
        with self._voice_lock:
            spoken_revision = self._voice_delay_notice_revision.get(guild_id)
            return spoken_revision is not None and spoken_revision <= revision

    def _clear_voice_delay_notice(self, guild_id: int, revision: int) -> None:
        with self._voice_lock:
            spoken_revision = self._voice_delay_notice_revision.get(guild_id)
            if spoken_revision is not None and spoken_revision <= revision:
                self._voice_delay_notice_revision.pop(guild_id, None)

    def _sage_voice_scope(self, guild_id):
        guild = self._client.get_guild(guild_id) if self._client else None
        channel = getattr(getattr(guild, "voice_client", None), "channel", None)
        return f"discord:voice:{guild_id}:{getattr(channel, 'id', guild_id)}"

    def _voice_generation_worker(
        self, guild_id: int, member, text: str, voice_profile: str = "", cancel=None,
        social_state: dict[str, Any] | None = None,
        sage_job: tuple[str, str] | None = None,
    ) -> None:
        started = monotonic()
        delivered = False
        cancel = cancel or threading.Event()
        exchange = self._voice_exchanges[guild_id]
        exchange_revision, exchange_snapshot = exchange.snapshot()
        with self._voice_lock:
            self._voice_generation_revision[guild_id] = exchange_revision
            self._voice_playback_trace.pop(guild_id, None)
            interrupted_text_snapshot = tuple(self._voice_interrupted_text[guild_id])
            resume_after_interruption = guild_id in self._voice_interruption_pending
            self._voice_interruption_pending.discard(guild_id)
        exchange_block = exchange.render(exchange_snapshot)
        if exchange_snapshot:
            latest = exchange_snapshot[-1]
            guild_for_member = self._client.get_guild(guild_id) if self._client else None
            original_member = guild_for_member.get_member(int(latest.speaker_id)) if guild_for_member else None
            if original_member is not None:
                member = original_member
            user_profile = "; ".join(dict.fromkeys(
                item.voice_profile for item in exchange_snapshot if item.voice_profile
            ))
            voice_profile = user_profile
            text = exchange_block
            social_state = latest.social_state

        def cancel_stalled_turn() -> None:
            LOG.warning("Discord VC cancelling stalled model turn guild=%s after 40 seconds", guild_id)
            cancel.set()

        # Allow the three-second notice plus its thirty-second recovery window.
        deadline = threading.Timer(40.0, cancel_stalled_turn)
        deadline.daemon = True
        deadline.start()
        user_id = self._mako_user_id(member.id)
        group_context = self._voice_context_snapshot(guild_id)
        with self._voice_lock:
            continuity = self._voice_continuity.get(guild_id)
        guild = self._client.get_guild(guild_id) if self._client else None
        voice_client = getattr(guild, "voice_client", None)
        active_members = getattr(getattr(voice_client, "channel", None), "members", [])
        participant_rows = [
            {"user_id": self._mako_user_id(item.id), "name": str(item.display_name)}
            for item in active_members
        ]
        if not any(item["user_id"] == user_id for item in participant_rows):
            participant_rows.append({"user_id": user_id, "name": str(member.display_name)})
        voice_channel_id = str(getattr(getattr(voice_client, "channel", None), "id", guild_id))
        sage = getattr(self.core, "sage", None)
        sage_scope = self._sage_voice_scope(guild_id)
        last_sage_speech_at = 0.0
        user_mood_state = {"label": "neutral", "intensity": 0.0}
        user_mood_context = ""
        if sage is not None and sage.enabled:
            last_sage_speech_at = sage.scene(sage_scope).state.last_stella_at
            if not sage_job:
                user_mood_state = sage.user_mood(sage_scope, user_id)
                user_mood_context = sage.user_mood_prompt(sage_scope, user_id)
        recent_replies = [
            line.removeprefix("Mako: ")
            for speaker, line in self._voice_timeline[guild_id]
            if speaker == "mako"
        ][-8:]
        event = ConversationEvent(content=text, source=EventSource.DISCORD, mode=InteractionMode.CALL,
                visibility=Visibility.PUBLIC, user_id=user_id, display_name=str(member.display_name),
                channel_id=self._speaker_channel_id(guild_id, user_id),
                metadata={
                    "discord_voice": True,
                    "discord_guild_id": str(guild_id),
                    "discord_channel_id": voice_channel_id,
                    "discord_participants": participant_rows,
                    "discord_recent_mako_replies": recent_replies,
                    "discord_voice_group_context": group_context,
                    "discord_voice_exchange": [
                        {"speaker_id": item.speaker_id, "speaker_name": item.speaker_name,
                         "timestamp": item.timestamp, "text": item.text,
                         "social_state": item.social_state}
                        for item in exchange_snapshot
                    ],
                    "discord_voice_interrupted_text": list(interrupted_text_snapshot),
                    "discord_voice_resume_after_interruption": resume_after_interruption,
                    "call_continuity": continuity.prompt_block() if continuity is not None else "",
                    "voice_profile": voice_profile,
                    "conversation_state": social_state or {},
                    "discord_voice_reentry": bool(
                        last_sage_speech_at and time() - last_sage_speech_at >= 90.0
                    ),
                    "discord_user_mood_state": user_mood_state,
                    "discord_user_mood": user_mood_context,
                })
        # Recall uses the normal memory retrieval and model response path.
        if sage is not None and sage.enabled:
            scene_scope = sage_scope
            scene_context = sage.context(scene_scope, text)
            if scene_context:
                event.metadata["call_continuity"] = scene_context
                event.metadata["discord_recent_mako_replies"] = []
            if sage_job:
                event.user_id = "sage"
                event.display_name = "Stella"
                event.metadata["sage_initiated"] = True
                event.metadata["sage_packet"] = sage.packet(*sage_job)
        recall_bridge = ""
        response_ready = threading.Event()
        stream_ready = threading.Event()
        streamed_result: list[str] = []
        bridge_started = threading.Event()
        bridge_playback = None
        stream = (
            _DiscordReplyStream(
                require_response_decision=True,
                expressive_tts=self.core.config.voice.tts_backend.lower() == "elevenlabs_tts",
                user_text=text,
            )
            if self.core.config.model.call_streaming_tts
            and self.core.config.voice.tts_backend.lower() in {"elevenlabs_tts", "cartesia_tts"}
            and not recall_bridge
            else None
        )
        # User mood is contextual evidence for Stella's reasoning; streaming voice
        # waits for Stella's own response expression before speaking its first clause.
        if stream is not None:
            with self._voice_lock:
                self._voice_streams[guild_id] = stream
        stream_playback = (
            self._submit(
                self._speak_elevenlabs_in_voice(
                    self._client.get_guild(guild_id),
                    "",
                    chunks_override=stream.chunks,
                    fallback_text=lambda: streamed_result[0] if streamed_result else "",
                    fallback_ready=stream_ready,
                    cancel=cancel,
                )
            )
            if stream is not None and self._client and self._client.get_guild(guild_id)
            else None
        )

        async def speak_delay_notice(warning):
            # Close the empty streaming request before opening notice playback.
            if stream_playback is not None:
                try:
                    await asyncio.wrap_future(stream_playback)
                except asyncio.CancelledError:
                    pass
                except Exception:
                    LOG.exception("Discord VC empty stream failed before delay notice")
            if cancel.is_set():
                return
            await self._speak_voice_text(guild_id, warning, str(uuid4()), cancel=cancel)
            interrupted = cancel.is_set()
            with self._voice_lock:
                journal = self._voice_journals.get(guild_id)
                if not interrupted:
                    self._voice_delay_notice_revision[guild_id] = exchange_revision
                    self._voice_timeline[guild_id].append(("mako", f"Mako: {warning}"))
            if journal is not None:
                journal.record(
                    "assistant_notice", text=warning, reason="delayed_ai_response",
                    status="interrupted" if interrupted else "completed",
                )
            if continuity is not None:
                continuity.record_assistant(text=warning, interrupted=interrupted)
            if not interrupted:
                notice_id = f"stella:delay-notice:{guild_id}:{exchange_revision}"
                self.core.memory.record_assistant_notice(
                    event_id=notice_id,
                    text=warning,
                    user_id=user_id,
                    display_name="Stella",
                    channel_id=event.channel_id,
                    shared_channel_id=str(event.metadata.get("discord_channel_id", "")),
                )
                if sage is not None:
                    sage.observe(
                        self._sage_voice_scope(guild_id), notice_id,
                        "stella", "Stella", warning, kind="notice",
                        data={"status": "completed", "reason": "delayed_ai_response"},
                    )

        def play_delay_notice(warning):
            if stream is not None:
                stream.abort()
            if stream_playback is not None:
                stream_playback.cancel()
            stream_ready.set()
            LOG.warning("Discord VC AI delay notice guild=%s generation_seconds=%.3fs",
                        guild_id, monotonic() - started)
            return self._submit(speak_delay_notice(warning))

        delay_notice = DiscordDelayNotice(started, cancel, play_delay_notice)
        already_warned = self._voice_delay_notice_was_spoken(guild_id, exchange_revision)
        if self.core.config.model.provider.strip().lower() == "lithos" and not already_warned and not sage_job:
            delay_notice.start()

        def on_model_token(token):
            may_stream = delay_notice.token(token)
            if may_stream and stream is not None and stream_playback is not None:
                stream.on_token(token)
                if stream.floor_action == "claim" and stream.response_decision is True:
                    self._activate_voice_floor_claim(guild_id, cancel)

        def begin_recall_bridge() -> None:
            nonlocal bridge_playback
            if response_ready.is_set() or cancel.is_set() or not recall_bridge:
                return
            bridge_started.set()
            event.metadata["response_prefix"] = recall_bridge
            event.metadata["response_prefix_started_at"] = time()
            LOG.info(
                "Discord VC recall cue started guild=%s eot_to_cue=%.3fs text=%r",
                guild_id,
                monotonic() - started,
                recall_bridge,
            )
            bridge_playback = self._submit(
                self._speak_voice_text(
                    guild_id, recall_bridge, str(uuid4()), vocal_cue="hmm", delivery="soft", cancel=cancel
                )
            )

        bridge_timer = threading.Timer(0.7, begin_recall_bridge) if recall_bridge else None
        if bridge_timer:
            bridge_timer.daemon = True
            bridge_timer.start()
        try:
            result = self.core.respond(
                event,
                cancel=cancel,
                on_token=on_model_token,
                defer_commit=True,
            )
            candidate_data = (result.trace or {}).get("candidate", {})
            if candidate_data.get("floor_action") == "claim":
                self._activate_voice_floor_claim(guild_id, cancel)
            deadline.cancel()
            original_text = result.text
            result.text = delay_notice.finish(result.text)
            if result.text != original_text:
                result.trace["ai_delay_resolved"] = True
            response_ready.set()
            if bridge_timer:
                bridge_timer.cancel()
            if not result.text.strip() and stream is not None:
                stream.finish("")
            if result.text.strip():
                with self._voice_lock:
                    self._voice_active_reply_text[guild_id] = result.text
                streamed_result.append(result.text)
                with self._voice_lock:
                    journal = self._voice_journals.get(guild_id)
                if journal is not None:
                    participation = (result.trace or {}).get("candidate", {})
                    journal.record(
                        "assistant_turn",
                        addressed_to=(social_state or {}).get("speaker_name", str(member.display_name)),
                        text=result.text, model=result.model,
                        generation_seconds=result.generation_seconds,
                        turn_id=result.turn_id,
                        expression=str(result.expression), move=result.move,
                        participation={key: participation.get(key) for key in (
                            "respond", "addressee", "addressee_name", "social_act", "address_confidence"
                        )},
                    )
                LOG.info("Discord VC model seconds=%.3f model=%s", monotonic() - started, result.model)
                self.core.body.apply_response(result)
                if bridge_started.is_set() and bridge_playback is not None:
                    bridge_playback.result(timeout=15.0)
                spoken_text = result.text
                if recall_bridge and (result.trace or {}).get("response_prefix") == recall_bridge:
                    spoken_text = result.text[len(recall_bridge):].lstrip()
                # Do not release the guild turn until synthesis and Discord playback
                # finish. Otherwise short fragments spoken during Mako's reply queue
                # as separate, stale conversations.
                if stream is not None and stream_playback is not None and delay_notice.warning_at is None:
                    stream.finish(spoken_text)
                    stream_ready.set()
                    stream_playback.result(timeout=75.0)
                else:
                    playback = self._submit(
                        self._speak_voice_text(
                            guild_id,
                            spoken_text,
                            str(uuid4()),
                            vocal_cue=str((result.acting or {}).get("vocal_cue", "none")),
                            delivery=str((result.acting or {}).get("delivery", "neutral")),
                            mood=str(getattr(result.expression, "value", result.expression)),
                            cancel=cancel,
                        )
                    )
                    playback.result(timeout=45.0)
                if cancel.is_set():
                    self.core.discard_deferred_call_response(event.id)
                else:
                    self.core.commit_deferred_call_response(event, result)
                    if not sage_job:
                        self._apply_delivered_user_mood(sage_scope, user_id, result)
                    delivered = True
                    with self._voice_lock:
                        self._voice_timeline[guild_id].append(("mako", f"Mako: {result.text}"))
                    if sage is not None:
                        sage.observe(self._sage_voice_scope(guild_id), f"stella:{result.turn_id}",
                                     "stella", "Stella", result.text, kind="assistant")
                    if exchange.acknowledge(exchange_snapshot):
                        self._clear_voice_delay_notice(guild_id, exchange_revision)
                    with self._voice_lock:
                        pending_partial = self._voice_interrupted_text[guild_id]
                        if tuple(pending_partial[:len(interrupted_text_snapshot)]) == interrupted_text_snapshot:
                            del pending_partial[:len(interrupted_text_snapshot)]
                if continuity is not None:
                    continuity.record_assistant(text=result.text, interrupted=cancel.is_set())
                if not cancel.is_set():
                    with self._voice_lock:
                        tracker = self._voice_trackers.get(guild_id)
                    if tracker is not None:
                        tracker.observe_assistant(
                            text=result.text,
                            timestamp=datetime.now().astimezone().isoformat(timespec="milliseconds"),
                        )
                with self._voice_lock:
                    journal = self._voice_journals.get(guild_id)
                if journal is not None:
                    journal.record(
                        "assistant_playback", turn_id=result.turn_id,
                        status="interrupted" if cancel.is_set() else "completed",
                        generated_text_excluded_from_continuity=cancel.is_set(),
                    )
            else:
                with self._voice_lock:
                    journal = self._voice_journals.get(guild_id)
                    if not cancel.is_set():
                        if exchange.acknowledge(exchange_snapshot):
                            self._clear_voice_delay_notice(guild_id, exchange_revision)
                        pending_partial = self._voice_interrupted_text[guild_id]
                        if tuple(pending_partial[:len(interrupted_text_snapshot)]) == interrupted_text_snapshot:
                            del pending_partial[:len(interrupted_text_snapshot)]
                if journal is not None:
                    participation = (result.trace or {}).get("candidate", {})
                    journal.record(
                        "assistant_decision", action="silent", reason="model_turn_participation_decision",
                        model=result.model, generation_seconds=result.generation_seconds,
                        speaker_id=str(member.id), speaker_name=str(member.display_name),
                        addressee=participation.get("addressee", "unclear"),
                        addressee_name=participation.get("addressee_name", ""),
                        social_act=participation.get("social_act", "unclear"),
                        address_confidence=participation.get("address_confidence", 0.0),
                    )
        except Exception as exc:
            if stream is not None:
                stream.abort()
                stream_ready.set()
            LOG.warning("Discord VC response failed: %s", exc)
        finally:
            delay_notice.close()
            if sage_job and sage is not None:
                sage.finish(*sage_job, delivered)
            try:
                self.core.discard_deferred_call_response(event.id)
            except Exception:
                pass
            stream_ready.set()
            response_ready.set()
            if bridge_timer:
                bridge_timer.cancel()
            deadline.cancel()
            with self._voice_lock:
                # An interrupted autonomous worker can finish after a human's
                # replacement worker has started. It must not clear that slot.
                if self._voice_generation_cancel.get(guild_id) is not cancel:
                    return
                self._voice_generation_active.discard(guild_id)
                self._voice_sage_intents.pop(guild_id, None)
                self._voice_generation_cancel.pop(guild_id, None)
                self._voice_generation_revision.pop(guild_id, None)
                self._voice_streams.pop(guild_id, None)
                self._voice_endpointed_at.pop(guild_id, None)
                claim = self._voice_floor_claim_until.get(guild_id)
                if claim is not None and claim[0] is cancel:
                    self._voice_floor_claim_until.pop(guild_id, None)
                pending = self._pending_voice_turns[guild_id].popleft() if self._pending_voice_turns[guild_id] else None
                self._voice_interrupt_candidates = {
                    key: value for key, value in self._voice_interrupt_candidates.items()
                    if key[0] != guild_id
                }
                self._voice_interrupt_partial_text = {
                    key: value for key, value in self._voice_interrupt_partial_text.items()
                    if key[0] != guild_id
                }
                self._voice_active_reply_text.pop(guild_id, None)
                has_new_exchange = (
                    exchange.snapshot()[0] > exchange_revision
                    and guild_id in self._voice_journals
                    and guild_id not in self._voice_response_timers
                    and self._voice_quiet_until.get(guild_id, 0) <= monotonic()
                )
                next_cancel = None
                if has_new_exchange and pending is None:
                    self._voice_generation_active.add(guild_id)
                    next_cancel = threading.Event()
                    self._voice_generation_cancel[guild_id] = next_cancel
            self.core.body.speech_finished()
            LOG.info("Discord VC released turn guild=%s", guild_id)
            if pending is not None:
                self._respond_to_voice(
                    guild_id, pending[0], pending[1], voice_profile=pending[2], social_state=pending[3]
                )
            elif next_cancel is not None:
                latest = exchange.snapshot()[1]
                guild = self._client.get_guild(guild_id) if self._client else None
                anchor = guild.get_member(int(latest[0].speaker_id)) if guild else None
                if anchor is None:
                    anchor = member
                threading.Thread(
                    target=self._voice_generation_worker,
                    args=(guild_id, anchor, "", "", next_cancel, latest[0].social_state),
                    daemon=True,
                ).start()

    async def _speak_voice_text(
        self,
        guild_id: int,
        text: str,
        message_id: str,
        *,
        vocal_cue: str = "none",
        delivery: str = "neutral",
        mood: str = "neutral",
        cancel=None,
    ) -> None:
        # This runs on Discord's event loop, so an asyncio lock safely serializes audio
        # without leaving a worker thread stuck behind an unreliable playback callback.
        lock = self._voice_playback_locks.get(guild_id)
        if lock is None:
            lock = asyncio.Lock()
            self._voice_playback_locks[guild_id] = lock
        async with lock:
            guild = self._client.get_guild(guild_id) if self._client else None
            if guild and not (cancel is not None and cancel.is_set()):
                await self._speak_reply_in_voice(
                    guild, text, message_id, vocal_cue=vocal_cue, delivery=delivery, mood=mood, cancel=cancel
                )

    async def _send_dm(self, user_id: str, content: str) -> None:
        if self._client is None:
            raise RuntimeError("Discord is not connected")
        user = await self._client.fetch_user(int(user_id))
        await user.send(content, allowed_mentions=self._discord.AllowedMentions.none())

    async def _send_channel(self, channel_id: str, content: str) -> None:
        if self._client is None:
            raise RuntimeError("Discord is not connected")
        if channel_id not in self.config.allowed_channel_ids:
            raise PermissionError("Discord channel is not allowlisted")
        channel = self._client.get_channel(int(channel_id)) or await self._client.fetch_channel(int(channel_id))
        await channel.send(content, allowed_mentions=self._discord.AllowedMentions.none())

    async def _speak_inworld_stream_in_voice(self, guild, text: str, *, cancel=None) -> None:
        """Feed Inworld's arriving audio chunks directly to Discord playback."""
        import base64
        import io

        import aiohttp
        import numpy as np
        import soundfile as sf

        voice_client = guild.voice_client
        if voice_client is None or not voice_client.is_connected():
            return
        if voice_client.is_playing():
            while voice_client.is_playing():
                if cancel is not None and cancel.is_set():
                    return
                await asyncio.sleep(0.05)

        audio_queue: queue.Queue[bytes | None] = queue.Queue()
        audio_source_type = self._discord.AudioSource
        body = self.core.body

        class StreamingPcmAudio(audio_source_type):
            def __init__(self) -> None:
                self._buffer = bytearray()
                self._finished = False

            def read(self) -> bytes:
                while len(self._buffer) < 3840 and not self._finished:
                    if cancel is not None and cancel.is_set():
                        self._finished = True
                        break
                    try:
                        chunk = audio_queue.get(timeout=0.1)
                    except queue.Empty:
                        continue
                    if chunk is None:
                        self._finished = True
                    else:
                        self._buffer.extend(chunk)
                if not self._buffer:
                    return b""
                frame = bytes(self._buffer[:3840])
                del self._buffer[:3840]
                # Measure frames when Discord consumes them, not when the network
                # receives them. Visual timing must follow actual playback.
                try:
                    body.set_speech_level(audioop.rms(frame, 2) / 32768.0)
                except Exception:
                    pass
                return frame.ljust(3840, b"\0")

        loop = asyncio.get_running_loop()
        playback_done = loop.create_future()

        def playback_finished(error: Exception | None) -> None:
            try:
                body.set_speech_level(0.0)
            except Exception:
                pass
            if error:
                LOG.warning("Discord streaming voice playback failed: %s", error)
            if not playback_done.done():
                loop.call_soon_threadsafe(playback_done.set_result, None)

        source = StreamingPcmAudio()
        voice_client.play(source, after=playback_finished)
        config = self.core.config.voice
        payload = {
            "text": text,
            "voiceId": config.inworld_tts_voice,
            "modelId": config.inworld_tts_model,
            "audioConfig": {
                "audioEncoding": "LINEAR16",
                "sampleRateHertz": config.inworld_tts_sample_rate,
            },
            "deliveryMode": config.inworld_tts_delivery_mode,
            "instruction": config.inworld_tts_instruction,
            "timestampTransportStrategy": "ASYNC",
        }
        started = monotonic()
        first_audio = True
        rate_state = None
        stream_error: Exception | None = None
        timeout = aiohttp.ClientTimeout(total=60, sock_read=45)
        try:
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(
                    "https://api.inworld.ai/tts/v1/voice:stream",
                    headers={"Authorization": f"Basic {self._voice_renderer._inworld_api_key()}"},
                    json=payload,
                ) as response:
                    if response.status >= 400:
                        raise RuntimeError(
                            f"Inworld TTS request failed ({response.status}): {await response.text()}"
                        )
                    async for raw_line in response.content:
                        if cancel is not None and cancel.is_set():
                            break
                        line = raw_line.decode("utf-8", errors="replace").strip()
                        if not line:
                            continue
                        if line.startswith("data:"):
                            line = line[5:].strip()
                        item = json.loads(line)
                        if item.get("error"):
                            raise RuntimeError(f"Inworld TTS stream error: {item['error']}")
                        encoded = str(item.get("result", {}).get("audioContent", ""))
                        if not encoded:
                            continue
                        audio, sample_rate = sf.read(
                            io.BytesIO(base64.b64decode(encoded)), dtype="float32"
                        )
                        samples = np.asarray(audio, dtype="float32")
                        if samples.ndim > 1:
                            samples = samples.mean(axis=1)
                        if not samples.size:
                            continue
                        pcm = (np.clip(samples, -1.0, 1.0) * 32767.0).astype("<i2").tobytes()
                        pcm = audioop.tostereo(pcm, 2, 1, 1)
                        if int(sample_rate) != 48_000:
                            pcm, rate_state = audioop.ratecv(
                                pcm, 2, 2, int(sample_rate), 48_000, rate_state
                            )
                        if first_audio:
                            first_audio = False
                            endpointed_at = self._voice_endpointed_at.get(guild.id)
                            LOG.info(
                                "Discord Inworld streaming first audio seconds=%.3f eot_to_audio=%.3f chars=%s",
                                monotonic() - started,
                                max(0.0, monotonic() - endpointed_at) if endpointed_at else -1.0,
                                len(text),
                            )
                        audio_queue.put(pcm)
        except Exception as exc:
            stream_error = exc
        finally:
            audio_queue.put(None)
            if cancel is not None and cancel.is_set() and voice_client.is_playing():
                _stop_voice_playback(voice_client)
        await playback_done
        if stream_error is not None:
            raise stream_error
        LOG.info("Discord Inworld streaming playback seconds=%.3f", monotonic() - started)

    async def _speak_reply_in_voice(
        self,
        guild,
        text: str,
        message_id: str,
        *,
        vocal_cue: str = "none",
        delivery: str = "neutral",
        mood: str = "neutral",
        cancel=None,
    ) -> None:
        """Speak text replies into Mako's current guild voice channel when connected."""
        if not self.config.voice_enabled or guild is None:
            return
        voice_client = guild.voice_client
        if voice_client is None or not voice_client.is_connected():
            return
        if self.core.config.voice.tts_backend.lower() == "cartesia_tts":
            await self._speak_elevenlabs_in_voice(guild, text, cancel=cancel)
            return
        if self.core.config.voice.tts_backend.lower() == "elevenlabs_tts":
            from .elevenlabs_voice import expressive_text
            await self._speak_elevenlabs_in_voice(
                guild, expressive_text(text, vocal_cue=vocal_cue, delivery=delivery, mood=mood), cancel=cancel
            )
            return
        if self.core.config.voice.tts_backend.lower() == "inworld_tts":
            text = inworld_expressive_text(text, vocal_cue=vocal_cue, delivery=delivery)
            await self._speak_inworld_stream_in_voice(guild, text, cancel=cancel)
            return
        path = self.core.paths.temporary / "discord-voice" / f"{message_id}-{uuid4().hex}.wav"
        try:
            started = monotonic()
            if self.core.config.voice.call_backend.lower() == "xai_realtime":
                await render_xai_voice_wav(self.core.config.voice, text, path)
                LOG.info("Discord VC xAI voice seconds=%.3f", monotonic() - started)
            else:
                await asyncio.to_thread(
                    self._voice_renderer.render_speech_wav,
                    text,
                    path,
                    vocal_cue=vocal_cue,
                    delivery=delivery,
                )
                LOG.info("Discord VC local TTS seconds=%.3f", monotonic() - started)
            if cancel is not None and cancel.is_set():
                return
            if voice_client.is_playing():
                LOG.warning("Discord VC playback was unexpectedly active; waiting for the current turn")
                while voice_client.is_playing():
                    if cancel is not None and cancel.is_set():
                        return
                    await asyncio.sleep(0.05)

            loop = asyncio.get_running_loop()
            playback_done = loop.create_future()

            def cleanup(error: Exception | None) -> None:
                if error:
                    LOG.warning("Discord voice playback failed: %s", error)
                try:
                    path.unlink(missing_ok=True)
                except OSError:
                    pass
                loop.call_soon_threadsafe(playback_done.set_result, None)

            pcm = _discord_pcm_from_wav(path)
            audio_source_type = self._discord.AudioSource

            class BufferedPcmAudio(audio_source_type):
                def __init__(self, payload: bytes) -> None:
                    self._payload = payload
                    self._offset = 0

                def read(self) -> bytes:
                    if cancel is not None and cancel.is_set():
                        return b""
                    frame = self._payload[self._offset:self._offset + 3840]
                    self._offset += len(frame)
                    return frame.ljust(3840, b"\0") if frame else b""

            voice_client.play(BufferedPcmAudio(pcm), after=cleanup)
            LOG.info("Discord voice playback queued guild=%s", guild.id)
            await playback_done
        except Exception as exc:
            LOG.warning("Discord voice synthesis/playback unavailable: %s", exc)
