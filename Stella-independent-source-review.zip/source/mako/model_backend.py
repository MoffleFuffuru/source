from __future__ import annotations

import json
import logging
import os
import queue
import shutil
import ssl
import subprocess
import threading
import time
from dataclasses import dataclass, replace
from typing import Any, Callable, Protocol
from urllib.error import HTTPError, URLError
from urllib.request import HTTPSHandler, ProxyHandler, Request, build_opener, urlopen

from .config import ModelConfig
from .usage import UsageTracker


REQUEST_HEADERS = {
    "User-Agent": "Mako-V4/1.0 (+https://github.com)",
}

logger = logging.getLogger(__name__)
_provider_pause_lock = threading.Lock()
_provider_pause_until: dict[str, float] = {}


def provider_cooling_down(provider: str) -> bool:
    """Background lanes yield after a provider rejects live traffic."""
    with _provider_pause_lock:
        return time.monotonic() < _provider_pause_until.get(provider.lower(), 0.0)


class ModelError(RuntimeError):
    pass


@dataclass(slots=True)
class Generation:
    text: str
    model: str
    elapsed_seconds: float
    first_token_seconds: float | None = None
    prompt_tokens: int = 0
    output_tokens: int = 0
    cached_tokens: int = 0
    rate_limits: dict[str, str] | None = None
    tool_calls: list[dict[str, Any]] | None = None


def _memory_tool_specs() -> list[dict[str, Any]]:
    return [
        {
            "type": "function", "function": {
                "name": "search_memory",
                "description": (
                    "Search Stella's established memories when prior shared history is needed. "
                    "For explicit recall, search before answering; refine a broad result. If a result's "
                    "context is insufficient, pass its memory handle to inspect_memory. Owner-private personal "
                    "call memories are available to the owner across direct Stella conversations."
                ),
                "parameters": {
                    "type": "object", "properties": {
                        "query": {"type": "string", "maxLength": 240},
                    }, "required": ["query"], "additionalProperties": False,
                },
            },
        },
        {
            "type": "function", "function": {
                "name": "inspect_memory",
                "description": (
                    "Read a supplied memory handle plus nearby turns from the same conversation. For the owner's "
                    "private personal-call memories, set full_call=true to inspect that entire call in pages. "
                    "Use when a surfaced memory lacks context or Stella is asked where it came from/what happened around it."
                ),
                "parameters": {
                    "type": "object", "properties": {
                        "handle": {"type": "string", "maxLength": 32},
                        "context_radius": {"type": "integer", "minimum": 0, "maximum": 4},
                        "full_call": {"type": "boolean"},
                        "call_offset": {"type": "integer", "minimum": 0},
                        "page_size": {"type": "integer", "minimum": 1, "maximum": 12},
                    }, "required": ["handle"], "additionalProperties": False,
                },
            },
        },
        {
            "type": "function", "function": {
                "name": "related_memories",
                "description": "Find closely associated memories from a supplied memory handle.",
                "parameters": {
                    "type": "object", "properties": {
                        "handle": {"type": "string", "maxLength": 32},
                    }, "required": ["handle"], "additionalProperties": False,
                },
            },
        },
    ]


class ModelBackend(Protocol):
    @property
    def active_model(self) -> str: ...

    def prewarm(self) -> None: ...

    def available_models(self) -> list[str]: ...

    def begin_conversation(self, scope: str, *, model: str | None = None) -> None: ...

    def end_conversation(self, scope: str) -> None: ...

    def has_conversation_history(self, scope: str) -> bool: ...

    def generate(
        self,
        *,
        system: str = "",
        prompt: str = "",
        messages: list[dict[str, str]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        json_output: bool = False,
        json_schema: dict[str, Any] | None = None,
        images: list[str] | None = None,
        cancel: threading.Event | None = None,
        on_token: Callable[[str], None] | None = None,
        model: str | None = None,
        context_tokens: int | None = None,
        timeout_seconds: float | None = None,
        reasoning_effort: str | None = None,
        retry_empty: bool = True,
        conversation_scope: str | None = None,
    ) -> Generation: ...


class OpenAICompatibleBackend:
    """Client for OpenAI-compatible chat APIs, routed by ModelConfig.provider."""

    def __init__(self, config: ModelConfig, usage: UsageTracker | None = None) -> None:
        self.config = config
        self.usage = usage
        self._active_model = config.primary
        self._dynamic_tool_handler: Callable[[str, dict[str, Any]], str] | None = None

    def set_dynamic_tool_handler(
        self, handler: Callable[[str, dict[str, Any]], str] | None
    ) -> None:
        self._dynamic_tool_handler = handler

    def begin_conversation(self, scope: str, *, model: str | None = None) -> None:
        """OpenAI-compatible providers are stateless; history is sent per request."""
        del scope, model

    def end_conversation(self, scope: str) -> None:
        """There is no remote conversation to close for this stateless backend."""
        del scope

    def has_conversation_history(self, scope: str) -> bool:
        """Conversation history is maintained locally and included in each request."""
        del scope
        return False

    def _open_request(self, request: Request, *, timeout: float):
        if self.config.provider.strip().lower() == "lithos":
            # Use a maintained CA bundle; the local Windows/OpenSSL store can
            # select an expired chain. Hostname and certificate checks stay on.
            import certifi
            context = ssl.create_default_context(cafile=certifi.where())
            return build_opener(ProxyHandler({}), HTTPSHandler(context=context)).open(request, timeout=timeout)
        # Stella's local runtime can inherit a dead development proxy. Cerebras
        # is a direct HTTPS API, so do not let that proxy turn a live call into
        # a silent Codex fallback.
        if self.config.provider.strip().lower() == "cerebras":
            return build_opener(ProxyHandler({})).open(request, timeout=timeout)
        return urlopen(request, timeout=timeout)

    @property
    def provider_name(self) -> str:
        names = {"xai": "xAI", "groq": "Groq", "cerebras": "Cerebras", "openrouter": "OpenRouter", "lithos": "LithosAI"}
        provider = self.config.provider.strip().lower()
        return names.get(provider, provider or "model provider")

    @property
    def active_model(self) -> str:
        return self._active_model

    def prewarm(self) -> None:
        # Groq keeps the model fleet warm. Avoid a paid startup generation and let
        # the first real turn authenticate the key instead.
        self._require_api_key()

    def available_models(self) -> list[str]:
        api_key = self._require_api_key()
        request = Request(
            f"{self.config.endpoint.rstrip('/')}/models",
            headers={
                **REQUEST_HEADERS,
                "Authorization": f"Bearer {api_key}",
                "Accept": "application/json",
            },
        )
        try:
            with self._open_request(request, timeout=8.0) as response:
                data = json.loads(response.read().decode("utf-8"))
        except HTTPError as exc:
            raise ModelError(self._http_error(self.provider_name, exc)) from exc
        except (URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
            raise ModelError(f"{self.provider_name} is unavailable: {exc}") from exc
        return [str(item.get("id", "")) for item in data.get("data", []) if item.get("id")]

    def generate(self, **kwargs: Any) -> Generation:
        handler = self._dynamic_tool_handler
        if handler is None or not kwargs.get("conversation_scope"):
            return self._generate_once(**kwargs)

        messages = list(kwargs.get("messages") or [
            {"role": "system", "content": kwargs.get("system", "")},
            {"role": "user", "content": kwargs.get("prompt", "")},
        ])
        elapsed = 0.0
        prompt_tokens = output_tokens = cached_tokens = 0
        first_token_seconds: float | None = None
        for tool_round in range(2):
            result = self._generate_once(
                **{
                    **kwargs,
                    "messages": messages,
                    "json_output": False,
                    "json_schema": None,
                    "tools": _memory_tool_specs(),
                }
            )
            elapsed += result.elapsed_seconds
            prompt_tokens += result.prompt_tokens
            output_tokens += result.output_tokens
            cached_tokens += result.cached_tokens
            if first_token_seconds is None and result.first_token_seconds is not None:
                first_token_seconds = elapsed - result.elapsed_seconds + result.first_token_seconds
            calls = result.tool_calls or []
            if not calls:
                if tool_round == 0:
                    return result
                return Generation(
                    text=result.text, model=result.model, elapsed_seconds=elapsed,
                    first_token_seconds=first_token_seconds, prompt_tokens=prompt_tokens,
                    output_tokens=output_tokens, cached_tokens=cached_tokens,
                    rate_limits=result.rate_limits,
                )
            messages.append({"role": "assistant", "content": result.text or None, "tool_calls": calls})
            for call in calls:
                function = call.get("function", {})
                name = str(function.get("name", ""))
                try:
                    arguments = json.loads(str(function.get("arguments", "{}")))
                    if not isinstance(arguments, dict):
                        raise ValueError("tool arguments must be an object")
                    output = handler(name, arguments)
                except Exception as exc:
                    output = f"Memory tool failed: {exc}"
                messages.append({
                    "role": "tool", "tool_call_id": str(call.get("id", "")),
                    "name": name, "content": str(output)[:48000 if name == "inspect_memory" else 12000],
                })

        result = self._generate_once(
            **{**kwargs, "messages": messages, "tools": None}
        )
        elapsed += result.elapsed_seconds
        prompt_tokens += result.prompt_tokens
        output_tokens += result.output_tokens
        cached_tokens += result.cached_tokens
        return Generation(
            text=result.text, model=result.model, elapsed_seconds=elapsed,
            first_token_seconds=first_token_seconds or result.first_token_seconds,
            prompt_tokens=prompt_tokens, output_tokens=output_tokens,
            cached_tokens=cached_tokens, rate_limits=result.rate_limits,
        )

    def _generate_once(
        self,
        *,
        system: str = "",
        prompt: str = "",
        messages: list[dict[str, str]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        json_output: bool = False,
        json_schema: dict[str, Any] | None = None,
        images: list[str] | None = None,
        cancel: threading.Event | None = None,
        on_token: Callable[[str], None] | None = None,
        model: str | None = None,
        context_tokens: int | None = None,
        timeout_seconds: float | None = None,
        reasoning_effort: str | None = None,
        retry_empty: bool = True,
        retry_rate_limit: bool = True,
        retry_transport: bool = True,
        conversation_scope: str | None = None,
        tools: list[dict[str, Any]] | None = None,
    ) -> Generation:
        del context_tokens
        if images:
            raise ModelError("Vision is not configured for the GPT-OSS text model.")
        if cancel and cancel.is_set():
            raise ModelError("generation cancelled")

        api_key = self._require_api_key()
        selected_model = model or self.config.primary
        estimated_tokens = (max_tokens or self.config.max_output_tokens) + 1200
        if (
            selected_model == self.config.primary
            and self.usage
            and not self.usage.daily_available(
                selected_model, estimated_tokens=estimated_tokens, config=self.config
            )
        ):
            selected_model = self.config.fallback
        payload: dict[str, Any] = {
            "model": selected_model,
            "messages": messages or [
                {"role": "system", "content": system},
                {"role": "user", "content": prompt},
            ],
            "temperature": self.config.temperature if temperature is None else temperature,
            "top_p": self.config.top_p,
            "max_completion_tokens": max_tokens or self.config.max_output_tokens,
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        reasoning_effort = reasoning_effort or self.config.reasoning_effort
        # xAI's explicitly non-reasoning models should not receive the
        # reasoning control at all; "none" is not a valid effort value.
        if reasoning_effort and "non-reasoning" not in selected_model.lower():
            payload["reasoning_effort"] = reasoning_effort
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"
        if json_schema is not None:
            payload["response_format"] = {
                "type": "json_schema",
                "json_schema": {"name": "mako_response", "strict": True, "schema": json_schema},
            }
        elif json_output:
            payload["response_format"] = {"type": "json_object"}

        headers = {
            **REQUEST_HEADERS,
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        }
        if self.config.provider.strip().lower() == "xai" and conversation_scope:
            # xAI routes a stable conversation ID to the same cache-bearing
            # server, preserving prompt-cache hits across one live call.
            headers["x-grok-conv-id"] = conversation_scope
        request = Request(
            f"{self.config.endpoint.rstrip('/')}/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        started = time.monotonic()
        chunks: list[str] = []
        usage: dict[str, Any] = {}
        rate_limits: dict[str, str] = {}
        first_token_seconds: float | None = None
        tool_calls: dict[int, dict[str, Any]] = {}
        try:
            with self._open_request(
                request,
                timeout=self.config.timeout_seconds if timeout_seconds is None else timeout_seconds,
            ) as response:
                rate_limits = self._rate_limits(response.headers)
                for encoded_line in response:
                    if cancel and cancel.is_set():
                        response.close()
                        raise ModelError("generation cancelled")
                    line = encoded_line.decode("utf-8", errors="replace").strip()
                    if not line or not line.startswith("data:"):
                        continue
                    raw_data = line[5:].strip()
                    if raw_data == "[DONE]":
                        break
                    data = json.loads(raw_data)
                    if data.get("usage"):
                        usage = data["usage"]
                    for choice in data.get("choices", []):
                        delta = choice.get("delta", {})
                        for fragment in delta.get("tool_calls", []) or []:
                            index = int(fragment.get("index", 0))
                            call = tool_calls.setdefault(index, {
                                "id": "", "type": "function",
                                "function": {"name": "", "arguments": ""},
                            })
                            call["id"] += str(fragment.get("id") or "")
                            function = fragment.get("function", {}) or {}
                            call["function"]["name"] += str(function.get("name") or "")
                            call["function"]["arguments"] += str(function.get("arguments") or "")
                        token = str(delta.get("content") or "")
                        if token:
                            if first_token_seconds is None:
                                first_token_seconds = time.monotonic() - started
                            chunks.append(token)
                            if on_token:
                                on_token(token)
        except HTTPError as exc:
            if exc.code in {429, 502, 503, 504}:
                with _provider_pause_lock:
                    _provider_pause_until[self.config.provider.lower()] = time.monotonic() + 60.0
            rate_limits = self._rate_limits(exc.headers)
            error_message = self._http_error(self.provider_name, exc)
            if exc.code == 429 and selected_model == self.config.primary and retry_rate_limit:
                # The request header is RPD. A zero here is a genuine daily
                # request exhaustion, so preserve availability via the 20B reserve.
                if (
                    self._is_exhausted_daily_request_budget(rate_limits)
                    or self._is_daily_token_exhaustion(error_message)
                ) and self.config.fallback:
                    return self.generate(
                        system=system, prompt=prompt, messages=messages, temperature=temperature, max_tokens=max_tokens,
                        json_output=json_output, json_schema=json_schema, cancel=cancel,
                        on_token=on_token, model=self.config.fallback, timeout_seconds=timeout_seconds,
                        reasoning_effort=reasoning_effort, retry_empty=retry_empty,
                        retry_rate_limit=False, retry_transport=False,
                    )
                # TPM is a rolling, temporary window. For a live companion the
                # 20B reserve is preferable to surfacing a raw 429 or waiting a
                # minute; GPT-OSS quotas are tracked separately by model.
                if self.config.fallback and self._insufficient_tpm_budget(
                    rate_limits, estimated_tokens
                ):
                    return self.generate(
                        system=system, prompt=prompt, messages=messages, temperature=temperature, max_tokens=max_tokens,
                        json_output=json_output, json_schema=json_schema, cancel=cancel,
                        on_token=on_token, model=self.config.fallback, timeout_seconds=timeout_seconds,
                        reasoning_effort=reasoning_effort, retry_empty=retry_empty,
                        retry_rate_limit=False, retry_transport=False,
                    )
                retry_after = self._retry_after(exc.headers)
                if retry_after is not None and retry_after <= 3.0:
                    time.sleep(retry_after)
                    return self.generate(
                        system=system, prompt=prompt, messages=messages, temperature=temperature, max_tokens=max_tokens,
                        json_output=json_output, json_schema=json_schema, cancel=cancel,
                        on_token=on_token, model=selected_model, timeout_seconds=timeout_seconds,
                        reasoning_effort=reasoning_effort, retry_empty=retry_empty,
                        retry_rate_limit=False, retry_transport=retry_transport,
                    )
            raise ModelError(error_message) from exc
        except (URLError, TimeoutError, OSError) as exc:
            with _provider_pause_lock:
                _provider_pause_until[self.config.provider.lower()] = time.monotonic() + 60.0
            if selected_model == self.config.primary and retry_transport and self.config.fallback and self.config.fallback != selected_model:
                return self.generate(
                    system=system, prompt=prompt, messages=messages, temperature=temperature, max_tokens=max_tokens,
                    json_output=json_output, json_schema=json_schema, cancel=cancel,
                    on_token=on_token, model=self.config.fallback, timeout_seconds=timeout_seconds,
                    reasoning_effort=reasoning_effort, retry_empty=retry_empty,
                    retry_rate_limit=retry_rate_limit, retry_transport=False,
                )
            raise ModelError(f"{self.provider_name} request failed: {exc}") from exc
        except json.JSONDecodeError as exc:
            raise ModelError(f"{self.provider_name} returned invalid streaming JSON: {exc}") from exc

        text = "".join(chunks).strip()
        if tool_calls:
            self._active_model = selected_model
            generation = Generation(
                text=text, model=selected_model, elapsed_seconds=time.monotonic() - started,
                first_token_seconds=first_token_seconds,
                prompt_tokens=int(usage.get("prompt_tokens", 0)),
                output_tokens=int(usage.get("completion_tokens", 0)),
                cached_tokens=int((usage.get("prompt_tokens_details") or {}).get("cached_tokens") or 0),
                rate_limits=rate_limits,
                tool_calls=[tool_calls[index] for index in sorted(tool_calls)],
            )
            if self.usage:
                self.usage.record(
                    model=selected_model, prompt_tokens=generation.prompt_tokens,
                    cached_tokens=generation.cached_tokens, completion_tokens=generation.output_tokens,
                    status="success", fallback=selected_model == self.config.fallback,
                    rate_limits=rate_limits,
                )
            return generation
        if not text:
            if retry_empty and not (cancel and cancel.is_set()):
                # Groq occasionally finishes a streamed reasoning turn without a
                # visible content delta. Retry that transport edge case once.
                return self.generate(
                    system=system,
                    prompt=prompt,
                    messages=messages,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    json_output=json_output,
                    json_schema=json_schema,
                    cancel=cancel,
                    on_token=on_token,
                    model=model,
                    timeout_seconds=timeout_seconds,
                    reasoning_effort=reasoning_effort,
                    retry_empty=False,
                    retry_rate_limit=retry_rate_limit,
                    retry_transport=retry_transport,
                )
            if selected_model == self.config.primary and self.config.fallback:
                return self.generate(
                    system=system, prompt=prompt, messages=messages, temperature=temperature, max_tokens=max_tokens,
                    json_output=json_output, json_schema=json_schema, cancel=cancel,
                    on_token=on_token, model=self.config.fallback, timeout_seconds=timeout_seconds,
                    reasoning_effort=reasoning_effort, retry_empty=False,
                    retry_rate_limit=retry_rate_limit, retry_transport=False,
                )
            prompt_tokens = usage.get("prompt_tokens", "unknown")
            completion_tokens = usage.get("completion_tokens", "unknown")
            remaining = rate_limits.get("x-ratelimit-remaining-tokens", "unknown")
            raise ModelError(
                f"{self.provider_name} returned an empty response "
                f"(prompt_tokens={prompt_tokens}, completion_tokens={completion_tokens}, "
                f"remaining_tokens={remaining})"
            )
        self._active_model = selected_model
        generation = Generation(
            text=text,
            model=selected_model,
            elapsed_seconds=time.monotonic() - started,
            first_token_seconds=first_token_seconds,
            prompt_tokens=int(usage.get("prompt_tokens", 0)),
            output_tokens=int(usage.get("completion_tokens", 0)),
            cached_tokens=int((usage.get("prompt_tokens_details") or {}).get("cached_tokens") or 0),
            rate_limits=rate_limits,
        )
        logger.info(
            "%s generation model=%s first_token=%.3fs wall=%.3fs prompt_tokens=%s cached_tokens=%s cache_scope=%s",
            self.provider_name,
            generation.model,
            generation.first_token_seconds if generation.first_token_seconds is not None else -1.0,
            generation.elapsed_seconds,
            generation.prompt_tokens,
            generation.cached_tokens,
            conversation_scope or "none",
        )
        if self.usage:
            self.usage.record(
                model=selected_model, prompt_tokens=generation.prompt_tokens,
                cached_tokens=generation.cached_tokens, completion_tokens=generation.output_tokens,
                status="success", fallback=selected_model == self.config.fallback,
                rate_limits=rate_limits,
            )
        return generation

    def _require_api_key(self) -> str:
        name = self.config.api_key_environment_variable.strip() or "GROQ_API_KEY"
        api_key = os.environ.get(name, "").strip()
        if not api_key and os.name == "nt":
            try:
                import winreg

                with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as key:
                    value, _ = winreg.QueryValueEx(key, name)
                api_key = str(value).strip()
            except OSError:
                pass
        if not api_key:
            raise ModelError(f"{self.provider_name} API key missing. Set the {name} environment variable.")
        return api_key

    @staticmethod
    def _http_error(provider: str, error: HTTPError) -> str:
        detail = error.read().decode("utf-8", errors="replace")[:500]
        if "<html" in detail.lower():
            return (
                f"{provider} HTTP {error.code}: request blocked before reaching the API. "
                "Check network access and retry."
            )
        return f"{provider} HTTP {error.code}: {detail or error.reason}"

    @staticmethod
    def _rate_limits(headers: Any) -> dict[str, str]:
        if not headers:
            return {}
        return {
            "remaining_requests": str(headers.get("x-ratelimit-remaining-requests", "")),
            "remaining_tokens": str(headers.get("x-ratelimit-remaining-tokens", "")),
            "reset_requests": str(headers.get("x-ratelimit-reset-requests", "")),
            "reset_tokens": str(headers.get("x-ratelimit-reset-tokens", "")),
        }

    @staticmethod
    def _retry_after(headers: Any) -> float | None:
        try:
            return float(headers.get("retry-after", ""))
        except (AttributeError, TypeError, ValueError):
            return None

    @staticmethod
    def _is_exhausted_daily_request_budget(rate_limits: dict[str, str]) -> bool:
        try:
            return float(rate_limits.get("remaining_requests", "")) <= 0.0
        except (TypeError, ValueError):
            return False

    @staticmethod
    def _is_daily_token_exhaustion(error_message: str) -> bool:
        """Groq exposes TPD exhaustion in the 429 body, not a rate-limit header."""
        return "tokens per day" in error_message.lower()

    @staticmethod
    def _insufficient_tpm_budget(rate_limits: dict[str, str], estimated_tokens: int) -> bool:
        """Treat a 429 with too little current TPM headroom as a 20B fallback case."""
        try:
            return float(rate_limits.get("remaining_tokens", "")) < estimated_tokens
        except (TypeError, ValueError):
            # Groq does not always return the limit headers on a rejected stream.
            # The only remaining safe real-time recovery is the model reserve.
            return True


GroqBackend = OpenAICompatibleBackend  # Backward-compatible import for older plugins/tests.


class ProviderFallbackBackend:
    """Retry a failed primary response on a separately configured hosted provider."""

    def __init__(self, primary: ModelBackend, fallback: OpenAICompatibleBackend, *, model: str) -> None:
        self.primary = primary
        self.fallback = fallback
        self.model = model
        self._active_model = primary.active_model

    @property
    def active_model(self) -> str:
        return self._active_model

    @staticmethod
    def _is_temporary_failure(error: ModelError) -> bool:
        message = str(error).lower()
        return any(marker in message for marker in (
            "http 429", "status 429", "rate limit", "overloaded", "at capacity",
            "temporarily unavailable", "http 502", "http 503", "http 504",
            "timed out", "timeout", "connection reset", "connection refused",
            "name or service not known", "temporary failure",
        ))

    def generate(self, **kwargs: Any) -> Generation:
        emitted = False
        callback = kwargs.get("on_token")

        primary_config = getattr(self.primary, "config", None)
        primary_provider = str(getattr(primary_config, "provider", "") or "").strip().lower()

        def generate_fallback() -> Generation:
            fallback_kwargs = dict(kwargs)
            fallback_kwargs["model"] = self.model
            return self.fallback.generate(**fallback_kwargs)

        def track_token(token: str) -> None:
            nonlocal emitted
            emitted = True
            if callback:
                callback(token)

        if primary_provider and provider_cooling_down(primary_provider):
            logger.info(
                "Primary provider %s is cooling down; routing directly to %s",
                primary_provider,
                self.fallback.provider_name,
            )
            result = generate_fallback()
        else:
            primary_kwargs = dict(kwargs)
            # This wrapper already owns a cross-provider fallback. Retrying a
            # second model on the same unreachable provider just doubles the
            # read-timeout before the healthy fallback can answer.
            primary_kwargs.setdefault("retry_transport", False)
            if callback:
                primary_kwargs["on_token"] = track_token
            try:
                result = self.primary.generate(**primary_kwargs)
            except ModelError as exc:
                cancel = kwargs.get("cancel")
                if emitted or (cancel and cancel.is_set()) or not self._is_temporary_failure(exc):
                    raise
                logger.warning("Primary provider failed before streaming; retrying on %s: %s", self.fallback.provider_name, exc)
                result = generate_fallback()
        self._active_model = result.model
        return result

    def prewarm(self) -> None:
        self.primary.prewarm()

    def available_models(self) -> list[str]:
        return self.primary.available_models()

    def begin_conversation(self, scope: str, *, model: str | None = None) -> None:
        self.primary.begin_conversation(scope, model=model)

    def end_conversation(self, scope: str) -> None:
        self.primary.end_conversation(scope)

    def has_conversation_history(self, scope: str) -> bool:
        return self.primary.has_conversation_history(scope)

    def set_dynamic_tool_handler(self, handler: Callable[[str, dict[str, Any]], str] | None) -> None:
        for backend in (self.primary, self.fallback):
            setter = getattr(backend, "set_dynamic_tool_handler", None)
            if callable(setter):
                setter(handler)

    def close(self) -> None:
        close = getattr(self.primary, "close", None)
        if callable(close):
            close()


class CodexAppServerBackend:
    """Codex client with scoped conversations and read-only memory tools."""

    def __init__(self, config: ModelConfig, usage: UsageTracker | None = None) -> None:
        del usage
        self.config = config
        self._active_model = config.primary
        self._process: subprocess.Popen[str] | None = None
        self._messages: queue.Queue[dict[str, Any]] = queue.Queue()
        self._stderr: list[str] = []
        self._request_id = 0
        self._lock = threading.RLock()
        self._persistent_threads: dict[str, str] = {}
        self._initialized_scopes: set[str] = set()
        self._dynamic_tool_handler: Callable[[str, dict[str, Any]], str] | None = None

    def set_dynamic_tool_handler(
        self,
        handler: Callable[[str, dict[str, Any]], str],
    ) -> None:
        self._dynamic_tool_handler = handler

    @property
    def active_model(self) -> str:
        return self._active_model

    def prewarm(self) -> None:
        with self._lock:
            self._ensure_server()

    def available_models(self) -> list[str]:
        with self._lock:
            self._ensure_server()
            data = self._request("model/list", {"limit": 100, "includeHidden": False})
            return [str(item.get("model", "")) for item in data.get("data", []) if item.get("model")]

    def begin_conversation(self, scope: str, *, model: str | None = None) -> None:
        """Create one in-memory App Server thread for an explicit conversation."""
        if not scope:
            return
        with self._lock:
            if scope not in self._persistent_threads:
                self._persistent_threads[scope] = self._start_thread(
                    model=model,
                    conversation_scope=scope,
                    persistent=True,
                )

    def end_conversation(self, scope: str) -> None:
        """Forget an ephemeral conversation thread at the application boundary."""
        with self._lock:
            self._persistent_threads.pop(scope, None)
            self._initialized_scopes.discard(scope)

    def has_conversation_history(self, scope: str) -> bool:
        with self._lock:
            return scope in self._initialized_scopes

    def generate(
        self,
        *,
        system: str = "",
        prompt: str = "",
        messages: list[dict[str, str]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        json_output: bool = False,
        json_schema: dict[str, Any] | None = None,
        images: list[str] | None = None,
        cancel: threading.Event | None = None,
        on_token: Callable[[str], None] | None = None,
        model: str | None = None,
        context_tokens: int | None = None,
        timeout_seconds: float | None = None,
        reasoning_effort: str | None = None,
        retry_empty: bool = True,
        conversation_scope: str | None = None,
    ) -> Generation:
        del temperature, context_tokens, retry_empty
        if images:
            raise ModelError("Vision is not configured for the Codex App Server backend.")
        if cancel and cancel.is_set():
            raise ModelError("generation cancelled")
        with self._lock:
            persistent = bool(
                conversation_scope
                and conversation_scope in self._persistent_threads
            )
            thread_id = (
                self._persistent_threads[conversation_scope]
                if persistent and conversation_scope
                else self._start_thread(model=model, conversation_scope=conversation_scope)
            )
            selected_model = model or self.config.primary
            source_messages = messages or [
                {"role": "system", "content": system},
                {"role": "user", "content": prompt},
            ]
            if persistent and conversation_scope in self._initialized_scopes:
                # The App Server thread already owns prior turns. Replaying Mako's
                # bounded history here duplicates context and can distort replies.
                source_messages = source_messages[-1:]
            app_input = self._application_input(source_messages)
            params: dict[str, Any] = {
                "threadId": thread_id,
                "input": [{"type": "text", "text": app_input}],
                "approvalPolicy": "never",
                "sandboxPolicy": {"type": "readOnly", "networkAccess": False},
                "environments": [],
                "personality": self.config.codex_personality or "none",
                "model": selected_model,
                "effort": reasoning_effort or self.config.reasoning_effort,
                "summary": "none",
            }
            if json_schema is not None:
                params["outputSchema"] = json_schema
            elif json_output:
                params["outputSchema"] = {"type": "object"}
            started = time.monotonic()
            try:
                response = self._request("turn/start", params)
                turn_id = str(response["turn"]["id"])
                text = self._wait_for_turn(
                    turn_id,
                    thread_id=thread_id,
                    timeout=timeout_seconds or self.config.timeout_seconds,
                    cancel=cancel,
                    on_token=on_token,
                ).strip()
            except ModelError:
                if persistent and conversation_scope and cancel and cancel.is_set():
                    # Rehydrate from Mako's authoritative history after an
                    # interrupted speculative/stale turn.
                    self.end_conversation(conversation_scope)
                raise
            if not text:
                raise ModelError("Codex App Server returned an empty response")
            if persistent and conversation_scope:
                self._initialized_scopes.add(conversation_scope)
            self._active_model = selected_model
            return Generation(text=text, model=selected_model, elapsed_seconds=time.monotonic() - started)

    def close(self) -> None:
        with self._lock:
            self._persistent_threads.clear()
            self._initialized_scopes.clear()
            process = self._process
            self._process = None
            if process and process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()

    def _ensure_server(self) -> None:
        if self._process and self._process.poll() is None:
            return
        executable = self.config.codex_executable.strip() or shutil.which("codex")
        if not executable:
            raise ModelError("Codex CLI was not found. Set model.codex_executable to codex.exe.")
        codex_home = self.config.codex_home.strip()
        if not codex_home:
            raise ModelError("Set model.codex_home to Mako's isolated ChatGPT-authenticated CODEX_HOME.")
        environment = os.environ.copy()
        environment["CODEX_HOME"] = codex_home
        try:
            self._process = subprocess.Popen(
                [executable, "app-server"], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, text=True, encoding="utf-8", bufsize=1, env=environment,
            )
        except OSError as exc:
            raise ModelError(f"Could not start Codex App Server: {exc}") from exc
        assert self._process.stdout and self._process.stderr
        threading.Thread(target=self._read_stdout, daemon=True).start()
        threading.Thread(target=self._read_stderr, daemon=True).start()
        self._request(
            "initialize",
            {"clientInfo": {"name": "mako-v4", "version": "4"}, "capabilities": {"experimentalApi": True}},
        )

    def _start_thread(
        self,
        *,
        model: str | None = None,
        conversation_scope: str | None = None,
        persistent: bool = False,
    ) -> str:
        """Start a clean App Server thread for one Mako-owned context snapshot."""
        self._ensure_server()
        result = self._request(
            "thread/start",
            {
                "ephemeral": True,
                "approvalPolicy": "never",
                "sandbox": "read-only",
                "environments": [],
                "personality": self.config.codex_personality or "none",
                "model": model or self.config.primary,
                "dynamicTools": self._dynamic_tools() if conversation_scope else [],
                "baseInstructions": (
                    "You are Stella's text-generation engine. Never use files, terminal, web, external "
                    "actions, or any tool except the supplied read-only memory tools. For an explicit memory "
                    "recall request, call search_memory before answering. Use the supplied evidence as a lead, "
                    "not proof that you searched. The application supplies "
                    "Stella's behavior and output contract in "
                    "each turn. Follow that contract exactly, return only the requested answer, and never "
                    "mention Codex, system prompts, tools, or this wrapper."
                ),
                "developerInstructions": (
                    "Produce conversational text only after any required memory lookup. Treat memory search "
                    "results as evidence, never invent a memory when no matching evidence is returned. "
                    f"Conversation scope: {conversation_scope or 'default'}. "
                    + (
                        "Retain only this ephemeral call's turns until the application ends the call."
                        if persistent
                        else "Do not retain facts beyond this turn."
                    )
                ),
            },
        )
        return str(result["thread"]["id"])

    def _dynamic_tools(self) -> list[dict[str, Any]]:
        if self._dynamic_tool_handler is None:
            return []
        return [
            {
                "type": "function",
                "name": "search_memory",
                "description": (
                    "Search Stella's established memories for a specific past detail. Use this whenever the "
                    "supplied context is insufficient and remembering would improve the response. For an explicit "
                    "recall question, call this before answering; if results only establish that something existed, "
                    "refine the query and search again. Read-only, privacy-scoped, and limited to four results per call."
                ),
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "A concise description of the event, person, fact, or topic to remember.",
                            "maxLength": 240,
                        }
                    },
                    "required": ["query"],
                    "additionalProperties": False,
                },
            },
            {
                "type": "function",
                "name": "inspect_memory",
                "description": (
                    "Read a supplied memory handle and up to a bounded number of surrounding turns "
                    "from that same authorized conversation. Use this whenever a surfaced memory "
                    "lacks its context, or Stella is asked where it came from or what happened around it. "
                    "Available during any turn with memory tools; privacy-scoped and read-only."
                ),
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "handle": {"type": "string", "maxLength": 32},
                        "context_radius": {
                            "type": "integer", "minimum": 0, "maximum": 4,
                            "description": "Surrounding turns on each side; defaults to 2.",
                        },
                    },
                    "required": ["handle"], "additionalProperties": False,
                },
            },
            {
                "type": "function",
                "name": "related_memories",
                "description": "Find closely associated memories from a supplied memory handle.",
                "inputSchema": {
                    "type": "object",
                    "properties": {"handle": {"type": "string", "maxLength": 32}},
                    "required": ["handle"], "additionalProperties": False,
                },
            },
        ]

    def _read_stdout(self) -> None:
        assert self._process and self._process.stdout
        for line in self._process.stdout:
            try:
                self._messages.put(json.loads(line))
            except json.JSONDecodeError:
                continue

    def _read_stderr(self) -> None:
        assert self._process and self._process.stderr
        for line in self._process.stderr:
            self._stderr.append(line.rstrip())

    def _request(self, method: str, params: dict[str, Any], timeout: float = 45.0) -> dict[str, Any]:
        if not self._process or not self._process.stdin:
            raise ModelError("Codex App Server is not running")
        self._request_id += 1
        request_id = self._request_id
        self._process.stdin.write(json.dumps({"jsonrpc": "2.0", "id": request_id, "method": method, "params": params}) + "\n")
        self._process.stdin.flush()
        deadline = time.monotonic() + timeout
        held: list[dict[str, Any]] = []
        while time.monotonic() < deadline:
            try:
                message = self._messages.get(timeout=max(0.05, deadline - time.monotonic()))
            except queue.Empty:
                break
            if message.get("id") == request_id:
                for prior in held:
                    self._messages.put(prior)
                if "error" in message:
                    raise ModelError(f"Codex App Server {method} failed: {message['error']}")
                return message.get("result", {})
            held.append(message)
        for prior in held:
            self._messages.put(prior)
        detail = " | ".join(self._stderr[-3:])
        raise ModelError(f"Codex App Server timed out during {method}{': ' + detail if detail else ''}")

    def _wait_for_turn(
        self, turn_id: str, *, thread_id: str, timeout: float, cancel: threading.Event | None,
        on_token: Callable[[str], None] | None,
    ) -> str:
        deadline = time.monotonic() + timeout
        chunks: list[str] = []
        turn_error = None
        held: list[dict[str, Any]] = []
        while time.monotonic() < deadline:
            if cancel and cancel.is_set():
                self._request("turn/interrupt", {"threadId": thread_id, "turnId": turn_id})
                raise ModelError("generation cancelled")
            try:
                message = self._messages.get(timeout=0.1)
            except queue.Empty:
                continue
            method, params = message.get("method"), message.get("params", {})
            event_turn_id = params.get("turnId") or params.get("turn", {}).get("id")
            if event_turn_id != turn_id:
                held.append(message)
                continue
            if method == "item/tool/call":
                self._respond_to_dynamic_tool(message)
            elif method == "error":
                turn_error = params.get("error")
            elif method == "item/agentMessage/delta":
                token = str(params.get("delta", ""))
                chunks.append(token)
                if on_token and token:
                    on_token(token)
            elif method == "turn/completed":
                for prior in held:
                    self._messages.put(prior)
                turn = params.get("turn", {})
                status = turn.get("status")
                error = turn.get("error") or turn_error
                if error or status in {"failed", "interrupted"}:
                    detail = error.get("message", str(error)) if isinstance(error, dict) else error
                    raise ModelError(f"Codex App Server turn {status or 'failed'}: {detail or status}")
                return "".join(chunks)
        for prior in held:
            self._messages.put(prior)
        raise ModelError(f"Codex App Server timed out waiting for response after {timeout:.0f}s")

    def _respond_to_dynamic_tool(self, message: dict[str, Any]) -> None:
        if not self._process or not self._process.stdin or "id" not in message:
            raise ModelError("Codex App Server requested a tool without a response channel")
        params = message.get("params", {})
        tool = str(params.get("tool", ""))
        arguments = params.get("arguments", {})
        if not isinstance(arguments, dict):
            arguments = {}
        success = False
        output = "Memory search is unavailable."
        if tool in {"search_memory", "inspect_memory", "related_memories"} and self._dynamic_tool_handler is not None:
            try:
                output = self._dynamic_tool_handler(tool, arguments)
                success = True
            except Exception as exc:
                output = f"Memory search failed: {exc}"
        logger.info("Model memory tool call tool=%s success=%s result_chars=%d", tool, success, len(output))
        response = {
            "jsonrpc": "2.0",
            "id": message["id"],
            "result": {
                "success": success,
                "contentItems": [{"type": "inputText", "text": output}],
            },
        }
        self._process.stdin.write(json.dumps(response) + "\n")
        self._process.stdin.flush()

    @staticmethod
    def _application_input(messages: list[dict[str, str]]) -> str:
        lines = ["APPLICATION INSTRUCTIONS AND CONTEXT:"]
        for message in messages:
            role = str(message.get("role", "user")).upper()
            content = str(message.get("content", "")).strip()
            if content:
                lines.append(f"[{role}]\n{content}")
        lines.append("Return only the output required by the application instructions above.")
        return "\n\n".join(lines)


class HybridCodexCallBackend:
    """Route ordinary Mako turns to Codex and live calls to a separate API."""

    def __init__(self, config: ModelConfig, usage: UsageTracker | None = None) -> None:
        self.config = config
        self.codex = CodexAppServerBackend(config, usage)
        call_provider = config.call_provider.strip().lower() or "xai"
        self._call_uses_codex = call_provider == "codex"
        default_endpoints = {
            "lithos": "https://api.lithosai.cloud/v1",
            "xai": "https://api.x.ai/v1",
            "cerebras": "https://api.cerebras.ai/v1",
            "groq": "https://api.groq.com/openai/v1",
            "openrouter": "https://openrouter.ai/api/v1",
        }
        default_keys = {
            "lithos": "LITHOSAI_API_KEY",
            "xai": "XAI_API_KEY",
            "cerebras": "CEREBRAS_API_KEY",
            "groq": "GROQ_API_KEY",
            "openrouter": "OPENROUTER_API_KEY",
        }
        self.call = OpenAICompatibleBackend(
            replace(
                config,
                provider=call_provider,
                endpoint=config.call_endpoint or default_endpoints.get(call_provider, ""),
                api_key_environment_variable=(
                    config.call_api_key_environment_variable
                    or default_keys.get(call_provider, "MODEL_API_KEY")
                ),
                primary=config.call_model,
                fallback=config.call_model,
                reasoning_effort=config.call_reasoning_effort,
            ),
            usage,
        )
        self._active_model = config.primary

    @property
    def active_model(self) -> str:
        return self._active_model

    def prewarm(self) -> None:
        if self._call_uses_codex:
            self.codex.prewarm()
        else:
            self.call.prewarm()

    def available_models(self) -> list[str]:
        return self.codex.available_models() if self._call_uses_codex else self.call.available_models()

    def begin_conversation(self, scope: str, *, model: str | None = None) -> None:
        if self._call_uses_codex or model != self.config.call_model:
            self.codex.begin_conversation(scope, model=model)

    def end_conversation(self, scope: str) -> None:
        self.codex.end_conversation(scope)

    def has_conversation_history(self, scope: str) -> bool:
        return self._call_uses_codex and self.codex.has_conversation_history(scope)

    def set_dynamic_tool_handler(
        self, handler: Callable[[str, dict[str, Any]], str] | None
    ) -> None:
        self.codex.set_dynamic_tool_handler(handler)
        self.call.set_dynamic_tool_handler(handler)

    def generate(self, **kwargs: Any) -> Generation:
        # Stella is configured around the low-latency Cerebras call model. Keep
        # desktop text, voice calls, and Discord on that same live route instead
        # of attempting the unavailable Codex App Server for non-call turns.
        if not self._call_uses_codex:
            call_kwargs = dict(kwargs)
            call_kwargs["model"] = self.config.call_model
            generation = self.call.generate(**call_kwargs)
        elif kwargs.get("model") == self.config.call_model:
            if self._call_uses_codex:
                generation = self.codex.generate(**kwargs)
                self._active_model = generation.model
                return generation
            emitted_token = False
            on_token = kwargs.get("on_token")

            def track_token(token: str) -> None:
                nonlocal emitted_token
                emitted_token = True
                if on_token is not None:
                    on_token(token)

            call_kwargs = dict(kwargs)
            if on_token is not None:
                call_kwargs["on_token"] = track_token
            try:
                generation = self.call.generate(**call_kwargs)
            except ModelError as exc:
                if emitted_token:
                    raise
                logger.warning(
                    "%s call generation failed; preserving the configured call route: %s",
                    self.call.provider_name,
                    exc,
                )
                raise
        else:
            generation = self.codex.generate(**kwargs)
        self._active_model = generation.model
        return generation

    def close(self) -> None:
        self.codex.close()


def create_backend(config: ModelConfig, usage: UsageTracker | None = None) -> ModelBackend:
    if config.provider.strip().lower() in {"groq", "xai", "lithos"}:
        primary = OpenAICompatibleBackend(config, usage)
        if (
            config.provider.strip().lower() == "lithos"
            and config.call_fallback_provider
            and config.call_fallback_model
        ):
            default_endpoints = {"cerebras": "https://api.cerebras.ai/v1"}
            default_keys = {"cerebras": "CEREBRAS_API_KEY"}
            fallback_provider = config.call_fallback_provider.strip().lower()
            fallback_config = replace(
                config,
                provider=fallback_provider,
                endpoint=config.call_fallback_endpoint or default_endpoints.get(fallback_provider, ""),
                api_key_environment_variable=(
                    config.call_fallback_api_key_environment_variable
                    or default_keys.get(fallback_provider, "MODEL_API_KEY")
                ),
                primary=config.call_fallback_model,
                fallback="",
                reasoning_effort=config.call_reasoning_effort,
            )
            return ProviderFallbackBackend(
                primary,
                OpenAICompatibleBackend(fallback_config, usage),
                model=config.call_fallback_model,
            )
        return primary
    if config.provider.strip().lower() == "codex_app_server":
        return CodexAppServerBackend(config, usage)
    if config.provider.strip().lower() in {"hybrid_codex_xai", "hybrid_codex_call"}:
        return HybridCodexCallBackend(config, usage)
    raise ModelError(f"Unsupported model provider: {config.provider!r}")
