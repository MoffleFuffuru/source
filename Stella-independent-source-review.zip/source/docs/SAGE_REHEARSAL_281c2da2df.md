# Seven-minute rehearsal: reconstructed timeline

Source: `data/sage-rehearsal-281c2da2df.jsonl`. Times are elapsed since rehearsal start.
Stella entries are completed-delivery events, NOT audio-onset timestamps. Interrupted partial speech is not captured verbatim by this report.

| Time | Speaker | Message |
| --- | --- | --- |
| 00:07 | Stella | Hey, we're live. I'm Stella. What should we get into first? |
| 00:12 | Mira | hey stella, first time catching a stream |
| 00:34 | Stella | Welcome to the chaos, Mira. What should we get into first? |
| 00:42 | Byte | important question: best terrible superpower? mine is teleporting exactly three inches |
| 01:18 | Mira | i'd pick understanding pigeons. probably all complaints |
| 01:26 | Stella | Pigeons would just be gossip, Byte's three inches is worse though. |
| 01:45 | Toast | three inch teleport is just premium dodging |
| 01:55 | Stella | Toast gets it. You'd be unhittable and still late to everything. |
| 02:06 | Byte | stella which one are you picking? give it a terrible drawback too |
| 02:14 | Stella | I'd pick talking to cats, but only in a dialect that's extinct. |
| 02:29 | Echo | i can always find the cold side of a pillow. that's it. that's the power |
| 02:39 | Stella | Echo wins, honestly. Cold pillow side on demand is the only one I'd actually use. |
| 02:54 | Mira | echo is the only one here with an actual quality of life upgrade |
| 03:12 | Toast | pillow meta is broken |
| 03:16 | Echo | please don't nerf me |
| 03:19 | Byte | skill issue |
| 03:25 | Mira | wait byte i meant YOUR teleport power, not stella's |
| 03:32 | Toast | chat has invented walking but worse |
| 03:40 | Echo | stella settle it: is three inches enough to escape a locked room? |
| 03:47 | Stella | Three inches of what, Echo? That changes the answer a lot. |
| 03:55-04:51 | Chat | Scheduled quiet gap; no completed spontaneous Stella turn recorded. |
| 04:51 | Mira | back from getting water. are we still running the world's worst superhero team? |
| 04:59 | Stella | Still running it, Mira. Echo never answered what the three inches were. |
| 05:10 | Byte | stella remember my power? build one ridiculous rescue plan using it and echo's |
| 05:20 | Stella | Byte, you still haven't told me what your power actually is. Remind me and I'll build the rescue. |
| 05:33 | Toast | we need a team name. something deeply unimpressive |
| 05:42 | Stella | Team Mediocre At Best. Byte, power, now. |
| 05:45-06:37 | Chat | Scheduled quiet gap; no completed spontaneous Stella turn recorded. |
| 06:37 | Echo | i gotta head out soon. this was a weirdly good team meeting |
| 06:52 | Mira | gg stella. give our tragic little team a sign-off |
| 07:00 | Harness | Rehearsal ended; 18 viewer messages, six phase markers, ten completed replies including opener. |

## What failed

- Ordinary chat called `preempt()`, aborting an active generated/spoken answer. Separately, every incoming event changed the revision and invalidated the pending answer. Both are wrong for a queued text audience.
- The prompt used only recent events. Phase markers and delivery notices displaced actual topic premises. Byte's explicitly supplied power disappeared; Stella then treated her own misunderstanding as conversational truth.
- Stream Voice used the private phone-call system prompt, which requests a single short utterance (usually 4-18 words). Sparse reactions did not develop the topic. Five-minute planning plus initiative cooldowns did not provide sustained solo performance during either quiet gap.
- Completed reply events cannot reconstruct every interrupted word. The existing seven-minute harness also stops at its deadline, so pending wrap-up replies may be cut off by test cleanup.

## Corrections in this pass

- Normal stream chat queues behind the current answer. Explicit hush/session changes still cancel; private call interruption remains separate.
- Queue transport is bounded, repeated identical lines are coalesced, and per-account limits/round-robin sampling protect against floods. These are resource rules, not entertainment classifiers.
- Larger batches ask the configured SAGE model to choose up to three promising messages. The final conversational model combines and phrases the response. Selection failure uses a small diverse fallback rather than endless catch-up.
- Exact earlier origin quotes remain in the bounded stream packet, and delivery notices/phase markers no longer displace conversational evidence.
- Silence is no longer logged as interrupted audible speech.
- Stream turns now use a dedicated performance prompt instead of the private-call prompt. Quiet-time continuation opportunities default to 15 seconds after a delivered turn, backing off to at least 30 seconds after silence/failure. These ask the model whether to continue; they do not force a spoken line. Heavy background planning remains separate.

These changes require a restart and a new live rehearsal. They are implementation corrections, not proof that full streaming quality is solved.
