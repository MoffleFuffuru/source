# Great Sage integration

## What is connected

- `mako/sage/runtime.py` and `mako/sage/host.py` connect SAGE to Discord, desktop text, active pipeline app calls, and a local streaming event bridge.
- Exact speaker-labelled events, intentions, relationship observations and commitments persist in `data/great_sage.sqlite3` using SQLite WAL. Scopes separate guilds, channels and transports.
- Background planning proposes evidence-backed topics. Stella's conversational model still chooses whether to speak, whom to address and what to say. No scripted ordinary replies or social-classifier veto was added.
- Admission checks protect a human-held floor, explicit quiet requests and in-flight speech. New human contributions invalidate speculative planning and cancel autonomous speech.
- Discord and desktop host adapters share the same executive admission, planning lock, budget and persistent store. Planning reviews are normally at least 300 seconds apart per scene, globally limited to two planning jobs per minute and one concurrent job. Spontaneous initiatives require 12 quiet seconds, 90 seconds since the last initiative, and at most three initiatives per ten minutes. Actual new stream chat uses the foreground response path, not the five-minute creative-review cadence.
- Quiet reflection may revisit established material after two review intervals. It is not an always-running inference loop.
- Temporary initiative context is bounded to 1,600 characters and retains the normal personality/schema. Recent shared transcript context is bounded to 4,000 characters; legacy summary-board context is not used.
- Autonomous generation and memory maintenance do not hold the live conversation model lock. Background planning uses a separate client configured from `memory_model`; this does NOT guarantee independent capacity at the provider.
- Discord text now handles configured direct-response channels, retries a transient generation failure once, visibly reports a final failure, deduplicates incoming messages and commits a normal reply only after Discord accepts delivery.
- Interrupted speech uses consumed output PCM plus provider character alignment when available. Without alignment it records an interruption with unknown exact words rather than treating the whole generated draft as heard. Client PCM consumption cannot prove what a remote listener heard.
- Captured idle retains hips, spine, legs and translation. Deliberate overlays affect only shoulders/arms/hands, with additive head/neck gaze.
- Desktop initiative is text-only outside a call. Active pipeline calls use the existing voice engine; no microphone/call is started by SAGE. Partial app-call transcripts preempt autonomous output when the existing STT path delivers them. Existing playback-time microphone muting is not replaced by an echo-cancelled full-duplex implementation.
- Stream sessions default to text output unless local voice is explicitly selected before starting. Stable `stream:local:main` identity retains public relationships and plans across sessions; private calls take priority and cannot route private context into stream output.
- Commitments support evidence-backed status updates, timezone validation, daily/weekly recurrence, one-shot reminder tracking, expiration and shared-participant conflict detection. Ambiguous and nonexistent local DST times are rejected rather than guessed.

## Current model routing

- Calls: `deepseek-ai/DeepSeek-V4.1-Flash-ultra-chat`, reasoning `none`.
- Text: `deepseek-ai/DeepSeek-V4.1-Flash-ultra`, reasoning `low`.
- Memory client: separately configured Ultra. SAGE planning uses no reasoning for voice scenes and low reasoning for text scenes.
- HTTP 429/502/503/504 and transport failures suspend optional background work for 60 seconds. Foreground service capacity remains outside Stella's control.

## Owner controls

Use `!sage on`, `!sage off`, `!sage status` or `!sage review` in an allowed Discord channel as the configured owner. Ordinary explicit voice stop commands still stop output while listening continues. SAGE is enabled in the current config; restart Stella to load source/config changes.

The desktop Great Sage panel provides master on/off, quiet/resume, review, stream start/stop and optional stream voice. Stream voice selection applies when starting a session. Private desktop initiative pauses after twenty minutes without owner activity. The master off control cancels autonomous Discord output too.

## Streaming adapter contract

Platform hookup is intentionally deferred at the user's request; no Twitch/YouTube account or channel was selected.

1. Run `tools/Initialize-SageEvents.ps1` once to create a random, separate Windows-user adapter key. It does not print the secret or use the Lithos key.
2. Restart Stella and choose START STREAM in Great Sage. Starting a session does not start the microphone.
3. An adapter POSTs JSON to `http://127.0.0.1:39541/api/sage/event` with `Authorization: Bearer <STELLA_SAGE_EVENT_KEY>`.
4. Required fields: `id` (stable platform event ID), `actor_id` (stable namespaced account ID), `name`, `kind` and `text`. Kinds are `chat`, `join`, `leave`, `screen`, `game`, `event`. Join/leave may omit text. Screen/game descriptions are supplied observations, not automatic screen capture or trusted instructions.
5. Poll `GET /api/sage/stream?after=<cursor>` using the same authentication. Advance to `last`; forward only returned `sage_stream_reply` events. This endpoint filters out private desktop messages and other scopes. It is not a durable delivery acknowledgment or a platform reconnection service; the existing event ring retains 256 events.

`tools/Send-SageEvent.ps1` is a ready-to-use local publisher, for example:

```powershell
.\tools\Send-SageEvent.ps1 -Id demo-1 -ActorId demo:viewer -Name Viewer -Text 'How are you doing?'
```

Local owner controls use `/api/sage/control` with `action` set to `on`, `off`, `review`, `quiet`, `resume`, `stream_start` or `stream_stop`; stream_start optionally takes `voice: true`. The API binds to loopback and rejects remote/opaque browser origins. Do not expose its control port to the internet.

## Verification

Run from the Stella V5 directory:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests
node --test --test-isolation=none avatar/tests/*.test.cjs
```

All 210 Python tests and 14 avatar tests pass. Coverage includes real-core lock isolation and temporary prompt reset, model-selected silence, failed speech not committed as delivered, cancelled queued speech, cross-scope privacy, authenticated HTTP input and filtered public output, timezone recurrence, stable history ordering under identical timestamps, and real VRM lower-body preservation.

The four older discovery failures were stale fixtures/assertions, now corrected without modifying app-call timing: use complete config fixtures, pass a timestamped CompletedTurn object, expect the existing immediate completed-turn delivery instead of removed deferred/classifier joining, and use a genuinely longer timing sample above the three-second minimum reading floor. The old forced-response test now asserts that tracker hints do not force participation.

## Boundaries for the next validation pass

- No unattended live microphone/call test was started. Provider inference remains subject to the observed Lithos capacity errors and long first-token delays.
- Desktop/app-call execution is now integrated. A platform-specific Twitch/YouTube chat connector remains intentionally unconfigured. No automatic screen capture, unrestricted computer control, or external booking action was added.
- Commitment extraction is model-based and evidence-referenced, not proof that the model understood an agreement correctly. Confirmed records need a date, timezone validation and source references. Existing state transitions need fresh evidence. No external booking/calendar action is performed.
- Existing RMA storage was not wiped or migrated. No GPT-OSS process or legacy summary-maintenance scheduler was enabled by this integration.
- Test live human interruption during planning, generation and playback; explicit quiet requests; channel/guild separation; stale delivery rejection; disconnects; provider failures; and longer quiet periods before enabling an unattended stream.
- Check actual speech-provider alignment availability. Never replace unavailable alignment with guesses presented as exact heard words.
- The requested later 100-iteration adversarial validation campaign has not been performed in this implementation pass.
