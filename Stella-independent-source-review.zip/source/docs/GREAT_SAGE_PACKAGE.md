# SAGE — Stella Autonomous Generative Executive

**Deliverable:** installable-by-copy Python foundation, 17 modules, tests, and integration notes. **This is an operational scaffold, not a fully integrated or trained AI autonomy system.** The archive includes no Stella source files, VRM assets, API keys, trained classifiers, or vendor SDKs.

## Installation

Copy `mako/sage/` into Stella's existing `mako/` Python package. **Do not replace `mako/__init__.py` or existing files.** Standard library only, Python 3.11+ (Stella's Python 3.12 is suitable).

Run tests from this extracted folder with `python -m unittest discover -s tests -v` (works with implicit namespace `mako`). In Stella's repository, run after adding the `mako/sage` folder and tests.

## Wiring (Codex integration checklist)

1. Instantiate `SageExecutive()` once in the application's existing core lifecycle. Do not start a second independent autonomy loop.
2. Map existing Discord/voice/chat/turn events to `Event(EventKind.*, actor_id=stable_account_id, ...)`. Use **real speaker-end / floor-available signals**, not guessed silence alone. Mark `turn_finished=True` in event data for final STT/chat turns.
3. Connect RMA through `MemoryAdapter(search=...)` returning **verified** `MemoryEvidence` with IDs, visibility, confidence, and actor identity. RMA evidence must come from the active retrieval path, not cached summary-board files.
4. Integrate `SageExecutive.try_autonomous_turn(floor_available=...)` into the **existing** autonomous-turn admission point. It returns `(intent_id, optional_prompt_packet)`, never speaks itself. Supply the packet to the normal DeepSeek conversation turn only after rechecking floor availability and cancellation. Call `confirm_speech_started()` only once the turn is admitted; call `complete_turn()` when finished/cancelled. Do not inject packets into ordinary user turns.
5. Wire the existing BodyController's semantic-intent transport to the JSON envelope from `EmbodimentDirector.set_intent()`. **The JS renderer still needs a matching consumer and animation arbitration logic.** No skeleton/bone animation implementation is included in this Python-only deliverable.
6. Connect creative generation by providing a background callable to `sage.creative.generator`, guarded with `sage.budget.acquire()/release()`. No default model calls. Candidate text is untrusted and must not become facts.
7. Use `SageStore` for opt-in persistence; never store private transcripts or credentials in it. Use encrypted/restricted storage if necessary. Reconcile persisted intents with the current conversation and RMA before acting after restart.
8. Enable `InitiativeConfig(enabled=True)` **only after** testing; disabled is the safe default. Also ensure existing `mako/proactive.py` and Discord autonomy do not both initiate the same turn.

## Example (no speech will occur until explicitly enabled)

```python
from mako.sage import SageExecutive, Event, EventKind, Intent, InitiativeConfig
sage = SageExecutive(config=InitiativeConfig(enabled=False))
sage.publish(Event(EventKind.USER_JOIN, actor_id='discord:123'))
sage.queue(Intent('Ask about the game we discussed', evidence_ids=['episode:4821']))
# Host calls sage.try_autonomous_turn(floor_available=True) when appropriate.
```

## Important limits

- The temporal ledger enforces basic transition rules, but does **not** automatically parse natural-language dates, handle ambiguous DST folds, or send invitations. Those require further integration and confirmation UX.
- The relationship engine is an evidence-linked fact store, not a trained social intelligence model.
- The creative studio is an adapter for an optional model, not a bundled LLM.
- The motion director emits **semantic instructions**, not bone-level animation. JS motion arbiters/gesture libraries are separate work.
- The Python-only package does not claim to meet latency targets until tested with Stella's actual runtime.
- Production deployment should add concurrency protection (event-loop ownership or locks), persisted deduplication, prompt-injection filtering for external chat/model suggestions, retention policies, and soak/regression tests.
