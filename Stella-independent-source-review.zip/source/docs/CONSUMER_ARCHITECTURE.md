# Stella V5 Consumer Architecture Map

Status: engineering/test build, not a consumer release. Last reviewed 2026-10-06.

## Existing systems to retain

- **Conversation and memory:** `mako/` contains the existing Stella/Mako core,
  prompt assembly, durable memory, and text/call orchestration. Preserve behavior
  and memory data formats while separating provider transport from the core.
- **Inference:** Qwen through Cerebras is the current primary path. Existing
  provider configuration and fallback hooks should remain behind a provider
  interface; the desktop client must not ship provider credentials.
- **Voice:** the existing app-call, ElevenLabs STT/TTS, Inworld options, device
  selection, and audio processing remain in the runtime. Local dependencies and
  licensed/model assets must be inventoried before packaging; do not assume a
  Python virtual environment is relocatable.
- **Avatar:** `avatar/` is the Electron/Three.js/VRM presentation shell. Keep its
  motion director, VRMA assets, and local body-signal bridge independent from
  conversation and billing failures.
- **Configuration and runtime:** `main.py` starts the local shell API consumed
  by Electron. `config.json` and `data/` contain machine/user state and must not
  be copied into a clean customer profile or release artifact.

## Current account-service slice

- `backend/stella_backend/` is a FastAPI account-service prototype, launched by
  Electron on loopback. It currently provides local signup/login, UUID account
  IDs, scrypt password hashes, revocable sessions, a 50-credit trial ledger,
  usage summaries/quotes, admin account search, audited credit adjustments,
  and permanent account deactivation.
- Electron stores its session token using OS-backed safe storage and shows
  account/usage status in the Settings area.
- The account service binds locally by default. It is not a public multi-user
  service and must not be exposed to the internet as-is.
- It does **not** yet authorize or proxy Cerebras/ElevenLabs calls, settle real
  provider usage, charge credits for live requests, integrate hosted checkout or
  verified billing webhooks, or provide production email verification/MFA,
  hosted TLS, operational backups, or account recovery.

## Consumer-build removals and isolation

- Hide diagnostic controls, raw provider/model knobs, movement labs, benchmark
  tools, test databases, development logs, and personal owner memory from the
  normal customer build. Keep developer-only tools behind an explicit build
  profile rather than deleting useful engineering code.
- Create a first-run profile with fresh memory and configuration. Never bundle
  the owner's `config.json`, `data/`, account database, logs, API keys, or saved
  session token.
- Keep app-call and text state private to the signed-in local profile; do not
  upload conversation or memory content for credit accounting.

## Required refactors and service boundaries

1. **Desktop client:** Electron owns windows, OS-secure session storage, local
   audio device selection, and a narrow authenticated API client. It contains no
   Cerebras, ElevenLabs, Paddle, or admin secrets.
2. **Local companion runtime:** retains memory, prompt assembly, tool routing,
   voice device I/O, and avatar telemetry. For commercial mode, it requests
   inference from the authenticated service and reports provider usage only as
   returned by that service. Local developer mode may retain direct provider
   adapters but must be a separate, visibly non-commercial build.
3. **Hosted application API:** owns identity, sessions/devices, entitlements,
   rate limits, remote config, inference proxy, actual usage capture, credit
   ledger settlement, and audit events. Provider keys exist only in its secret
   store. Client-supplied cost, token counts, plan, or balance are never trusted.
4. **Billing service:** hosted Paddle checkout and customer portal, signed and
   idempotent webhooks, subscription/quota grants, refunds, and auditable
   purchased/bonus balances. Do not accept card data in Stella.
5. **Admin dashboard:** separate authenticated web surface with RBAC/MFA,
   account search/actions, plan/price/quota configuration, unit economics,
   audit log, provider health, and release/feature-flag controls.
6. **Update service:** stable/beta metadata, signed manifests and binaries,
   staged rollout, required/optional updates, rollback, and release notes. Remote
   configuration can change validated settings but cannot execute arbitrary
   code on the desktop.

## Data model direction

Keep account identity separate from authentication. Use UUIDv7 (or another
non-sequential random public ID), normalized email identity, password hash or a
trusted identity provider, revocable hashed sessions, account status, device
records, subscription entitlement, feature entitlements, and billing customer
ID. Make the append-only credit ledger authoritative: trial, subscription,
purchase, bonus, inference charge, refund, and admin adjustment events. Enforce
idempotency and balance changes transactionally. Preserve purchased credits
across subscription renewal; configure consumption order centrally.

Usage events should record request ID, account ID, provider/model, input/output
usage, audio characters/seconds, measured provider cost, credit charge, latency,
and success/refund state. Do not store prompt or transcript content in this
ledger. Reconcile provider-reported usage before charging; failed requests that
produce no useful output follow an explicit no-charge/refund rule.

## Release sequence and gates

1. **Local test vertical slice:** stabilize launcher/boot, tests, onboarding,
   local account/ledger/admin UX, and visible non-production status. This slice
   must never claim that provider usage is charged when it is not.
2. **Provider gateway:** authenticate requests, reserve credits idempotently,
   call Cerebras and ElevenLabs server-side, stream output, reconcile measured
   usage, and compensate failed/cancelled requests. Add contract tests without
   requiring production API keys.
3. **Hosted accounts and billing:** deploy TLS-backed API/database, email
   verification/recovery, session/device revocation, admin RBAC/MFA, Paddle
   checkout/portal, signature-verified idempotent webhooks, backups, rate limits,
   abuse controls, and operational monitoring.
4. **Consumer client:** replace the developer console with Chat, Memory,
   Apps/Tools, Account, Usage, Settings, and About/Updates; use understandable
   controls and preserve memory/privacy boundaries.
5. **Windows release:** bundle the supported Python runtime and all required
   speech/model/runtime assets, create an installer/uninstaller and shortcuts,
   verify clean-machine startup and complete shutdown, sign the application and
   update manifests, and test upgrade/rollback. The current folder and launcher
   are not yet this release.

## Explicit release blockers

- No hosted provider proxy or actual provider-usage credit settlement.
- No production account deployment, billing integration, email verification,
  MFA/RBAC hardening, backup plan, or remote configuration service.
- No signed update manifest/service or automatic updater.
- No reproducible Windows installer/build pipeline or clean-machine test.
- Current UI still exposes developer-oriented inference/voice controls, and the
  root README describes an older Mako V4 build.

Do not distribute the present development folder as a commercial installer.
