# Stream Memory Review

Reviewed: 2026-10-16, manually by Codex.

## Scope

The owner authorizes private app calls, Discord calls and texts to be inspected
for public streaming excerpts. Preserve ordinary warmth, jokes and ambiguous
friendly exchanges. Exclude actual romantic disclosures or material that would
meaningfully reveal that relationship. Do not publish third-party private details.
The only permitted on-stream name for the creator is **moffle**.

## Current Status

The initial set contains 52 manually selected, source-referenced excerpts.
Every referenced episode/concept was checked against the archive. This is NOT
a completed review of all 4,124 owner-labeled episodes or all Discord history.
Unreviewed source records are pending, not denied or deleted.

`data/stream_memory_approved.json` is the local approval record. Its `approved`
array contains the only historical owner excerpts exported to SAGE streams.
Its policy and withheld examples are audit information, not model context.
Approving an excerpt does not approve its raw neighboring messages.

## Integration

- SAGE stream planning and reply generation use `StreamMemory`.
- A small selection rotates across turns and also ranks by topic relevance.
- Approved creator identity is included alongside the selected excerpts.
- Missing/invalid approval data yields no archive access, not a private fallback.
- Ordinary private calls/texts keep their existing memory path unchanged.
- Source records are not deleted, rewritten or globally relabeled public.
- Newly stored private memories require contextual review before stream export.

The existing live stream timeline still supplies actual chat and delivered public
speech. The reviewed excerpt system governs access to historical owner memories;
it is not a guarantee that the conversational model cannot make a factual mistake.
