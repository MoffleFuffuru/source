# Cartesia Sonic 3.6

- Backend value: `cartesia_tts`.
- Model: `sonic-3.6`.
- Voice: configured in `voice.cartesia_tts_voice`.
- Language: `en` (English).
- Key: Windows user environment `CARTESIA_API_KEY`; never stored in config or logs.
- API: https://docs.cartesia.ai/api-reference/tts/bytes
- Version header: `2026-10-17`.

Desktop calls, SAGE speech, Discord voice, and WAV rendering share the streamed
24 kHz mono signed 16-bit PCM transport. Incremental call clauses use sequential
HTTP requests; they are not yet a single persistent Cartesia WebSocket context.
Lip sync follows actual audio energy. Existing generation cancellation and
delivery receipts remain in control. No automatic provider fallback/replay is
enabled for Cartesia, especially after partial playback.

Cartesia currently does not supply alignment to the Discord word tracker through
this transport; exact word-level interruption tracking is unavailable here.

Setup: run `tools/Initialize-Cartesia.ps1` in PowerShell. Select Cartesia in the
Speech Engine setting after the key is present. Speech recognition is unchanged.

Verification: 39 targeted Python/UI tests passed. After the owner saved the key,
live Sonic 3.6 synthesis with the configured voice and English returned 138,240
valid PCM bytes (2.88 seconds). Cartesia is now selected in config.json.
No microphone call was started during this verification.
