# Stella Movement System

## What it does

The renderer now runs a motion director alongside the existing VRM and body-signal path. It loads the standing Rocketbox VRMA family, retargets the clips onto the active VRM, keeps a full-body idle underneath, and layers separate listening and speaking motion over the upper body. It crossfades between base clips, smooths upper-body joints at bounded speeds, and retains the source finger tracks. Upper arms are held near the family's hanging rest pose during idle; deliberate one-shot actions can move them outside that envelope. Lower-body animation remains sourced from the full-body VRMA clips.

Conversation phases are idle, listening, anticipation, speaking, and settle. Speech level drives mouth movement and small chest accents; the dialogue response's expression and gesture select the speaking face and one-shot. The idle gaze wanders gently, follows slow cursor movement with a speed cap, and ignores abrupt cursor crossings. Gestures are chosen when a conversational response calls for one; waves and celebrations are not injected into idle.

## Interface reactions

Changing a control sends a local visual reaction immediately. Discord being switched off applies a restrained pout, a lowered chin, a small shoulder draw, and an annoyed expression. The existing Qwen dialogue path receives a clearly marked system/interface event, not fabricated user speech, and generates a brief in-character line. When the line begins, the facial intent and speaking motion blend over the held reaction. Re-enabling Discord maps to a pleased/warm reaction. The other current controls have bounded glance or posture reactions; routine sliders and settings do not generate spoken comments.

Comments wait for active speech/model work to finish and rapid setting changes are coalesced. A live desktop call can admit the comment between turns. The existing XAI full-duplex call path cannot accept an external Qwen turn, so its interface reaction remains visual. Discord voice audio reports playback level to the body controller and clears the speaking state when the turn ends.

## Motion source and licensing

The project includes 38 standing VRMA clips under `avatar/assets/movement/`. They provide four idle variants, three listening variants, three speaking variants, and deliberate nod, shake, wave, shrug, thinking, laugh, happy, relaxed, sad, and angry actions. The downloaded clips have 53 humanoid tracks apiece, including 30 finger tracks. Provenance, hashes, and the upstream conversion plan are recorded in `avatar/assets/movement/sources.json`; the source notice and MIT license are beside the files.

The clips are converted Rocketbox animations distributed in the [Hanami repository](https://github.com/Undi95/Hanami), pinned at commit `6787685c8d40e4e79bffbb0d389b478f32ef88d6`. The original character and animation source is [Microsoft Rocketbox](https://github.com/microsoft/Microsoft-Rocketbox), pinned at commit `0943055db6ec570bcef9f2c8b41c9e5467c808f9` and licensed under MIT. Adobe Mixamo was reviewed as another potential library; Adobe's [Mixamo FAQ](https://helpx.adobe.com/creative-cloud/faq/mixamo-faq.html) describes its royalty-free use terms, but importing clips from a different rig family now would complicate retargeting and transition quality. This first pass stays within one compatible standing family.

## Preview and verification

The offline preview is open at `http://127.0.0.1:39545/index.html?movementLab=1`. Expand **Movement Preview** to try idle, listening, speaking, each semantic action, and the UI-reaction mappings. Its Discord control is simulated: it makes no model request, opens no microphone, and contacts no Discord service. The main viewer still supports `?movement=legacy` as a reversible fallback.

Focused verification: seven renderer tests pass, including retargeting all clips on Mako's rig, finger articulation, leg preservation during upper-body gestures, bounded head speed, anticipation before audio, and no repeated gesture on duplicate packets. Five interface tests pass for event wording, call-prompt routing, coalescing, non-spoken settings, and gesture validation. Modified Python modules compile successfully.

## Limits and next work

This is a conversation-safe standing motion system, not a general human-pose generator. It composes a curated repertoire of standing clips and six procedural pose accents; it does not solve arbitrary reaching, sitting, walking, hand-to-object contact, or foot planting with inverse kinematics. Cursor attention is head and neck only. Some source idle clips retain their authored timing and subtle cyclic rhythm. The camera auto-frames the model's skinned bounds, but unusual custom VRMs may need per-model framing calibration.

The next useful increment is to add measured interaction-specific actions after observing Stella in the live app: richer low-amplitude hand/finger rest variation, a true cursor target sampled from desktop regions, and contact-aware overlay poses only if the intended UI behavior is clear. Reuse the semantic tags and blending path instead of adding another independent animation player.
