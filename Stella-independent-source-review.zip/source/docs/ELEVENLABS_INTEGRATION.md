# ElevenLabs first integration - 2026-09-30

## Active configuration

This is the Downloads/Stella V5 copy launched by Start Mako with Avatar.bat.
Restart that app to pick up the code and settings. No other Stella copies changed.

- Primary STT: scribe_v2_realtime, PCM16/16kHz, server VAD, 0.45-second silence setting.
- Primary TTS: eleven_v4_turbo, Text to Dialogue WebSocket, mono PCM16/24kHz.
- Voice: Stella, TaAj41g1TDT9zKVixsDm. Account voice listing and synthesis verified.
- Keyterms: Stella, Ghoul, Moffle, War Robots. Editable in the UI; at most 50 terms, each at most 20 characters. No forced transcript replacements.
- Credentials: ELEVENLABS_API_KEY from process environment or Windows user Environment registry. No key stored in source/config/logs.
- Inworld is retained as startup-STT fallback and pre-audio TTS fallback. Partial speech is never replayed through fallback.
- Independent vocal context selector: off by default; optional Inworld transcription sidecar.

## Ownership and lifecycle

Scribe committed_transcript alone creates an authoritative input. Partial, timestamp, and edited-transcript events cannot create a second reply. Scribe VAD owns endpointing; older Discord endpoint timers are bypassed for Scribe. Network gaps receive real-time silence, not a large manufactured pause. Reconnect discards old queued audio. Two reconnect attempts are allowed; failure reports an error and requires a new call.

Desktop TTS accepts coherent clauses from the existing model token callback. Short final replies flush immediately; incomplete text flushes after 180ms without another chunk. Each reply owns its TTD socket; keepalive messages cover pauses while waiting for text, and close_socket flushes the tail. Existing model, prompts, memory and other endpoints are unchanged except enabling the existing call_streaming_tts switch.

Playback cancellation invalidates queued desktop replies, closes synthesis, and discards remaining audio. Desktop microphone suppression and Discord admission/interruption policy are retained, not redesigned. This older V5 Discord policy still declines replies while another generation owns the guild turn. This integration does not add the later V4 conversational barge-in policy.

Discord input is isolated by guild/member, with at most eight simultaneous speaker streams, five seconds of startup input buffering, and retirement after 30 seconds without audible input. Disconnect/cleanup closes those streams. Discord audio consumes 20ms/48kHz/stereo frames, uses an 80ms prebuffer, supplies silence rather than blocking on network gaps, and pads the last frame. Discord currently starts TTS after its existing full-model-result callback, rather than streaming model tokens. Returned TTS audio streams immediately.

Optional Inworld analysis requires a second transcription stream and extra provider usage. It never supplies authoritative text. Only an exact normalized transcript with the same commit ordinal and a recent, unused profile can attach; late, conflicting, or differently segmented profiles are omitted without delaying the reply. This is conservative best-effort metadata, not a guaranteed profile for every turn. After Scribe reconnect, the sidecar stays disabled until the next call to avoid stale associations.

## Measured tests

Live account tests passed after API permissions were updated. Models Read lists eleven_v4_turbo. The production transports synthesized the following and replayed the PCM through Scribe, without opening a microphone:

| Case | First received TTS PCM | Audio duration | Scribe result |
| --- | --- | --- | --- |
| Yes. | 0.625s | 0.96s | Yes. |
| Stella, Moffle and Ghoul play War Robots. | 0.344s | 3.52s | Stella, Moffle, and Ghoul play War Robots. |
| The kettle is on the kitchen counter. I'll meet you by the front door. | 0.375s | 3.92s | Both sentences correct, committed separately at the spoken pause. |

The first two VAD commits arrived 0.390s and 0.141s after the final supplied audio chunk. The third case committed its first sentence before all audio had been supplied, so treating that timestamp as whole-utterance latency would be misleading. VAD is silence-based rather than semantic: increase the exposed silence setting if natural pauses cause premature turns. These are tiny synthetic-audio observations, not an accuracy benchmark.

A separate direct-protocol Stella probe returned first PCM in 0.359s and an exact keyterm transcript 0.110s after manual commit. These are network/transport timings, NOT measured microphone-end-to-first-audible-response latencies. Actual Windows output, real microphone speech, long real conversations, echo behavior, live Discord playback and network recovery still need a user call. Playback-start timestamps are logged for that check.

16 new offline tests pass: keyterm validation, no duplicate timestamp commits, muted/stopped input rejection, clause order and long text, cancellation, fragmented PCM, provider errors, STT startup fallback, reconnect queue clearing, speaker isolation, Discord silence/EOF behavior and cleanup. Python compilation, viewer JavaScript syntax, config loading and existing Inworld unit tests also pass.

Legacy test_voice.py has two failures (CompletedTurn fixture missing endpointed_at; dangling-clause expectation differs from existing behavior). test_call.py has one failure (FakeCore lacks config.voice). Those paths/fixtures were not repaired in this task. Do not interpret this as a fully green application test suite.

Run local tests: .venv\Scripts\python.exe -m unittest discover -s tests -p test_elevenlabs_voice.py -v

Run a paid production-transport smoke: .venv\Scripts\python.exe tools/test_elevenlabs_pipeline.py

## Cost and references

Checked September 30, 2026. The API pricing page lists v4 Turbo at $0.011/1,000 characters promotional through October 12 (regular displayed price $0.04/1,000), and Scribe Realtime at $0.39/hour. The realtime API reference specifies a 20% keyterm premium: approximately $0.468/hour at that base rate. The pricing FAQ also mentions a $0.05/hour keyterm charge in its general STT wording; account billing is authoritative where published wording differs. Multiple simultaneous speaker streams, streamed silence, and optional Inworld sidecars increase usage. No account-specific bill was measured.

- https://elevenlabs.io/pricing/api
- https://elevenlabs.io/docs/api-reference/speech-to-text/v-1-speech-to-text-realtime
- https://elevenlabs.io/docs/eleven-api/guides/how-to/speech-to-text/batch/keyterm-prompting
- https://elevenlabs.io/docs/eleven-api/guides/how-to/websockets/realtime-tdd
- https://docs.inworld.ai/stt/voice-profiles
