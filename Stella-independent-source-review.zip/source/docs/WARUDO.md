# Stella + Warudo Prototype

## Runtime split

Stella's existing STT, LLM, memory, and TTS paths are unchanged. Warudo is only
the renderer and body-language layer:

* VMC/OSC on `127.0.0.1:39539`: continuous blink, real TTS audio-envelope lip
  movement, and low-level expression blendshapes.
* Warudo WebSocket on `127.0.0.1:19190`: discrete intent events from the
  `Stella Event Bridge` Playground node.

The event payload is:

```json
{"emotion":"annoyed","intensity":0.7,"gesture":"small_shake","look_at_user":true}
```

The bridge is deliberately asynchronous. An unavailable Warudo channel cannot
delay or break a call.

## One-time Warudo setup

1. Start Warudo and select **Basic Setup -> Get Started**.
2. Choose `Stella.vrm` from the Characters dropdown.
3. Under motion capture, select **VMC** and leave the receiver port at `39539`.
4. Keep Warudo's idle/breathing/sway animation enabled. Do not enable full-body
   VMC pose tracking: Stella sends only facial blendshapes so Warudo retains
   natural native body motion.
5. In Blueprints, add **Stella Event Bridge**, select the Stella character, and
   connect `HeadShake`, `SmallNod`, and `Wave` to three **Play Character One
   Shot Overlay Animation** nodes. Use short upper-body-only animations.
6. Connect `LookAtUser` to a native Look At node aimed at the active camera.

The node writes its channel ID to `data/warudo-bridge.json`; Stella reads it on
the next body state change. Restarting Warudo renews that channel automatically.

## Expression policy

The node maps warm/amused/playful/excited to `Joy`, annoyed to `Angry`,
concerned/sad to `Sorrow`, and surprised/confused to `Fun`. These are transient
and layer over the VMC face stream. If a VRM's imported expression closes the
mouth, turn off that expression's mouth override in Warudo so lip sync wins.

Fallbacks: relaxed -> neutral, embarrassed -> warm, angry -> annoyed, and
unknown -> neutral. Inworld does not currently return a separate prosody score
to Stella; the existing per-turn acting intensity is used until such metadata is
available.

## Validation and latency

Use: `don't call me bro, it ruins the vibe.` Expected result: an annoyed face,
brief head-shake one-shot, user gaze, and uninterrupted TTS-driven mouth
movement. VMC is sent at 20 Hz, giving a local face-update budget of 0-50 ms
(about 25 ms average); WebSocket intent events run off-thread and add no blocking
latency to STT, model generation, or TTS.

## Limits

The VMC standard carries facial blendshapes safely, but sparse skeletal packets
can force unsupported VRMs into bad poses. For that reason gestures use Warudo's
native overlay animations, not synthetic partial-bone VMC data. Warudo's
Playground node is the only custom code; it uses Warudo's built-in WebSocket
channel and native Character/Blueprint systems.
