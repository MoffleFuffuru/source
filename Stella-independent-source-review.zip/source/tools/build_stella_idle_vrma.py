"""Derive conversation-safe VRM Animation clips from Stella's long VRMA source.

The source is a recorded full-body performance, so this tool preserves only low
amplitude body motion for loops and exports high-amplitude sections separately
for later semantic review. It uses only the standard library to keep the build
reproducible on the Stella machine.
"""

from __future__ import annotations

import copy
import json
import math
import struct
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "avatar" / "assets" / "natural-standing-idle.vrma"
OUTPUT = ROOT / "motion"

# Selected after inspecting per-bone amplitudes over the whole 170s recording.
# The idle regions are deliberately quiet; the gesture ranges stay as one-shots.
IDLES = {
    "stella_idle_rest_a": (16.0, 26.5),
    "stella_idle_rest_b": (20.0, 29.5),
    "stella_idle_rest_c": (145.0, 155.5),
}
ONE_SHOTS = {
    "stella_left_hand_phrase_a": (5.0, 15.0),
    "stella_left_hand_phrase_b": (30.0, 35.0),
    "stella_right_hand_phrase_a": (35.0, 50.0),
    "stella_left_hand_phrase_c": (50.0, 60.0),
    "stella_full_body_phrase": (65.0, 110.0),
    "stella_left_hand_phrase_d": (110.0, 120.0),
    "stella_right_hand_phrase_b": (120.0, 135.0),
    "stella_left_hand_phrase_e": (135.0, 145.0),
    "stella_left_hand_phrase_f": (160.0, 170.0),
}

ARM_REST = {
    "leftShoulder": (0, 0, 0), "rightShoulder": (0, 0, 0),
    "leftUpperArm": (.045, -.28, -1.39), "rightUpperArm": (.045, .28, 1.39),
    "leftLowerArm": (0, 0, .025), "rightLowerArm": (0, 0, -.025),
}


def q_multiply(a, b):
    x, y, z, w = a
    X, Y, Z, W = b
    return q_normalize((w*X+x*W+y*Z-z*Y, w*Y-x*Z+y*W+z*X,
                        w*Z+x*Y-y*X+z*W, w*W-x*X-y*Y-z*Z))


def arm_rest_quaternion(angles):
    x, y, z = (value / 2 for value in angles)
    c1, c2, c3 = math.cos(x), math.cos(y), math.cos(z)
    s1, s2, s3 = math.sin(x), math.sin(y), math.sin(z)
    return (s1*c2*c3+c1*s2*s3, c1*s2*c3-s1*c2*s3,
            c1*c2*s3+s1*s2*c3, c1*c2*c3-s1*s2*s3)


def padded4(data: bytes) -> bytes:
    return data + b"\0" * ((4 - len(data) % 4) % 4)


def load_glb(path: Path) -> tuple[dict, bytearray]:
    raw = path.read_bytes()
    magic, version, total = struct.unpack_from("<4sII", raw, 0)
    if magic != b"glTF" or version != 2 or total != len(raw):
        raise ValueError(f"{path} is not a valid GLB 2 file")
    offset = 12
    chunks: list[tuple[bytes, bytes]] = []
    while offset < total:
        size, kind = struct.unpack_from("<I4s", raw, offset)
        offset += 8
        chunks.append((kind, raw[offset:offset + size]))
        offset += size
    document = json.loads(next(data for kind, data in chunks if kind == b"JSON").decode().rstrip(" \0\r\n"))
    binary = bytearray(next(data for kind, data in chunks if kind == b"BIN\0"))
    return document, binary


def component_count(type_name: str) -> int:
    return {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4}[type_name]


def accessor_values(document: dict, binary: bytes, index: int) -> list[tuple[float, ...]]:
    accessor = document["accessors"][index]
    if accessor["componentType"] != 5126:
        raise ValueError("The source should use float animation accessors")
    view = document["bufferViews"][accessor["bufferView"]]
    count = component_count(accessor["type"])
    fmt = "<" + "f" * count
    stride = view.get("byteStride", struct.calcsize(fmt))
    start = view.get("byteOffset", 0) + accessor.get("byteOffset", 0)
    return [struct.unpack_from(fmt, binary, start + row * stride) for row in range(accessor["count"])]


def q_normalize(q: tuple[float, float, float, float]) -> tuple[float, float, float, float]:
    length = math.sqrt(sum(part * part for part in q)) or 1.0
    return tuple(part / length for part in q)  # type: ignore[return-value]


def q_slerp(a: tuple[float, ...], b: tuple[float, ...], t: float) -> tuple[float, float, float, float]:
    a4, b4 = q_normalize(a), q_normalize(b)
    dot = sum(x * y for x, y in zip(a4, b4))
    if dot < 0:
        b4, dot = tuple(-x for x in b4), -dot
    if dot > .9995:
        return q_normalize(tuple(x + (y - x) * t for x, y in zip(a4, b4)))
    theta = math.acos(max(-1.0, min(1.0, dot)))
    sin_theta = math.sin(theta)
    left = math.sin((1 - t) * theta) / sin_theta
    right = math.sin(t * theta) / sin_theta
    return tuple(left * x + right * y for x, y in zip(a4, b4))  # type: ignore[return-value]


def sample_segment(times: list[tuple[float, ...]], values: list[tuple[float, ...]], start: float, end: float) -> tuple[list[float], list[tuple[float, ...]]]:
    indices = [index for index, point in enumerate(times) if start <= point[0] <= end]
    if len(indices) < 2:
        raise ValueError("Segment has too few source keyframes")
    return [times[index][0] - start for index in indices], [values[index] for index in indices]


def append_accessor(document: dict, binary: bytearray, values: list[tuple[float, ...]], type_name: str) -> int:
    count = component_count(type_name)
    if not values or len(values[0]) != count:
        raise ValueError("Accessor value shape mismatch")
    offset = len(binary)
    binary.extend(b"\0" * ((4 - offset % 4) % 4))
    offset = len(binary)
    for value in values:
        binary.extend(struct.pack("<" + "f" * count, *value))
    view_index = len(document["bufferViews"])
    document["bufferViews"].append({"buffer": 0, "byteOffset": offset, "byteLength": len(values) * count * 4})
    accessor_index = len(document["accessors"])
    accessor = {"bufferView": view_index, "componentType": 5126, "count": len(values), "type": type_name}
    if type_name == "SCALAR":
        scalar_values = [value[0] for value in values]
        accessor["min"] = [min(scalar_values)]
        accessor["max"] = [max(scalar_values)]
    document["accessors"].append(accessor)
    return accessor_index


def write_glb(path: Path, document: dict, binary: bytearray) -> None:
    document["buffers"][0]["byteLength"] = len(binary)
    json_data = json.dumps(document, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    # GLB JSON chunks require space padding; null padding makes JSON.parse fail
    # in Three.js and silently sends the viewer to its fallback idle.
    json_chunk = json_data + b" " * ((4 - len(json_data) % 4) % 4)
    binary_chunk = padded4(bytes(binary))
    total = 12 + 8 + len(json_chunk) + 8 + len(binary_chunk)
    path.write_bytes(struct.pack("<4sII", b"glTF", 2, total) + struct.pack("<I4s", len(json_chunk), b"JSON") + json_chunk + struct.pack("<I4s", len(binary_chunk), b"BIN\0") + binary_chunk)


def build_clip(source_document: dict, source_binary: bytearray, start: float, end: float, *, idle: bool) -> tuple[dict, bytearray]:
    document, binary = copy.deepcopy(source_document), bytearray(source_binary)
    source_animation = source_document["animations"][0]
    new_animation = {"name": "Stella conversation idle" if idle else "Stella semantic one-shot", "samplers": [], "channels": []}
    names = [node.get("name", "") for node in source_document["nodes"]]
    human_nodes = {bone["node"] for bone in source_document["extensions"]["VRMC_vrm_animation"]["humanoid"]["humanBones"].values()}

    for channel in source_animation["channels"]:
        target = channel["target"]
        node_name = names[target["node"]]
        path_name = target["path"]
        if idle and target["node"] not in human_nodes:
            continue
        sampler = source_animation["samplers"][channel["sampler"]]
        all_times = accessor_values(source_document, source_binary, sampler["input"])
        all_values = accessor_values(source_document, source_binary, sampler["output"])
        times, values = sample_segment(all_times, all_values, start, end)

        if idle:
            first = values[0]
            if path_name == "rotation" and node_name in ARM_REST:
                # Change only the arm's resting direction. Preserve every
                # captured delta at full strength, including wrists/fingers.
                inverse = tuple(-v if i < 3 else v for i, v in enumerate(q_normalize(first)))
                target_rest = arm_rest_quaternion(ARM_REST[node_name])
                values = [q_multiply(target_rest, q_multiply(inverse, value)) for value in values]
                first = values[0]
            # Ease the final 0.8s back to the first pose, making each clip loopable.
            seam_start = max(0.0, times[-1] - .8)
            for index, time_value in enumerate(times):
                if time_value < seam_start:
                    continue
                blend = (time_value - seam_start) / max(.001, times[-1] - seam_start)
                if path_name == "rotation":
                    values[index] = q_slerp(values[index], first, blend)
                else:
                    values[index] = tuple(value * (1 - blend) + initial * blend for value, initial in zip(values[index], first))
        elif node_name == "hips":
            # One-shots retain their local weight shifts but never walk the avatar away.
            first = values[0]
            values = [first if path_name in {"translation", "rotation"} else value for value in values]

        time_accessor = append_accessor(document, binary, [(value,) for value in times], "SCALAR")
        value_accessor = append_accessor(document, binary, values, "VEC3" if path_name == "translation" else "VEC4")
        sampler_index = len(new_animation["samplers"])
        new_animation["samplers"].append({"input": time_accessor, "output": value_accessor, "interpolation": "LINEAR"})
        new_animation["channels"].append({"sampler": sampler_index, "target": copy.deepcopy(target)})

    document["animations"] = [new_animation]
    return document, binary


def main() -> None:
    document, binary = load_glb(SOURCE)
    idle_dir, oneshot_dir = OUTPUT / "idle", OUTPUT / "one-shots"
    idle_dir.mkdir(parents=True, exist_ok=True)
    oneshot_dir.mkdir(parents=True, exist_ok=True)
    report = {"source": str(SOURCE), "idles": {}, "one_shots": {}}
    for name, (start, end) in IDLES.items():
        clip, clip_binary = build_clip(document, binary, start, end, idle=True)
        target = idle_dir / f"{name}.vrma"
        write_glb(target, clip, clip_binary)
        report["idles"][name] = {"range_seconds": [start, end], "duration_seconds": end - start, "classification": "continuous_idle"}
    for name, (start, end) in ONE_SHOTS.items():
        clip, clip_binary = build_clip(document, binary, start, end, idle=False)
        target = oneshot_dir / f"{name}.vrma"
        write_glb(target, clip, clip_binary)
        report["one_shots"][name] = {"range_seconds": [start, end], "duration_seconds": end - start, "classification": "semantic_one_shot_review_required"}
    (OUTPUT / "motion-report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"Created {len(IDLES)} idle loops and {len(ONE_SHOTS)} one-shots in {OUTPUT}")


if __name__ == "__main__":
    main()
