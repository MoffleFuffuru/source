"""Small authenticated speech checks; never prints the credential."""
from __future__ import annotations

import argparse
import asyncio
import base64
import json
import os
import time
import wave
from pathlib import Path

import aiohttp


def api_key() -> str:
    key = os.getenv("ELEVENLABS_API_KEY", "").strip()
    if not key and os.name == "nt":
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as handle:
            key = str(winreg.QueryValueEx(handle, "ELEVENLABS_API_KEY")[0]).strip()
    if not key:
        raise RuntimeError("ELEVENLABS_API_KEY is not configured")
    return key


async def probe(voice: str, output: Path) -> None:
    key = api_key()
    report = {}
    timeout = aiohttp.ClientTimeout(total=30)
    async with aiohttp.ClientSession(headers={"xi-api-key": key}, timeout=timeout) as session:
        started = time.monotonic()
        try:
            async with session.ws_connect(
                "wss://api.elevenlabs.io/v1/text-to-dialogue/stream-input",
                params={"model_id": "eleven_v4_turbo", "output_format": "pcm_24000"},
            ) as ws:
                await ws.send_json({"voices": [voice]})
                await ws.send_json({"inputs": [{"text": "Hi, I'm Stella. Moffle and Ghoul play War Robots.", "voice_id": voice}]})
                await ws.send_json({"close_socket": True})
                pcm = bytearray()
                async with asyncio.timeout(25):
                    async for msg in ws:
                        if msg.type != aiohttp.WSMsgType.TEXT:
                            continue
                        data = json.loads(msg.data)
                        if data.get("error"):
                            raise RuntimeError(str(data["error"]).replace(key, "[redacted]"))
                        if data.get("audio"):
                            if not pcm:
                                report["tts_first_pcm_seconds"] = round(time.monotonic() - started, 3)
                            pcm.extend(base64.b64decode(data["audio"]))
                        if data.get("is_final"):
                            break
                if not pcm:
                    raise RuntimeError("No TTS audio received")
                output.parent.mkdir(parents=True, exist_ok=True)
                with wave.open(str(output), "wb") as wav:
                    wav.setparams((1, 2, 24000, 0, "NONE", "not compressed"))
                    wav.writeframes(pcm)
                report["tts_audio_seconds"] = round(len(pcm) / 48000, 3)
                report["tts_output"] = str(output)
        except Exception as exc:
            report["tts_error"] = str(exc).replace(key, "[redacted]")
        try:
            async with session.ws_connect(
                "wss://api.elevenlabs.io/v1/speech-to-text/realtime",
                params=[("model_id", "scribe_v2_realtime"), ("audio_format", "pcm_24000"),
                        ("commit_strategy", "manual"), ("keyterms", "Stella"),
                        ("keyterms", "Ghoul"), ("keyterms", "Moffle"), ("keyterms", "War Robots")],
            ) as ws:
                first = await ws.receive_json(timeout=10)
                report["stt_session"] = first.get("message_type")
                if first.get("message_type") != "session_started":
                    raise RuntimeError(str(first).replace(key, "[redacted]"))
                if "tts_error" not in report:
                    for offset in range(0, len(pcm), 4800):
                        await ws.send_json({"message_type": "input_audio_chunk", "audio_base_64": base64.b64encode(pcm[offset:offset + 4800]).decode(), "sample_rate": 24000})
                        await asyncio.sleep(.1)
                    await ws.send_json({"message_type": "input_audio_chunk", "audio_base_64": base64.b64encode(bytes(4800)).decode(), "commit": True, "sample_rate": 24000})
                    committed_at = time.monotonic()
                    async with asyncio.timeout(15):
                        async for msg in ws:
                            if msg.type != aiohttp.WSMsgType.TEXT:
                                continue
                            data = json.loads(msg.data)
                            if data.get("error"):
                                raise RuntimeError(str(data["error"]).replace(key, "[redacted]"))
                            if data.get("message_type") == "committed_transcript":
                                report["stt_text"] = data.get("text")
                                report["stt_commit_seconds"] = round(time.monotonic() - committed_at, 3)
                                break
        except Exception as exc:
            report["stt_error"] = str(exc).replace(key, "[redacted]")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--voice", required=True)
    parser.add_argument("--output", type=Path, default=Path("data/elevenlabs-smoke.wav"))
    args = parser.parse_args()
    asyncio.run(probe(args.voice, args.output))
