"""Opt-in paid smoke test of the production transports, without opening a mic."""
from __future__ import annotations

import asyncio
import json
import queue
import sys
import threading
import time
import wave
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

from mako.config import VoiceConfig
from mako.elevenlabs_voice import ScribeSTTClient, stream_dialogue


async def synth(config, text):
    chunks = queue.Queue()
    chunks.put(text)
    chunks.put(None)
    started = time.monotonic()
    first = None
    pcm = bytearray()
    async for frame in stream_dialogue(config, chunks):
        if first is None:
            first = time.monotonic() - started
        pcm.extend(frame)
    return bytes(pcm), round(first, 3)


def main():
    config = VoiceConfig(elevenlabs_tts_voice="TaAj41g1TDT9zKVixsDm", elevenlabs_stt_fallback="", elevenlabs_tts_fallback="")
    results = []
    for name, text in [
        ("short", "Yes."),
        ("keyterms", "Stella, Moffle and Ghoul play War Robots."),
        ("ordinary", "The kettle is on the kitchen counter. I'll meet you by the front door."),
    ]:
        pcm, first = asyncio.run(synth(config, text))
        path = Path("data") / f"elevenlabs-test-{name}.wav"
        with wave.open(str(path), "wb") as wav:
            wav.setparams((1, 2, 24000, 0, "NONE", "not compressed"))
            wav.writeframes(pcm)
        turns = []
        arrived = threading.Event()
        endpoint = None
        def commit(value):
            turns.append({"text": value, "at": time.monotonic()})
            arrived.set()
        client = ScribeSTTClient(config, capture_microphone=False, on_utterance=commit)
        try:
            client.start()
            samples = np.frombuffer(pcm, dtype="<i2").astype(np.float32) / 32768
            for offset in range(0, len(samples), 2400):
                client.push_audio(samples[offset:offset + 2400], 24000)
                time.sleep(.1)
            endpoint = time.monotonic()
            if not arrived.wait(8):
                raise RuntimeError(f"No Scribe commit for {name}")
            time.sleep(.5)
        finally:
            client.stop()
        results.append({"case": name, "input": text, "transcripts": [turn["text"] for turn in turns],
                        "tts_first_pcm_seconds": first, "audio_seconds": round(len(pcm) / 48000, 3),
                        "after_audio_to_commit_seconds": round(turns[0]["at"] - endpoint, 3)})
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
