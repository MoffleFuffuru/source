"""Replay Mako's most recent call context through GPT-5.6-Luna externally.

Run from normal Windows PowerShell, never from Codex Desktop's terminal. The
script reads call history but does not write to Mako's live databases.
"""

from __future__ import annotations

import argparse
import json
import sqlite3
import statistics
import sys
from dataclasses import replace
from datetime import datetime
from pathlib import Path

# When Python launches this file directly, only tools/ is on sys.path.
# Add the Mako project root before importing the application package.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from mako.config import load_config
from mako.dialogue import CALL_RESPONSE_SCHEMA, DialogueManager
from mako.model_backend import CodexAppServerBackend
from mako.models import ConversationEvent, EventSource, InteractionMode, Visibility
from mako.prompts import CALL_GENERATE_SYSTEM


def recent_call_session(database: Path) -> list[tuple[str, str, str]]:
    connection = sqlite3.connect(database)
    try:
        rows = connection.execute(
            "SELECT created_at, user_text, mako_text FROM episodes "
            "WHERE mode = 'call' ORDER BY created_at DESC LIMIT 80"
        ).fetchall()
    finally:
        connection.close()
    rows.reverse()
    if not rows:
        raise RuntimeError("No call transcript was found.")

    # A gap of over two minutes denotes a new call session for replay purposes.
    start = len(rows) - 1
    for index in range(len(rows) - 1, 0, -1):
        current = datetime.fromisoformat(rows[index][0])
        previous = datetime.fromisoformat(rows[index - 1][0])
        if (current - previous).total_seconds() > 120:
            break
        start = index - 1
    return rows[start:]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="gpt-5.6-luna")
    parser.add_argument("--limit", type=int, default=20)
    parser.add_argument("--out", type=Path, default=Path("last_call_luna_replay.json"))
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    session = recent_call_session(root / "data" / "memory.sqlite3")[-args.limit :]
    config = load_config(root / "config.json")
    config.model.primary = args.model
    config.model.call_model = args.model
    config.model.reasoning_effort = "medium"
    config.model.call_reasoning_effort = "medium"
    backend = CodexAppServerBackend(config.model)
    dialogue = DialogueManager(config, backend, ledger=None)  # Prompt construction only.
    results: list[dict[str, object]] = []
    recorded_history: list[tuple[str, str, str]] = []
    try:
        for created_at, user_text, recorded_reply in session:
            event = ConversationEvent(
                content=user_text,
                source=EventSource.VOICE_CALL,
                mode=InteractionMode.CALL,
                visibility=Visibility.PRIVATE,
                user_id="owner",
                display_name="Moffle",
                channel_id="desktop",
                created_at=created_at,
            )
            dynamic_prompt = dialogue._generation_prompt(
                event=event,
                history=recorded_history,
                memories=[],
                mood_summary="Current private emotional tendencies: use the established tone of the supplied conversation.",
                semantic_guidance="",
                lessons=[],
                rejected=[],
                private_feedback="",
                exhausted_topics=set(),
                forbidden_topics=set(),
                history_as_messages=True,
                recent_live_history=recorded_history[-2:],
            )
            messages = dialogue._cached_message_prefix(
                system=CALL_GENERATE_SYSTEM,
                history=recorded_history,
                dynamic_prompt=dynamic_prompt,
                history_limit=len(recorded_history),
            )
            generation = backend.generate(
                messages=messages,
                model=args.model,
                max_tokens=config.model.call_max_output_tokens,
                json_schema=CALL_RESPONSE_SCHEMA,
                reasoning_effort="medium",
                timeout_seconds=30.0,
            )
            try:
                replay_reply = json.loads(generation.text)["text"]
            except (json.JSONDecodeError, KeyError, TypeError):
                replay_reply = generation.text
            results.append(
                {
                    "created_at": created_at,
                    "user": user_text,
                    "recorded_terra_reply": recorded_reply,
                    "luna_reply": replay_reply,
                    "latency_seconds": round(generation.elapsed_seconds, 3),
                }
            )
            recorded_history.append((user_text, recorded_reply, created_at))
    finally:
        backend.close()

    latencies = [float(item["latency_seconds"]) for item in results]
    payload = {
        "model": args.model,
        "reasoning_effort": "medium",
        "replayed_turns": len(results),
        "note": "Uses recorded call history and Mako's real call prompt/schema. It does not mutate live Mako memory.",
        "summary": {
            "average_latency_seconds": round(statistics.mean(latencies), 3),
            "median_latency_seconds": round(statistics.median(latencies), 3),
            "minimum_latency_seconds": round(min(latencies), 3),
            "maximum_latency_seconds": round(max(latencies), 3),
        },
        "turns": results,
    }
    args.out.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(payload["summary"], indent=2))
    print(f"Wrote {args.out.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
