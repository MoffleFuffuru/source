"""Replay a real multi-user Discord session through GPT-5.6 Terra at low effort.

Run from normal Windows PowerShell. The corpus is a read-only SQLite snapshot;
this script never opens or modifies Mako's live memory database.
"""

from __future__ import annotations

import argparse
import json
import re
import sqlite3
import statistics
import sys
from pathlib import Path

TOOLS_ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = TOOLS_ROOT.parent
if str(TOOLS_ROOT) not in sys.path:
    sys.path.insert(0, str(TOOLS_ROOT))
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from benchmark_call_terra_reasoning import resolve_codex_executable
from mako.config import load_config
from mako.dialogue import TEXT_RESPONSE_SCHEMA, DialogueManager
from mako.model_backend import CodexAppServerBackend
from mako.models import ConversationEvent, EventSource, InteractionMode, Visibility
from mako.prompts import GENERATE_SYSTEM


SPEAKER_LINE = re.compile(r"^Discord speaker (.+?) \(([^)]+)\):\s*(.*)$", re.DOTALL)


def corpus(database: Path, limit: int) -> list[dict[str, str]]:
    connection = sqlite3.connect(f"file:{database}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    try:
        rows = connection.execute(
            """
            SELECT event_id, created_at, user_id, user_text, mako_text, channel_id
            FROM episodes
            WHERE source = 'discord'
              AND channel_id = 'discord:1259652032835616800:shared'
              AND trim(mako_text) <> ''
              AND created_at BETWEEN '2026-08-30T05:00:00+00:00'
                                 AND '2026-08-30T06:10:00+00:00'
            GROUP BY event_id
            ORDER BY created_at DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
    finally:
        connection.close()
    selected = [dict(row) for row in reversed(rows)]
    speakers = {row["user_id"] for row in selected}
    if len(selected) < min(20, limit) or len(speakers) < 3:
        raise RuntimeError(f"Corpus validation failed: {len(selected)} turns across {len(speakers)} speakers")
    return selected


def unpack_speaker(row: dict[str, str]) -> tuple[str, str, str]:
    match = SPEAKER_LINE.match(row["user_text"])
    if not match:
        return row["user_id"], row["user_id"], row["user_text"]
    return match.group(1), match.group(2), match.group(3).strip()


def parse_payload(text: str) -> dict[str, object]:
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return {"text": text.strip(), "expression": "invalid"}
    return payload if isinstance(payload, dict) else {"text": text.strip(), "expression": "invalid"}


def latency_summary(turns: list[dict[str, object]]) -> dict[str, float]:
    values = [float(turn["latency_seconds"]) for turn in turns]
    return {
        "average_seconds": round(statistics.mean(values), 3),
        "median_seconds": round(statistics.median(values), 3),
        "minimum_seconds": round(min(values), 3),
        "maximum_seconds": round(max(values), 3),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="gpt-5.6-terra")
    parser.add_argument("--effort", default="low")
    parser.add_argument("--limit", type=int, default=60)
    parser.add_argument("--database", type=Path, default=PROJECT_ROOT / "discord_benchmark_memory.sqlite3")
    parser.add_argument("--out", type=Path, default=Path("discord_terra_low_benchmark.json"))
    args = parser.parse_args()

    rows = corpus(args.database, args.limit)
    config = load_config(PROJECT_ROOT / "config.json")
    config.model.primary = args.model
    config.model.reasoning_effort = args.effort
    config.model.codex_executable = resolve_codex_executable(config.model.codex_executable)
    backend = CodexAppServerBackend(config.model)
    dialogue = DialogueManager(config, backend, ledger=None)
    recorded_history: list[tuple[str, str, str]] = []
    results: list[dict[str, object]] = []
    try:
        for row in rows:
            display_name, speaker_id, content = unpack_speaker(row)
            event = ConversationEvent(
                content=content,
                source=EventSource.DISCORD,
                mode=InteractionMode.TEXT,
                visibility=Visibility.PUBLIC,
                user_id=speaker_id,
                display_name=display_name,
                channel_id=row["channel_id"],
                created_at=row["created_at"],
            )
            history = recorded_history[-config.memory.recent_turns :]
            dynamic_prompt = dialogue._generation_prompt(
                event=event,
                history=history,
                memories=[],
                mood_summary="Public group conversation. Preserve speaker identity, established jokes, boundaries, and safety judgment.",
                semantic_guidance="",
                lessons=[],
                rejected=[],
                private_feedback="",
                exhausted_topics=set(),
                forbidden_topics=set(),
                history_as_messages=True,
                recent_live_history=[],
            )
            messages = dialogue._cached_message_prefix(
                system=GENERATE_SYSTEM,
                history=history,
                dynamic_prompt=dynamic_prompt,
                history_limit=len(history),
            )
            generation = backend.generate(
                messages=messages,
                model=args.model,
                max_tokens=config.model.max_output_tokens,
                json_schema=TEXT_RESPONSE_SCHEMA,
                reasoning_effort=args.effort,
                timeout_seconds=config.model.timeout_seconds,
            )
            payload = parse_payload(generation.text)
            results.append({
                "created_at": row["created_at"],
                "speaker": display_name,
                "speaker_id": speaker_id,
                "user": content,
                "recorded_medium_reply": row["mako_text"],
                "low_reply": str(payload.get("text", "")).strip(),
                "expression": payload.get("expression", "invalid"),
                "latency_seconds": round(generation.elapsed_seconds, 3),
            })
            # Both the recorded and replayed paths receive the same real history,
            # isolating reasoning effort instead of compounding divergent replies.
            recorded_history.append((row["user_text"], row["mako_text"], row["created_at"]))
    finally:
        backend.close()

    payload = {
        "model": args.model,
        "reasoning_effort": args.effort,
        "turns": len(results),
        "speakers": sorted({str(turn["speaker"]) for turn in results}),
        "corpus": "real public Discord session with rapid multi-user switching, boundaries, callbacks, owner warmth, and medical safety escalation",
        "latency": latency_summary(results),
        "results": results,
    }
    args.out.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"turns": len(results), "speakers": payload["speakers"], "latency": payload["latency"]}, indent=2, ensure_ascii=False))
    print(f"Wrote {args.out.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
