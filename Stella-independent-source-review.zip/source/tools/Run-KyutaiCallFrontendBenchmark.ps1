$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$python = Join-Path $root ".venv\Scripts\python.exe"
if (-not (Test-Path -LiteralPath $python)) {
    throw "Mako's .venv was not found at $python"
}

Set-Location $root
& $python ".\tools\benchmark_kyutai_call_frontend.py" @args
