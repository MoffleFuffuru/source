"""Owner-only RMA retrieval experiment using per-turn archive evidence."""
from __future__ import annotations

import argparse
import json
import re
import sqlite3
import sys
from dataclasses import replace
from datetime import datetime
from pathlib import Path
from time import perf_counter
from time import time
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from mako.config import load_config
from mako.dialogue import CALL_RESPONSE_SCHEMA, DialogueManager, parse_json_object
from mako.model_backend import GroqBackend
from mako.models import ConversationEvent, EventSource, InteractionMode, Visibility
from mako.prompts import CALL_GENERATE_SYSTEM
from mako.quality import token_jaccard

OUTPUT = ROOT / "data" / "owner_memory_lab_report.json"
ARCHIVE = ROOT / "data" / "memory.sqlite3"

# These cases deliberately vary direct, oblique, relationship, and no-recall
# prompts.  Expected terms are scored only as a signal for human review.
CASES = (
    ("What was the old name for this project before Stella?", ["mako"]),
    ("What game did we plan to play, and what map was named for 1v1s?", ["war robot", "zero"]),
    ("What was that recurring Discord memory-test anchor about?", ["toes"]),
    ("What did I ask you to do about the keyboard joke?", ["stop"]),
    ("What are we trying to improve in the voice stack?", ["glitchy"]),
    ("What did I say I wanted to do when I just wanted to relax?", ["chill"]),
    ("What did I say about Mako being more than code?", ["script"]),
    ("What feature did I want to make the interaction less serious?", ["call"]),
    ("What was the virtual-nap idea?", ["nap"]),
    ("What did the archive actually establish about a last call with Jalty?", ["memory"]),
    ("What was the plan for a movie night?", ["scooby"]),
    ("What does the archive say about my cat?", ["black"]),
    ("Do you remember the keyboard joke or coat reference?", ["keyboard", "coat"]),
    ("What did I say I wanted to build with Mako?", ["desktop"]),
)

STOPWORDS = {
    "about", "and", "are", "can", "did", "do", "for", "from", "i", "in", "is", "it",
    "me", "my", "of", "our", "tell", "that", "the", "this", "to", "was", "we", "what",
    "when", "where", "who", "with", "you", "your",
}


class NullLedger:
    def recent_responses(self) -> list[str]:
        return []

    def relevant_lessons(self, _text: str) -> list[str]:
        return []


def terms(text: str) -> set[str]:
    normalized: set[str] = set()
    for word in re.findall(r"[a-z0-9']+", text.lower()):
        if word in STOPWORDS or len(word) <= 2:
            continue
        # Enough morphology for exact conversational anchors: toe/toes, call/calls.
        normalized.add(word[:-1] if word.endswith("s") and len(word) > 4 else word)
    return normalized


def open_archive() -> sqlite3.Connection:
    uri = ARCHIVE.resolve().as_uri() + "?mode=ro&immutable=1"
    connection = sqlite3.connect(uri, uri=True)
    connection.row_factory = sqlite3.Row
    return connection


def active_recall(query: str, *, limit: int = 8) -> list[dict[str, str]]:
    """Unrestricted owner-development search across every concept and episode."""
    qterms = terms(query)
    ranked: list[tuple[float, dict[str, str]]] = []
    with open_archive() as connection:
        concepts = connection.execute(
            "SELECT key, label, summary, strength, confidence FROM concepts"
        ).fetchall()
        episodes = connection.execute(
            "SELECT id, created_at, user_text, mako_text, importance, emotional_weight FROM episodes"
        ).fetchall()
    for row in concepts:
        text = f"{row['label']}: {row['summary']}"
        overlap = qterms & terms(text)
        score = token_jaccard(query, text) + float(row["strength"]) * .12 + len(overlap) * .38
        if qterms & terms(str(row["label"])):
            score += .45
        if score >= .22:
            ranked.append((score, {
                "source": f"concept:{row['key']}", "kind": "concept", "text": text[:900],
            }))
    for row in episodes:
        text = f"User: {row['user_text']}\nStella: {row['mako_text']}"
        overlap = qterms & terms(text)
        score = token_jaccard(query, text) + float(row["importance"]) * .05 + len(overlap) * .42
        lowered = text.lower()
        for phrase in re.findall(r"[a-z0-9']+(?:\s+[a-z0-9']+){1,2}", query.lower()):
            if len(phrase) > 6 and phrase in lowered:
                score += .22
        if score >= .24:
            ranked.append((score, {
                "source": f"episode:{row['id']}", "kind": "episode",
                "text": f"[{row['created_at']}] {text}"[:1200],
            }))
    ranked.sort(key=lambda item: item[0], reverse=True)
    selected: list[dict[str, str]] = []
    seen: set[str] = set()
    for _, item in ranked:
        fingerprint = item["text"].lower()
        if fingerprint in seen:
            continue
        seen.add(fingerprint)
        selected.append(item)
        if len(selected) == limit:
            break
    return selected


def semantic_resonance(
    backend: GroqBackend, query: str, evidence: list[dict[str, str]],
) -> str:
    """Resolve meaning-level recall before Qwen receives the final prompt."""
    prompt = (
        "CURRENT QUESTION:\n" + query + "\n\nRMA ARCHIVE EVIDENCE:\n"
        + "\n".join(f"[{item['source']}] {item['text']}" for item in evidence[:5])
        + "\n\nReturn 2-5 compact, evidence-only facts that answer the question. "
          "If evidence is absent, say exactly that. When evidence changes across time, distinguish what was "
          "known then from what is known later instead of selecting one contradiction. Do not roleplay or add advice."
    )
    result = backend.generate(
        system=("You are the Resonance Continuity semantic recall layer. Ground every statement in supplied evidence. "
                "For factual recall, preserve concrete names, actions, and needed qualifiers."),
        prompt=prompt, model="gpt-oss-120b", max_tokens=6000, reasoning_effort="high", timeout_seconds=90.0,
    )
    return result.text.strip()


def prompt_board(
    query: str, *, semantic_packet: str = "",
) -> tuple[str, list[dict[str, str]], float]:
    started = perf_counter()
    evidence = active_recall(query)
    recall = [
        "ACTIVE OWNER-DEVELOPMENT RECALL - AUTHORITATIVE FOR THIS TURN",
        "The following archive evidence was retrieved before response generation.",
        "Answer from it precisely. If it is insufficient, say what is missing; do not invent.",
        "If the question names multiple people, memories, or subjects, explicitly address every named part. "
        "Preserve concrete names and qualifiers; do not flatten a specific fact into a vague paraphrase.",
    ]
    recall.extend(f"- [{item['source']}] {item['text'][:650]}" for item in evidence[:5])
    if semantic_packet:
        recall.extend((
            "RESONANCE SEMANTIC RESOLUTION - HARD PRIORITY:",
            "This was selected specifically to answer the current message. Answer this resolution first; "
            "do not substitute a broader fact from unrelated memory. Include the action and its stated reason "
            "when both appear in the resolution; reconcile time-ordered evidence explicitly when it changes.",
            semantic_packet,
        ))
    return "\n".join(recall), evidence, perf_counter() - started


def run(*, semantic: bool = False) -> dict[str, Any]:
    config = load_config(ROOT / "config.json")
    backend = GroqBackend(replace(
        config.model, provider="cerebras", endpoint="https://api.cerebras.ai/v1",
        api_key_environment_variable="CEREBRAS_API_KEY", primary="qwen-3.8-27b",
        fallback="", call_model="qwen-3.8-27b", call_provider="cerebras",
        call_reasoning_effort="none", call_max_attempts=1,
    ))
    dialogue = DialogueManager(config, backend, NullLedger())
    run_scope = f"owner-memory-lab:{int(time() * 1000)}"
    history: list[tuple[str, str]] = []
    turns: list[dict[str, Any]] = []
    for index, (user_text, expected) in enumerate(CASES, start=1):
        _, evidence, retrieval_seconds = prompt_board(user_text)
        semantic_packet = semantic_resonance(backend, user_text, evidence) if semantic else ""
        enriched, evidence, _ = prompt_board(user_text, semantic_packet=semantic_packet)
        event = ConversationEvent(
            content=user_text, source=EventSource.VOICE_CALL, mode=InteractionMode.CALL,
            visibility=Visibility.PRIVATE, user_id="owner", display_name="Moffle",
            channel_id="owner-memory-lab", metadata={"call_event": "utterance"},
        )
        prompt = dialogue._generation_prompt(
            event=event, history=history[-10:], memories=[enriched],
            mood_summary="Current emotional tendency: warm, grounded, and conversational.",
            semantic_guidance="", lessons=[], rejected=[], private_feedback="",
            exhausted_topics=set(), forbidden_topics=set(), history_as_messages=True,
            recent_live_history=[],
        )
        messages = dialogue._fit_call_prompt(dialogue._cached_message_prefix(
            system=CALL_GENERATE_SYSTEM, history=history[-10:], dynamic_prompt=prompt,
            history_limit=min(10, len(history)),
        ))
        generation = backend.generate(
            messages=messages, model="qwen-3.8-27b", max_tokens=config.model.call_max_output_tokens,
            json_schema=CALL_RESPONSE_SCHEMA, reasoning_effort="none", timeout_seconds=45.0,
            conversation_scope=run_scope,
        )
        try:
            reply = str(parse_json_object(generation.text).get("text", "")).strip()
        except Exception:
            reply = generation.text.strip()
        passed = all(term in reply.lower() for term in expected)
        turns.append({
            "turn": index, "user": user_text, "expected_terms": expected, "passed": passed,
            "retrieval_seconds": round(retrieval_seconds, 3), "evidence": evidence,
            "semantic_packet": semantic_packet,
            "prompt_characters": len(prompt), "prompt_tokens": generation.prompt_tokens,
            "generation_seconds": round(generation.elapsed_seconds, 3), "reply": reply,
        })
        history.append((user_text, reply))
    return {
        "experiment": "resonance-continuity-owner-lab-v2" if semantic else "resonance-continuity-owner-lab-v1",
        "created_at": datetime.now().astimezone().isoformat(),
        "turn_count": len(turns), "passed": sum(item["passed"] for item in turns),
        "base_board_characters": len(board), "turns": turns,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", action="store_true", help="run the 15-turn owner memory lab")
    parser.add_argument("--semantic", action="store_true", help="use GPT-OSS high semantic recall before Qwen")
    args = parser.parse_args()
    if not args.run:
        raise SystemExit("Use --run")
    report = run(semantic=args.semantic)
    OUTPUT.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Owner memory lab: {report['passed']}/{report['turn_count']} passed. Wrote {OUTPUT}")
