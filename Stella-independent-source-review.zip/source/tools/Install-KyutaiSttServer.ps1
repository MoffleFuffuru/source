$ErrorActionPreference = "Stop"

$cargo = Get-Command cargo -ErrorAction SilentlyContinue
if (-not $cargo) {
    $cargoPath = Join-Path $env:USERPROFILE ".cargo\bin\cargo.exe"
    if (Test-Path -LiteralPath $cargoPath) {
        $cargo = Get-Item -LiteralPath $cargoPath
    }
}
if (-not $cargo) {
    throw "Rust is missing. Install rustup from https://rustup.rs, reopen PowerShell, then rerun this script."
}

$nvcc = Get-Command nvcc -ErrorAction SilentlyContinue
if (-not $nvcc) {
    $nvcc = Get-ChildItem -LiteralPath "C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA" `
        -Recurse -Filter nvcc.exe -File -ErrorAction SilentlyContinue |
        Sort-Object FullName -Descending |
        Select-Object -First 1
}
if (-not $nvcc) {
    throw "The CUDA Toolkit compiler is missing. Install the NVIDIA CUDA Toolkit, reopen PowerShell, then rerun this script."
}

$cudaBin = Split-Path -Parent $nvcc.Source
$env:CUDA_PATH = Split-Path -Parent $cudaBin
$env:CUDA_HOME = $env:CUDA_PATH
$env:PATH = "$cudaBin;$env:USERPROFILE\.cargo\bin;$env:PATH"

if (-not (Get-Command cl.exe -ErrorAction SilentlyContinue)) {
    $vswhere = "C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe"
    if (-not (Test-Path -LiteralPath $vswhere)) {
        throw "Visual Studio's vswhere.exe was not found. Repair the Desktop development with C++ workload."
    }
    $vsRoot = & $vswhere -latest -products * `
        -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 `
        -property installationPath
    $vsDevCmd = Join-Path $vsRoot "Common7\Tools\VsDevCmd.bat"
    if (-not (Test-Path -LiteralPath $vsDevCmd)) {
        throw "Visual Studio's x64 developer environment was not found under $vsRoot."
    }
    $developerCommand = "call `"$vsDevCmd`" -no_logo -arch=x64 -host_arch=x64 && set"
    $developerEnvironment = & $env:ComSpec /d /c $developerCommand
    if ($LASTEXITCODE -ne 0) {
        throw "Visual Studio's x64 developer environment could not be initialized."
    }
    $loadedNames = [System.Collections.Generic.HashSet[string]]::new(
        [System.StringComparer]::OrdinalIgnoreCase
    )
    foreach ($line in $developerEnvironment) {
        $name, $value = $line -split "=", 2
        if ($name -and $null -ne $value -and $loadedNames.Add($name)) {
            Set-Item -LiteralPath "Env:$name" -Value $value
        }
    }
}
if (-not (Get-Command cl.exe -ErrorAction SilentlyContinue)) {
    throw "Microsoft's cl.exe is still unavailable after loading the Visual Studio x64 developer environment."
}

# Candle 0.9.2 instantiates BF16 WMMA kernels on Turing even though BF16 WMMA
# requires Ampere or newer. Kyutai STT does not use the MoE path, so guard only
# those unsupported instantiations while retaining the FP16 kernels.
$candleSource = Get-ChildItem -LiteralPath (Join-Path $env:USERPROFILE ".cargo\registry\src") `
    -Recurse -Directory -Filter "candle-kernels-0.9.2" -ErrorAction SilentlyContinue |
    Select-Object -First 1
if ($candleSource) {
    $moeWmma = Join-Path $candleSource.FullName "src\moe\moe_wmma.cu"
    $sourceText = [System.IO.File]::ReadAllText($moeWmma)
    if ($sourceText -notmatch "data_type == 1[\s\S]{0,80}NO_BF16_KERNEL") {
        $oldBlock = @'
    } else if (data_type == 1) { // bfloat16
        if (is_prefill) {
            LAUNCH_MOE_WMMA(nv_bfloat16, 16, 16, 2)
        } else {
            LAUNCH_MOE_WMMA(nv_bfloat16, 8, 32, 1)
        }
    }
'@
        $newBlock = @'
    } else if (data_type == 1) { // bfloat16
#ifndef NO_BF16_KERNEL
        if (is_prefill) {
            LAUNCH_MOE_WMMA(nv_bfloat16, 16, 16, 2)
        } else {
            LAUNCH_MOE_WMMA(nv_bfloat16, 8, 32, 1)
        }
#endif
    }
'@
        if (-not $sourceText.Contains($oldBlock)) {
            throw "Could not apply the Candle sm75 BF16 compatibility guard."
        }
        [System.IO.File]::WriteAllText($moeWmma, $sourceText.Replace($oldBlock, $newBlock))
    }
    # Runtime flags are not tracked by bindgen_cuda, so force libmoe to rebuild.
    (Get-Item -LiteralPath (Join-Path $candleSource.FullName "build.rs")).LastWriteTime = Get-Date
}

Remove-Item Env:CXXFLAGS -ErrorAction SilentlyContinue
$env:NVCC_PREPEND_FLAGS = "-Xcompiler=/Zc:preprocessor -Xcompiler=/MD -DNO_BF16_KERNEL"
$previousBuild = Get-ChildItem -LiteralPath $env:TEMP -Directory -Filter "cargo-install*" `
    -ErrorAction SilentlyContinue |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 1
if ($previousBuild) {
    $env:CARGO_BUILD_BUILD_DIR = $previousBuild.FullName
    Write-Host "Reusing Cargo build artifacts from $($previousBuild.FullName)"
}
& $cargo.Source install --features cuda moshi-server@0.6.4
if ($LASTEXITCODE -ne 0) {
    throw "Kyutai moshi-server compilation failed with exit code $LASTEXITCODE."
}
Write-Host "Kyutai moshi-server is installed. Run .\tools\Start-KyutaiSttServer.ps1 next."
