param(
    [Parameter(Mandatory=$true)][string]$Id,
    [Parameter(Mandatory=$true)][string]$ActorId,
    [string]$Name,
    [ValidateSet('chat','join','leave','screen','game','event')][string]$Kind = 'chat',
    [string]$Text
)
$key = [Environment]::GetEnvironmentVariable('STELLA_SAGE_EVENT_KEY', 'Process')
if (-not $key) { $key = [Environment]::GetEnvironmentVariable('STELLA_SAGE_EVENT_KEY', 'User') }
if (-not $key) { throw 'Set STELLA_SAGE_EVENT_KEY for your Windows account, then restart Stella.' }
$body = @{ id=$Id; actor_id=$ActorId; name=$Name; kind=$Kind; text=$Text } | ConvertTo-Json
Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:39541/api/sage/event' `
    -Headers @{ Authorization="Bearer $key" } -ContentType 'application/json; charset=utf-8' `
    -Body ([Text.Encoding]::UTF8.GetBytes($body))
