"""Explicit, small paid smoke test. Never prints credentials or personal context."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from mako.config import load_config
from mako.model_backend import create_backend

config = load_config(ROOT / 'config.json').model
assert config.call_provider == 'lithos'
backend = create_backend(config)
tokens = []
try:
    result = backend.generate(
        system='You are a connection test. Reply with a brief greeting only.',
        prompt='Say hello.', max_tokens=48, on_token=tokens.append,
        reasoning_effort=config.call_reasoning_effort,
    )
    assert result.text and tokens, 'No visible streamed response'
    assert result.model == 'deepseek-ai/DeepSeek-V4.1-Flash'
    print('PASS: live Stella backend streamed:', result.text)
    print('Model:', result.model, 'Reasoning:', config.call_reasoning_effort)
    print('First token seconds:', result.first_token_seconds)
finally:
    backend.close()
