[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$codexExe = Get-ChildItem -Path (Join-Path $env:LOCALAPPDATA 'OpenAI\Codex\bin') -Filter 'codex.exe' -Recurse -File |
    Sort-Object LastWriteTime -Descending | Select-Object -First 1 -ExpandProperty FullName
if (-not $codexExe) { throw 'Could not locate codex.exe.' }
$env:PATH = "$(Split-Path -Parent $codexExe);$env:PATH"
Set-Location $root
python .\tools\benchmark_last_call_luna.py --out .\last_call_luna_replay.json
