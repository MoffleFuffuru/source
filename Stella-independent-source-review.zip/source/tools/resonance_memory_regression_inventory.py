"""Inventory historical memory questions and create a source-grounded Resonance regression set."""
from __future__ import annotations

import json
import re
import sqlite3
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tools.owner_memory_lab import ARCHIVE, active_recall, terms

OUTPUT = ROOT / "data" / "resonance_memory_regression_inventory.json"
PATTERN = re.compile(
    r"\b(?:remember|memory|recall|recollect|last\s+(?:thing|message|time|call)|"
    r"what\s+did\s+(?:i|we)|who\s+(?:was|were)\s+i)\b", re.IGNORECASE,
)
SPECIFIC_RECALL = re.compile(
    r"\b(?:do|did|can|could|would)\s+you\s+remember\b|"
    r"\bremember\s+(?:what|when|anything|the|our|who)\b|"
    r"\bwhat\s+did\s+(?:i|we|you)\b|\bwho\s+(?:was|were)\s+i\b|"
    r"\b(?:last|earlier|previous)\s+(?:call|message|thing|conversation)\b",
    re.IGNORECASE,
)
NOISY = {"memory", "remember", "recall", "thing", "message", "conversation", "call", "last"}


def rows() -> list[sqlite3.Row]:
    uri = ARCHIVE.resolve().as_uri() + "?mode=ro&immutable=1"
    with sqlite3.connect(uri, uri=True) as connection:
        connection.row_factory = sqlite3.Row
        return connection.execute(
            "SELECT id, created_at, user_text, mako_text FROM episodes ORDER BY created_at"
        ).fetchall()


def relevant(question: str, evidence: list[dict[str, str]]) -> bool:
    subject = terms(question) - NOISY
    if not subject:
        return False
    return any(len(subject & terms(item["text"])) >= 1 for item in evidence)


def canonical_question(question: str) -> str:
    """Collapse mirrored Discord ingestion into the original human wording."""
    value = re.sub(r"^discord speaker [^:]{1,140}:\s*", "", question, flags=re.IGNORECASE)
    value = re.sub(r"<@!?\d+>\s*", "", value)
    return " ".join(value.lower().split())


def performance_set(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    candidates = [item for item in items if SPECIFIC_RECALL.search(item["question"])
                  and item["currently_retrievable"]
                  and len(item["historical_answer"]) >= 12 and 20 <= len(item["question"]) <= 320]
    # Favor a broad set of concise, independently testable memories rather than
    # repeatedly selecting the longest implementation-plan discussion.
    candidates.sort(key=lambda item: (
        abs(len(item["question"]) - 120), -len(item["historical_answer"]), item["asked_at"]
    ))
    selected: list[dict[str, Any]] = []
    selected_terms: list[set[str]] = []
    for item in candidates:
        current = terms(item["question"]) - NOISY
        if not current:
            continue
        overlap = max((len(current & old) / max(1, len(current | old)) for old in selected_terms), default=0.0)
        if overlap > .45:
            continue
        selected.append(item)
        selected_terms.append(current)
        if len(selected) == 20:
            break
    return selected


def main() -> None:
    grouped: dict[str, sqlite3.Row] = {}
    for row in rows():
        question = " ".join(str(row["user_text"] or "").split())
        if len(question) < 12 or not PATTERN.search(question):
            continue
        key = canonical_question(question)
        # Prefer the ingested copy that actually contains Stella's historical answer.
        if key not in grouped or (not grouped[key]["mako_text"] and row["mako_text"]):
            grouped[key] = row
    inventory: list[dict[str, Any]] = []
    for question, row in grouped.items():
        evidence = active_recall(question, limit=5)
        inventory.append({
            "question": question,
            "source_episode": str(row["id"]),
            "asked_at": str(row["created_at"]),
            "historical_answer": str(row["mako_text"] or ""),
            "current_evidence": evidence,
            "currently_retrievable": relevant(question, evidence),
        })
    # Favor substantive old answers and unique subjects. The full inventory stays
    # in the report; this is the separate 20-case performance set for model calls.
    report = {
        "historical_memory_questions": len(inventory),
        "currently_retrievable": sum(item["currently_retrievable"] for item in inventory),
        "with_historical_answer": sum(bool(item["historical_answer"]) for item in inventory),
        "performance_set": performance_set(inventory),
        "inventory": inventory,
    }
    OUTPUT.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({key: report[key] for key in ("historical_memory_questions", "currently_retrievable", "with_historical_answer")}, indent=2))
    print(f"Performance set: {len(report['performance_set'])}; wrote {OUTPUT}")


if __name__ == "__main__":
    main()
