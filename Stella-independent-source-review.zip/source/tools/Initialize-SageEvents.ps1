$bytes = New-Object byte[] 32
$rng = [Security.Cryptography.RandomNumberGenerator]::Create()
try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
$key = [Convert]::ToBase64String($bytes)
[Environment]::SetEnvironmentVariable('STELLA_SAGE_EVENT_KEY', $key, 'User')
$env:STELLA_SAGE_EVENT_KEY = $key
Write-Output 'SAGE adapter key saved for your Windows account. Restart Stella before sending events.'
