$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$config = Join-Path $PSScriptRoot "kyutai-stt-batch1.toml"
$logDirectory = Join-Path $root "data\logs\kyutai-stt"

New-Item -ItemType Directory -Force -Path $logDirectory | Out-Null
$server = Get-Command moshi-server -ErrorAction SilentlyContinue
if (-not $server) {
    throw "moshi-server is not installed. Run .\tools\Install-KyutaiSttServer.ps1 first."
}

Set-Location $root
& $server.Source worker --config $config --port 8090
