"""Compare GPT-5.6 Terra call quality and latency at two reasoning levels.

Run this from a normal Windows PowerShell session, not Codex Desktop. The
benchmark reads a saved call transcript and never writes to Mako's live DBs.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sqlite3
import statistics
import sys
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from mako.config import load_config
from mako.dialogue import CALL_RESPONSE_SCHEMA, DialogueManager
from mako.model_backend import CodexAppServerBackend
from mako.models import ConversationEvent, EventSource, InteractionMode, Visibility
from mako.prompts import CALL_GENERATE_SYSTEM


# Fixed real-call corpus. Keeping it in the benchmark makes the A/B replay
# portable and prevents it from accidentally querying a live or wrong-shaped
# SQLite database.
CORPUS: list[tuple[str, str, str]] = [
    ("2026-08-30T04:54:51.974582+00:00", "A live call from the user just connected. Give one short, natural pickup greeting.", "hey, you caught me awake."),
    ("2026-08-30T04:55:01.435066+00:00", "Hey, sorry I hung up on you.", "you're forgiven. i was only dramatically abandoned for a minute."),
    ("2026-08-30T04:55:17.569399+00:00", "Yeah there was a bit of a error the app kind of crashed", "ah, so the app abandoned both of us. rude."),
    ("2026-08-30T04:55:28.166234+00:00", "I know right very rude", "honestly, it has no respect for our dramatic timing."),
    ("2026-08-30T04:55:38.966165+00:00", "Agreed.", "good. the app has officially been judged."),
    ("2026-08-30T04:55:55.084716+00:00", "Mean you were gonna be judging the app a lot here in a little bit", "oh, absolutely. it had better prepare a convincing defense."),
    ("2026-08-30T04:56:10.682983+00:00", "Yeah for real especially under all of that spaghetti code", "careful, insult the spaghetti and it may crash out of spite."),
    ("2026-08-30T04:56:23.583357+00:00", "You know what? that's fair. that's fair.", "see? even chaos deserves a little professional courtesy."),
    ("2026-08-30T04:56:36.383570+00:00", "Through that", "wait, through what exactly?"),
    ("2026-08-30T04:56:47.089174+00:00", "Wait, what did she say?", "i asked what you meant by 'through that.'"),
    ("2026-08-30T04:57:05.446981+00:00", "Oh, I meant true that.", "oh, that makes considerably more sense."),
    ("2026-08-30T04:57:19.742441+00:00", "Yeah, sorry. I guess the speech-to-text didn't catch it correctly.", "no harm done. it gave us a tiny mystery."),
    ("2026-08-30T04:57:31.995120+00:00", "Mystery solved.", "and with remarkably little detective work. impressive."),
    ("2026-08-30T04:58:00.313009+00:00", "I'm going to go now, Mako.", "okay. goodnight, you. try not to crash anything without me."),
    ("2026-08-30T04:58:13.447639+00:00", "I will try not to see you later.", "see you later. i'll hold you to that."),
]


def latest_call_session(database: Path, limit: int) -> list[tuple[str, str, str]]:
    connection = sqlite3.connect(database)
    try:
        rows = connection.execute(
            "SELECT created_at, user_text, mako_text FROM episodes "
            "WHERE mode = 'call' ORDER BY created_at DESC LIMIT 100"
        ).fetchall()
    finally:
        connection.close()
    rows.reverse()
    if not rows:
        raise RuntimeError(f"No call transcript in {database}")

    # A two-minute silence defines a new call. The latest session contains the
    # STT correction and context-repair sequence used as this benchmark corpus.
    start = len(rows) - 1
    for index in range(len(rows) - 1, 0, -1):
        current = datetime.fromisoformat(rows[index][0])
        previous = datetime.fromisoformat(rows[index - 1][0])
        if (current - previous).total_seconds() > 120:
            break
        start = index - 1
    session = rows[start:]
    return session[-limit:]


def response_payload(text: str) -> dict[str, object]:
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return {"text": text.strip(), "expression": "invalid", "acting": {}}
    return data if isinstance(data, dict) else {"text": text.strip(), "expression": "invalid", "acting": {}}


def replay(
    *,
    backend: CodexAppServerBackend,
    dialogue: DialogueManager,
    session: list[tuple[str, str, str]],
    model: str,
    effort: str,
) -> list[dict[str, object]]:
    history: list[tuple[str, str, str]] = []
    results: list[dict[str, object]] = []
    for created_at, user_text, recorded_reply in session:
        event = ConversationEvent(
            content=user_text,
            source=EventSource.VOICE_CALL,
            mode=InteractionMode.CALL,
            visibility=Visibility.PRIVATE,
            user_id="owner",
            display_name="Moffle",
            channel_id="desktop",
            created_at=created_at,
        )
        dynamic_prompt = dialogue._generation_prompt(
            event=event,
            history=history,
            memories=[],
            mood_summary="Current private emotional tendencies: use the established tone of the supplied conversation.",
            semantic_guidance="",
            lessons=[],
            rejected=[],
            private_feedback="",
            exhausted_topics=set(),
            forbidden_topics=set(),
            history_as_messages=True,
            recent_live_history=history[-2:],
        )
        messages = dialogue._cached_message_prefix(
            system=CALL_GENERATE_SYSTEM,
            history=history,
            dynamic_prompt=dynamic_prompt,
            history_limit=len(history),
        )
        generation = backend.generate(
            messages=messages,
            model=model,
            max_tokens=dialogue.config.model.call_max_output_tokens,
            json_schema=CALL_RESPONSE_SCHEMA,
            reasoning_effort=effort,
            timeout_seconds=45.0,
        )
        payload = response_payload(generation.text)
        results.append({
            "created_at": created_at,
            "user": user_text,
            "recorded_terra_reply": recorded_reply,
            "reply": str(payload.get("text", "")).strip(),
            "expression": payload.get("expression", "invalid"),
            "acting": payload.get("acting", {}),
            "latency_seconds": round(generation.elapsed_seconds, 3),
        })
        # Preserve the original context for both passes. This isolates the
        # reasoning-level variable instead of compounding divergent replies.
        history.append((user_text, recorded_reply, created_at))
    return results


def latency_summary(turns: list[dict[str, object]]) -> dict[str, float]:
    values = [float(turn["latency_seconds"]) for turn in turns]
    return {
        "average_latency_seconds": round(statistics.mean(values), 3),
        "median_latency_seconds": round(statistics.median(values), 3),
        "minimum_latency_seconds": round(min(values), 3),
        "maximum_latency_seconds": round(max(values), 3),
    }


def resolve_codex_executable(configured: str) -> str:
    """Use the current Desktop-installed CLI even after a Codex self-update."""
    configured_path = Path(configured)
    if configured_path.is_file():
        return str(configured_path)
    on_path = shutil.which("codex")
    if on_path:
        return on_path
    local_app_data = os.environ.get("LOCALAPPDATA")
    if local_app_data:
        candidates = list((Path(local_app_data) / "OpenAI" / "Codex" / "bin").glob("*/codex.exe"))
        if candidates:
            return str(max(candidates, key=lambda item: item.stat().st_mtime))
    raise RuntimeError("Codex CLI was not found. Reinstall or open Codex Desktop once, then retry.")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--database", type=Path, help="Optional alternate memory database; omitted uses the fixed real-call corpus.")
    parser.add_argument("--limit", type=int, default=20)
    parser.add_argument("--model", default="gpt-5.6-terra")
    parser.add_argument("--efforts", nargs="+", default=["medium", "low"])
    parser.add_argument("--out", type=Path, default=Path("call_terra_reasoning_benchmark.json"))
    args = parser.parse_args()

    session = latest_call_session(args.database, args.limit) if args.database else CORPUS[-args.limit :]
    config = load_config(PROJECT_ROOT / "config.json")
    config.model.primary = args.model
    config.model.call_model = args.model
    config.model.codex_executable = resolve_codex_executable(config.model.codex_executable)
    backend = CodexAppServerBackend(config.model)
    dialogue = DialogueManager(config, backend, ledger=None)
    try:
        by_effort = {
            effort: replay(backend=backend, dialogue=dialogue, session=session, model=args.model, effort=effort)
            for effort in args.efforts
        }
    finally:
        backend.close()

    payload = {
        "model": args.model,
        "corpus": "latest contiguous live call: STT ambiguity, correction, context repair, interruption, and close",
        "turns": len(session),
        "note": "Both passes receive identical recorded history. Judge quality from the paired replies; this script does not mutate live memory.",
        "results": {effort: {"latency": latency_summary(turns), "turns": turns} for effort, turns in by_effort.items()},
    }
    args.out.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    for effort, turns in by_effort.items():
        print(f"{effort}: {json.dumps(latency_summary(turns))}")
    print(f"Wrote {args.out.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
