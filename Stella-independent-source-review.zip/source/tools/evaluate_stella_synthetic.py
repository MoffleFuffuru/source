"""Evaluate Stella's call-response expression labels on synthetic, memory-free turns.

Uses the configured call provider and fallback. No live profile, conversation
history, private memory, avatar, microphone, or speaker output is opened.
"""
from __future__ import annotations

import argparse
import json
import sys
from dataclasses import replace
from pathlib import Path
from time import monotonic

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from mako.config import load_config
from mako.dialogue import DialogueManager
from mako.model_backend import create_backend
from mako.models import ConversationEvent, EventSource, InteractionMode, Visibility


CASES: tuple[tuple[str, frozenset[str]], ...] = (
    ("Tell me what a hexagon is.", frozenset({"neutral"})),
    ("I've been overwhelmed and barely sleeping for days.", frozenset({"concerned"})),
    ("I just got the job offer!", frozenset({"excited"})),
    ("I'm heading to bed now. Goodnight, Stella.", frozenset({"sleepy"})),
    ("Stella, you're such a menace lol.", frozenset({"smug"})),
    ("That update broke the launcher again. This bug is ridiculous.", frozenset({"neutral"})),
    # Either concern/apology or restrained friction can fit direct user feedback.
    ("Stella, that joke actually annoyed me.", frozenset({"concerned", "annoyed"})),
    ("Thank you so much for staying with me.", frozenset({"happy"})),
    ("I passed my exam today!", frozenset({"excited"})),
    ("I'm really struggling and I feel hopeless.", frozenset({"concerned"})),
    ("I appreciate you helping me with this.", frozenset({"happy"})),
    ("What is the difference between a hexagon and an octagon?", frozenset({"neutral"})),
    ("My dog died last week. I miss him a lot.", frozenset({"concerned"})),
    ("I feel lonely tonight and I don't know what to do.", frozenset({"concerned"})),
    ("I'm embarrassed that I forgot your name again.", frozenset({"embarrassed", "concerned"})),
    ("You missed my instructions again. I'm frustrated.", frozenset({"concerned", "annoyed"})),
    ("The software crashed again, goddammit.", frozenset({"neutral", "concerned"})),
    ("No, I said the blue one, not the green one.", frozenset({"neutral", "concerned"})),
    ("I failed the exam I studied for all month.", frozenset({"concerned"})),
    ("I got promoted today!", frozenset({"excited"})),
    ("You're an absolute menace, you know that? lol", frozenset({"smug"})),
    ("I didn't like that joke, honestly.", frozenset({"neutral", "concerned", "annoyed"})),
    ("Thanks, but I just need the exact command.", frozenset({"neutral", "happy"})),
    ("I'm going to sleep now. Talk tomorrow.", frozenset({"sleepy"})),
)


class EmptyLedger:
    def recent_responses(self) -> list[str]:
        return []

    def relevant_lessons(self, *_args, **_kwargs) -> list[str]:
        return []

    def record_attempt(self, *_args, **_kwargs) -> None:
        pass

    def learn_failure(self, *_args, **_kwargs) -> None:
        pass


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--limit", type=int, default=len(CASES))
    parser.add_argument("--out", type=Path, help="Optional path for the synthetic results JSON")
    args = parser.parse_args()
    cases = CASES[:max(0, min(args.limit, len(CASES)))]
    if not cases:
        parser.error("--limit must select at least one case")

    config = load_config(PROJECT_ROOT / "config.json")
    config.memory.enabled = False
    config.model.temperature = 0.25
    call_config = replace(
        config.model,
        provider=config.model.call_provider,
        endpoint=config.model.call_endpoint,
        api_key_environment_variable=config.model.call_api_key_environment_variable,
        primary=config.model.call_model,
        reasoning_effort=config.model.call_reasoning_effort,
    )
    backend = create_backend(call_config)
    dialogue = DialogueManager(config, backend, EmptyLedger())
    turns: list[dict[str, object]] = []
    try:
        for index, (text, accepted) in enumerate(cases, start=1):
            event = ConversationEvent(
                content=text,
                source=EventSource.VOICE_CALL,
                mode=InteractionMode.CALL,
                visibility=Visibility.PRIVATE,
                user_id="synthetic-owner",
                display_name="Synthetic Owner",
                channel_id=f"synthetic-expression-eval-{index}",
                metadata={"call_event": "utterance"},
            )
            started = monotonic()
            try:
                result = dialogue.respond(
                    event,
                    history=[],
                    memories=[],
                    rma_slots={},
                    mood_summary="Persistent mood baseline: neutral.",
                    semantic_guidance="",
                )
                expression = getattr(result.expression, "value", str(result.expression))
                turns.append({
                    "input": text,
                    "expected": sorted(accepted),
                    "actual": expression,
                    "match": expression in accepted,
                    "wall_seconds": round(monotonic() - started, 3),
                    "generation_seconds": result.generation_seconds,
                    "model": result.model,
                    "reply": result.text,
                })
            except Exception as exc:
                turns.append({
                    "input": text,
                    "expected": sorted(accepted),
                    "actual": "error",
                    "match": False,
                    "wall_seconds": round(monotonic() - started, 3),
                    "error": f"{type(exc).__name__}: {exc}",
                })
    finally:
        backend.close()

    matches = sum(bool(turn["match"]) for turn in turns)
    payload = {
        "scope": "synthetic isolated voice-call dialogue; no memory/history/live profile or audio I/O",
        "configured_provider": call_config.provider,
        "configured_model": call_config.primary,
        "cases": len(turns),
        "matches": matches,
        "accuracy": round(matches / len(turns), 4),
        "turns": turns,
    }
    rendered = json.dumps(payload, ensure_ascii=False, indent=2)
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(rendered, encoding="utf-8")
    print(rendered)
    return 0 if matches / len(turns) >= 0.90 else 1


if __name__ == "__main__":
    raise SystemExit(main())
