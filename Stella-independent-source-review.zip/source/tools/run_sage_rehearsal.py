"""Replay the prepared seven-minute chat locally; never posts to a real platform."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import time
from urllib.error import HTTPError
from urllib.request import Request, build_opener, ProxyHandler
from uuid import uuid4


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--text-only', action='store_true')
    parser.add_argument('--validate-only', action='store_true')
    args = parser.parse_args()
    fixture = Path(__file__).with_name('sage_rehearsal_7min.json')
    plan = json.loads(fixture.read_text(encoding='utf-8'))
    assert 300 <= plan['duration_seconds'] <= 600
    assert all(0 <= row['at'] < plan['duration_seconds'] for row in plan['messages'])
    if args.validate_only:
        print(f"Prepared {len(plan['messages'])} messages across {len(plan['phases'])} phases, {plan['duration_seconds']} seconds.")
        return
    key = os.environ.get('STELLA_SAGE_EVENT_KEY', '')
    if not key and os.name == 'nt':
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, 'Environment') as registry:
                key = str(winreg.QueryValueEx(registry, 'STELLA_SAGE_EVENT_KEY')[0])
        except OSError:
            pass
    if not key:
        raise SystemExit('Run tools/Initialize-SageEvents.ps1 first. The secret is never printed.')
    opener = build_opener(ProxyHandler({}))
    def api(route, data=None):
        request = Request('http://127.0.0.1:39541' + route,
            data=None if data is None else json.dumps(data).encode(),
            headers={'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'})
        with opener.open(request, timeout=5) as response:
            return json.load(response)
    state = api('/api/state')
    if state.get('call_active'):
        raise SystemExit('End the private app call before the public rehearsal.')
    if not state.get('sage', {}).get('enabled'):
        raise SystemExit('Enable SAGE before starting the rehearsal.')
    previous = state['sage']
    run_id = uuid4().hex[:10]
    report = fixture.parent.parent / 'data' / ('sage-rehearsal-' + run_id + '.jsonl')
    report.parent.mkdir(exist_ok=True)
    cursor = api('/api/events?after=0')['last']
    try:
        active = api('/api/sage/control', {'action': 'simulation_start', 'voice': not args.text_only})
    except HTTPError as error:
        if error.code == 400:
            raise SystemExit('Restart Stella to load isolated rehearsal mode, then run this again.')
        raise
    scope = active['stream_scope']
    schedule = [(row['at'], 'phase', row) for row in plan['phases']]
    schedule += [(row['at'], 'chat', row) for row in plan['messages']]
    schedule.sort(key=lambda row: row[0])
    start = time.monotonic()
    sent = 0
    replies = 0
    print('REHEARSAL STARTED: 7 minutes; local simulated viewers; no real-memory commits.', flush=True)
    try:
        with report.open('w', encoding='utf-8') as output:
            def record(kind, data):
                entry = {'elapsed': round(time.monotonic()-start, 3), 'kind': kind, **data}
                output.write(json.dumps(entry, ensure_ascii=False) + '\n')
                output.flush()
                print(json.dumps(entry, ensure_ascii=True), flush=True)
            while time.monotonic() - start < plan['duration_seconds']:
                now = time.monotonic() - start
                status = api('/api/sage')
                if status['stream_scope'] != scope or not status['enabled']:
                    record('stopped', {'reason': 'operator stopped or changed the session'})
                    break
                while schedule and schedule[0][0] <= now:
                    _, kind, row = schedule.pop(0)
                    phase = kind == 'phase'
                    actor = 'director' if phase else row['actor']
                    text = 'Rehearsal phase: ' + row['name'] if phase else row['text']
                    payload = {'id': f'sim:{run_id}:{sent}', 'actor_id': 'sim:' + actor,
                        'name': 'Test Director' if phase else actor.title(),
                        'kind': 'event' if phase else 'chat', 'text': text}
                    api('/api/sage/event', payload)
                    record(kind, payload)
                    sent += 1
                packet = api('/api/events?after=' + str(cursor))
                cursor = packet['last']
                for event in packet['events']:
                    if event['type'] in {'sage_stream_reply', 'sage_error'} and event['data'].get('scope') == scope:
                        record(event['type'], event['data'])
                        replies += event['type'] == 'sage_stream_reply'
                time.sleep(.5)
            record('complete', {'sent': sent, 'replies': replies, 'report': str(report)})
    finally:
        # Do not take over if the operator changed session/mode while we ran.
        try:
            status = api('/api/sage')
            if status['stream_scope'] == scope:
                api('/api/sage/control', {'action': 'stream_stop'})
                if previous.get('stream_active'):
                    api('/api/sage/control', {'action': 'stream_start', 'voice': previous.get('stream_voice', False)})
        except Exception as error:
            print('Could not restore prior stream state:', type(error).__name__, flush=True)


if __name__ == '__main__':
    main()
