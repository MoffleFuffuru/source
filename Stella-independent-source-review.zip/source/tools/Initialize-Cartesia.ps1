$ErrorActionPreference = 'Stop'
$secure = Read-Host 'Cartesia API key (hidden)' -AsSecureString
$key = [System.Net.NetworkCredential]::new('', $secure).Password.Trim()
if ([string]::IsNullOrWhiteSpace($key)) {
    throw 'No key entered. Nothing was changed.'
}
try {
    [Environment]::SetEnvironmentVariable('CARTESIA_API_KEY', $key, 'User')
    $env:CARTESIA_API_KEY = $key
    if ([string]::IsNullOrWhiteSpace([Environment]::GetEnvironmentVariable('CARTESIA_API_KEY', 'User'))) {
        throw 'Windows did not retain the user environment variable.'
    }
    Write-Host 'Cartesia key saved and verified present. Its value was not displayed.'
} finally {
    Remove-Variable key, secure -ErrorAction SilentlyContinue
}
