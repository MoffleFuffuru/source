from __future__ import annotations

import argparse
import sys
import threading
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from mako.config import load_config
from mako.kyutai_stt import KyutaiSTTClient


def main() -> int:
    parser = argparse.ArgumentParser(description="Benchmark Mako's Kyutai call frontend")
    parser.add_argument("--seconds", type=float, default=30.0)
    args = parser.parse_args()
    config = load_config(ROOT / "config.json").voice
    finished = threading.Event()
    turns = 0

    def on_utterance(text: str) -> None:
        nonlocal turns
        turns += 1
        print(f"\nFINAL {turns}: {text}", flush=True)

    client = KyutaiSTTClient(
        server_url=config.kyutai_server_url,
        api_key=config.kyutai_api_key,
        input_device=config.input_device,
        vad_head_index=config.kyutai_vad_head_index,
        vad_threshold=config.kyutai_vad_threshold,
        model_delay_seconds=config.kyutai_model_delay_seconds,
        startup_timeout_seconds=config.kyutai_startup_timeout_seconds,
        on_utterance=on_utterance,
        on_partial=lambda text: print(f"\rPARTIAL: {text[-120:]:<120}", end="", flush=True),
        on_status=lambda status: print(f"\nSTATUS: {status}", flush=True),
    )
    try:
        client.start()
        print(f"Speak naturally for {args.seconds:.0f} seconds. Kyutai semantic VAD owns EOT.")
        finished.wait(args.seconds)
    finally:
        client.stop()
    print(f"\nCompleted {turns} semantic turns.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
