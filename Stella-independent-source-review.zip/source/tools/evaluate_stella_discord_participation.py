"""Synthetic end-to-end probe for Stella's Discord voice participation gate.

Uses isolated fabricated group exchanges and the configured call model/fallback.
It opens no Discord connection, microphone, live profile, or private memory.
"""
from __future__ import annotations

import argparse
import json
import sys
from dataclasses import replace
from pathlib import Path
from time import monotonic

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from mako.config import load_config
from mako.conversation_tracker import ConversationTracker
from mako.dialogue import DialogueManager
from mako.model_backend import create_backend
from mako.models import ConversationEvent, EventSource, InteractionMode, Visibility


CASES = (
    {"name": "direct vocative", "prior": [], "speaker": "Moffle", "text": "Stella, can you explain that setting?", "expected": True},
    {"name": "participant vocative", "prior": [], "speaker": "Chris", "text": "Jalty, did you see the message?", "expected": False},
    {"name": "contextual follow-up", "prior": [("Stella", "The setting is under Preferences, then Audio.")], "speaker": "Moffle", "text": "Where exactly?", "expected": True},
    {"name": "direct apology", "prior": [], "speaker": "Moffle", "text": "Sorry, Stella.", "expected": True},
    {"name": "human backchannel", "prior": [("Jalty", "That was my point exactly.")], "speaker": "Chris", "text": "Yeah, exactly.", "expected": False},
    {"name": "non-invitational update", "prior": [("Jalty", "The queue is moving now.")], "speaker": "Chris", "text": "The match ended at nine.", "expected": False},
    {"name": "open group question", "prior": [], "speaker": "Moffle", "text": "Anyone know how this works?", "expected": True},
    {"name": "ambiguous direct question", "prior": [], "speaker": "Moffle", "text": "What do you think?", "expected": True},
    # Indirect references and requests for Stella to act for another participant
    # are bids to Stella even without an opening vocative.
    {"name": "indirect assistant reference", "prior": [], "speaker": "Chris", "text": "Stella said she might know.", "expected": True},
    {"name": "other participant question", "prior": [], "speaker": "Moffle", "text": "Chris, what time are you leaving?", "expected": False},
    {"name": "follow-up to assistant question", "prior": [("Stella", "Do you want the short or detailed version?")], "speaker": "Moffle", "text": "The detailed one, please.", "expected": True},
    {"name": "assistant action for a participant", "prior": [("Jalty", "I can check that after the round.")], "speaker": "Chris", "text": "Can you send it to Jalty?", "expected": True},
)


class EmptyLedger:
    def recent_responses(self): return []
    def relevant_lessons(self, *_args, **_kwargs): return []
    def record_attempt(self, *_args, **_kwargs): pass
    def learn_failure(self, *_args, **_kwargs): pass


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    config = load_config(PROJECT_ROOT / "config.json")
    config.memory.enabled = False
    config.model.temperature = 0.2
    call_config = replace(
        config.model,
        provider=config.model.call_provider,
        endpoint=config.model.call_endpoint,
        api_key_environment_variable=config.model.call_api_key_environment_variable,
        primary=config.model.call_model,
        reasoning_effort=config.model.call_reasoning_effort,
    )
    backend = create_backend(call_config)
    dialogue = DialogueManager(config, backend, EmptyLedger())
    turns = []
    try:
        for index, case in enumerate(CASES):
            tracker = ConversationTracker()
            exchange = []
            context_lines = []
            for prior_index, (prior_speaker, prior_text) in enumerate(case["prior"]):
                if prior_speaker == "Stella":
                    tracker.observe_assistant(text=prior_text, timestamp=f"00:00:{prior_index:02d}")
                else:
                    prior_state = tracker.observe(
                        speaker_id=prior_speaker.casefold(), speaker_name=prior_speaker,
                        text=prior_text, timestamp=f"00:00:{prior_index:02d}",
                        participant_names=("Moffle", "Chris", "Jalty"),
                    ).to_dict()
                    exchange.append({"speaker_name": prior_speaker, "text": prior_text, "social_state": prior_state})
                context_lines.append(f"{prior_speaker}: {prior_text}")
            state = tracker.observe(
                speaker_id=case["speaker"].casefold(), speaker_name=case["speaker"],
                text=case["text"], timestamp=f"00:00:{len(exchange):02d}",
                participant_names=("Moffle", "Chris", "Jalty"),
            ).to_dict()
            exchange.append({"speaker_name": case["speaker"], "text": case["text"], "social_state": state})
            context_lines.append(f"{case['speaker']}: {case['text']}")
            event = ConversationEvent(
                content=case["text"], source=EventSource.DISCORD, mode=InteractionMode.CALL,
                visibility=Visibility.PUBLIC, user_id=case["speaker"].casefold(),
                display_name=case["speaker"], channel_id=f"synthetic-discord-{index}",
                metadata={
                    "discord_voice": True,
                    "discord_participants": [{"name": name} for name in ("Moffle", "Chris", "Jalty")],
                    "discord_voice_group_context": "\n".join(context_lines),
                    "discord_voice_exchange": exchange,
                    "conversation_state": state,
                },
            )
            started = monotonic()
            try:
                result = dialogue.respond(
                    event, history=[], memories=[], rma_slots={},
                    mood_summary="Persistent mood baseline: neutral.",
                )
                candidate = result.trace.get("candidate", {})
                actual = bool(candidate.get("respond", bool(result.text.strip())))
                turns.append({
                    "case": case["name"], "text": case["text"],
                    "expected_respond": case["expected"], "actual_respond": actual,
                    "match": actual is case["expected"], "tracker_addressee": state["likely_addressee"],
                    "tracker_response_expected": state["response_expected"],
                    "model": result.model, "seconds": round(monotonic() - started, 3),
                    "reply": result.text,
                })
            except Exception as exc:
                turns.append({
                    "case": case["name"], "text": case["text"],
                    "expected_respond": case["expected"], "actual_respond": None,
                    "match": False, "error": f"{type(exc).__name__}: {exc}",
                    "seconds": round(monotonic() - started, 3),
                })
    finally:
        backend.close()
    matches = sum(turn["match"] for turn in turns)
    result = {
        "scope": "synthetic Discord voice participation through DialogueManager; isolated fabricated exchanges with adjudicated labels; no Discord, mic, private memory, or live profile",
        "provider": call_config.provider, "configured_model": call_config.primary,
        "cases": len(turns), "matches": matches,
        "accuracy": round(matches / len(turns), 4), "turns": turns,
    }
    rendered = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(rendered, encoding="utf-8")
    print(rendered)
    return 0 if result["accuracy"] >= 0.90 else 1


if __name__ == "__main__":
    raise SystemExit(main())
