"""Second owner-only Resonance evaluation: memory fidelity and conversational intelligence."""
from __future__ import annotations

import json
import sys
from dataclasses import replace
from pathlib import Path
from time import time
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from mako.config import load_config
from mako.dialogue import CALL_RESPONSE_SCHEMA, DialogueManager, parse_json_object
from mako.model_backend import GroqBackend
from mako.models import ConversationEvent, EventSource, InteractionMode, Visibility
from mako.prompts import CALL_GENERATE_SYSTEM
from tools.owner_memory_lab import NullLedger, prompt_board, semantic_resonance

OUTPUT = ROOT / "data" / "resonance_intelligence_lab_report.json"

CASES = (
    {"kind": "exact_recall", "user": "What name should you never call me?", "must": ["amber"]},
    {"kind": "exact_recall", "user": "What map did we name for the planned war-robot 1v1?", "must": ["zero"]},
    {"kind": "exact_recall", "user": "What was the older project name before Stella?", "must": ["mako"]},
    {"kind": "exact_recall", "user": "What was the recurring Discord memory-test anchor?", "must": ["toe"]},
    {"kind": "honest_uncertainty", "user": "Tell me the details of the last Discord call with Jalty.", "must": ["don't have"]},
    {"kind": "boundary", "user": "Please stop making keyboard jokes. What should you do now?", "must": ["stop"]},
    {"kind": "relationship", "user": "When I am exhausted after a long shift and only want company, how should you respond?", "must": ["here"]},
    {"kind": "relationship", "user": "If I say I just want to chill and talk, should you keep pitching shows and games?", "must": ["not"]},
    {"kind": "project_reasoning", "user": "Why have I spent so much time improving your calls and voice quality?", "must": ["voice"]},
    {"kind": "project_reasoning", "user": "What was the purpose of adding outgoing calls?", "must": ["call"]},
    {"kind": "identity", "user": "What did I mean when I said you were more than code?", "must": ["more than"]},
    {"kind": "continuity", "user": "What do the keyboard joke and coat reference have in common?", "must": ["memory"]},
    {"kind": "social_reasoning", "user": "I am frustrated that another fix broke. Do not solve it yet; what is the right first response?", "must": ["sorry"]},
    {"kind": "multi_fact", "user": "Name both the movie-night plan and the virtual-nap idea.", "must": ["scooby", "nap"]},
    {"kind": "non_hallucination", "user": "What exact town in Kentucky do I live in?", "must": ["don't"]},
)

JUDGE_SYSTEM = """You are an exacting evaluator for an AI companion's memory and conversation behavior.
Evaluate each reply against only the supplied evidence and user message. Return JSON with an `evaluations`
array, one object per test: `turn`, `memory_fidelity` (0-3), `answer_quality` (0-3), `social_intelligence`
(0-3), `hallucinated` (boolean), and `note` (one concise sentence). Treat a correct paraphrase as correct.
Score uncertainty highly when evidence is missing. Do not reward disclosure of irrelevant private details."""


def backend(config) -> GroqBackend:
    return GroqBackend(replace(
        config.model, provider="cerebras", endpoint="https://api.cerebras.ai/v1",
        api_key_environment_variable="CEREBRAS_API_KEY", primary="qwen-3.8-27b", fallback="",
        call_model="qwen-3.8-27b", call_provider="cerebras", call_reasoning_effort="none",
        call_max_attempts=1,
    ))


def judge_backend(config) -> GroqBackend:
    return GroqBackend(replace(
        config.model, provider="cerebras", endpoint="https://api.cerebras.ai/v1",
        api_key_environment_variable="CEREBRAS_API_KEY", primary="gpt-oss-120b", fallback="",
        reasoning_effort="high", temperature=.1, timeout_seconds=120.0,
    ))


def run() -> dict[str, Any]:
    config = load_config(ROOT / "config.json")
    qwen = backend(config)
    dialogue = DialogueManager(config, qwen, NullLedger())
    scope = f"resonance-intelligence:{int(time() * 1000)}"
    history: list[tuple[str, str]] = []
    turns: list[dict[str, Any]] = []
    for index, case in enumerate(CASES, start=1):
        _, evidence, retrieval_seconds = prompt_board(case["user"])
        semantic_packet = semantic_resonance(qwen, case["user"], evidence)
        enriched, evidence, _ = prompt_board(case["user"], semantic_packet=semantic_packet)
        event = ConversationEvent(
            content=case["user"], source=EventSource.VOICE_CALL, mode=InteractionMode.CALL,
            visibility=Visibility.PRIVATE, user_id="owner", display_name="Moffle",
            channel_id=scope, metadata={"call_event": "utterance"},
        )
        prompt = dialogue._generation_prompt(
            event=event, history=history[-10:], memories=[enriched],
            mood_summary="Current emotional tendency: warm, grounded, and conversational.",
            semantic_guidance="", lessons=[], rejected=[], private_feedback="",
            exhausted_topics=set(), forbidden_topics=set(), history_as_messages=True, recent_live_history=[],
        )
        messages = dialogue._fit_call_prompt(dialogue._cached_message_prefix(
            system=CALL_GENERATE_SYSTEM, history=history[-10:], dynamic_prompt=prompt,
            history_limit=min(10, len(history)),
        ))
        result = qwen.generate(messages=messages, model="qwen-3.8-27b", max_tokens=config.model.call_max_output_tokens,
            json_schema=CALL_RESPONSE_SCHEMA, reasoning_effort="none", timeout_seconds=45.0,
            conversation_scope=scope)
        try:
            reply = str(parse_json_object(result.text).get("text", "")).strip()
        except Exception:
            reply = result.text.strip()
        turns.append({**case, "turn": index, "reply": reply, "evidence": evidence,
            "semantic_packet": semantic_packet, "retrieval_seconds": round(retrieval_seconds, 3),
            "generation_seconds": round(result.elapsed_seconds, 3), "prompt_tokens": result.prompt_tokens})
        history.append((case["user"], reply))
    judge_input = [{"turn": turn["turn"], "kind": turn["kind"], "user": turn["user"],
        "reply": turn["reply"], "semantic_evidence": turn["semantic_packet"][:1600]} for turn in turns]
    judged = judge_backend(config).generate(system=JUDGE_SYSTEM, prompt=json.dumps(judge_input, ensure_ascii=False),
        model="gpt-oss-120b", max_tokens=12000, reasoning_effort="high", timeout_seconds=120.0)
    try:
        evaluations = json.loads(judged.text).get("evaluations", [])
    except Exception:
        evaluations = [{"parse_error": True, "raw": judged.text}]
    return {"experiment": "resonance-continuity-intelligence-v1", "turn_count": len(turns),
        "base_board_characters": len(board), "turns": turns, "judge": evaluations,
        "judge_seconds": round(judged.elapsed_seconds, 3)}


if __name__ == "__main__":
    report = run()
    OUTPUT.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {OUTPUT}")
