"""Fetch pinned Rocketbox VRMA conversions and preserve their source notices."""
from __future__ import annotations

import hashlib
import json
import struct
from pathlib import Path

import requests


ROOT = Path(__file__).resolve().parents[1]
REV = "6787685c8d40e4e79bffbb0d389b478f32ef88d6"
BASE = f"https://raw.githubusercontent.com/Undi95/Hanami/{REV}/"
DEST = ROOT / "avatar" / "assets" / "movement"


def main() -> None:
    DEST.mkdir(parents=True, exist_ok=True)
    session = requests.Session()
    response = session.get(f"https://api.github.com/repos/Undi95/Hanami/git/trees/{REV}?recursive=1", timeout=30)
    response.raise_for_status()
    files = [row["path"] for row in response.json()["tree"] if row["path"].startswith("vrma/rb-") and row["path"].endswith(".vrma")]
    report = []
    for source in files + ["vrma/NOTICE.md", "scripts/rocketbox-plan.json"]:
        response = session.get(BASE + source, timeout=30)
        response.raise_for_status()
        payload = response.content
        entry = {"file": Path(source).name, "source": BASE + source, "sha256": hashlib.sha256(payload).hexdigest(), "bytes": len(payload)}
        if source.endswith(".vrma"):
            if payload[:4] != b"glTF":
                raise ValueError(f"Not a GLB: {source}")
            length = struct.unpack_from("<I", payload, 12)[0]
            data = json.loads(payload[20:20 + length])
            animations = data.get("animations", [])
            entry["tracks"] = len(animations[0]["channels"])
            entry["seconds"] = max(data["accessors"][s["input"]].get("max", [0])[0] for s in animations[0]["samplers"])
            entry["finger_tracks"] = sum("finger" in data["nodes"][c["target"]["node"]].get("name", "").lower() or any(n in data["nodes"][c["target"]["node"]].get("name", "").lower() for n in ("index", "thumb", "middle", "ring", "little")) for c in animations[0]["channels"])
        (DEST / Path(source).name).write_bytes(payload)
        report.append(entry)
    response = session.get("https://raw.githubusercontent.com/microsoft/Microsoft-Rocketbox/0943055db6ec570bcef9f2c8b41c9e5467c808f9/LICENSE.md", timeout=30)
    response.raise_for_status()
    (DEST / "ROCKETBOX-LICENSE.md").write_bytes(response.content)
    (DEST / "sources.json").write_text(json.dumps({"revision": REV, "files": report}, indent=2), encoding="utf-8")
    print(json.dumps({"clips": len(files), "bytes": sum(r["bytes"] for r in report), "tracks": sorted({r["tracks"] for r in report if "tracks" in r}), "finger_tracks": sorted({r["finger_tracks"] for r in report if "finger_tracks" in r})}))


if __name__ == "__main__":
    main()
