"""Replay historical memory questions through Resonance and compare old vs current replies."""
from __future__ import annotations

import json
import sys
from dataclasses import replace
from pathlib import Path
from time import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from mako.config import load_config
from mako.dialogue import CALL_RESPONSE_SCHEMA, DialogueManager, parse_json_object
from mako.model_backend import GroqBackend
from mako.models import ConversationEvent, EventSource, InteractionMode, Visibility
from mako.prompts import CALL_GENERATE_SYSTEM
from tools.owner_memory_lab import NullLedger, prompt_board, semantic_resonance

INVENTORY = ROOT / "data" / "resonance_memory_regression_inventory.json"
OUTPUT = ROOT / "data" / "resonance_memory_regression_report.json"
JUDGE = """You compare historical and current AI-companion replies to memory questions. Judge only supplied
archive evidence. Return JSON: {"evaluations":[{"turn":int,"historical_memory":0-3,"current_memory":0-3,
"historical_intelligence":0-3,"current_intelligence":0-3,"winner":"historical|current|tie","note":string}]}.
Reward exact evidence, useful uncertainty, and following the user's actual request. Penalize invented details."""


def make_backend(config, model: str, effort: str) -> GroqBackend:
    return GroqBackend(replace(config.model, provider="cerebras", endpoint="https://api.cerebras.ai/v1",
        api_key_environment_variable="CEREBRAS_API_KEY", primary=model, fallback="", call_model=model,
        call_provider="cerebras", call_reasoning_effort=effort, reasoning_effort=effort,
        call_max_attempts=1, timeout_seconds=120.0))


def main() -> None:
    config = load_config(ROOT / "config.json")
    cases = json.loads(INVENTORY.read_text(encoding="utf-8"))["performance_set"]
    qwen = make_backend(config, "qwen-3.8-27b", "none")
    dialogue = DialogueManager(config, qwen, NullLedger())
    scope, history, turns = f"resonance-regression:{int(time() * 1000)}", [], []
    for index, case in enumerate(cases, 1):
        question = case["question"]
        _, evidence, retrieval = prompt_board(question)
        semantic = semantic_resonance(qwen, question, evidence)
        enriched, _, _ = prompt_board(question, semantic_packet=semantic)
        event = ConversationEvent(content=question, source=EventSource.VOICE_CALL, mode=InteractionMode.CALL,
            visibility=Visibility.PRIVATE, user_id="owner", display_name="Moffle", channel_id=scope,
            metadata={"call_event":"utterance"})
        prompt = dialogue._generation_prompt(event=event, history=history[-10:], memories=[enriched],
            mood_summary="Current emotional tendency: warm, grounded, and conversational.", semantic_guidance="",
            lessons=[], rejected=[], private_feedback="", exhausted_topics=set(), forbidden_topics=set(),
            history_as_messages=True, recent_live_history=[])
        messages = dialogue._fit_call_prompt(dialogue._cached_message_prefix(system=CALL_GENERATE_SYSTEM,
            history=history[-10:], dynamic_prompt=prompt, history_limit=min(10, len(history))))
        generated = qwen.generate(messages=messages, model="qwen-3.8-27b", max_tokens=config.model.call_max_output_tokens,
            json_schema=CALL_RESPONSE_SCHEMA, reasoning_effort="none", timeout_seconds=45.0, conversation_scope=scope)
        try: current = str(parse_json_object(generated.text).get("text", "")).strip()
        except Exception: current = generated.text.strip()
        turn = {"turn":index,"question":question,"historical_answer":case["historical_answer"],
            "current_answer":current,"semantic_evidence":semantic,"generation_seconds":round(generated.elapsed_seconds,3),
            "retrieval_seconds":round(retrieval,3)}
        turns.append(turn); history.append((question,current))
    judge_backend = make_backend(config, "gpt-oss-120b", "high")
    evaluations=[]
    for start in range(0,len(turns),10):
        batch=[{"turn":t["turn"],"question":t["question"],"historical":t["historical_answer"],
            "current":t["current_answer"],"evidence":t["semantic_evidence"][:1500]} for t in turns[start:start+10]]
        judged=judge_backend.generate(system=JUDGE,prompt=json.dumps(batch,ensure_ascii=False),model="gpt-oss-120b",
            max_tokens=10000,reasoning_effort="high",timeout_seconds=120.0)
        try: evaluations.extend(json.loads(judged.text).get("evaluations",[]))
        except Exception: evaluations.append({"parse_error":True,"raw":judged.text})
    report={"experiment":"resonance-historical-memory-regression-v1","turn_count":len(turns),"turns":turns,"evaluations":evaluations}
    OUTPUT.write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding="utf-8")
    print(f"Wrote {OUTPUT}")


if __name__ == "__main__": main()
