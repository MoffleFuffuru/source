"""Measure a structured Resonance recall contract and one-pass Qwen completeness repair."""
from __future__ import annotations

import json
import re
import sys
from dataclasses import replace
from pathlib import Path
from time import perf_counter, time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from mako.config import load_config
from mako.dialogue import CALL_RESPONSE_SCHEMA, DialogueManager, parse_json_object
from mako.model_backend import GroqBackend
from mako.models import ConversationEvent, EventSource, InteractionMode, Visibility
from mako.prompts import CALL_GENERATE_SYSTEM
from tools.owner_memory_lab import NullLedger, prompt_board

OUTPUT = ROOT / "data" / "resonance_contract_probe.json"
CASES = (
    "what did i say i had done to stop my friend injecting more ideas?",
    "Name both the movie-night plan and the virtual-nap idea, including what the nap involved.",
    "mako, let me ask you a question, what do you remember about jalty?",
    "do you now remember the implementation plan i mentioned in the app?",
    "What map did we name for the planned war-robot 1v1?",
)
STOP = {"the", "a", "an", "and", "or", "to", "of", "in", "on", "with", "was", "were", "is", "are", "it", "you", "i"}


def words(text: str) -> set[str]:
    return {word for word in re.findall(r"[a-z0-9']+", text.lower()) if len(word) > 2 and word not in STOP}


def backend(config, model: str, effort: str) -> GroqBackend:
    return GroqBackend(replace(config.model, provider="cerebras", endpoint="https://api.cerebras.ai/v1",
        api_key_environment_variable="CEREBRAS_API_KEY", primary=model, fallback="", call_model=model,
        call_provider="cerebras", reasoning_effort=effort, call_reasoning_effort=effort,
        call_max_attempts=1, timeout_seconds=120.0))


def contract(oss: GroqBackend, question: str, evidence: list[dict[str, str]]) -> tuple[dict[str, object], float]:
    prompt = (
        "QUESTION:\n" + question + "\n\nRMA ARCHIVE EVIDENCE:\n"
        + "\n".join(f"[{item['source']}] {item['text']}" for item in evidence[:5])
        + "\n\nReturn ONLY JSON: {\"resolution\":[\"fact\"],\"required_facts\":[\"fact that must appear in answer\"],\"uncertainty\":\"\"}. "
          "Use 1-3 facts. Preserve names, actions, reasons, and temporal changes. If the archive is insufficient, "
          "put the exact limitation in uncertainty and required_facts."
    )
    started = perf_counter()
    result = oss.generate(system="You are Resonance Continuity's evidence-only memory contract resolver.", prompt=prompt,
        model="gpt-oss-120b", max_tokens=8000, json_output=True, reasoning_effort="high", timeout_seconds=120.0)
    try:
        data = json.loads(result.text)
    except Exception:
        data = {"resolution": [result.text], "required_facts": [], "uncertainty": ""}
    facts = data.get("required_facts", [])
    if not isinstance(facts, list):
        facts = []
    # Provenance belongs in resolution, not in the natural-language fact that
    # Qwen must say aloud and the validator must compare.
    data["required_facts"] = [
        re.sub(r"\s*(?:\[[^\]]+\]|\([^)]*source[^)]*\))\s*", " ", str(fact)).strip()
        for fact in facts
    ]
    return data, perf_counter() - started


def missing(reply: str, facts: list[str]) -> list[str]:
    reply_words = words(reply)
    result=[]
    for fact in facts:
        fact_words=words(fact)
        if fact_words and len(reply_words & fact_words) / len(fact_words) < .55:
            result.append(fact)
    return result


def generate(dialogue, model, config, scope, history, question, packet, repair=""):
    board = "ACTIVE RESONANCE CONTRACT - REQUIRED FACTS:\n" + "\n".join("- "+x for x in packet.get("required_facts",[]))
    board += "\nRESOLUTION:\n" + "\n".join("- "+x for x in packet.get("resolution",[]))
    if packet.get("uncertainty"): board += "\nUNCERTAINTY TO STATE: " + str(packet["uncertainty"])
    if repair: board += "\nREPAIR: Your prior draft omitted required memory evidence. Include this exact factual clause verbatim, then speak naturally: " + repair
    event=ConversationEvent(content=question,source=EventSource.VOICE_CALL,mode=InteractionMode.CALL,
        visibility=Visibility.PRIVATE,user_id="owner",display_name="Moffle",channel_id=scope,metadata={"call_event":"utterance"})
    prompt=dialogue._generation_prompt(event=event,history=history,memories=[board],
        mood_summary="Current emotional tendency: warm, grounded, and conversational.",semantic_guidance="",lessons=[],rejected=[],private_feedback="",exhausted_topics=set(),forbidden_topics=set(),history_as_messages=True,recent_live_history=[])
    messages=dialogue._fit_call_prompt(dialogue._cached_message_prefix(system=CALL_GENERATE_SYSTEM,history=history,dynamic_prompt=prompt,history_limit=len(history)))
    result=model.generate(messages=messages,model="qwen-3.8-27b",max_tokens=config.model.call_max_output_tokens,
        json_schema=CALL_RESPONSE_SCHEMA,reasoning_effort="none",timeout_seconds=45,conversation_scope=scope)
    try: return str(parse_json_object(result.text).get("text","")).strip(), result.elapsed_seconds
    except Exception: return result.text.strip(), result.elapsed_seconds


def main():
    config=load_config(ROOT / "config.json"); qwen=backend(config,"qwen-3.8-27b","none"); oss=backend(config,"gpt-oss-120b","high")
    dialogue=DialogueManager(config,qwen,NullLedger()); scope=f"contract:{int(time()*1000)}"; history=[]; turns=[]
    for question in CASES:
        _, evidence, lexical=prompt_board(question); packet, oss_seconds=contract(oss,question,evidence)
        draft,draft_seconds=generate(dialogue,qwen,config,scope,history,question,packet)
        gaps=missing(draft,[str(x) for x in packet.get("required_facts",[])])
        reply,repair_seconds=(draft,0.0)
        if gaps: reply,repair_seconds=generate(dialogue,qwen,config,scope,history,question,packet,"; ".join(gaps))
        turns.append({"question":question,"contract":packet,"lexical_seconds":round(lexical,3),"oss_seconds":round(oss_seconds,3),
            "draft":draft,"missing_before_repair":gaps,"reply":reply,"qwen_seconds":round(draft_seconds,3),"repair_seconds":round(repair_seconds,3)})
        history.append((question,reply))
    OUTPUT.write_text(json.dumps({"turns":turns},indent=2,ensure_ascii=False),encoding="utf-8")
    print(f"Wrote {OUTPUT}")


if __name__ == "__main__": main()
